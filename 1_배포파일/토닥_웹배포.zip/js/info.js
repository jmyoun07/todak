/* 정보 탭 — 06 정보(부작용 정보 · 음식·건강기능식품 · 자가관리 가이드) · 09 음식·건강기능식품 · 17 자가관리 가이드
   2026-09-28 교수님 말씀 반영. 이 세 화면만 이 파일을 부른다(.content[data-info] 가 없으면 아무 일도 하지 않는다).

   · 06 맨 위 네 칸(전체 / 부작용 정보 / 음식·건강기능식품 / 자가관리 가이드)은 라디오 + CSS 로 고른다
     — 스크립트가 없어도(시안 갤러리) 동작한다. 여기서는 칸을 바꾸면 맨 위로 올리고, 주소의 ?cat=se|food|self 로 칸을 고르게 한다.
   · '바로 가기'(.jump) 단추는 거르지 않는다. 누르면 그 상자 자리로 부드럽게 내려가고 도착한 상자 제목이 잠깐 빛난다.
     주소(#)를 바꾸지 않으므로 뒤로가기 기록이 쌓이지 않는다(스크립트가 없으면 보통 #이동으로 똑같이 간다).
     화면 위에 붙어 있는 칸(position:sticky)이 있으면 그 높이만큼 더 띄운다 — 지금 세 화면에는 없다.
   · 타일을 눌러 다른 화면에 갔다가 ‹(또는 휴대폰 뒤로가기)로 돌아오면, 고른 칸과 보던 자리를 되살린다.
     돌아왔는지는 '방금 연 화면(document.referrer)이 떠날 때 누른 화면과 같은가'로 본다 — 하단 탭 '정보'로 새로 열면 늘 '전체' 맨 위.
     기억은 이 앱을 연 동안만(sessionStorage, 화면마다 따로), 한 번 쓰면 지운다. 화면 이름·고른 칸·자리 말고는 아무것도 남기지 않는다.
   · 주소에 #상자 가 붙어 열리면(17 '건강기능식품 안전하게' → 09#s-supp) 글꼴이 다 그려진 뒤 그 자리로 다시 맞춘다.
   ES5 로만 쓴다. */
(function () {
  var doc = document;
  var content = doc.querySelector('.content[data-info]');
  if (!content) return;

  /* 화면 이름은 '.html' 을 뗀 꼴로 비교한다 — 웹앱(Netlify)은 주소에서 .html 을 떼어 낸다(/31-detail-nausea) */
  var PAGE = nameOf(location.pathname);
  var KEY = 'todak_info_back_' + PAGE;   /* 화면마다 따로 — 06 → 09 → 60 처럼 여러 번 들어가도 각자 돌아갈 자리를 지킨다 */
  var reduce = false;
  try { reduce = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e0) { reduce = false; }
  /* focus({preventScroll}) 를 아는 엔진인지 — 모르는 옛 웹뷰에서는 초점을 옮기면 부드러운 이동이 끊기므로 옮기지 않는다 */
  var PS = false;
  try { doc.createElement('div').focus({ get preventScroll() { PS = true; return true; } }); } catch (e1) { PS = false; }
  var SMOOTH = typeof content.scrollTo === 'function' && ('scrollBehavior' in doc.documentElement.style);

  function nameOf(u) { return String(u || '').split('#')[0].split('?')[0].split('/').pop().replace(/\.html$/i, ''); }
  /* 이 화면을 연 화면(?from=) — app.js FROM_BACK 과 같은 규칙(같은 폴더의 화면 파일명만) */
  function fromParam() {
    var m = /[?&]from=([^&#]*)/.exec(location.search || ''), v = '';
    try { v = m ? decodeURIComponent(m[1]) : ''; } catch (e) { v = ''; }
    return /^[0-9A-Za-z._-]+\.html$/.test(v) ? v : '';
  }
  function historyReturn() {
    try {
      var n = window.performance && performance.getEntriesByType ? performance.getEntriesByType('navigation') : [];
      if (n && n[0] && n[0].type === 'back_forward') return true;
      return !!(window.performance && performance.navigation && performance.navigation.type === 2);
    } catch (e) { return false; }
  }
  function load() { try { return JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
  function save(o) { try { if (o) sessionStorage.setItem(KEY, JSON.stringify(o)); else sessionStorage.removeItem(KEY); } catch (e) { /* 못 담아도 화면은 그대로 */ } }

  /* ── 06 맨 위 칸 (라디오) ── */
  var radios = [];
  (function () {
    var all = doc.querySelectorAll('input.flt-in[name="info"]');
    for (var i = 0; i < all.length; i++) radios.push(all[i]);
  })();
  function curCat() {
    for (var i = 0; i < radios.length; i++) if (radios[i].checked) return radios[i].id;
    return '';
  }
  function setCat(id) {
    for (var i = 0; i < radios.length; i++) {
      if (radios[i].id === id) { radios[i].checked = true; return true; }
    }
    return false;
  }
  /* 가려진 칸 안의 상자로 가야 하면 그 칸을 먼저 연다 */
  function reveal(el) {
    if (!radios.length) return;
    for (var p = el; p && p !== content; p = p.parentNode) {
      var c = p.getAttribute && p.getAttribute('data-cat');
      if (c) {
        var now = curCat();
        if (now !== 'info-all' && now !== 'info-' + c) setCat('info-' + c);
        return;
      }
    }
  }

  /* ── 자리 옮기기 ── */
  function stickyH() {
    var h = 0, kids = content.children;
    for (var i = 0; i < kids.length; i++) {
      var cs = window.getComputedStyle(kids[i]);
      if (cs.position === 'sticky' || cs.position === '-webkit-sticky') h += kids[i].offsetHeight;
    }
    return h;
  }
  function yOf(el) {
    var m = 0;
    try { m = parseFloat(window.getComputedStyle(el).scrollMarginTop) || 0; } catch (e) { m = 0; }
    var y = el.getBoundingClientRect().top - content.getBoundingClientRect().top + content.scrollTop - m - stickyH();
    var max = content.scrollHeight - content.clientHeight;
    if (y > max) y = max;
    return Math.max(0, Math.round(y));
  }
  function setY(y) {
    var sb = content.style.scrollBehavior;
    content.style.scrollBehavior = 'auto';
    content.scrollTop = y;
    content.style.scrollBehavior = sb;
  }
  function goTo(el, smooth) {
    var y = yOf(el);
    if (smooth && SMOOTH && !reduce) content.scrollTo({ top: y, behavior: 'smooth' });
    else setY(y);
  }
  function flash(el) {
    if (!el || !el.classList) return;
    el.classList.remove('is-arrive');
    void el.offsetWidth;                       /* 같은 단추를 다시 눌러도 또 빛나게 */
    el.classList.add('is-arrive');
    clearTimeout(el.__arrT);
    el.__arrT = setTimeout(function () { el.classList.remove('is-arrive'); }, 2000);
    var t = el.querySelector('.sec-t');
    if (t && PS) {                              /* 화면 읽기 프로그램이 도착한 상자 제목부터 읽게 */
      if (!t.hasAttribute('tabindex')) t.setAttribute('tabindex', '-1');
      try { t.focus({ preventScroll: true }); } catch (e) { /* 초점만 못 옮길 뿐 */ }
    }
  }
  function whenLaidOut(fn) {
    var done = 0;
    var run = function () { if (done++ < 2) fn(); };
    try { if (doc.fonts && doc.fonts.ready) doc.fonts.ready.then(run, run); } catch (e) { /* 글꼴 소식이 없으면 load 만 */ }
    if (doc.readyState === 'complete') setTimeout(run, 0);
    else window.addEventListener('load', run, false);
  }
  /* 목록을 그리는 뒤쪽 스크립트·글꼴 때문에 높이가 늦게 달라져도 같은 자리를 지킨다.
     마지막 적용이 끝난 뒤에만 저장값을 지운다 — 그 전에 지우면 bfcache pageshow 가 다시 살릴 근거가 없다. */
  function settleY(y, done) {
    var waits = [0, 40, 120, 300, 700], left = waits.length;
    function one() {
      setY(y);
      left--;
      if (!left && done) done();
    }
    for (var i = 0; i < waits.length; i++) setTimeout(one, waits[i]);
  }

  /* ── 누르기: 이동 단추 / 다른 화면으로 가는 타일 ── */
  function linkOf(t) {
    for (; t && t !== content && t !== doc; t = t.parentNode) {
      if (t.tagName === 'A') return t;
    }
    return null;
  }
  content.addEventListener('click', function (e) {
    var a = linkOf(e.target);
    if (!a) return;
    var h = a.getAttribute('href') || '';
    if (h.charAt(0) === '#') {
      var id = h.slice(1);
      try { id = decodeURIComponent(id); } catch (e2) { /* 그대로 */ }
      var tg = id ? doc.getElementById(id) : null;
      if (!tg || !content.contains(tg)) return;
      e.preventDefault();
      reveal(tg);
      goTo(tg, true);
      flash(tg);
      return;
    }
    if (/^[A-Za-z][A-Za-z0-9+.\-]*:/.test(h)) return;          /* tel: · 바깥 주소 — 돌아올 자리를 적지 않는다 */
    var to = nameOf(h);
    if (!/^[0-9A-Za-z_-]+$/.test(to) || to === PAGE) return;
    save({ p: PAGE, to: to, cat: curCat(), y: Math.round(content.scrollTop), from: fromParam(), t: new Date().getTime() });
  }, false);

  /* 맨 위 칸을 바꾸면 내용이 통째로 바뀌므로 맨 위에서 보여 준다 */
  for (var r = 0; r < radios.length; r++) {
    radios[r].addEventListener('change', function () { setY(0); }, false);
  }

  /* ── 열 때: 돌아온 것이면 되살리기 → 아니면 ?cat= → #상자 ── */
  function restore(fromCache) {
    var o = load();
    if (!o || o.p !== PAGE) return false;
    if (new Date().getTime() - (+o.t || 0) > 6 * 3600 * 1000) { save(null); return false; }
    /* 새 문서로 돌아온 때는 바로 전 상세 화면만 허용한다. bfcache 로 살아난 문서의 referrer 는
       이 화면에 처음 들어오기 전 주소 그대로라서 비교하면 늘 실패한다. persisted pageshow 자체가
       브라우저 기록으로 이 문서에 돌아왔다는 증거이므로 그때는 저장된 화면 이름을 믿는다. */
    if (!fromCache) {
      var ref = nameOf(doc.referrer);
      if (!ref || ref !== o.to) { save(null); return false; }
    }
    if (o.cat) setCat(o.cat);
    /* 상세 화면의 ‹ 는 '?from=' 없이 이 화면을 연다(06-sideeffects.html). 처음에 다른 화면에서 왔다면(06 → 09 → 60 → 09)
       그 '온 화면'을 주소에 되붙여, 여기서 한 번 더 ‹ 를 누르면 처음 온 화면(06)으로 간다.
       이 파일은 app.js 보다 먼저 돌아서, app.js(FROM_BACK)·native.js(휴대폰 뒤로가기)가 되붙인 주소를 그대로 읽는다. */
    if (o.from && !fromParam() && o.from !== PAGE + '.html' && window.history && history.replaceState) {
      try {
        var qs = location.search ? location.search + '&' : '?';
        history.replaceState(history.state, '', location.pathname + qs + 'from=' + encodeURIComponent(o.from) + location.hash);
      } catch (e4) { /* 주소를 못 고치면 ‹ 는 화면에 정해 둔 곳(홈)으로 간다 — 예전과 같다 */ }
    }
    var y = Math.max(0, +o.y || 0);
    setY(y);
    whenLaidOut(function () { setY(y); });
    settleY(y, function () { save(null); });
    return true;
  }
  if (!restore(historyReturn())) {
    var q = /[?&]cat=(se|food|self)(?:&|#|$)/.exec(location.search + location.hash);
    if (q) setCat('info-' + q[1]);
    var hid = (location.hash || '').slice(1);
    try { hid = decodeURIComponent(hid); } catch (e3) { /* 그대로 */ }
    var ht = hid ? doc.getElementById(hid) : null;
    if (ht && content.contains(ht)) {
      reveal(ht);
      goTo(ht, false);
      whenLaidOut(function () { goTo(ht, false); });
      flash(ht);
    }
  }

  /* 브라우저/웹뷰가 화면을 통째로 되살리는 경우에는 스크립트가 다시 돌지 않는다.
     custom scroller(.content)는 브라우저가 0으로 되돌릴 수 있으므로 pageshow 에서 직접 복원한다. */
  window.addEventListener('pageshow', function (ev) { if (ev && ev.persisted) restore(true); }, false);
})();
