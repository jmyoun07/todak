/* ═══ 토닥 병원 찾기 배선 — 84 내 병원 연락처 · 85/91 안내 · 92 근처 병원 목록 ═══
   위치정보 원칙 (방통위 해설서 근거 · 변경 금지):
   · 병원 목록은 "지역(시·도)"으로 공공데이터에서 받아온다 — 좌표를 서버에 보내지 않는다
   · GPS 는 받아온 목록을 휴대폰 안에서 거리순으로 줄 세우는 데만 쓰고, 어디에도 저장하지 않는다
   · 다만 지도(카카오맵)로 보여 드릴 때는 지도를 그리려고 카카오에 그 순간의 위치가 전달된다 —
     처리방침 25(위치정보 이용 동의·FAQ 3·5)와 권한 표에 적어 두었다. 토닥 서버에는 남지 않는다
   · 사용기록(app_events)에는 'nearby_search' 라는 이벤트명만 남는다 */
(function () {
  'use strict';
  var T = window.TD || {};
  var sb = T.sb, $ = T.$, $$ = T.$$, toast = T.toast, koError = T.koError, PAGE = T.PAGE;
  if (!sb || !$) return;
  var CFG = window.TODAK_CONFIG || {};
  var cap = window.Capacitor;
  var isNative = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  var P = (cap && cap.Plugins) || {};

  function el(html) { var d = document.createElement('div'); d.innerHTML = html; return d.firstElementChild; }
  /* app.js 의 세션 도우미를 쓴다. 웹앱에서 예전 app.js 가 캐시에 남아 새 이 파일과 섞이면
     T.withSession 이 없어 화면이 통째로 멈춘다 — 그때만 쓰는 대체 길을 둔다. */
  function sessGet(cb) {
    if (T.withSession) { T.withSession(cb); return; }
    sb.auth.getSession().then(function (r) {
      cb((r && r.data && r.data.session) || null, (r && r.error) || null);
    }, function (e) { cb(null, e || true); });
  }
  function sessOff(btn) {
    if (T.sessOffline) { T.sessOffline(btn); return; }
    if (btn && T.busy) T.busy(btn, false);
    if (toast) toast('연결이 원활하지 않아요. 잠시 후 다시 시도해 주세요.');
  }
  function uid(cb) {
    sessGet(function (ses, err) {
      if (ses) { cb(ses.user.id); return; }
      /* 토큰이 만료된 채 통신이 나쁘면 getSession 은 세션 없이 error 를 돌려준다(실측 25.5초) —
         로그아웃이 아니다. 01-splash 로 내보내면 app.js 첫머리가 todak_ocr_meds 를 지워
         사진으로 읽은 약이 전부 사라지고, 16 증상 기록·10 진료 질문·58 약 이름처럼 적던 것도
         함께 날아간다. 화면에 머물게 하고 알려만 드린다. (2026-09-28 · app.js withSession 참고) */
      if (err) { sessOff(); return; }
      location.replace('01-splash.html');
    });
  }
  function getCare(cb) { /* cb(care, treatment, id, err) — err 있으면 저장 금지 */
    uid(function (id) {
      sb.from('profiles').select('treatment').eq('id', id).maybeSingle().then(function (r) {
        if (r.error) { cb({}, {}, id, r.error); return; }
        var t = (r.data && r.data.treatment) || {};
        cb(t.care || {}, t, id, null);
      }, function (e) { cb({}, {}, id, e || true); });
    });
  }

  /* 지금의 위치 동의 = consent_records 의 가장 최근 행 (app.js 열람 화면과 같은 규칙:
     consented_at → id 내림차순). 그 행에 withdrawn_at 이 찍혀 있으면 철회된 동의라 위치를 쓰지 않는다.
     cb(true | false | null) — null 은 확인하지 못함(92 는 위치를 쓰지 않는 쪽으로 처리) */
  function locConsent(cb) {
    uid(function (id) {
      sb.from('consent_records').select('location,withdrawn_at').eq('user_id', id)
        .order('consented_at', { ascending: false }).order('id', { ascending: false }).limit(1)
        .then(function (r) {
          if (!r || r.error) { cb(null); return; }
          var row = r.data && r.data[0];
          cb(!!(row && row.location && !row.withdrawn_at));
        }, function () { cb(null); });
    });
  }

  /* 91 뒤로가기 = 병원 찾기에 들어오기 직전 화면.
     85(→91 리다이렉트)·91 에 들어올 때 document.referrer 의 파일명(+안전한 쿼리)을 검사해 세션에 남긴다.
     병원 찾기 화면끼리(85·91·92·93) 오간 경우는 처음 들어온 곳을 그대로 둔다. 모르면 홈으로. */
  var NB_FROM = 'todak_nearby_from';
  var NB_SELF = { '85-nearby-clinic.html': 1, '91-nearby-gate.html': 1, '92-nearby-list.html': 1, '93-nearby-fallback.html': 1 };
  function safeBack(v) {           /* 같은 폴더의 화면 파일명만 (74 처럼 ?m= 쿼리로 내용을 고르는 화면은 쿼리까지) */
    var m = /^([0-9A-Za-z._-]+\.html)(\?[0-9A-Za-z._~%&=+!*'()-]{0,300})?$/.exec(v || '');
    return (m && !NB_SELF[m[1]]) ? v : '';
  }
  function refFile() {             /* 같은 출처의 referrer 에서 '파일명?쿼리' — 없거나 다른 출처면 '' */
    var r = document.referrer || '';
    var base = location.protocol + '//' + location.host + '/';
    if (!r || r.indexOf(base) !== 0) return '';
    r = r.split('#')[0];
    var qi = r.indexOf('?');
    var path = qi > -1 ? r.slice(0, qi) : r, qs = qi > -1 ? r.slice(qi) : '';
    var file = path.split('/').pop();
    /* 넷리파이 Pretty URLs 는 '.html' 없이 보여 준다 — 그 화면에서 85 로 들어오면
       referrer 가 '05-home' 이라 safeBack 이 걸러 버려 ‹ 가 기본 자리(홈)로 갔다. (2026-09-26) */
    if (file && file.indexOf('.') < 0) file += '.html';
    return file + qs;
  }
  function noteEntry(fresh) {      /* fresh: 85 로 새로 들어온 경우 — 출처를 모르면 지난 값을 지운다 */
    try {
      var f = refFile();
      if (NB_SELF[f.split('?')[0]]) return;
      var ok = safeBack(f);
      if (ok) sessionStorage.setItem(NB_FROM, ok);
      else if (fresh) sessionStorage.removeItem(NB_FROM);
    } catch (e) {}
  }

  var SIDO = [
    ['110000', '서울특별시'], ['210000', '부산광역시'], ['220000', '인천광역시'], ['230000', '대구광역시'],
    ['240000', '광주광역시'], ['250000', '대전광역시'], ['260000', '울산광역시'], ['410000', '세종특별자치시'],
    ['310000', '경기도'], ['320000', '강원특별자치도'], ['330000', '충청북도'], ['340000', '충청남도'],
    ['350000', '전북특별자치도'], ['360000', '전라남도'], ['370000', '경상북도'], ['380000', '경상남도'], ['390000', '제주특별자치도']
  ];

  /* 시·군·구 코드(sgguCd) — 출처: 보건의료빅데이터개방시스템(opendata.hira.or.kr)
     › 서비스 소개 › 용어설명 › 코드조회 › 지역코드 (2026-09 확인, 지역코드 전 항목을 읽어 옮겼다).
     지금 없어진 옛 시·군(예: 청원군·연기군·마산시)은 담지 않았다 — 지금 병원 자료는 바뀐 이름으로 들어온다.
     세종특별자치시는 시·군·구가 없어 시·도 하나로만 찾는다.
     '코드 이름' 을 빈칸으로 이어 붙인 문자열이다(파일을 짧게 두려고). */
  var SGGU_RAW = {
    '110000': '110001 강남구|110002 강동구|110024 강북구|110003 강서구|110004 관악구|110023 광진구|110005 구로구|110025 금천구|110022 노원구|110006 도봉구|110007 동대문구|110008 동작구|110009 마포구|110010 서대문구|110021 서초구|110011 성동구|110012 성북구|110018 송파구|110020 양천구|110013 영등포구|110014 용산구|110015 은평구|110016 종로구|110017 중구|110019 중랑구',
    '210000': '210012 강서구|210011 금정구|210001 남구|210002 동구|210003 동래구|210004 부산진구|210005 북구|210015 사상구|210010 사하구|210006 서구|210014 수영구|210007 영도구|210013 연제구|210008 중구|210009 해운대구|210100 기장군',
    '220000': '220008 계양구|220012 검단구|220006 남동구|220001 미추홀구|220003 부평구|220011 서해구|220007 연수구|220009 영종구|220010 제물포구|220100 강화군|220200 옹진군',
    '230000': '230001 남구|230007 달서구|230002 동구|230003 북구|230004 서구|230005 수성구|230006 중구|230100 달성군|230200 군위군',
    '240000': '240004 광산구|240001 동구|240005 남구|240002 북구|240003 서구',
    '250000': '250002 대덕구|250004 동구|250003 서구|250001 유성구|250005 중구',
    '260000': '260001 남구|260002 동구|260004 북구|260003 중구|260100 울주군',
    '310000': '310900 과천시|310100 광명시|312600 광주시|311000 구리시|311400 군포시|312300 김포시|311500 남양주시|310200 동두천시|310300 부천시|311100 안산시|312400 안성시|311800 오산시|311600 의왕시|310800 의정부시|312100 이천시|312200 파주시|311200 평택시|312800 포천시|311300 하남시|312500 화성시|310600 수원시|312000 용인시|311700 시흥시|312700 양주시|312900 여주시|311901 고양시 덕양구|311903 고양시 일산동구|311902 고양시 일산서구|310403 성남시 분당구|310401 성남시 수정구|310402 성남시 중원구|310702 안양시 동안구|310701 안양시 만안구|310001 가평군|310009 양평군|310011 연천군',
    '320000': '320100 강릉시|320200 동해시|320700 삼척시|320300 속초시|320400 원주시|320500 춘천시|320600 태백시|320001 고성군|320004 양구군|320005 양양군|320006 영월군|320008 인제군|320009 정선군|320010 철원군|320012 평창군|320013 홍천군|320014 화천군|320015 횡성군',
    '330000': '330100 청주시|330200 충주시|330300 제천시|330001 괴산군|330002 단양군|330003 보은군|330004 영동군|330005 옥천군|330006 음성군|330009 진천군|330011 증평군',
    '340000': '340800 계룡시|340300 공주시|340700 논산시|340900 당진시|340400 보령시|340500 아산시|340600 서산시|340200 천안시|340002 금산군|340007 부여군|340009 서천군|340012 예산군|340016 태안군|340014 청양군|340015 홍성군',
    '350000': '350100 군산시|350600 김제시|350200 남원시|350300 익산시|350400 전주시|350500 정읍시|350001 고창군|350004 무주군|350005 부안군|350006 순창군|350008 완주군|350010 임실군|350011 장수군|350013 진안군',
    '360000': '360700 광양시|360200 나주시|360300 목포시|360400 순천시|360500 여수시|360001 강진군|360002 고흥군|360003 곡성군|360006 구례군|360008 담양군|360009 무안군|360010 보성군|360012 신안군|360014 영광군|360015 영암군|360016 완도군|360017 장성군|360018 장흥군|360019 진도군|360020 함평군|360021 해남군|360022 화순군',
    '370000': '371000 경산시|370100 경주시|370200 구미시|370300 김천시|370800 문경시|370900 상주시|370400 안동시|370500 영주시|370600 영천시|370700 포항시|370002 고령군|370007 봉화군|370010 성주군|370012 영덕군|370013 영양군|370017 예천군|370018 울릉군|370019 울진군|370021 의성군|370022 청도군|370023 청송군|370024 칠곡군',
    '380000': '381000 거제시|380100 김해시|380900 밀양시|380300 사천시|380500 진주시|380800 통영시|380700 창원시|381100 양산시|380002 거창군|380003 고성군|380005 남해군|380008 산청군|380011 의령군|380014 창녕군|380016 하동군|380017 함안군|380018 함양군|380019 합천군',
    '390000': '390200 제주시|390100 서귀포시'
  };
  var SGGU_CACHE = {};
  function sgguList(sidoCd) {   /* [[코드, 이름], …] — 없으면 빈 배열(시·도 전체로 찾는다) */
    if (SGGU_CACHE[sidoCd]) return SGGU_CACHE[sidoCd];
    var raw = SGGU_RAW[sidoCd], out = [], parts, i, sp;
    if (raw) {
      parts = raw.split('|');
      for (i = 0; i < parts.length; i++) {
        sp = parts[i].indexOf(' ');
        out.push([parts[i].slice(0, sp), parts[i].slice(sp + 1)]);
      }
    }
    SGGU_CACHE[sidoCd] = out;
    return out;
  }
  function sgguName(sidoCd, code) {
    var l = sgguList(sidoCd), i;
    for (i = 0; i < l.length; i++) if (l[i][0] === code) return l[i][1];
    return '';
  }
  /* ── 지역 고르기 칸 채우기 (92 지역 검색 · 84 내 병원 선택하기 두 곳이 같이 쓴다) ── */
  function putOpts(sel, list) {
    sel.innerHTML = '';
    for (var i = 0; i < list.length; i++) {
      var o = document.createElement('option');
      o.value = list[i][0]; o.textContent = list[i][1];
      sel.appendChild(o);
    }
  }
  function fillSido(sel) { putOpts(sel, SIDO); }
  function fillSggu(sel, sidoCd) {
    var l = sgguList(sidoCd);
    putOpts(sel, [['', l.length ? '시·군·구 전체' : '(이 지역은 시·도 전체로 찾아요)']].concat(l));
    sel.disabled = !l.length;
  }
  function fillCl(sel) { putOpts(sel, [['', '병원 종류 전체']].concat(CLCD)); }
  /* 그 병원이 어느 읍·면·동인지 — 공공데이터의 emdongNm 을 먼저 쓰고,
     비어 있으면 주소에서 '○○동/○○읍/○○면' 을 찾아 쓴다 (도로명만 적힌 주소는 '' 이다) */
  function emdOf(h) {
    var v = (h && h.emd) ? String(h.emd).replace(/\s+/g, ' ').trim() : '';
    if (v) return v;
    var a = String((h && h.addr) || '').split(/\s+/), i;
    for (i = 1; i < a.length; i++) {          /* 0번은 시·도 */
      if (/[0-9A-Za-z]/.test(a[i])) continue;                 /* '101동' 같은 아파트 동 번호는 뺀다 */
      if (/[로길]$/.test(a[i])) break;                        /* 도로명이 나오면 그 뒤는 번지·건물이다 */
      if (a[i].length >= 2 && /[동읍면]$/.test(a[i])) return a[i];
    }
    return '';
  }
  /* 고르신 지역을 한 줄로 — '서울특별시 종로구' 처럼 */
  /* 2026-07-01 인천 행정체제 개편 — 새 구(제물포·영종·서해·검단)로 찾아 결과가 없으면 옛 구 코드로 한 번 더 찾는다
     제물포구 = 옛 중구(내륙)+동구 · 영종구 = 옛 중구(영종도) · 서해구·검단구 = 옛 서구 */
  var OLD_SGGU = { '220010': ['220004', '220002'], '220009': ['220004'], '220011': ['220005'], '220012': ['220005'] };
  function areaLabel(sidoCd, sgguCd, emd) {
    var s = sidoName(sidoCd);
    var g = sgguCd ? sgguName(sidoCd, sgguCd) : '';
    return s + (g ? ' ' + g : '') + (emd ? ' ' + emd : '');
  }
  var CLCD = [
    ['11', '종합병원'], ['01', '상급종합병원'], ['21', '병원'], ['31', '의원'],
    ['41', '치과병원'], ['51', '치과의원']
  ];
  function sidoName(code) {
    for (var i = 0; i < SIDO.length; i++) if (SIDO[i][0] === code) return SIDO[i][1];
    return '그 지역';
  }

  /* ── 주소(?sido= · ?sggu=)로 들어온 지역 이름·코드를 우리 코드로 옮긴다 ──
     AI 상담(07) 카드가 붙여 주는 한글 정식 이름('대전광역시')을 먼저 받고,
     줄여 쓴 이름('대전')과 행정표준코드 앞 두 자리('30'), 심평원 코드('250000')도 함께 받는다.
     못 알아보면 '' 를 돌려준다 — 부르는 쪽이 평소 화면(내 위치 먼저)으로 조용히 넘어간다 */
  var SIDO_ALIAS = {
    '11': '110000', '26': '210000', '28': '220000', '27': '230000', '29': '240000',
    '30': '250000', '31': '260000', '36': '410000', '41': '310000', '42': '320000',
    '51': '320000', '43': '330000', '44': '340000', '45': '350000', '52': '350000',
    '46': '360000', '47': '370000', '48': '380000', '50': '390000',
    '서울': '110000', '서울시': '110000', '부산': '210000', '부산시': '210000',
    '인천': '220000', '인천시': '220000', '대구': '230000', '대구시': '230000',
    '광주': '240000', '광주시': '240000', '대전': '250000', '대전시': '250000',
    '울산': '260000', '울산시': '260000', '세종': '410000', '세종시': '410000',
    '경기': '310000', '경기도': '310000', '강원': '320000', '강원도': '320000',
    '충북': '330000', '충청북도': '330000', '충남': '340000', '충청남도': '340000',
    '전북': '350000', '전라북도': '350000', '전남': '360000', '전라남도': '360000',
    '경북': '370000', '경상북도': '370000', '경남': '380000', '경상남도': '380000',
    '제주': '390000', '제주도': '390000'
  };
  function sidoResolve(v) {
    var s = String(v || '').replace(/\s+/g, ''), i;
    if (!s) return '';
    for (i = 0; i < SIDO.length; i++) if (SIDO[i][0] === s || SIDO[i][1] === s) return SIDO[i][0];
    return SIDO_ALIAS.hasOwnProperty(s) ? SIDO_ALIAS[s] : '';
  }
  /* 시·군·구 — 코드 → 정식 이름 → '구·시·군' 이 빠진 이름('유성') →
     앞에 시 이름이 붙는 곳('고양시 덕양구')을 뒤에서 맞춰 보기 — 순서대로 한 번씩.
     뒤맞춤은 딸 곳이 오직 하나일 때만 받는다(헷갈린 곳으로 보내지 않게) */
  function sgguResolve(sidoCd, v) {
    var s = String(v || '').replace(/\s+/g, ''), l = sgguList(sidoCd), i, nm, hit, tail, n;
    if (!s) return '';
    for (i = 0; i < l.length; i++) if (l[i][0] === s) return l[i][0];
    for (i = 0; i < l.length; i++) if (l[i][1].replace(/\s+/g, '') === s) return l[i][0];
    if (!/[구시군]$/.test(s)) {
      tail = ['구', '시', '군'];
      for (n = 0; n < tail.length; n++) {
        for (i = 0; i < l.length; i++) if (l[i][1].replace(/\s+/g, '') === s + tail[n]) return l[i][0];
      }
    }
    hit = '';
    for (i = 0; i < l.length; i++) {
      nm = l[i][1].replace(/\s+/g, '');
      if (nm.length > s.length && nm.slice(nm.length - s.length) === s) {
        if (hit) return '';        /* 둘 이상이면 고를 수 없다 — 시·도 전체로 찾는다 */
        hit = l[i][0];
      }
    }
    return hit;
  }

  /* ── 좌표 → 시·도 판정 (휴대폰 안에서만 한다 — 좌표는 어떤 서버로도 보내지 않는다) ──
     MET: 특별시·광역시·특별자치시 — [코드, 시청 위도, 시청 경도, 반경km]. 반경 안이면 그 시로 본다.
          도 안에 들어 있는 광역시(서울·인천/경기, 대구/경북, 광주/전남, 대전·세종/충남,
          부산·울산/경남)를 가르는 기준이다. 반경은 시청에서 그 시 끝자락까지 담되
          옆 시·군을 덜 먹도록 잡았다.
     PRV: 도 — 도청 한 곳만 두면 도 경계에서 어긋난다(천안은 충남도청보다 충북도청이 가깝다).
          그래서 도마다 주요 시·군청 여러 곳을 대표 좌표로 두고, 가장 가까운 곳의 도로 본다. */
  var MET = [
    ['110000', 37.5663, 126.9779, 17],   /* 서울시청 */
    ['220000', 37.4563, 126.7052, 20],   /* 인천시청 */
    ['230000', 35.8714, 128.6014, 15],   /* 대구시청 */
    ['240000', 35.1600, 126.8514, 13],   /* 광주시청 */
    ['250000', 36.3504, 127.3845, 13],   /* 대전시청 */
    ['260000', 35.5384, 129.3114, 17],   /* 울산시청 */
    ['210000', 35.1796, 129.0756, 17],   /* 부산시청 */
    ['410000', 36.4801, 127.2890, 12]    /* 세종시청 */
  ];
  var PRV = [
    ['310000', 37.2636, 127.0286], ['310000', 37.6584, 126.8320], ['310000', 37.7381, 127.0337],
    ['310000', 37.2410, 127.1776], ['310000', 37.4200, 127.1265], ['310000', 36.9921, 127.1128],
    ['310000', 37.6153, 126.7156], ['310000', 37.3219, 126.8309], ['310000', 37.6360, 127.2165],
    ['310000', 37.2723, 127.4350], ['310000', 37.5035, 126.7660], ['310000', 37.4786, 126.8646],
    ['310000', 37.5393, 127.2148], ['310000', 37.5944, 127.1296], ['310000', 37.4292, 126.9878],
    ['310000', 37.3943, 126.9568], ['310000', 37.7599, 126.7800], ['310000', 37.3800, 126.8031],
    ['320000', 37.8813, 127.7300], ['320000', 37.3422, 127.9202], ['320000', 37.7519, 128.8761],
    ['320000', 38.2070, 128.5918], ['320000', 37.1640, 128.9856],
    ['330000', 36.6424, 127.4890], ['330000', 36.9910, 127.9259], ['330000', 37.1326, 128.1910],
    ['330000', 36.1750, 127.7764],
    ['340000', 36.6588, 126.6728], ['340000', 36.8151, 127.1139], ['340000', 36.7898, 127.0018],
    ['340000', 36.7848, 126.4503], ['340000', 36.4465, 127.1190], ['340000', 36.3333, 126.6127],
    ['340000', 36.1871, 127.0987], ['340000', 36.8894, 126.6457],
    ['350000', 35.8242, 127.1480], ['350000', 35.9676, 126.7368], ['350000', 35.9483, 126.9576],
    ['350000', 35.5699, 126.8560], ['350000', 35.4164, 127.3905],
    ['360000', 34.8161, 126.4629], ['360000', 34.8118, 126.3922], ['360000', 34.7604, 127.6622],
    ['360000', 34.9506, 127.4872], ['360000', 35.0160, 126.7108], ['360000', 34.9407, 127.6959],
    ['360000', 34.5734, 126.5989],
    ['370000', 36.5684, 128.7294], ['370000', 36.0190, 129.3435], ['370000', 36.1196, 128.3444],
    ['370000', 35.8562, 129.2247], ['370000', 36.1398, 128.1136], ['370000', 36.8056, 128.6240],
    ['370000', 35.8251, 128.7415], ['370000', 36.4109, 128.1590],
    ['380000', 35.2280, 128.6811], ['380000', 35.1803, 128.1076], ['380000', 35.2285, 128.8894],
    ['380000', 34.8544, 128.4331], ['380000', 34.8804, 128.6212], ['380000', 35.3350, 129.0373],
    ['380000', 35.5037, 128.7465], ['380000', 35.0034, 128.0642],
    ['390000', 33.4996, 126.5312], ['390000', 33.2541, 126.5600]
  ];

  /* 진료과목코드(dgsbjtCd) — 출처: 보건의료빅데이터개방시스템(opendata.hira.or.kr)
     › 서비스 소개 › 용어설명 › 코드조회 › 진료과목코드.  [파라미터값, 이름, 진료과목코드, 종별코드 목록]
     치과·구강내과만 진료과목(49·56) 대신 종별(41 치과병원·51 치과의원)로 거른다 —
     종합병원 치과까지 섞이지 않고 동네 치과만 나오게 하려는 것이다. */
  var DEPT = [
    ['49', '치과', '', ['51', '41']],
    ['01', '내과', '01', []],
    ['13', '이비인후과', '13', []],
    ['12', '안과', '12', []],
    ['14', '피부과', '14', []],
    ['05', '정형외과', '05', []],
    ['23', '가정의학과', '23', []],
    ['15', '비뇨의학과', '15', []],
    ['10', '산부인과', '10', []],
    ['11', '소아청소년과', '11', []],
    ['04', '외과', '04', []],
    ['21', '재활의학과', '21', []],
    ['03', '정신건강의학과', '03', []]
  ];
  /* 심평원 목록을 dgsbjtCd 로 거르면 '그 과만 보는 곳'이 아니라
     '그 진료과목을 신고한 모든 요양기관'이 나온다 — 피부과를 골라도 내과의원·비뇨의학과의원이 섞인다
     (2026-09 실측: 대구 중구 전체 481곳 → 피부과 123곳, 그중 이름에 피부과가 있는 곳은 10곳).
     그래서 거르지 않고 '순서'를 준다 — 아무 곳도 사라지지 않게 하려는 것이다.
       0 이름에 그 과가 들어간 곳   1 병원급 이상(그 과를 따로 두는 곳)   2 그 과목도 함께 보는 곳
     아래 표는 [맞는 이름, 빼야 할 이름, 그 자체가 그 과인 종별(없으면 생략)].
     치과(49)는 이미 종별로 걸러 나오므로 여기 없다. */
  var DEPT_NM = {
    '01': [/내과/, null],
    '13': [/이비인후과/, null],
    '12': [/안과/, null],
    '14': [/피부과/, null],
    '05': [/정형외과/, null],
    '23': [/가정의학과/, null],
    '15': [/비뇨(의학|기)과/, null],
    '10': [/산부인과|여성의원|여성병원/, null],
    '11': [/소아(청소년)?과/, null],
    '04': [/외과/, /(정형|성형|신경|흉부|심장혈관|구강악안면|악안면|치과)외과/],
    '21': [/재활의학과|재활병원/, null],
    '03': [/정신건강의학과|신경정신과|정신과/, null, '정신병원']
  };
  /* 종별(clCdNm) 이 이 셋이면 그 진료과를 따로 두고 보는 곳으로 본다.
     '요양병원' 은 일부러 뺐다 — 이름에 병원이 들어가지만 그 과를 보러 가는 곳이 아니다 */
  var CL_BIG = { '상급종합': 1, '종합병원': 1, '병원': 1 };
  function deptFind(v) {
    var s = String(v || '').trim();
    if (!s) return null;
    for (var i = 0; i < DEPT.length; i++) if (DEPT[i][0] === s || DEPT[i][1] === s) return DEPT[i];
    return null;
  }
  function nbQS(k) {
    var m = new RegExp('[?&]' + k + '=([^&#]*)').exec(location.search || '');
    if (!m) return '';
    try { return decodeURIComponent(m[1]); } catch (e) { return ''; }
  }

  function fetchHosp(params, ok, fail) {
    var q = { numOfRows: '200', pageNo: '1' };
    for (var k in params) if (params[k]) q[k] = params[k];
    function parse(xml) {
        if (xml.indexOf('<resultCode>00<') < 0) { fail('api'); return; }
        var items = [], m, re = /<item>([\s\S]*?)<\/item>/g;
        function unesc(v) {
          return v.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
                  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&apos;/g, "'");
        }
        function pick(s, tag) {
          var mm = new RegExp('<' + tag + '>([^<]*)</' + tag + '>').exec(s);
          return mm ? unesc(mm[1]) : '';
        }
        while ((m = re.exec(xml))) {
          var s = m[1];
          items.push({
            name: pick(s, 'yadmNm'), cl: pick(s, 'clCdNm'), addr: pick(s, 'addr'),
            emd: pick(s, 'emdongNm'),                       /* 읍·면·동 고르기에 쓴다 */
            tel: pick(s, 'telno'), x: parseFloat(pick(s, 'XPos')), y: parseFloat(pick(s, 'YPos'))
          });
        }
        var tcm = /<totalCount>(\d+)<\/totalCount>/.exec(xml);
        ok(items, tcm ? parseInt(tcm[1], 10) : items.length);
    }
    /* 앱·웹 모두 토닥 중계 함수(hosp-proxy)를 거친다 — 좌표는 보내지 않는다.
       공공데이터 인증키를 앱에 심으면 배포본에서 그대로 읽히므로 서버에만 둔다. */
    if (!CFG.fnBase) { fail('web'); return; }
    sb.auth.getSession().then(function (rs) {
      var tok = rs.data.session ? rs.data.session.access_token : null;
      var qs = [];
      for (var k2 in q) qs.push(k2 + '=' + encodeURIComponent(q[k2]));
      fetch(CFG.fnBase + '/hosp-proxy?' + qs.join('&'), { headers: { 'Authorization': 'Bearer ' + (tok || CFG.anonKey), 'apikey': CFG.anonKey } })
        .then(function (r) { if (!r.ok) throw new Error('api'); return r.text(); })
        .then(parse, function () { fail('net'); });
    });
  }

  /* 응급실 직통번호 — 국립중앙의료원 '전국 응급의료기관 정보'(hosp-proxy 의 /er 통로).
     병원 이름과 주소(시·도·시·군·구)로 찾아 dutyTel3 를 돌려준다. 못 찾거나 서비스 신청 전이면 ''.
     지정 응급의료기관만 있는 자료라 동네 의원은 나오지 않는다. 좌표는 보내지 않는다. */
  function fetchER(name, addr, ok) {
    if (!CFG.fnBase || !name) return ok('');
    /* 이름은 부분 일치라 '서울대학교병원' 으로 찾으면 분당서울대까지 나온다 → 시·도로 좁히고 주소로 고른다 */
    var a = String(addr || '').split(/\s+/), q = { QN: String(name).slice(0, 20), numOfRows: '10' };
    if (a[0]) q.Q0 = a[0];
    var qs = [], k;
    for (k in q) if (q[k]) qs.push(k + '=' + encodeURIComponent(q[k]));
    sb.auth.getSession().then(function (rs) {
      var tok = rs.data.session ? rs.data.session.access_token : null;
      fetch(CFG.fnBase + '/hosp-proxy/er?' + qs.join('&'), { headers: { 'Authorization': 'Bearer ' + (tok || CFG.anonKey), 'apikey': CFG.anonKey } })
        .then(function (r) { return r.ok ? r.text() : ''; })
        .then(function (xml) {
          if (!xml || xml.indexOf('<resultCode>00<') < 0) return ok('');
          var re2 = /<item>([\s\S]*?)<\/item>/g, mm, best = null, bestScore = -1;
          var plain = function (v) { return String(v || '').replace(/[\s()]/g, ''); };
          var want = plain(name), gu = a[1] ? plain(a[1]) : '';
          while ((mm = re2.exec(xml))) {
            var it = mm[1];
            var g = function (tag) { var x = new RegExp('<' + tag + '>([^<]*)</' + tag + '>').exec(it); return x ? x[1].trim() : ''; };
            var nm = g('dutyName'), ad = plain(g('dutyAddr')), tel = g('dutyTel3');
            if (!tel) continue;
            var sc = 0, pn = plain(nm);
            if (pn === want) sc += 6;
            else if (pn.indexOf(want) > -1 || want.indexOf(pn) > -1) sc += 3;
            if (gu && ad.indexOf(gu) > -1) sc += 4;          /* 같은 시·군·구면 크게 올린다 */
            if (sc > bestScore) { bestScore = sc; best = tel; }
          }
          ok(bestScore >= 3 ? best : '');                    /* 이름도 지역도 안 맞으면 채우지 않는다 */
        }, function () { ok(''); });
    }, function () { ok(''); });
  }

  function haversineKm(y1, x1, y2, x2) {
    var R = 6371, dY = (y2 - y1) * Math.PI / 180, dX = (x2 - x1) * Math.PI / 180;
    var a = Math.sin(dY / 2) * Math.sin(dY / 2)
      + Math.cos(y1 * Math.PI / 180) * Math.cos(y2 * Math.PI / 180) * Math.sin(dX / 2) * Math.sin(dX / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }
  /* 내 위치에서 그 병원이 어느 쪽인지 — 0도가 북쪽, 시계방향(90도 동쪽).
     휴대폰 안에서만 쓴다 — 방위도 거리도 어떤 서버로도 보내지 않는다 */
  function bearingDeg(y1, x1, y2, x2) {
    var dn = y2 - y1;
    var de = (x2 - x1) * Math.cos((y1 + y2) / 2 * Math.PI / 180);
    return (Math.atan2(de, dn) * 180 / Math.PI + 360) % 360;
  }
  /* 내 위치에 맞는 시·도를 가까운 순으로 — 첫째가 가장 맞는 곳, 둘째는 경계일 때 함께 찾을 곳.
     광역시 반경 안이면 그 광역시를 맨 앞으로 끌어온다(-1000km). 좌표는 이 함수 밖으로 나가지 않는다 */
  function sidoRank(y, x) {
    var sc = {}, i, d, c, out = [], r = [], near = null, inMet = null, head = null;
    function put(code, v) { if (sc[code] == null || v < sc[code]) sc[code] = v; }
    for (i = 0; i < MET.length; i++) {
      d = haversineKm(y, x, MET[i][1], MET[i][2]);
      put(MET[i][0], d);
      if (d <= MET[i][3] && (inMet === null || d < inMet[1])) inMet = [MET[i][0], d];
    }
    for (i = 0; i < PRV.length; i++) {
      d = haversineKm(y, x, PRV[i][1], PRV[i][2]);
      put(PRV[i][0], d);
      if (near === null || d < near[1]) near = [PRV[i][0], d];
    }
    for (c in sc) if (sc.hasOwnProperty(c)) out.push([c, sc[c]]);
    out.sort(function (a, b) { return a[1] - b[1]; });
    for (i = 0; i < out.length; i++) r.push(out[i][0]);
    /* ① 도의 대표 시·군청 6km 안이면 그 도 — 부천·광명·고양·경산처럼 광역시청보다
          제 시청이 더 가까운 곳을 살린다.  ② 아니면 광역시 반경 안이면 그 광역시.
       ③ 둘 다 아니면 그냥 가장 가까운 곳. 둘째부터는 거리순 그대로 둔다(경계일 때 함께 찾을 곳) */
    head = (near && near[1] <= 6) ? near[0] : (inMet ? inMet[0] : null);
    if (head) {
      for (i = 0; i < r.length; i++) if (r[i] === head) { r.splice(i, 1); break; }
      r.unshift(head);
    }
    return r;
  }
  function getGPS(ok, fail) {   /* 좌표는 이 함수의 콜백 밖으로 저장하지 않는다 */
    var done = false;
    function good(y, x) { if (!done) { done = true; ok(y, x); } }
    function bad() { if (!done) { done = true; fail(); } }
    if (isNative && P.Geolocation && P.Geolocation.getCurrentPosition) {
      P.Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 10000 })
        .then(function (pos) { good(pos.coords.latitude, pos.coords.longitude); }, bad);
    } else if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        function (pos) { good(pos.coords.latitude, pos.coords.longitude); }, bad, { timeout: 10000 });
    } else bad();
    setTimeout(bad, 12000);
  }

  /* ── 84 내 병원 연락처 — 담당 병원 등록·전화 ── */
  function page84() {
    var content = $('.content');
    var card = $$('.card', content)[0];               /* 진료 병원 카드 */
    if (!card) return;
    var nameEl = $$('.strong', card).filter(function (n) { return (' ' + n.className + ' ').indexOf(' tiny ') < 0; })[0];
    var deptEl = $('.small.muted', card);
    var searchBox = $('.input', card);

    /* 표시 → 입력형으로 재구성 */
    var nameInp = el('<input class="input" type="text" placeholder="병원 이름 (예: ○○대학교병원)" aria-label="병원 이름">');
    var addrInp = el('<input class="input" type="text" placeholder="주소 (선택)" style="margin-top:8px;" aria-label="병원 주소">');
    var deptInp = el('<input class="input" type="text" placeholder="진료과 (예: 종양내과)" style="margin-top:8px;" aria-label="진료과">');
    var outInp = el('<input class="input" type="tel" placeholder="외래(대표) 전화" style="margin-top:8px;" aria-label="외래 전화">');
    var erInp = el('<input class="input" type="tel" placeholder="응급실 전화 (선택)" style="margin-top:8px;" aria-label="응급실 전화">');
    var addrEl = $('[data-nb-addr]', card);
    if (nameEl) nameEl.parentNode.replaceChild(nameInp, nameEl);
    if (addrEl) addrEl.parentNode.replaceChild(addrInp, addrEl);
    if (deptEl) deptEl.parentNode.replaceChild(deptInp, deptEl);
    if (!addrEl) nameInp.insertAdjacentElement('afterend', addrInp);
    addrInp.insertAdjacentElement('afterend', deptInp);
    deptInp.insertAdjacentElement('afterend', outInp);
    outInp.insertAdjacentElement('afterend', erInp);

    /* 이름 검색: 심평원에서 이름으로 찾아 대표전화 자동 채움 (위치 불필요) */
    var sugWrap = el('<div style="margin-top:8px;"></div>');
    if (searchBox) {
      var row = searchBox.parentNode;
      row.parentNode.insertBefore(sugWrap, row.nextSibling);
      row.style.display = 'none';   /* 가짜 검색창은 숨긴다 — 위 이름 칸에서 바로 찾아준다 */
    }
    /* 내 병원 선택하기 — 92 의 지역 검색과 같은 방법으로 찾아 고르면 이름·주소·대표전화가 채워진다 */
    var pickBtn = $('#nb-pick', card);
    if (!pickBtn) {
      pickBtn = el('<a class="btn btn-outline btn-block" id="nb-pick" href="javascript:void(0)" style="margin-top:10px;">🔎 내 병원 선택하기</a>');
      erInp.insertAdjacentElement('afterend', pickBtn);
    }
    pickBtn.addEventListener('click', function (e) {
      e.preventDefault();
      hospPop(function (h) {
        nameInp.value = h.name;
        if (h.addr) addrInp.value = h.addr;
        if (h.tel) outInp.value = h.tel;
        dirty = true;
        sugWrap.innerHTML = '';
        toast('병원 이름·주소·대표전화를 채웠어요.\n응급실 번호를 찾아볼게요…');
        fetchER(h.name, h.addr, function (tel) {
          if (tel && !erInp.value) { erInp.value = tel; dirty = true; toast('응급실 번호도 채웠어요.\n진료과는 직접 넣어 주세요.'); }
          else toast('응급실 번호는 찾지 못했어요.\n진료과와 함께 직접 넣어 주세요.');
        });
      });
    });
    var timer = null, seq = 0;
    nameInp.addEventListener('input', function () {
      clearTimeout(timer);
      var q = nameInp.value.trim();
      sugWrap.innerHTML = '';
      if (q.length < 2) return;
      timer = setTimeout(function () {
        var my = ++seq;
        fetchHosp({ yadmNm: q, numOfRows: '5' }, function (items) {
          if (my !== seq) return;
          sugWrap.innerHTML = '';
          items.slice(0, 3).forEach(function (h) {
            var li = el('<div class="listitem" style="cursor:pointer;"><span class="li-ic">🏥</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="strong small" style="color:var(--primary-dark);">선택</span></div>');
            $('.li-title', li).textContent = h.name;
            $('.li-sub', li).textContent = h.cl + ' · ' + h.addr.slice(0, 22);
            li.addEventListener('click', function () {
              nameInp.value = h.name;
              if (h.addr && !addrInp.value) addrInp.value = h.addr;
              if (h.tel && !outInp.value) outInp.value = h.tel;
              sugWrap.innerHTML = '';
              toast('주소·대표전화를 채웠어요. 응급실 번호는 직접 넣어 주세요.');
            });
            sugWrap.appendChild(li);
          });
        }, function () {});
      }, 400);
    });

    /* 저장된 번호 줄 → 실제 전화 */
    var items2 = $$('a.listitem', content);
    var outRow = items2.filter(function (li) { return li.textContent.indexOf('외래') > -1; })[0];
    var erRow = items2.filter(function (li) { return li.textContent.indexOf('응급실') > -1; })[0];
    function paintRows(care) {
      [[outRow, care.tel_out, '진료과 · 외래'], [erRow, care.tel_er, '응급실']].forEach(function (p) {
        var row = p[0]; if (!row) return;
        var t = $('.li-title', row), s2 = $('.li-sub', row);
        if (p[1]) {
          row.setAttribute('href', 'tel:' + p[1].replace(/[^0-9+]/g, ''));
          if (t) t.textContent = (care.name ? care.name + ' · ' : '') + p[2];
          if (s2) s2.textContent = p[1];
        } else {
          row.setAttribute('href', 'javascript:void(0)');
          if (s2) s2.textContent = '위에서 번호를 등록해 주세요';
          row.addEventListener('click', function (e) { e.preventDefault(); nameInp.focus(); });
        }
      });
    }

    /* 저장 버튼 (앱바 ✏️ → 저장) */
    var saveBtn = $('.appbar .action');
    if (saveBtn) {
      saveBtn.textContent = '저장';
      saveBtn.style.cssText = 'color:var(--primary-dark);font-weight:800;cursor:pointer;font-size:15px;';
      saveBtn.setAttribute('role', 'button'); saveBtn.setAttribute('tabindex', '0');
    }
    /* 불러오기 성공 전에는 저장 금지 — 실패 상태로 저장하면 치료 일정·복약 시간까지
       빈 값으로 덮어써 버린다 (적대검증 3차에서 잡힌 치명 결함) */
    var ready = false, treatAll = {}, myId = null, dirty = false;
    [nameInp, addrInp, deptInp, outInp, erInp].forEach(function (inp) {
      inp.addEventListener('input', function () { dirty = true; });
    });
    function loadCare() {
      getCare(function (care, t, id, err) {
        if (err) return;                 /* ready 유지 안 함 — 저장 시 재시도 */
        ready = true; treatAll = t; myId = id;
        /* 프리필은 아직 손대지 않은 칸만 채운다 */
        if (care.name && !nameInp.value) nameInp.value = care.name;
        if (care.addr && !addrInp.value) addrInp.value = care.addr;
        if (care.dept && !deptInp.value) deptInp.value = care.dept;
        if (care.tel_out && !outInp.value) outInp.value = care.tel_out;
        if (care.tel_er && !erInp.value) erInp.value = care.tel_er;
        paintRows(care);
      });
    }
    loadCare();
    function doSave(after) {
      if (saveBtn && saveBtn.__busy) return;
      if (!ready || !myId) {
        toast('저장해 두신 내용을 확인하는 중이에요.\n잠시 후 다시 눌러 주세요.');
        loadCare();
        return;
      }
      if (saveBtn) saveBtn.__busy = true;
      treatAll.care = {
        name: nameInp.value.trim() || null,
        addr: addrInp.value.trim() || null,
        dept: deptInp.value.trim() || null,
        tel_out: outInp.value.trim() || null,
        tel_er: erInp.value.trim() || null
      };
      T.mergeTreatment({ care: treatAll.care }, function (r) {
        if (saveBtn) saveBtn.__busy = false;
        if (r && r.error) return toast(koError(r.error));
        dirty = false;
        toast('내 병원 연락처를 저장했어요 📞');
        paintRows(treatAll.care);
        if (after) after();
      }, function () { if (saveBtn) saveBtn.__busy = false; toast('연결이 원활하지 않아요. 다시 시도해 주세요.'); });
    }
    if (saveBtn) saveBtn.addEventListener('click', function (e) { e.preventDefault(); doSave(null); });
    /* 저장 안 하고 뒤로 나가면 입력이 사라지므로, 나갈 때 자동 저장 */
    var backA = $('.appbar .back');
    if (backA) backA.addEventListener('click', function (e) {
      if (!dirty) return;
      e.preventDefault(); e.stopPropagation();   /* 전역 뒤로가기(replace)가 먼저 이동시키지 않게 */
      var to = backA.getAttribute('href') || '13-settings.html';
      doSave(function () { setTimeout(function () { location.href = to; }, 500); });
    });
  }

  /* ── 85·91 담당 병원 카드 실데이터 + 91 안내 일반화 ── */
  function fillCareCard(root) {
    var cards = $$('.card', root).filter(function (c) { return c.textContent.indexOf('내 담당 병원') > -1; });
    if (!cards.length) return;
    getCare(function (care) {
      cards.forEach(function (card) {
        var nm = $$('.strong', card).filter(function (n) { return (' ' + n.className + ' ').indexOf(' tiny ') < 0; })[0], tel = $('.small.muted', card);
        var btns = $$('a.btn', card);
        if (care.name) {
          if (nm) nm.textContent = care.name + (care.dept ? ' · ' + care.dept : '');
          if (tel) tel.textContent = (care.tel_out ? '외래 ' + care.tel_out : '') + (care.tel_er ? ' · 응급실 ' + care.tel_er : '') || '아직 등록된 번호가 없어요';
          if (btns[0]) {
            var n = care.tel_er || care.tel_out;
            if (n) {
              btns[0].setAttribute('href', 'tel:' + n.replace(/[^0-9+]/g, ''));
              btns[0].innerHTML = '📞 담당 병원에 전화';
            }
          }
        } else {
          if (nm) nm.textContent = '아직 등록된 병원이 없어요';
          if (tel) tel.textContent = '번호를 등록해 두면 급할 때 바로 걸 수 있어요';
          if (btns[0]) { btns[0].setAttribute('href', '84-care-contacts.html?from=92-nearby-list.html'); btns[0].innerHTML = '📞 병원 등록하러 가기'; }
        }
      });
    });
  }
  function page91() {
    fillCareCard(document);
    /* 구내염 전용 시안 → 어느 증상에서 들어와도 맞는 일반 안내로 */
    var sub = $('.appbar-sub'); if (sub) sub.textContent = '가벼운 증상일 때';
    /* 예전에는 구내염 전용 시안 두 칸(동네 병원 기준 · 가시기 전에 꼭)을 여기서 갈아 끼웠다.
       2026-09-28 에 91 화면을 다시 짜면서 그 두 칸이 화면 안으로 들어가, 여기서 할 일이 없다. (2026-09-29 지움) */
    var cta = $$('.footer-actions a.btn').filter(function (a) { return a.textContent.indexOf('근처') > -1; })[0];
    if (cta) cta.innerHTML = '📍 근처 병원 찾기';

    /* ‹ (와 휴대폰 뒤로가기) = 병원 찾기에 들어오기 직전 화면. 시안은 36 구내염으로 고정돼 있었다.
       ?from= 으로 들어온 경우는 app.js 가 이미 처리하므로 건드리지 않는다. */
    noteEntry(false);
    if (!/[?&]from=/.test(location.search || '')) {
      var backTo = '';
      try { backTo = safeBack(sessionStorage.getItem(NB_FROM) || ''); } catch (eB) { backTo = ''; }
      $$('.appbar a.back').forEach(function (b) { b.setAttribute('href', backTo || '05-home.html'); });
    }

    /* 📍 위치 고지 — 실제 동작에 맞춘다. 92 는 들어가면 곧바로 그 순간의 위치를 한 번 확인해
       가까운 순으로 보여 주고, 위치를 쓸 수 없을 때만 지역을 여쭤본다. */
    var locBox = $('[data-nb-loc]') || $$('.banner--info .small').filter(function (d) {
      var ic = d.parentNode && $('.b-ic', d.parentNode);
      return !!(ic && ic.textContent.indexOf('📍') > -1);
    })[0];
    if (locBox) locConsent(function (ok) {
      /* 동의하신 경우: 화면에 적힌 글이 이미 그 경우의 글이다 — 손대지 않는다.
         (예전에는 같은 내용을 한 문단으로 다시 써 넣어, 화면의 점 목록이 줄글로 바뀌어 보였다 · 2026-09-29)
         동의하지 않으셨거나 확인하지 못한 경우에만 같은 점 목록 모양으로 바꾼다. */
      if (ok === true) return;
      locBox.innerHTML = '<ul class="dots">'
        + '<li><b>위치는 쓰지 않아요.</b>'
        + '<span class="dots-b">찾으실 <b>지역을 고르시거나</b>, 가실<br><b>장소 이름을 적어</b>(예: ‘서울역’)<br>그곳에서 가까운 순으로 보여 드려요.</span></li>'
        + '<li>위치 사용 동의는 <b>내 정보 ›<br>내가 동의한 내용 보기</b>에서<br>언제든 켜실 수 있어요.</li>'
        + '</ul>';
    });
  }

  /* ── 92 근처 병원 목록 ── */
  function page92() {
    var content = $('.content');
    if (!content) return;
    var title = $('.appbar-title'), sub = $('.appbar-sub');
    var want = deptFind(nbQS('dept'));   /* ?dept=49 · ?dept=치과 — 그 진료과만 찾는다 */
    /* 앱바에는 제목('근처 병원 찾기')만 둔다 — 부제 '공공데이터 병원 목록'은 없앤다.
       자료 출처는 화면 아래 '근거' 줄에 이미 적혀 있고, 찾는 중·몇 곳 같은 상태는 목록 위 한 줄(#nb-status)에 적는다 */
    if (sub && sub.parentNode) sub.parentNode.removeChild(sub);

    /* 상단 경고 배너의 담당병원 이름 실데이터 */
    var warnA = $('.banner--warn a');
    getCare(function (care) {
      if (warnA) warnA.textContent = '담당 병원' + (care.name ? '(' + care.name + ')' : '');
    });

    /* 시안 카드 틀 확보 후 본문 재구성 */
    var tmpl = $('.hosp') ? $('.hosp').cloneNode(true) : null;
    $$('.hosp', content).forEach(function (h) { h.parentNode.removeChild(h); });
    var widen = $('#nb-demo-other') || $$('a.btn', content).filter(function (a) {
      return a.textContent.indexOf('반경') > -1 || a.textContent.indexOf('다른 지역') > -1;
    })[0];
    if (widen) widen.style.display = 'none';
    var demoMore = $('#nb-demo-more', content);
    if (demoMore) demoMore.style.display = 'none';
    /* 시안의 방향 지도(예시 그림)는 감춘다 — 아래에서 진짜 위치로 다시 그린다 */
    var demoMap = $('#nb-demo-map', content);
    if (demoMap) demoMap.style.display = 'none';
    var countRow = $$('.row', content).filter(function (r) { return r.textContent.indexOf('가까운 순') > -1; })[0];
    if (countRow) countRow.style.display = 'none';
    /* 시안의 진료과 줄도 치운다 — 아래에서 진짜 진료과 버튼을 만들어 넣는다 */
    var demoDept = $('#nb-demo-dept', content);
    if (!demoDept) {
      var demoChips = $$('.chips', content).filter(function (c) { return c.textContent.indexOf('전체 보기') > -1; })[0];
      demoDept = demoChips && demoChips.parentNode;
    }
    if (demoDept) demoDept.style.display = 'none';

    /* ① 진료과 — 화면 맨 위. 누르면 큰 팝업이 떠서 하나만 고르시면 된다
          (칩 줄은 글자가 작고 촘촘해 손이 저리신 분들이 누르기 어려웠다) */
    var deptWrap = el('<div style="margin:13px 2px 10px;">'
      + '<div class="small muted" style="margin-bottom:7px;">어떤 진료과를 찾으세요?</div>'
      + '<a class="btn btn-outline btn-block" id="nb-dept" href="javascript:void(0)" style="justify-content:space-between;">'
      + '<span id="nb-dept-cur">전체 보기</span><span aria-hidden="true">고르기 ›</span></a></div>');
    var firstBanner = $('.banner', content);
    content.insertBefore(deptWrap, firstBanner ? firstBanner.nextSibling : content.firstChild);
    var deptBtn = $('#nb-dept', deptWrap), deptCur = $('#nb-dept-cur', deptWrap);

    /* ② 다른 지역에서 찾기 / 내 위치에서 다시 찾기 — 진료과 바로 아래.
          위 '전체 보기 … 고르기 ›' 와 같은 큰 박스 버튼으로 둔다(같은 높이·테두리·글자 크기,
          왼쪽에 무엇을 하는지 · 오른쪽에 화살표). 작은 글씨 링크는 눈에 띄지 않는다는 말씀이 있었다 */
    var otherBtn = el('<a class="btn btn-outline btn-block" id="nb-other" href="javascript:void(0)" style="margin:0 0 10px; display:none; justify-content:space-between;">'
      + '<span>🗺 다른 지역에서 찾기</span><span aria-hidden="true">고르기 ›</span></a>');
    deptWrap.insertAdjacentElement('afterend', otherBtn);
    var gpsBtn = el('<a class="btn btn-outline btn-block" id="nb-gps" href="javascript:void(0)" style="margin:0 0 10px; display:none; justify-content:space-between;">'
      + '<span>📍 내 위치에서 다시 찾기</span><span aria-hidden="true">다시 찾기 ›</span></a>');
    otherBtn.insertAdjacentElement('afterend', gpsBtn);
    /* ②-2 장소로 찾기 — '서울역'처럼 가실 곳을 적으시면 그 곳 둘레에서 찾아 드린다.
          내 위치를 쓰지 않으므로 위치 권한을 묻지 않는다.
          카카오 장소 검색을 쓸 수 없는 환경에서는 이 버튼을 아예 내지 않는다(조용히 없던 일로) */
    var placeBtn = el('<a class="btn btn-outline btn-block" id="nb-place" href="javascript:void(0)" style="margin:0 0 10px; display:none; justify-content:space-between;">'
      + '<span>🔎 장소로 찾기</span><span aria-hidden="true">적기 ›</span></a>');
    gpsBtn.insertAdjacentElement('afterend', placeBtn);

    /* ③ 지역 고르기 — 기본 화면에는 두지 않는다. 위치를 쓸 수 없을 때와
          '다른 지역에서 찾기'를 누르셨을 때만 보여 준다 (좌표는 어디로도 보내지 않는다)
          시·도 › 시·군·구 › 읍·면·동까지 모두 '고르는' 칸이다(직접 적지 않으신다).
          읍·면·동 칸은 시·군·구 목록을 한 번 받아온 뒤, 그 목록에 들어 있는 동만 채워 넣는다 */
    var ctl = el('<div class="card" id="nb-ctl" style="display:none;">'
      + '<div class="small strong" style="color:var(--primary-dark);">어느 지역에서 찾을까요?</div>'
      + '<select class="input" aria-label="시·도" id="nb-sido" style="margin-top:10px;"></select>'
      + '<select class="input" aria-label="시·군·구" id="nb-sggu" style="margin-top:8px;"></select>'
      + '<div id="nb-emd-wrap" style="margin-top:8px;">'
      + '<select class="input" id="nb-emd" aria-label="읍·면·동"></select>'
      + '<p class="small muted" id="nb-emd-help" style="margin-top:7px; line-height:1.7;"></p>'
      + '</div>'
      + '<select class="input" aria-label="병원 종류" id="nb-cl" style="margin-top:10px;"></select>'
      + '<input class="input" type="text" id="nb-name" placeholder="병원 이름 (선택)" aria-label="병원 이름" style="margin-top:8px;">'
      + '<a class="btn btn-primary btn-block" id="nb-go" href="javascript:void(0)" style="margin-top:10px;">🔎 이 조건으로 찾기</a>'
      + '<p class="small muted" style="margin-top:8px; line-height:1.7;">지역으로 찾을 때는 <b>이름순</b>으로 보여 드려요.</p>'
      + '</div>');
    placeBtn.insertAdjacentElement('afterend', ctl);
    var selSido = $('#nb-sido', ctl), selSggu = $('#nb-sggu', ctl), selEmd = $('#nb-emd', ctl),
        emdWrap = $('#nb-emd-wrap', ctl), emdHelp = $('#nb-emd-help', ctl),
        selCl = $('#nb-cl', ctl), inpName = $('#nb-name', ctl), goBtn = $('#nb-go', ctl);
    fillSido(selSido); fillCl(selCl);
    try {
      var last = JSON.parse(localStorage.getItem('todak_nearby') || 'null');
      if (last) { if (last.sido) selSido.value = last.sido; if (last.cl) selCl.value = last.cl; }
    } catch (e) {}
    fillSggu(selSggu, selSido.value);
    try { if (last && last.sggu) selSggu.value = last.sggu; } catch (e2) {}

    /* ── 주소로 지역을 지정해서 열기 ──
       92-nearby-list.html?sido=대전광역시&sggu=유성구&dept=01&from=07-chat.html 처럼 들어오면
       내 위치를 묻지 않고(위치 권한 창이 뜨지 않는다) 그 지역이 골라진 채 바로 목록을 보여 드린다.
       · 시·도만 와도 된다(시·도 전체)
       · 시·군·구를 못 알아보면 그 시·도 전체로 찾는다
       · 시·도조차 못 알아보면(오타·없는 지역) urlSido 가 '' 라 아래에서 평소 화면(내 위치 먼저)으로
         조용히 넘어간다 — 오류 문구는 띄우지 않는다 */
    var urlSido = sidoResolve(nbQS('sido'));
    var urlSggu = urlSido ? sgguResolve(urlSido, nbQS('sggu')) : '';
    /* ?place=서울역 — 상담 카드가 장소를 함께 보내 온 경우. 장소를 먼저 찾아 보고,
       못 찾으면(또는 카카오가 안 되면) 함께 온 sido/sggu 로, 그것도 없으면 평소처럼 내 위치로 조용히 넘어간다 */
    var urlPlace = placeTrim(nbQS('place')).slice(0, 40);
    /* 주소로 들어온 지역은 '마지막에 고른 지역'(localStorage todak_nearby)을 덮어쓰지 않는다 —
       상담 답에 딸려 온 한 번뿐인 지역이지, 평소 찾으시는 동네가 아니기 때문이다.
       이 화면에서 직접 시·도·시·군·구를 바꾸시거나 '이 조건으로 찾기'를 누르시면 그때부터 기억한다 */
    var urlAreaLock = false;
    if (urlSido) {
      selSido.value = urlSido;
      fillSggu(selSggu, urlSido);
      selSggu.value = urlSggu;        /* '' 이면 '시·군·구 전체' 가 골라진다 */
      urlAreaLock = true;
    }

    /* ── 읍·면·동 고르기 ── 받아온 목록 안에 있는 동만 채운다. 서버에 emdongNm 을 보내지 않고,
       이미 받아온 목록을 그 동으로 거르기만 한다(요청이 늘지 않는다) */
    var areaAll = [], areaTotal = 0, areaCode = '', areaSggu = '', emdWant = '', areaTail = '';
    var EMD_LOCK_TXT = '읍·면·동 (시·군·구 먼저)';
    function emdLock() {
      putOpts(selEmd, [['', EMD_LOCK_TXT]]);
      selEmd.disabled = true;
      /* 세종처럼 시·군·구가 없는 시·도에서는 동 고르기 칸을 아예 숨긴다 */
      emdWrap.style.display = selSggu.disabled ? 'none' : '';
      emdHelp.innerHTML = '<b>시·군·구</b>를 고르시면 그 자리에서 <b>읍·면·동</b>까지 바로 고르실 수 있어요.';
    }
    function fillEmd(items) {
      var seen = {}, list = [], opts = [['', '읍·면·동 전체']],
          keep = selEmd.disabled ? emdWant : (selEmd.value || ''), i, d;
      for (i = 0; i < items.length; i++) {
        d = emdOf(items[i]);
        if (d && !seen[d]) { seen[d] = 1; list.push(d); }
      }
      list.sort(function (a, b) { return a < b ? -1 : (a > b ? 1 : 0); });   /* 가나다순 */
      if (!list.length) {                       /* 동 정보가 없으면 칸을 숨긴다 */
        putOpts(selEmd, [['', '읍·면·동 전체']]);
        selEmd.disabled = true;
        emdWrap.style.display = 'none';
        return;
      }
      for (i = 0; i < list.length; i++) opts.push([list[i], list[i]]);
      putOpts(selEmd, opts);
      selEmd.disabled = false;
      if (keep && seen[keep]) selEmd.value = keep;
      emdWrap.style.display = '';
      emdHelp.innerHTML = '<b>‘읍·면·동 전체’</b>로 두시면 고르신 시·군·구 전체를 보여 드려요. <b>동을 고르시면 곧바로</b> 그 동만 추려 드려요.';
    }
    /* keep=true 면 고르셨던 동을 기억해 둔다(같은 시·군·구에서 진료과만 바꾸신 경우 그대로 살린다) */
    function emdReset(keep) {
      if (keep) { if (!selEmd.disabled) emdWant = selEmd.value || ''; }
      else emdWant = '';
      areaAll = []; areaTotal = 0;
      emdLock();
    }
    emdLock();
    /* ── 지역 고르기 칸의 첫 값 ──
       지금 계신 시·도·시·군·구로 맞춰 둔다(placeRegion 이 알려 준다).
       못 알아내면 위에서 읽어 둔 '마지막에 고르셨던 지역'이 그대로 남고, 그것도 없으면 목록 첫 줄이다.
       한 번이라도 직접 손대시면(areaTouched) 다시는 건드리지 않는다 — 고르시던 것을 빼앗으면 안 된다 */
    var areaTouched = false;
    function areaPreset(sc, gc) {
      if (!sc || areaTouched) return;
      if (selSido.value !== sc) { selSido.value = sc; fillSggu(selSggu, sc); }
      selSggu.value = gc || '';          /* '' 이면 '시·군·구 전체' */
      urlAreaLock = false;               /* 지금 계신 곳이다 — 찾으시면 다음에도 기억해 드린다 */
      emdReset(false);
    }
    selSido.addEventListener('change', function () {
      urlAreaLock = false; areaTouched = true;
      fillSggu(selSggu, selSido.value); emdReset(false);
    });
    /* 시·군·구를 고르시면 그 자리에서 곧바로 찾는다 —
       전에는 '이 조건으로 찾기'를 한 번 누르셔야 읍·면·동 칸이 열려 같은 일을 두 번 하셔야 했다 */
    selSggu.addEventListener('change', function () {
      urlAreaLock = false; areaTouched = true; emdReset(false);
      if (selSggu.value) runArea();
    });

    /* 장소 적는 칸 — '장소로 찾기'를 누르시면 열린다 */
    var placeCtl = el('<div class="card" id="nb-place-ctl" style="display:none;">'
      + '<div class="small strong" style="color:var(--primary-dark);">어디 근처에서 찾을까요?</div>'
      + '<p class="small muted" style="margin-top:7px; line-height:1.7;">가실 곳의 이름을 적어 주세요.<br>예: <b>서울역</b> · <b>경복궁</b> · <b>해운대</b></p>'
      + '<input class="input" type="text" id="nb-place-q" placeholder="장소 이름" aria-label="장소 이름" autocomplete="off" style="margin-top:8px;">'
      + '<a class="btn btn-primary btn-block" id="nb-place-go" href="javascript:void(0)" style="margin-top:10px;">🔎 이 장소 둘레에서 찾기</a>'
      + '<p class="small muted" style="margin-top:8px; line-height:1.7;">그곳에서 <b>가까운 순</b>으로 보여 드려요. 내 위치는 쓰지 않아요.</p>'
      + '</div>');
    ctl.insertAdjacentElement('afterend', placeCtl);
    /* 어느 곳을 기준으로 삼았는지 — 같은 이름이 여러 곳이면 '다른 곳'으로 바꾸실 수 있다 */
    var placePick = el('<div class="card" id="nb-place-pick" style="display:none; padding-top:11px; padding-bottom:11px;">'
      + '<div class="row" style="align-items:center; gap:8px;">'
      + '<div class="grow"><div class="small strong" id="nb-place-nm" style="color:var(--primary-dark); line-height:1.6;"></div>'
      + '<div class="tiny muted" id="nb-place-ad" style="margin-top:3px; line-height:1.6;"></div></div>'
      + '<a class="btn btn-outline" id="nb-place-alt" href="javascript:void(0)" style="flex:0 0 auto; min-height:44px; display:none;">다른 곳</a>'
      + '</div></div>');
    placeCtl.insertAdjacentElement('afterend', placePick);
    /* 장소를 못 찾았을 때의 한 줄 — 오류 상자가 아니라 조용한 안내다.
       자리는 지역 고르기 카드보다 '위'다 — 장소를 못 찾아 지역으로 내려갈 때 그 카드가 펼쳐지면서
       이 한 줄이 첫 화면 밖으로 밀려나, 무슨 일이 있었는지 한 글자도 안 보이던 것을 맞춘다 */
    var placeNoteEl = el('<div class="small muted" id="nb-place-note" role="status" aria-live="polite" style="display:none; margin:10px 2px 0; line-height:1.7;"></div>');
    placeBtn.insertAdjacentElement('afterend', placeNoteEl);

    var statusEl = el('<div class="small muted" id="nb-status" role="status" aria-live="polite" style="margin:12px 2px 8px; display:none;"></div>');
    placePick.insertAdjacentElement('afterend', statusEl);
    /* 방향 지도 자리 — 상태 줄 바로 아래, 목록 위. 위치를 쓸 때만 채운다 */
    var dirMapWrap = el('<div id="nb-map" style="display:none;"></div>');
    statusEl.insertAdjacentElement('afterend', dirMapWrap);
    var listWrap = el('<div></div>');
    dirMapWrap.insertAdjacentElement('afterend', listWrap);
    var all = [], shown = 0;
    /* 한 번에 10곳씩만 — 한 화면에 스무 곳이 쏟아지면 눈이 지친다는 말씀이 있었다 */
    var STEP = 10;
    var moreBtn = el('<a class="btn btn-outline btn-block btn-sm" href="javascript:void(0)" style="margin:4px 0 10px; display:none;">10곳 더 보기</a>');
    listWrap.insertAdjacentElement('afterend', moreBtn);

    function fmtDist(km) { return km < 1 ? Math.round(km * 1000) + 'm' : (Math.round(km * 10) / 10) + 'km'; }
    var DIRS8 = ['북', '북동', '동', '남동', '남', '남서', '서', '북서'];
    /* 거리 옆에 방향을 함께 — '북서쪽 1.2km'. 지도를 접어도 방향은 여기 남는다 */
    function distLabel(h) {
      /* 병원 건물 안에서 여실 때 — 거의 같은 자리면 방향은 뜻이 없다('북쪽 0m' 로 적히던 자리) */
      if (h.dist != null && h.dist < 0.05) return '50m 안';
      return (h.dir == null ? '' : DIRS8[h.dir] + '쪽 ') + fmtDist(h.dist);
    }
    /* 고르신 진료과와 이 병원이 어떻게 맞는지 — 0 전문 · 1 진료과 있음 · 2 함께 봄.
       진료과를 안 고르셨거나 치과(종별로 이미 걸러짐)면 모두 0 이라 순서가 달라지지 않는다 */
    function deptTier(h) {
      if (!want || !want[2]) return 0;
      var r = DEPT_NM[want[0]], nm = h.name || '';
      if (!r) return 0;
      if (r[0].test(nm) && !(r[1] && r[1].test(nm))) return 0;
      if (r[2] && r[2] === h.cl) return 0;      /* 종별이 '정신병원' 이면 이름에 없어도 그 과 전문이다 */
      return CL_BIG[h.cl] ? 1 : 2;
    }
    function markTiers(items) {
      for (var i = 0; i < items.length; i++) items[i].tier = deptTier(items[i]);
      return items;
    }
    function tierCmp(a, b) { return (a.tier || 0) - (b.tier || 0); }
    /* 카드에 '왜 이 병원이 나왔는지' 한 마디 — 종별 옆에 붙는다('의원 · 피부과 전문') */
    function deptTag(h) {
      if (!want || !want[2] || !DEPT_NM[want[0]]) return '';
      var t = h.tier == null ? deptTier(h) : h.tier;
      return want[1] + (t === 0 ? ' 전문' : (t === 1 ? ' 진료과가 있어요' : ' 진료도 해요'));
    }
    /* 목록 맨 위 한 줄 — 왜 이런 순서인지 미리 알려 드린다(놀라지 않으시게) */
    function deptNote() {
      if (!want || !want[2] || !DEPT_NM[want[0]]) return;
      listWrap.appendChild(el('<div class="banner banner--info"><span class="b-ic">💡</span><div class="small">'
        + '<b>' + want[1] + '</b>를 고르셨어요. <b>' + want[1] + ' 전문</b>인 곳을 먼저 보여 드리고, '
        + '그 아래는 ' + want[1] + ' 진료도 <b>함께 보는 곳</b>이에요.</div></div>'));
    }
    function renderMore() {
      var next = all.slice(shown, shown + STEP), from = shown;
      next.forEach(function (h, ni) {
        var c = tmpl ? tmpl.cloneNode(true) : el('<div class="hosp"></div>');
        var nm = $('.hosp-name', c), ty = $('.tiny.muted', c), di = $('.hosp-dist', c);
        if (nm) nm.textContent = h.name;
        if (ty) { var tg = deptTag(h); ty.textContent = h.cl + (tg ? ' · ' + tg : ''); }
        if (di) { if (h.dist != null) di.textContent = distLabel(h); else di.style.display = 'none'; }
        $$('.hosp-no', c).forEach(function (o) { o.parentNode.removeChild(o); });   /* 시안 틀에 들어 있던 번호는 지운다 */
        /* 지도의 마커와 같은 번호. 누르면 지도가 그 병원으로 간다(카카오맵이 떴을 때만 — paintNo 가 켜 준다).
           누르는 자리는 44px, 보이는 동그라미는 30px — 카드가 번호로 두꺼워지지 않게 둘레 여백을 되돌린다 */
        var idx = from + ni;
        var top = $('.hosp-top', c) || c;
        var hit = el('<span class="nb-no-hit"></span>');
        hit.setAttribute('data-nb-no', String(idx));
        hit.setAttribute('data-nb-nm', h.name || '');
        hit.style.cssText = 'flex:0 0 auto; display:inline-flex; align-items:center; justify-content:center;'
          + ' width:44px; height:44px; margin:-7px -3px -7px -7px; -webkit-tap-highlight-color:transparent;';
        var noEl = el('<span class="hosp-no" aria-hidden="true"></span>');
        noEl.style.cssText = 'flex:0 0 auto; display:inline-flex; align-items:center; justify-content:center;'
          + ' min-width:30px; height:30px; padding:0 6px; border-radius:999px;'
          + ' background:var(--primary-tint); color:var(--primary-dark); font-size:14px; font-weight:800;';
        noEl.textContent = String(idx + 1);
        hit.appendChild(noEl);
        top.insertBefore(hit, top.firstChild);
        c.setAttribute('data-nb-i', String(idx));
        armNo(hit, idx);
        armCard(c, idx);          /* 번호뿐 아니라 카드 아무 데나 누르셔도 지도가 간다 */
        var metas = $$('.hosp-meta > div', c);
        if (metas[0]) metas[0].innerHTML = '<span class="k">주소</span>' + '';
        if (metas[0]) metas[0].appendChild(document.createTextNode(h.addr || '주소 정보 없음'));
        if (metas[1]) { metas[1].innerHTML = '<span class="k">전화</span>'; metas[1].appendChild(document.createTextNode(h.tel || '정보 없음')); }
        if (metas[2]) metas[2].style.display = 'none';
        var btns = $$('a.btn', c);
        if (btns[0]) {
          if (h.tel) btns[0].setAttribute('href', 'tel:' + h.tel.replace(/[^0-9+]/g, ''));
          else { btns[0].style.opacity = '.5'; btns[0].addEventListener('click', function (e) { e.preventDefault(); toast('전화번호 정보가 없어요.'); }); }
        }
        if (btns[1]) btns[1].addEventListener('click', function (e) { e.preventDefault(); mapPop(h); });
        if (btns[2]) btns[2].addEventListener('click', function (e) {
          e.preventDefault();
          var txt = h.name + ' ' + (h.addr || '');
          try {
            if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(function () { toast('주소를 복사했어요.'); }, function () { toast('복사하지 못했어요.'); });
            else toast('복사 기능을 쓸 수 없어요.');
          } catch (e2) { toast('복사하지 못했어요.'); }
        });
        listWrap.appendChild(c);
      });
      shown += next.length;
      paintNo(); paintPick();          /* 더 그린 칸에도 같은 차림을 입힌다 */
      moreBtn.textContent = Math.min(STEP, all.length - shown) + '곳 더 보기';
      moreBtn.style.display = shown < all.length ? '' : 'none';
    }
    moreBtn.addEventListener('click', function (e) { e.preventDefault(); renderMore(); });

    /* ═══ 앱이 직접 그리는 방향 지도 — 카카오맵을 못 불러올 때의 대비책(fallback) ═══
       평소에는 아래 drawMap() 이 카카오맵(진짜 지도)을 보여 준다.
       키가 거부되거나 인터넷이 끊겨 지도가 뜨지 않으면 조용히 이 그림으로 되돌아간다(지우지 말 것).
       방위와 거리만 앱 안에서 SVG 로 그린다 — 위치가 밖으로 나가지 않는다. 가운데가 내 위치, 위쪽이 북쪽,
       동그라미는 안쪽부터 500m · 1km · 3km(읍·면은 1km · 5km · 10km). 바깥 동그라미를 넘는 곳은 테두리에 붙여 '3km+' 로 알린다.
       위치를 쓸 수 없을 때(동의 안 함 · 권한 거부 · 지역으로 찾기)는 아예 그리지 않는다 — 거리 기준이 없다. */
    /* 지도는 늘 펴 둔다 — '지도 접기' 단추는 없앴다.
       예전에 접어 두신 분의 기기에는 'todak_nearby_map' 이 '0' 으로 남아 있다.
       이제 그 값을 읽지 않고 한 번 지워 둔다 — 옛 값 때문에 지도가 안 뜨는 일이 없게. */
    try { localStorage.removeItem('todak_nearby_map'); } catch (e0) {}
    var MVW = 320, MVH = 230, MCX = 160, MCY = 115, MR3 = 90, MDOT = 10, MGAP = 22;
    /* 동그라미 눈금(km) — 보통은 500m · 1km · 3km. 읍·면처럼 가까운 곳이 모두 3km 를 넘으면
       drawDirMap 이 5km · 10km 로 넓힌다(다 테두리에 붙어 방향만 남는 그림이 되지 않게) */
    var MRING = [0.5, 1, 3];
    /* 거리 → 반지름. 가까운 곳이 가운데 한 점에 뭉치지 않도록 제곱근으로 편다(안쪽이 넓다) */
    function mapR(km) { return km >= MRING[2] ? MR3 : MR3 * Math.sqrt(km / MRING[2]); }
    function mEsc(s) {
      return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    /* 지우기까지 한다 — 지난 검색의 지도가 남아 있으면 안 된다(지역으로 찾기·위치 거부일 때) */
    function hideDirMap() {
      kMark = null; kMove = null; kHas = null; pickI = -1;
      mapSeq++; dirMapWrap.style.display = 'none'; dirMapWrap.innerHTML = '';
    }
    /* 점을 누르면 그 병원 카드로 내려간다. 그 칸을 돌려준다(아직 안 그렸으면 더 그려서라도) */
    function gotoCard(i) {
      while (shown <= i && shown < all.length) renderMore();
      var c = listWrap.querySelector('[data-nb-i="' + i + '"]');
      if (!c) return null;
      try { c.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { c.scrollIntoView(); }
      return c;
    }
    /* 방향 지도(카카오가 안 될 때)에서 점을 눌렀을 때 — 잠깐 테두리로 짚어 준다.
       카카오맵일 때는 아래 setPick 이 '고른 병원' 테두리를 계속 둔다(잠깐이 아니라) */
    function flashCard(i) {
      var c = gotoCard(i);
      if (!c || pickI === i) return;
      c.style.outline = '3px solid var(--primary)';
      c.style.outlineOffset = '2px';
      c.__flash = 1;
      setTimeout(function () {
        c.__flash = 0;
        if (pickI !== i) { c.style.outline = ''; c.style.outlineOffset = ''; }
      }, 2200);
    }

    /* ═══ 목록 → 지도 ═══
       목록에서 번호를 누르시면 지도가 그 병원으로 옮겨가 확대되고, 그 마커가 커진다.
       · 누르는 자리는 번호 배지다 — 카드 전체를 누르게 하면 카드 안의 '전화 · 길찾기 · 주소복사' 와 부딪힌다.
       · 카카오맵이 떴을 때만 눌린다. 방향 지도(폴백)나 지도가 없을 때는 role/tabindex 도 주지 않아
         읽어 주는 기계도 '단추'라고 말하지 않는다 — 눌러도 아무 일이 없어 답답하지 않게.
       · 한 번 더 누르면 고른 것이 풀리고 지도는 처음 크기로 돌아간다. */
    var pickI = -1;                   /* 지금 고른 병원(목록 차례). -1 이면 고른 것 없음 */
    var kMark = null, kMove = null;   /* 카카오맵이 채워 준다 — 마커 키우기 · 그 병원으로 옮기기 */
    var kHas = null;                  /* 그 번호가 지도에 찍혀 있는가 — 지도는 가까운 열 곳만 찍는다 */
    /* 11번 아래는 지도에 없다. 눌러도 아무 일이 없어야 하고, 단추처럼 보여도 안 된다 */
    function mapLive(idx) { return !!kMove && (idx == null || (!!kHas && kHas(idx))); }
    function paintPick() {            /* 목록에서도 고른 칸이 보이게 테두리 */
      var cs = $$('[data-nb-i]', listWrap), i, c, ci, on;
      for (i = 0; i < cs.length; i++) {
        c = cs[i];
        ci = parseInt(c.getAttribute('data-nb-i'), 10);
        on = ci === pickI;
        /* 카드를 누르면 지도가 간다 — 누를 수 있을 때만 손가락 모양으로 */
        c.style.cursor = mapLive(ci) ? 'pointer' : '';
        if (!on && c.__flash) continue;          /* 방향 지도에서 잠깐 짚어 둔 칸은 건드리지 않는다 */
        c.style.outline = on ? '3px solid var(--primary)' : '';
        c.style.outlineOffset = on ? '2px' : '';
      }
    }
    function paintNo() {              /* 번호 배지 — 누를 수 있을 때만 단추처럼 보이게 */
      var ns = $$('.nb-no-hit', listWrap), i, hit, dot, idx, live;
      for (i = 0; i < ns.length; i++) {
        hit = ns[i];
        dot = hit.firstChild;
        idx = parseInt(hit.getAttribute('data-nb-no'), 10);
        live = mapLive(idx);
        if (live) {
          hit.setAttribute('role', 'button');
          hit.setAttribute('tabindex', '0');
          hit.setAttribute('aria-label', (idx + 1) + '번 ' + (hit.getAttribute('data-nb-nm') || '')
            + (idx === pickI ? ' — 지도에서 보고 있어요. 다시 누르면 지도가 처음으로 돌아가요'
                             : ' 지도에서 보기'));
          hit.style.cursor = 'pointer';
        } else {
          hit.removeAttribute('role'); hit.removeAttribute('tabindex'); hit.removeAttribute('aria-label');
          hit.style.cursor = '';
        }
        if (!dot) continue;
        dot.style.border = live ? '1.5px solid var(--primary)' : '';
        if (idx === pickI) { dot.style.background = 'var(--primary-dark)'; dot.style.color = 'var(--white)'; }
        else { dot.style.background = 'var(--primary-tint)'; dot.style.color = 'var(--primary-dark)'; }
      }
    }
    /* idx < 0 이면 고른 것을 푼다(지도는 처음 크기로 되돌아간다)
       toList = 목록을 그 칸으로 내린다(지도 마커를 눌렀을 때)
       toMap  = 지도를 그 병원으로 옮긴다(목록 번호를 눌렀을 때) */
    function setPick(idx, toList, toMap) {
      pickI = idx;
      if (toList && idx > -1) gotoCard(idx);   /* 칸이 아직 없으면 더 그린다 — 먼저 */
      paintPick(); paintNo();
      if (kMark) kMark(idx);
      if (toMap && kMove) kMove(idx);
    }
    /* 목록에서 번호를 누르셨을 때 지도가 화면 밖(위쪽)에 있으면 지도를 보여 드린다 —
       지도에서 무슨 일이 일어났는지 안 보이면 누른 보람이 없다 */
    function showMapTop() {
      if (dirMapWrap.style.display === 'none') return;
      var b;
      try { b = dirMapWrap.getBoundingClientRect(); } catch (e) { return; }
      var vh = window.innerHeight || document.documentElement.clientHeight || 0;
      if (b.top >= 0 && b.bottom <= vh) return;      /* 이미 다 보인다 — 건드리지 않는다 */
      try { dirMapWrap.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
      catch (e2) { dirMapWrap.scrollIntoView(); }
    }
    function armNo(hit, idx) {
      function go(ev) {
        if (ev && ev.preventDefault) ev.preventDefault();
        if (!mapLive(idx)) return;                   /* 지도가 없거나 지도에 없는 번호면 아무 일도 없다 */
        setPick(idx === pickI ? -1 : idx, false, true);
        showMapTop();
      }
      hit.addEventListener('click', go);
      hit.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' || ev.key === ' ' || ev.keyCode === 13 || ev.keyCode === 32) go(ev);
      });
    }
    /* 카드 아무 데나 누르시면 지도가 그 병원으로 간다 — 번호만 누르기는 손이 저리신 분께 너무 작다.
       다만 카드 안의 '전화 · 길찾기 · 주소복사' 와 번호 배지는 제 일을 그대로 한다:
       누르신 자리에서 카드까지 거슬러 올라가며 그 단추들을 만나면 지도를 건드리지 않고 물러난다.
       읽어 주는 기계·키보드용 단추는 번호 배지에 그대로 둔다(카드 안에 링크가 셋이라 카드를
       통째로 단추로 만들면 읽는 차례가 엉킨다) */
    function armCard(card, idx) {
      card.addEventListener('click', function (ev) {
        var n = ev.target, tn, cn;
        while (n && n !== card) {
          tn = String(n.tagName || '').toUpperCase();
          if (tn === 'A' || tn === 'BUTTON' || tn === 'INPUT' || tn === 'SELECT' || tn === 'TEXTAREA') return;
          cn = (n.getAttribute && n.getAttribute('class')) || '';
          if (String(cn).indexOf('nb-no-hit') > -1) return;    /* 번호 배지는 제 손잡이가 따로 있다 */
          n = n.parentNode;
        }
        if (!mapLive(idx)) return;                 /* 지도가 없거나 지도에 없는 번호면 아무 일도 없다 */
        if (ev.preventDefault) ev.preventDefault();
        setPick(idx === pickI ? -1 : idx, false, true);
        showMapTop();
      });
    }
    function drawDirMap() {
      var pick = [], far = [], busy = [], i, h, p, s;
      for (i = 0; i < all.length && i < 10; i++) {
        h = all[i];
        if (h.dist == null || h.dir == null) continue;
        pick.push({ i: i, no: i + 1, name: h.name, km: h.dist, brg: h.brg, dir: h.dir, x: MCX, y: MCY });
      }
      if (!pick.length) { hideDirMap(); return; }
      /* 읍·면 — 가까운 곳이 하나도 3km 안에 없으면 동그라미를 넓힌다. 가장 먼 곳에 맞춰 5km 나 10km */
      MRING = [0.5, 1, 3];
      var near0 = 1e9, far0 = 0;
      for (i = 0; i < pick.length; i++) {
        if (pick[i].km < near0) near0 = pick[i].km;
        if (pick[i].km > far0) far0 = pick[i].km;
      }
      if (near0 > 3) MRING = (far0 <= 5) ? [1, 3, 5] : [1, 5, 10];
      var r05 = mapR(MRING[0]), r1 = mapR(MRING[1]);
      var ringLab = [fmtDist(MRING[0]), fmtDist(MRING[1]), fmtDist(MRING[2])];
      function freeAt(qx, qy, skip) {  /* 가장 빠듯한 자리와의 여유 — 음수면 겹친다 (skip: 자기 자리는 빼고) */
        var m = 1e9, k, dx, dy, d;
        for (k = 0; k < busy.length; k++) {
          if (k === skip) continue;
          dx = qx - busy[k].x; dy = qy - busy[k].y;
          d = Math.sqrt(dx * dx + dy * dy) - busy[k].g;
          if (d < m) m = d;
        }
        return m;
      }
      /* 겹치면 '살짝' 만 민다 — 방향은 18도, 거리는 '실제 거리의 25% 안' 에서.
         그림 단위 고정값(16)으로 밀면 가운데 가까운 점이 두 배 넘게 멀어 보인다(470m 가 990m 자리로). */
      var DA = [0, 5, -5, 9, -9, 13, -13, 18, -18];
      function spot(q, skip) {         /* 이 병원을 놓을 가장 나은 자리 — 제자리가 비어 있으면 제자리 그대로 */
        var a2 = q.brg * Math.PI / 180, r2 = mapR(q.km);
        /* 밀 수 있는 폭도 거리에 비례 — 안쪽 점은 조금만. 내 위치와 같은 자리면 가운데 표시 밖으로만 */
        var rMax = Math.min(MR3, Math.max(mapR(q.km * 1.25), q.km < 0.05 ? MGAP : 0));
        var dRm = rMax - r2, DRq = [0, dRm / 3, dRm * 2 / 3, dRm];
        var bx = MCX + r2 * Math.sin(a2), by = MCY - r2 * Math.cos(a2), bf = freeAt(bx, by, skip);
        var ca, cr, qx2, qy2, cf, j2, k2;
        for (j2 = 0; j2 < DRq.length && bf < 0; j2++) {
          for (k2 = 0; k2 < DA.length; k2++) {
            ca = a2 + DA[k2] * Math.PI / 180;
            cr = Math.min(MR3, r2 + DRq[j2]);
            qx2 = MCX + cr * Math.sin(ca); qy2 = MCY - cr * Math.cos(ca);
            cf = freeAt(qx2, qy2, skip);
            if (cf > bf) { bf = cf; bx = qx2; by = qy2; }
            if (bf >= 0) break;
          }
        }
        return [bx, by];
      }
      function place(list) {
        busy.length = 0;
        busy.push({ x: MCX, y: MCY, g: 20 });        /* 가운데 = 내 위치 */
        var i2, pass, xy;
        for (i2 = 0; i2 < list.length; i2++) {
          xy = spot(list[i2], -1);
          list[i2].x = xy[0]; list[i2].y = xy[1];
          busy.push({ x: xy[0], y: xy[1], g: MGAP });
        }
        /* 다 놓은 뒤 두어 번 더 고른다 — 먼저 놓인 점이 자리를 차지해 뒤엣것이 겹쳐 버리는 것을 줄인다
           (자기 자리를 뺀 채 다시 고르므로 가장 좁은 간격이 좁아지지 않는다) */
        for (pass = 0; pass < 3; pass++) {
          for (i2 = 0; i2 < list.length; i2++) {
            xy = spot(list[i2], i2 + 1);
            list[i2].x = busy[i2 + 1].x = xy[0];
            list[i2].y = busy[i2 + 1].y = xy[1];
          }
        }
      }
      function minGap(list) {          /* 점 사이 가장 좁은 간격(가운데 사이 거리) */
        var m = 1e9, a3, b3, dx3, dy3, d3;
        for (a3 = 0; a3 < list.length; a3++) {
          for (b3 = a3 + 1; b3 < list.length; b3++) {
            dx3 = list[a3].x - list[b3].x; dy3 = list[a3].y - list[b3].y;
            d3 = Math.sqrt(dx3 * dx3 + dy3 * dy3);
            if (d3 < m) m = d3;
          }
        }
        return m;
      }
      place(pick);
      /* 도심처럼 한 방향에 몰려 밀어낼 자리가 없으면(점 지름 20px 도 못 벌어지면) 가까운 6곳만 그린다 —
         번호가 가려 안 보이고 누르면 엉뚱한 병원이 잡히느니, 나머지는 아래 목록에서 보시는 편이 낫다 */
      var capped = false;
      if (pick.length > 6 && minGap(pick) < 20) { pick = pick.slice(0, 6); place(pick); capped = true; }
      for (i = 0; i < pick.length; i++) if (pick[i].km > MRING[2]) far.push(pick[i].no);
      /* 거리 눈금은 눈금마다 따로 '가장 빈 자리' 를 고른다 — 점은 제자리를 지키고,
         눈금은 점보다 나중에(위에) 흰 테두리와 함께 그려 번호도 눈금도 읽히게 한다.
         바깥 눈금(3km·5km·10km)은 테두리 선 위 네 대각선 자리 가운데 하나에 — 가로로 두면 '동'·'서' 글자와
         12px 밖에 안 떨어져 '동쪽 3km' 처럼 한 방향의 거리로 잘못 읽힌다. */
      var MDG = MR3 * 0.7071;
      function labFree(cx, cy, hw) {   /* 그 자리에 눈금을 적으면 가장 가까운 점과 얼마나 남는지 — 클수록 빈자리 */
        var m = 1e9, q, v;
        for (q = 0; q < pick.length; q++) {
          v = Math.max(Math.abs(pick[q].x - cx) - (hw + MDOT), Math.abs(pick[q].y - cy) - (9 + MDOT));
          if (v < m) m = v;
        }
        return m;
      }
      /* 눈금마다 따로 빈자리를 고른다 — 셋을 한 덩어리로 고르면 한 눈금이 점에 정확히 가려도 그대로 간다 */
      function labPick(cand, hw) {
        var best = cand[0], bv = -1e9, k3, v;
        for (k3 = 0; k3 < cand.length; k3++) {
          v = labFree(cand[k3][0], cand[k3][1], hw);
          if (v > bv) { bv = v; best = cand[k3]; }
        }
        return best;
      }
      var lp0 = labPick([[MCX - r05, MCY - 6], [MCX + r05, MCY - 6]], 18);
      var lp1 = labPick([[MCX - r1, MCY + 16], [MCX + r1, MCY + 16]], 14);
      /* 바깥 눈금은 테두리 선 위 네 대각선 자리 가운데 가장 빈 곳 */
      var lp2 = labPick([[MCX - MDG, MCY - MDG], [MCX + MDG, MCY - MDG],
                         [MCX - MDG, MCY + MDG], [MCX + MDG, MCY + MDG]], 18);
      var lab = 'font-size:13px;font-weight:700;fill:var(--on-surface-variant);'
        + 'paint-order:stroke;stroke:var(--white);stroke-width:3.5;stroke-linejoin:round';
      var dlab = 'font-size:13px;font-weight:800;fill:var(--primary-dark)';
      s = '<svg id="nb-map-svg" viewBox="0 0 ' + MVW + ' ' + MVH + '" role="img"'
        + ' data-cx="' + MCX + '" data-cy="' + MCY + '" data-r3="' + MR3 + '"'
        + ' aria-label="' + mEsc(originNm() + '에서 가까운 병원 ' + pick.length + '곳의 방향과 거리를 그린 지도예요. '
          + '가운데가 ' + originNm() + ', 위쪽이 북쪽이고, 동그라미는 안쪽부터 ' + ringLab.join(' · ') + '예요.') + '"'
        + ' style="display:block; width:100%; height:auto; cursor:pointer; touch-action:manipulation;">';
      s += '<circle cx="' + MCX + '" cy="' + MCY + '" r="' + MR3 + '" style="fill:var(--primary-tint);stroke:var(--outline-strong);stroke-width:1.4"></circle>';
      s += '<circle cx="' + MCX + '" cy="' + MCY + '" r="' + r1.toFixed(1) + '" style="fill:none;stroke:var(--outline);stroke-width:1.2;stroke-dasharray:4 4"></circle>';
      s += '<circle cx="' + MCX + '" cy="' + MCY + '" r="' + r05.toFixed(1) + '" style="fill:none;stroke:var(--outline);stroke-width:1.2;stroke-dasharray:4 4"></circle>';
      s += '<line x1="' + MCX + '" y1="' + (MCY - MR3) + '" x2="' + MCX + '" y2="' + (MCY + MR3) + '" style="stroke:var(--outline);stroke-width:1"></line>';
      s += '<line x1="' + (MCX - MR3) + '" y1="' + MCY + '" x2="' + (MCX + MR3) + '" y2="' + MCY + '" style="stroke:var(--outline);stroke-width:1"></line>';
      s += '<text x="' + MCX + '" y="16" text-anchor="middle" style="' + dlab + '">북</text>';
      s += '<text x="' + MCX + '" y="' + (MVH - 5) + '" text-anchor="middle" style="' + dlab + '">남</text>';
      s += '<text x="' + (MVW - 6) + '" y="' + (MCY + 5) + '" text-anchor="end" style="' + dlab + '">동</text>';
      s += '<text x="6" y="' + (MCY + 5) + '" text-anchor="start" style="' + dlab + '">서</text>';
      s += '<circle cx="' + MCX + '" cy="' + MCY + '" r="8" style="fill:var(--white)"></circle>';
      s += '<circle cx="' + MCX + '" cy="' + MCY + '" r="5.5" style="fill:var(--primary-dark)"></circle>';
      for (i = 0; i < pick.length; i++) {          /* 바깥 동그라미를 넘는 곳은 테두리 밖으로 짧은 선을 그어 알린다 */
        p = pick[i];
        if (p.km <= MRING[2]) continue;
        var fa = Math.atan2(p.x - MCX, MCY - p.y);
        s += '<line x1="' + (MCX + (MR3 + 3) * Math.sin(fa)).toFixed(1) + '" y1="' + (MCY - (MR3 + 3) * Math.cos(fa)).toFixed(1)
          + '" x2="' + (MCX + (MR3 + 12) * Math.sin(fa)).toFixed(1) + '" y2="' + (MCY - (MR3 + 12) * Math.cos(fa)).toFixed(1)
          + '" style="stroke:var(--primary-dark);stroke-width:2.5;stroke-linecap:round"></line>';
      }
      if (far.length) s += '<text x="' + (MVW - 5) + '" y="18" text-anchor="end" style="' + dlab + '">' + ringLab[2] + '+</text>';
      for (i = 0; i < pick.length; i++) {
        p = pick[i];
        s += '<g class="nb-dot"><circle cx="' + p.x.toFixed(1) + '" cy="' + p.y.toFixed(1) + '" r="' + MDOT
          + '" style="fill:var(--primary);stroke:var(--white);stroke-width:2"></circle>'
          + '<text x="' + p.x.toFixed(1) + '" y="' + (p.y + 4.7).toFixed(1) + '" text-anchor="middle"'
          + ' style="font-size:13px;font-weight:800;fill:var(--white)">' + p.no + '</text>'
          + '<title>' + mEsc(p.no + '번 ' + p.name + ' · ' + distLabel({ dist: p.km, dir: p.dir })) + '</title></g>';
      }
      /* 거리 눈금은 점 뒤에 — 흰 테두리(paint-order)를 두르고 점 위에 얹어야 둘 다 읽힌다 */
      s += '<text x="' + lp0[0].toFixed(1) + '" y="' + lp0[1].toFixed(1) + '" text-anchor="middle" style="' + lab + '">' + ringLab[0] + '</text>';
      s += '<text x="' + lp1[0].toFixed(1) + '" y="' + lp1[1].toFixed(1) + '" text-anchor="middle" style="' + lab + '">' + ringLab[1] + '</text>';
      s += '<text x="' + lp2[0].toFixed(1) + '" y="' + (lp2[1] + 4).toFixed(1) + '" text-anchor="middle" style="' + lab + '">' + ringLab[2] + '</text>';
      s += '<rect x="0" y="0" width="' + MVW + '" height="' + MVH + '" style="fill:none;pointer-events:all"></rect>';
      s += '</svg>';
      /* 이 한 줄은 그림의 '눈금 설명'이라 남긴다 — 동그라미가 몇 km 인지 모르면 그림을 읽을 수 없다.
         (카카오 지도가 안 뜰 때만 나오는 대비책 그림이다) */
      var cap = '동그라미는 안쪽부터 <b>' + ringLab.join(' · ') + '</b>예요. 가운데 진한 점이 <b>'
        + (isPlace() ? mEsc(originNm()) : '내 위치') + '</b>, 위쪽이 <b>북쪽</b>이에요.';
      if (capped) cap += '<br>가까운 6곳만 그렸어요. 나머지는 아래 목록에서 보세요.';
      /* 다 테두리에 붙었으면 번호를 하나하나 부르지 않는다 — 열 줄짜리 설명은 읽기 힘들다 */
      if (far.length) cap += '<br>테두리에 붙은 점(<b>' + ringLab[2] + '+</b>)은 '
        + (far.length === pick.length ? '모두 ' + ringLab[2] + '보다 먼 곳이에요.'
          : ringLab[2] + '보다 먼 곳이에요 — ' + far.join('번 · ') + '번.');
      dirMapWrap.innerHTML = '<div class="card" style="padding-top:12px; padding-bottom:12px;">'
        + '<div class="small strong" style="color:var(--primary-dark);">'
        + (isPlace() ? (mEsc(originNm()) + '에서 보는 방향') : '내 위치에서 보는 방향') + '</div>'
        + '<div id="nb-map-body" style="margin-top:10px;">' + s
        + '<p class="small muted" id="nb-map-cap" style="margin-top:8px; line-height:1.7;">' + cap + '</p>'
        + '</div></div>';
      dirMapWrap.style.display = '';
      $('#nb-map-svg', dirMapWrap).addEventListener('click', function (e) {
        var svg = this, box = svg.getBoundingClientRect(), k, qx, qy, bi = -1, bd = 34 * 34, dd;
        if (!box.width || !box.height) return;
        var sx = (e.clientX - box.left) * MVW / box.width, sy = (e.clientY - box.top) * MVH / box.height;
        for (k = 0; k < pick.length; k++) {     /* 가장 가까운 점을 고른다 — 점 사이를 눌러도 헛손질이 없다 */
          qx = pick[k].x - sx; qy = pick[k].y - sy; dd = qx * qx + qy * qy;
          if (dd < bd) { bd = dd; bi = pick[k].i; }
        }
        if (bi > -1) flashCard(bi);
      });
    }

    /* ═══ 진짜 지도 — 카카오맵 ═══
       내 위치를 가운데에 두고 병원마다 번호를 찍는다. 번호를 누르면 아래 그 병원 칸으로 내려간다(방향 지도와 같다).
       지도를 그리는 동안 카카오에 그 순간의 위치가 전달된다 — 처리방침 25 에 적어 두었다.
       병원 목록을 받아올 때는 지역 코드만 쓰고 좌표를 보내지 않는다(그 원칙은 그대로다).
       지도를 못 불러오면(키 거부·도메인 미등록·인터넷 끊김) 위의 drawDirMap 으로 조용히 되돌아간다.
       손가락으로 끌어 옮기실 수 있다(setDraggable(true)). 지도 높이를 화면의 3분의 1 아래로 잡아
       지도 위·아래 여백에서 화면을 내리실 수 있게 했다 — 지도 안에 갇히지 않으시게.
       크게·작게는 지도 안 오른쪽 아래 ＋－ 상자에서 하신다(각 46px). */
    /* 지도 당김 정도(카카오 level — 숫자가 작을수록 크게 보인다).
       LV_PICK: 목록에서 한 곳을 고르셨을 때. 전에는 3(50m 자)이라 건물 한 채만 꽉 차서
                '여기가 어디쯤인지' 알 수 없다는 말씀이 있었다 — 두 단계 풀어 둘레 길이 보이게 한다.
       LV_MIN : 처음 테두리를 맞출 때 이보다 더 당기지 않는다(한 곳뿐일 때 지나치게 당겨지던 것) */
    var LV_PICK = 5, LV_MIN = 4;
    var myY = null, myX = null;       /* 이번 검색에 쓴 내 위치 — 지도 가운데에만 쓰고 저장하지 않는다 */
    var mapSeq = 0;                   /* 늦게 도착한 지도가 다음 검색 화면을 덮지 않게 */
    var KSDK = 0, kWait = [];         /* 0 아직 · 1 넣는 중 · 2 됨 · 3 안 됨 */
    var KSVC = false;                 /* 장소 검색(services)까지 실려 왔는지 — 지도와 따로 본다 */
    function kakaoReady(cb) {         /* 카카오 지도 스크립트는 처음 한 번만 넣는다 */
      if (KSDK === 2) { cb(true); return; }
      if (KSDK === 3) { cb(false); return; }
      kWait.push(cb);
      if (KSDK === 1) return;
      KSDK = 1;
      var key = CFG.kakaoJsKey, sc = null, t = null;
      function done(ok) {
        if (KSDK === 2 || KSDK === 3) return;
        KSDK = ok ? 2 : 3;
        if (t) clearTimeout(t);
        var q = kWait, i;
        kWait = [];
        for (i = 0; i < q.length; i++) { try { q[i](ok); } catch (e) {} }
      }
      if (!key) { done(false); return; }
      t = setTimeout(function () { done(false); }, 8000);
      try {
        sc = document.createElement('script');
        sc.async = true;
        /* libraries=services 는 '장소로 찾기'(키워드 검색·좌표→지역)에 쓴다.
           이 라이브러리가 빠져 와도 지도는 그대로 뜬다 — 아래에서 따로 확인한다 */
        sc.src = 'https://dapi.kakao.com/v2/maps/sdk.js?appkey=' + encodeURIComponent(key) + '&autoload=false&libraries=services';
        sc.onload = function () {
          try {
            var k = window.kakao;
            if (!k || !k.maps || !k.maps.load) { done(false); return; }
            k.maps.load(function () {
              var m = window.kakao && window.kakao.maps;
              KSVC = !!(m && m.services && m.services.Places && m.services.Geocoder && m.services.Status);
              done(!!(m && m.Map && m.LatLng && m.LatLngBounds && m.CustomOverlay));
            });
          } catch (e) { done(false); }
        };
        sc.onerror = function () { done(false); };
        (document.head || document.documentElement).appendChild(sc);
      } catch (e2) { done(false); }
    }

    /* ═══ 장소로 찾기 — 카카오 장소 검색(services) ═══
       '서울역' 처럼 가실 곳을 적으시면 그 곳의 좌표를 받아, 그 곳을 가운데에 두고 가까운 순으로 보여 드린다.
       · 심평원(병원 목록)에 보내는 것은 여전히 지역 코드뿐이다 — 좌표는 지도와 거리 계산에만 쓴다(내 위치 기준과 같다).
       · 카카오가 안 되면(열쇠 없음·도메인 미등록·스크립트 실패) 조용히 지역/내 위치 갈래로 떨어진다. */
    var PLACE_MAX = 5;                /* 같은 이름이 여러 곳이면 위에서 다섯 곳까지만 보여 드린다 */
    function placeCut(v, n) {         /* 화면에 넣을 이름 — 너무 길면 줄인다 */
      var t = String(v == null ? '' : v);
      return t.length > n ? t.slice(0, n) + '…' : t;
    }
    function placeTrim(v) { return String(v == null ? '' : v).replace(/\s+/g, ' ').trim(); }
    /* 받침에 맞춰 조사를 고른다 — '코스트코를' · '서울역을'.
       한글이 아닌 글자로 끝나면(숫자·영문·줄임표) 두 가지를 함께 적는다 */
    function josa(v, withB, noB) {
      var t = String(v == null ? '' : v), c;
      if (!t) return noB;
      c = t.charCodeAt(t.length - 1);
      if (c >= 0xAC00 && c <= 0xD7A3) return ((c - 0xAC00) % 28) ? withB : noB;
      return withB + '(' + noB + ')';
    }
    function placeSearch(q, cb) {     /* cb(목록) · 못 찾거나 카카오가 안 되면 cb(null) — 오류 문구는 띄우지 않는다 */
      kakaoReady(function (ok) {
        var K = (ok && window.kakao && window.kakao.maps) || null;
        if (!K || !KSVC) { cb(null); return; }
        var fin = false, t = null;
        function give(v) { if (fin) return; fin = true; if (t) clearTimeout(t); cb(v); }
        t = setTimeout(function () { give(null); }, 8000);
        try {
          new K.services.Places().keywordSearch(q, function (data, st) {
            if (st !== K.services.Status.OK || !data || !data.length) { give(null); return; }
            var out = [], i, d, y, x;
            for (i = 0; i < data.length && out.length < PLACE_MAX; i++) {
              d = data[i];
              y = parseFloat(d.y); x = parseFloat(d.x);
              if (!isFinite(y) || !isFinite(x)) continue;
              out.push({ name: placeTrim(d.place_name) || q,
                         addr: placeTrim(d.road_address_name || d.address_name || ''),
                         y: y, x: x });
            }
            give(out.length ? out : null);
          });
        } catch (e) { give(null); }
      });
    }
    /* 카카오가 주는 시·군·구 이름을 우리 표(SGGU_RAW)의 코드로 — sgguResolve 가 먼저 받아 보고,
       '수원시 영통구'처럼 시 안의 구까지 함께 오면 앞의 시 이름으로 한 번 더 본다.
       그래도 못 맞추면 ''(시·도 전체) — 어차피 거리순으로 세우므로 보여 드리는 차례는 달라지지 않는다 */
    function placeSggu(sidoCd, v) {
      var t = placeTrim(v), c, sp;
      if (!t) return '';
      c = sgguResolve(sidoCd, t);
      if (c) return c;
      sp = t.indexOf(' ');
      if (sp > 0) { c = sgguResolve(sidoCd, t.slice(0, sp)); if (c) return c; }
      return '';
    }
    /* 좌표 → 시·도·시·군·구 코드. 못 알아내면 ('', '') — 그때는 휴대폰 안에서 판정한 sidoRank 를 그대로 쓴다 */
    function placeRegion(y, x, cb) {
      kakaoReady(function (ok) {
        var K = (ok && window.kakao && window.kakao.maps) || null;
        if (!K || !KSVC) { cb('', ''); return; }
        var fin = false, t = null;
        function give(a, b) { if (fin) return; fin = true; if (t) clearTimeout(t); cb(a, b); }
        t = setTimeout(function () { give('', ''); }, 4000);
        try {
          new K.services.Geocoder().coord2RegionCode(x, y, function (res, st) {
            if (st !== K.services.Status.OK || !res || !res.length) { give('', ''); return; }
            var i, sc;
            for (i = 0; i < res.length; i++) {
              sc = sidoResolve(res[i].region_1depth_name);
              if (!sc) continue;
              give(sc, placeSggu(sc, res[i].region_2depth_name));
              return;
            }
            give('', '');
          });
        } catch (e) { give('', ''); }
      });
    }
    /* 지도·상태줄에 적을 기준 이름 — 장소로 찾을 때만 장소 이름, 아니면 '내 위치' */
    function originNm() { return (mode === 'place' && placeName) ? placeCut(placeName, 12) : '내 위치'; }
    function isPlace() { return mode === 'place' && !!placeName; }

    /* 지도 카드 껍데기 — 제목 줄과 본문. 접기 단추는 없앴다(지도는 늘 펴 둔다) */
    function mapShell(bodyHtml, title) {
      dirMapWrap.innerHTML = '<div class="card" style="padding-top:12px; padding-bottom:12px;">'
        + '<div class="small strong" style="color:var(--primary-dark);">'
        + (title || (isPlace() ? (mEsc(originNm()) + '에서 가까운 병원 · 내 위치가 아니에요') : '내 위치와 가까운 병원')) + '</div>'
        + '<div id="nb-map-body" style="margin-top:10px;">' + (bodyHtml || '') + '</div></div>';
      dirMapWrap.style.display = '';
      return $('#nb-map-body', dirMapWrap);
    }
    function mapPick() {              /* 지도에 찍을 곳 — 가까운 순 10곳 가운데 좌표가 있는 것만 */
      var out = [], i, h;
      for (i = 0; i < all.length && i < 10; i++) {
        h = all[i];
        if (h.dist == null || !h.y || !h.x) continue;
        out.push({ i: i, no: i + 1, name: h.name, km: h.dist, dir: h.dir, lat: h.y, lng: h.x });
      }
      return out;
    }
    /* pick : 지도에 찍을 병원 · tok : 늦게 온 지도가 다음 화면을 덮지 않게 하는 표
       opt  : { noMe, title, cap, extra } — noMe 면 가운데 점(내 위치)을 찍지 않는다(지역으로 찾기),
              extra 는 테두리를 맞출 때만 함께 넣을 점들(지역 전체가 들어오게)
       cb(true) 떴다 · cb(false) 못 떴다 */
    function drawKakaoMap(pick, tok, cb, opt) {
      opt = opt || {};
      var hasMe = (myY != null && myX != null && !opt.noMe);
      if (!hasMe && !pick.length) { cb(false); return; }
      kakaoReady(function (ok) {
        if (tok !== mapSeq) return;   /* 그 사이 다른 검색으로 바뀌었으면 그리지 않는다 */
        if (!ok) { cb(false); return; }
        var K = window.kakao.maps, fin = false, t2 = null;
        function finish(good) {
          if (fin) return;
          fin = true;
          if (t2) clearTimeout(t2);
          cb(good);
        }
        try {
          /* 지도 밑 설명 글은 두지 않는다 — 읽을 거리가 길어 지도와 목록이 멀어진다는 말씀이 있었다.
             '내 위치가 아니에요' 라는 꼭 필요한 한마디는 지도 카드 제목 줄로 옮겨 두었다
             (장소·지역으로 찾을 때 가운데 점을 내 위치로 오해하시면 안 된다). */
          /* 지도 높이는 화면의 3분의 1 아래로 — 손가락으로 끌 수 있게 되면서
             지도 위·아래 여백으로 화면을 내리셔야 하기 때문이다(지도 위에서는 화면이 안 내려간다) */
          var body = mapShell(
              '<div id="nb-map-hold" style="position:relative; z-index:0;">'   /* 번호·이름표가 아래 고정 버튼 위로 새지 않게 */
            + '<div id="nb-map-canvas" style="width:100%; height:56vw; min-height:190px; max-height:270px;'
            + ' border-radius:12px; overflow:hidden; background:var(--primary-tint);"></div>'
            + '<div id="nb-map-zoom" style="position:absolute; right:10px; bottom:10px; z-index:3;'
            + ' display:flex; flex-direction:column; gap:7px;"></div>'
            + '</div>',
            opt.title);
          var box = $('#nb-map-canvas', body);
          var mid = hasMe ? new K.LatLng(myY, myX) : new K.LatLng(pick[0].lat, pick[0].lng);
          var map = new K.Map(box, { center: mid, level: 5 });
          map.setDraggable(true);           /* 손가락으로 끌어 옮기실 수 있게 */
          map.setZoomable(true);
          var bounds = new K.LatLngBounds();
          if (hasMe) {
            var meEl = document.createElement('div');
            var meNm = isPlace() ? placeCut(placeName, 12) : '';
            meEl.setAttribute('aria-label', meNm ? ('찾으신 장소 ' + meNm) : '내 위치');
            meEl.title = meNm ? ('찾으신 장소 · ' + meNm) : '내 위치';
            if (meNm) {
              /* 장소로 찾을 때는 가운데를 점이 아니라 이름표로 둔다 — 내 위치로 오해하지 않으시게 */
              meEl.style.cssText = 'max-width:170px; padding:4px 9px; border-radius:999px; background:var(--primary-dark);'
                + ' color:#fff; border:2px solid #fff; box-shadow:0 1px 4px rgba(0,0,0,.35);'
                + ' font-size:13px; font-weight:800; line-height:1.4; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;'
                + ' pointer-events:none;';   /* 번호 위에 올려도 누르는 자리는 번호가 가져가게 */
              meEl.textContent = '📍 ' + meNm;
            } else {
              meEl.style.cssText = 'width:18px; height:18px; border-radius:999px; background:var(--primary-dark);'
                + ' border:3px solid #fff; box-shadow:0 1px 4px rgba(0,0,0,.35);';
            }
            /* 이름표는 번호(zIndex 3)보다 위에 둔다 — 목록이 가까운 순이라 ①번 병원이 늘 기준 장소
               바로 옆이어서, 이름표가 번호에 덮여 '내 위치가 아니다'를 알리는 유일한 표시가 가려졌다.
               내 위치를 뜻하는 작은 점은 그대로 아래에 둔다(번호를 가리지 않게) */
            new K.CustomOverlay({ position: mid, content: meEl, zIndex: meNm ? 4 : 2 }).setMap(map);
            bounds.extend(mid);
          }
          var i, p, pos, hit, dot;
          var dots = {}, poss = {}, ovs = {};      /* 목록 차례 → 마커 · 자리 · 겹침 */
          for (i = 0; i < pick.length; i++) {
            p = pick[i];
            pos = new K.LatLng(p.lat, p.lng);
            bounds.extend(pos);
            /* 누르는 자리는 44px, 보이는 동그라미는 30px — 지도가 번호로 뒤덮이지 않게 */
            hit = document.createElement('div');
            hit.style.cssText = 'width:44px; height:44px; display:flex; align-items:center; justify-content:center; cursor:pointer;';
            hit.setAttribute('role', 'button');
            hit.setAttribute('tabindex', '0');
            hit.setAttribute('aria-label', p.no + '번 ' + p.name);
            hit.title = p.no + '번 ' + p.name + (p.km == null ? '' : (' · ' + distLabel({ dist: p.km, dir: p.dir })));
            dot = document.createElement('div');
            dot.style.cssText = 'min-width:30px; height:30px; padding:0 6px; border-radius:999px; background:var(--primary);'
              + ' color:#fff; border:2px solid #fff; box-shadow:0 1px 4px rgba(0,0,0,.35);'
              + ' font-size:14px; font-weight:800; line-height:26px; text-align:center;';
            dot.textContent = String(p.no);
            hit.appendChild(dot);
            (function (idx, node) {
              /* 마커 → 카드. 목록을 그 칸으로 내리고 '고른 병원'으로 짚어 둔다(지도는 그대로 둔다 —
                 방금 누르신 곳이 손가락 밑에서 움직이면 어디를 보고 있었는지 잃으신다) */
              function go(ev) { if (ev && ev.preventDefault) ev.preventDefault(); setPick(idx, true, false); }
              node.addEventListener('click', go);
              node.addEventListener('keydown', function (ev) {
                if (ev.key === 'Enter' || ev.key === ' ' || ev.keyCode === 13 || ev.keyCode === 32) go(ev);
              });
            })(p.i, hit);
            ovs[p.i] = new K.CustomOverlay({ position: pos, content: hit, clickable: true, yAnchor: 0.5, zIndex: 3 });
            ovs[p.i].setMap(map);
            dots[p.i] = dot; poss[p.i] = pos;
          }
          for (i = 0; opt.extra && i < opt.extra.length; i++) {
            bounds.extend(new K.LatLng(opt.extra[i].lat, opt.extra[i].lng));
          }
          function fit() {                  /* 표시한 곳이 모두 들어오게 — 너무 가까우면 더 당기지 않는다 */
            try {
              /* 오른쪽·아래는 더 비운다 — ＋－ 상자 밑에 마커가 깔려 눌리지 않는 일이 없게 */
              map.setBounds(bounds, 26, 62, 62, 26);
              if (map.getLevel() < LV_MIN) map.setLevel(LV_MIN);
            } catch (e3) {}
          }
          fit();
          function zoom(d) {
            var lv = map.getLevel() + d;
            if (lv < 1) lv = 1;
            if (lv > 11) lv = 11;
            map.setLevel(lv);
          }
          /* ＋－ 상자 — 지도 안 오른쪽 아래. 카카오 기본 ZoomControl 은 어르신께 너무 작아 직접 만든다(각 46px).
             지도가 이 단추를 '끌기'로 잘못 알아듣지 않게 눌림은 여기서 멈춘다 */
          var zbox = $('#nb-map-zoom', body);
          function zbtn(lab, aria, d) {
            var a = el('<a href="javascript:void(0)" role="button"></a>');
            a.setAttribute('aria-label', aria);
            a.title = aria;
            a.style.cssText = 'display:flex; align-items:center; justify-content:center;'
              + ' width:46px; height:46px; border-radius:12px; background:#fff;'
              + ' border:1.5px solid var(--outline-strong); box-shadow:0 2px 7px rgba(0,0,0,.3);'
              + ' color:var(--primary-dark); font-size:25px; font-weight:800; line-height:1;'
              + ' text-decoration:none; -webkit-tap-highlight-color:transparent; cursor:pointer;';
            a.textContent = lab;
            function stop(ev) { if (ev && ev.stopPropagation) ev.stopPropagation(); }
            a.addEventListener('mousedown', stop);
            a.addEventListener('touchstart', stop);
            a.addEventListener('click', function (ev) { ev.preventDefault(); stop(ev); zoom(d); });
            zbox.appendChild(a);
          }
          zbtn('＋', '지도 크게 보기', -1);
          zbtn('－', '지도 작게 보기', 1);
          /* 목록 → 지도. drawMap/drawAreaMap 이 지도가 떴다고 확인한 뒤에 켜 준다(아래 cb) */
          kMark = function (idx) {
            var k3, on;
            for (k3 in dots) {
              if (!dots.hasOwnProperty(k3)) continue;
              on = (String(idx) === String(k3));
              dots[k3].style.minWidth = on ? '42px' : '30px';
              dots[k3].style.height = on ? '42px' : '30px';
              dots[k3].style.lineHeight = on ? '36px' : '26px';
              dots[k3].style.fontSize = on ? '19px' : '14px';
              dots[k3].style.background = on ? 'var(--primary-dark)' : 'var(--primary)';
              dots[k3].style.borderWidth = on ? '3px' : '2px';
              dots[k3].style.boxShadow = on ? '0 2px 10px rgba(0,0,0,.5)' : '0 1px 4px rgba(0,0,0,.35)';
              try { if (ovs[k3].setZIndex) ovs[k3].setZIndex(on ? 8 : 3); } catch (e9) {}
            }
          };
          kHas = function (idx) { return !!poss[idx]; };
          kMove = function (idx) {
            try {
              if (idx < 0 || !poss[idx]) { fit(); return; }   /* 고른 것을 푸셨다 — 처음 크기로 */
              if (map.getLevel() > LV_PICK) map.setLevel(LV_PICK);   /* 그 병원이 보이되 둘레도 함께 */
              if (map.panTo) map.panTo(poss[idx]); else map.setCenter(poss[idx]);
            } catch (e8) {}
          };
          function tileOk() {               /* 지도 그림이 한 장이라도 들어왔는지 — 키가 막히면 한 장도 없다 */
            var im = box.getElementsByTagName('img'), k2;
            for (k2 = 0; k2 < im.length; k2++) if (im[k2].naturalWidth > 0) return true;
            return false;
          }
          K.event.addListener(map, 'tilesloaded', function () { if (tileOk()) finish(true); });
          t2 = setTimeout(function () { finish(tileOk()); }, 6000);
        } catch (e7) { finish(false); }
      });
    }
    /* 지도 그리기 — 카카오맵을 먼저, 안 되면 방향 지도로 */
    function drawMap() {
      var pick = mapPick();
      kMark = null; kMove = null; kHas = null; pickI = -1;
      if (!pick.length) { hideDirMap(); return; }
      var tok = ++mapSeq;
      drawKakaoMap(pick, tok, function (ok) {
        if (tok !== mapSeq) return;
        if (!ok) { kMark = null; kMove = null; kHas = null; drawDirMap(); }
        paintNo(); paintPick();       /* 지도가 떴을 때만 목록 번호·카드가 눌린다 */
      });
    }
    /* ═══ 지역으로 찾을 때의 지도 ═══
       가운데 점(내 위치)은 찍지 않는다 — 무엇을 기준으로 한 지도인지 헷갈리지 않게, 상태줄과도 맞게.
       그 지역 병원이 모두 들어오게 처음 크기를 잡고, 번호는 목록 맨 위 열 곳에 찍는다.
       카카오가 안 되면 조용히 지도 없이 간다 — 방향 지도는 '내 위치에서 얼마'가 있어야 그릴 수 있다. */
    function areaPick() {
      var out = [], i, h;
      for (i = 0; i < all.length && out.length < 10; i++) {
        h = all[i];
        if (!h.y || !h.x) continue;
        out.push({ i: i, no: i + 1, name: h.name, km: null, dir: null, lat: h.y, lng: h.x });
      }
      return out;
    }
    /* 지역 전체가 들어오는 테두리. 자료가 어쩌다 엉뚱한 좌표를 주는 일이 있어 위·아래 1% 는 버린다 —
       한 곳 때문에 지도가 나라 전체만큼 벌어지면 그 지역이 점 하나로 뭉개진다 */
    function areaBox() {
      var la = [], ln = [], i, h;
      for (i = 0; i < all.length; i++) {
        h = all[i];
        if (!h.y || !h.x) continue;
        la.push(h.y); ln.push(h.x);
      }
      if (la.length < 2) return [];
      function num(a, b) { return a - b; }
      la.sort(num); ln.sort(num);
      var lo = Math.floor((la.length - 1) * 0.01), hi = Math.ceil((la.length - 1) * 0.99);
      return [{ lat: la[lo], lng: ln[lo] }, { lat: la[hi], lng: ln[hi] }];
    }
    function drawAreaMap(where) {
      var pick = areaPick();
      kMark = null; kMove = null; kHas = null; pickI = -1;
      if (!pick.length) { hideDirMap(); return; }
      var tok = ++mapSeq;
      drawKakaoMap(pick, tok, function (ok) {
        if (tok !== mapSeq) return;
        if (!ok) { kMark = null; kMove = null; kHas = null; hideDirMap(); }
        paintNo(); paintPick();
      }, { noMe: true, extra: areaBox(),
           title: mEsc(where) + ' 병원 위치 · 내 위치가 아니에요' });
    }

    function setStatus(msg) { statusEl.textContent = msg; statusEl.style.display = msg ? '' : 'none'; }
    var searchSeq = 0;      /* 이전 검색의 늦은 응답이 새 목록을 덮지 않게 */
    var mode = '';          /* 'gps' = 내 위치 기준 · 'area' = 지역을 골라서 · 'place' = 장소를 기준으로 */
    /* 아래 세 갈래 버튼을 한 번에 여닫는다. '장소로 찾기'는 카카오 장소 검색이 될 때만 낸다 */
    var placeOk = false, brOther = false, brGps = false;
    function showBranch(other, gps) {
      brOther = !!other; brGps = !!gps;
      otherBtn.style.display = brOther ? '' : 'none';
      gpsBtn.style.display = brGps ? '' : 'none';
      placeBtn.style.display = (placeOk && (brOther || brGps)) ? '' : 'none';
    }

    /* 진료과 — 지금 고르신 과를 버튼에 적고, 누르면 큰 팝업에서 바꾸신다 */
    /* 지역을 골라서 찾는 중이면 제목에서 '근처'를 뺀다 — 내 위치로 찾은 것처럼 보이지 않게.
       (상담 카드가 '대전광역시에서 내과 찾기' 라고 보내 놓고 여기 와서 '근처 내과 찾기' 가 뜨던 것을 맞춘다.
        어느 지역인지는 목록 위 상태줄에 이미 적힌다 — 앱바 제목은 짧게 둔다) */
    function paintDept() {
      var what = (want ? want[1] : '병원') + ' 찾기';
      /* 지역·장소로 찾을 때는 '근처'를 빼 둔다 — 무엇을 기준으로 찾았는지는 상태줄에 적힌다 */
      if (title) title.textContent = ((mode === 'area' || mode === 'place') ? what : '근처 ' + what);
      deptCur.textContent = want ? want[1] : '전체 보기';
    }
    function deptPop() {
      var pop = document.getElementById('deptpop');
      if (!pop) {
        pop = el('<div class="callpop" id="deptpop" role="dialog" aria-modal="true" aria-label="진료과 고르기" hidden>'
          + '<div class="callpop-card" style="text-align:left; max-height:90%; overflow:auto;">'
          + '<div class="strong" style="font-size:17px;">어떤 진료과를 찾으세요?</div>'
          + '<div class="small muted" style="margin-top:-6px; line-height:1.7;">하나만 고르시면 그 과가 있는 병원만 보여 드려요.</div>'
          + '<div id="deptpop-list" style="display:flex; flex-wrap:wrap; gap:8px;"></div>'
          + '<button class="btn btn-outline btn-block" id="deptpop-no" type="button">닫기</button>'
          + '</div></div>');
        ($('.screen') || document.body).appendChild(pop);
        $('#deptpop-no', pop).addEventListener('click', function () { pop.hidden = true; });
        pop.addEventListener('click', function (e) { if (e.target === pop) pop.hidden = true; });
      }
      var box = $('#deptpop-list', pop);
      box.innerHTML = '';
      [['', '전체 보기']].concat(DEPT).forEach(function (d) {
        var on = (want ? want[0] : '') === d[0];
        var b = el('<button type="button" class="btn ' + (on ? 'btn-primary' : 'btn-outline')
          + '" style="flex:1 1 44%; min-height:48px; font-size:14.5px; justify-content:center;"></button>');
        b.textContent = d[1];
        b.addEventListener('click', function () {
          pop.hidden = true;
          if ((want ? want[0] : '') === d[0]) return;
          want = d[0] ? deptFind(d[0]) : null;
          paintDept();
          if (mode === 'area') runArea();
          else if (mode === 'place' && placeY != null) placeUse(placeIdx);
          else start();
        });
        box.appendChild(b);
      });
      pop.hidden = false;
    }
    deptBtn.addEventListener('click', function (e) { e.preventDefault(); deptPop(); });

    /* 조건 → 요청 묶음. 치과처럼 종별로 거르는 과는 종별마다 한 번씩 받아 합친다.
       opt = { sido, sggu, emd, cl, name } — 좌표(xPos·yPos·radius)는 넣지 않는다 */
    function paramSets(opt) {
      var base = { sidoCd: opt.sido };
      if (opt.sggu) base.sgguCd = opt.sggu;
      if (opt.emd) base.emdongNm = opt.emd;
      if (opt.name) base.yadmNm = opt.name;
      if (want && want[2]) base.dgsbjtCd = want[2];
      var cls = (want && want[3].length) ? want[3] : [opt.cl || ''];
      var out = [], i, k, b;
      for (i = 0; i < cls.length; i++) {
        b = {};
        for (k in base) if (base.hasOwnProperty(k)) b[k] = base[k];
        if (cls[i]) b.clCd = cls[i];
        out.push(b);
      }
      return out;
    }

    /* 한 조건을 1쪽부터 이어받는다 (한 번에 1,000곳). 많이 못 받는 서버면 200곳씩 다시.
       쪽수 상한은 갈래마다 다르다 — 시·도 전체는 6쪽, 구 하나는 5쪽이면 넉넉하다.
       (2026-09 실측: 서울 강남구 3,179곳 = 4쪽이 가장 많았고 나머지 구는 1~2쪽이었다.
        시·도 전체는 서울 19,913곳·경기 18,237곳이라 6쪽으로도 다 못 받는다)
       onPage 를 주면 쪽이 하나 올 때마다 불러 준다 — 다 오기 전에 먼저 보여 드리려고. */
    var PAGE_ROWS = '1000', MAX_PAGES = 6, MAX_PAGES_SGGU = 5;
    function loadOne(base, my, note, cb, fail, onPage, maxPages) {
      var acc = [], total = 0, rows = PAGE_ROWS, lim = maxPages || MAX_PAGES;
      function step(pg) {
        if (my !== searchSeq) return;
        var p = {}, k;
        for (k in base) if (base.hasOwnProperty(k)) p[k] = base[k];
        p.numOfRows = rows; p.pageNo = String(pg);
        if (pg > 1) setStatus(note + ' 가져오는 중… (' + acc.length + '곳)');
        fetchHosp(p, function (items, tc) {
          if (my !== searchSeq) return;
          total = tc;
          acc = acc.concat(items);
          if (items.length && acc.length < tc && pg < lim) {
            if (onPage) { try { onPage(acc, total); } catch (eP) {} }
            step(pg + 1); return;
          }
          cb(acc, total);
        }, function (why) {
          if (my !== searchSeq) return;
          if (pg === 1 && rows === PAGE_ROWS) { rows = '200'; step(1); return; }
          if (acc.length) { cb(acc, total || acc.length); return; }   /* 일부라도 받았으면 보여준다 — 총곳수는 1쪽에서 받은 그대로 두어야 '일부만 받았어요' 안내가 남는다 */
          fail(why);
        });
      }
      step(1);
    }
    function loadSets(sets, my, note, cb, fail, onPage, maxPages) {
      var out = [], total = 0, i = 0;
      function next() {
        if (my !== searchSeq) return;
        if (i >= sets.length) { cb(out, total); return; }
        loadOne(sets[i++], my, note, function (items, tc) {
          out = out.concat(items); total += tc;
          if (onPage && i < sets.length) { try { onPage(out, total); } catch (eQ) {} }
          next();
        }, function (why) { if (out.length) { cb(out, total); return; } fail(why); },
        onPage ? function (acc, tc) { onPage(out.concat(acc), total + tc); } : null, maxPages);
      }
      next();
    }

    /* ══ 받아 둔 병원 목록을 하루 저장한다 (localStorage) ══
       담는 것은 심평원이 공개하는 병원 목록뿐이다 — 내 좌표는 담지 않는다.
       열쇠 = 시·도 + 시·군·구 + 진료과 + 종별. 구가 달라지면 열쇠가 달라져 저절로 새로 받는다.
       그래서 '위치가 많이 달라졌는가'를 가리려고 지난 좌표를 저장할 필요가 없다
       (같은 구 안에서 움직이신 것이면 병원 목록은 그대로고, 거리는 지금 위치로 다시 잰다).
       저장이 막힌 환경(사생활 보호·용량 초과)에서도 아무것도 깨지지 않게 모두 try/catch 로 감쌌다. */
    var HC_KEY = 'todak_hosp_cache_v1';
    var HC_TTL = 24 * 60 * 60 * 1000;    /* 하루가 지나면 버린다 */
    var HC_FRESH = 60 * 60 * 1000;       /* 한 시간 안에 받은 것이면 뒤에서 또 받지 않는다 */
    var HC_MAX = 3;                      /* 지역 세 곳만 남긴다 — 용량(5MB 안팎)을 지키려고 */
    var HC_CAP = 4000;                   /* 한 지역에 담는 최대 곳수 */
    function hcNow() { return (new Date()).getTime(); }
    function hcRead() {
      try { return JSON.parse(localStorage.getItem(HC_KEY) || '{}') || {}; } catch (e) { return {}; }
    }
    function hcKey(sido, sggu) {
      return sido + '|' + (sggu || '') + '|' + ((want && want[2]) ? want[2] : '')
        + '|' + ((want && want[3] && want[3].length) ? want[3].join(',') : '');
    }
    /* 배열로 눌러 담는다 — 키 이름이 빠져 절반 크기가 된다 */
    function hcPack(h) { return [h.name || '', h.cl || '', h.addr || '', h.emd || '', h.tel || '', h.x, h.y]; }
    function hcUnpack(a) {
      return { name: a[0] || '', cl: a[1] || '', addr: a[2] || '', emd: a[3] || '', tel: a[4] || '',
               x: (a[5] == null ? NaN : a[5]), y: (a[6] == null ? NaN : a[6]) };
    }
    function hcGet(key) {
      var db = hcRead(), e = db[key], out = [], i;
      if (!e || !e.t || !e.v || !e.v.length) return null;
      if (hcNow() - e.t > HC_TTL) return null;
      for (i = 0; i < e.v.length; i++) out.push(hcUnpack(e.v[i]));
      return { items: out, total: e.c || out.length, t: e.t };
    }
    function hcPut(key, items, total) {
      if (!key || !items || !items.length) return;
      var db = hcRead(), v = [], keys = [], i, k, n = Math.min(items.length, HC_CAP);
      for (i = 0; i < n; i++) v.push(hcPack(items[i]));
      db[key] = { t: hcNow(), c: total || items.length, v: v };
      for (k in db) if (db.hasOwnProperty(k)) keys.push(k);
      keys.sort(function (a, b) { return (db[b].t || 0) - (db[a].t || 0); });   /* 새것 먼저 */
      for (i = HC_MAX; i < keys.length; i++) delete db[keys[i]];                /* 오래된 것부터 버린다 */
      try { localStorage.setItem(HC_KEY, JSON.stringify(db)); return; } catch (e1) {}
      try {                                   /* 용량이 찼다 — 이번 지역 하나만 남겨 한 번 더 */
        var only = {}; only[key] = db[key];
        localStorage.setItem(HC_KEY, JSON.stringify(only)); return;
      } catch (e2) {}
      try { localStorage.removeItem(HC_KEY); } catch (e3) {}   /* 그래도 안 되면 조용히 포기한다 */
    }

    function dedupe(items) {
      var seen = {}, out = [], i, k;
      for (i = 0; i < items.length; i++) {
        k = items[i].name + '|' + (items[i].addr || '');
        if (seen[k]) continue;
        seen[k] = 1; out.push(items[i]);
      }
      return out;
    }
    function resetList() { listWrap.innerHTML = ''; all = []; shown = 0; moreBtn.style.display = 'none'; hideDirMap(); }
    function busy(on) {
      goBtn.__busy = on;
      goBtn.textContent = on ? '찾는 중…' : '🔎 이 조건으로 찾기';
      goBtn.style.opacity = on ? '.6' : '';
    }
    function showNone(byEmd) {
      setStatus('조건에 맞는 병원이 없어요');
      listWrap.appendChild(el('<div class="banner banner--info"><span class="b-ic">🔎</span><div class="small">'
        + (byEmd
          ? '<b>고르신 읍·면·동에는 조건에 맞는 병원이 없어요.</b> 읍·면·동을 <b>‘읍·면·동 전체’</b>로 바꾸시거나, 위의 <b>진료과</b>를 ‘전체 보기’로 넓혀 보세요.'
          : '<b>조건에 맞는 병원을 찾지 못했어요.</b> 위의 <b>진료과</b>를 ‘전체 보기’로 바꾸시거나, 병원 이름을 지우고 다시 찾아 보세요.')
        + '</div></div>'));
      if (mode !== 'area') showBranch(true, mode === 'place');   /* 지역 모드에서는 위에 이미 있다 */
    }
    function cutBanner(total, n) {
      if (total <= n) return;
      listWrap.appendChild(el('<div class="banner banner--info"><span class="b-ic">ℹ️</span><div class="small">이 지역에는 총 <b>' + total + '곳</b>이 있어 일부(' + n + '곳)만 받아왔어요. 위에서 <b>진료과</b>를 고르시면 찾으시는 곳이 더 잘 나와요.</div></div>'));
    }
    function failBox(why) {
      busy(false);
      setStatus('목록을 가져오지 못했어요');
      listWrap.appendChild(el('<div class="banner banner--warn"><span class="b-ic">⚠️</span><div class="small">'
        + (why === 'web' ? '병원 찾기 기능이 아직 열리지 않았어요. 잠시 후 다시 시도해 주세요.' : '공공데이터에서 병원 정보를 받아오지 못했어요. 잠시 후 다시 시도해 주세요.')
        + '</div></div>'));
      if (mode !== 'area') showBranch(true, mode === 'place');   /* 지역 모드에서는 위에 이미 있다 */
    }
    /* 사용기록: 이벤트명만 (지역·좌표 저장 안 함) */
    function logSearch() {
      sb.auth.getSession().then(function (rs) {
        if (rs.data.session) sb.from('app_events').insert({ user_id: rs.data.session.user.id, event: 'nearby_search' }).then(function () {}, function () {});
      });
    }

    /* ── 내 위치 기준 ── 좌표(y·x)는 이 흐름 안에서만 쓰고 저장·전송하지 않는다.
       시·도 판정도 휴대폰 안에서 한다(sidoRank) — 서버로 가는 것은 시·도 코드뿐이다 */
    function measure(items, y, x) {
      var min = null, i, d, b;
      for (i = 0; i < items.length; i++) {
        d = (items[i].y && items[i].x) ? haversineKm(y, x, items[i].y, items[i].x) : null;
        items[i].dist = d;
        if (d != null) {              /* 방위도 여기서만 — 거리와 함께 휴대폰 안에 머문다 */
          b = bearingDeg(y, x, items[i].y, items[i].x);
          items[i].brg = b;
          items[i].dir = Math.round(b / 45) % 8;
        }
        if (d != null && (min === null || d < min)) min = d;
      }
      return min;
    }
    /* tail  = 상태줄 뒤에 덧붙일 말('· 나머지도 찾는 중…' 처럼)
       again = 이미 보고 계신 목록을 고쳐 그리는 중이다.
               보고 계시던 만큼(shown)은 그대로 다시 채워 자리가 사라지지 않게 하고,
               가장 가까운 병원이 바뀌었을 때만 지도를 다시 그린다(괜히 깜빡이지 않게) */
    /* 지도에 찍은 열 곳이 그대로인가. 이웃 구를 더 받아 합쳐 2~10번이 밀리면
       지도의 번호와 목록의 번호가 어긋난다 — 그때는 지도를 다시 그려야 한다.
       열 곳이 다 같으면 그리지 않는다(괜히 깜빡이지 않게 — 앞 담당이 둔 뜻 그대로다) */
    function topKey() {
      var k = '', i;
      for (i = 0; i < all.length && i < 10; i++) k += all[i].name + '|' + (all[i].addr || '') + '\n';
      return k;
    }
    function doneGps(my, items, total, tail, again) {
      if (my !== searchSeq) return;
      busy(false);
      items = dedupe(items);
      if (!items.length) { if (!again) showNone(); return; }
      markTiers(items);
      items.sort(function (a, b) {
        return tierCmp(a, b) || ((a.dist == null ? 9e9 : a.dist) - (b.dist == null ? 9e9 : b.dist));
      });
      var was = again ? topKey() : '', keep = again ? shown : 0;
      all = items;
      listWrap.innerHTML = ''; shown = 0;
      /* 진료과를 고르시면 그 과 전문인 곳을 먼저 세운다(tierCmp) — 그러면 글도 그렇게 적어야 한다.
         '가까운 순'이라고만 적어 두고 8km 를 50m 보다 위에 놓으면 안 된다. 지역 모드도 같은 규칙이다. */
      var head = isPlace() ? (placeCut(placeName, 16) + '에서 가까운 순') : '내 위치에서 가까운 순';
      if (want && want[2] && DEPT_NM[want[0]]) head = want[1] + ' 전문 먼저 · ' + head;
      setStatus(head + (tail || ''));
      deptNote();
      cutBanner(total, items.length);
      do { renderMore(); } while (shown < keep && shown < all.length);
      if (!again || was !== topKey()) drawMap();   /* 지도에 찍은 열 곳이 달라졌을 때만 다시 그린다 */
      showBranch(true, mode === 'place');
    }
    /* region 을 주면(장소로 찾기처럼 이미 물어본 경우) 다시 묻지 않는다 — [시·도코드, 시·군·구코드] */
    function runGps(y, x, rank, region) {
      var my = ++searchSeq;
      myY = y; myX = x;             /* 지도 가운데에만 쓴다 — 저장하지 않는다 */
      kakaoReady(function () {});   /* 목록을 받는 동안 지도 스크립트를 미리 받아 둔다 */
      resetList(); busy(true); logSearch();
      showBranch(false, false);
      setStatus(isPlace() ? (placeCut(placeName, 14) + ' 가까운 병원을 찾는 중…') : '가까운 병원을 찾는 중…');
      if (region) { gpsGo(my, y, x, rank, region[0], region[1]); return; }
      /* 내 자리가 어느 '구'인지 알아낸다 — 휴대폰이 카카오 지도에 물어보는 것뿐이고,
         심평원(hosp-proxy)에는 좌표가 아니라 지역 코드만 간다. 못 알아내면 예전처럼 시·도 전체로.
         카카오 스크립트가 막혀 있으면 오래 걸릴 수 있어 3초만 기다린다 — 기다리게 하지 않으려고 */
      var went = false, gt = null;
      function go(sc, gc) {
        if (went || my !== searchSeq) return;
        went = true;
        if (gt) { clearTimeout(gt); gt = null; }
        gpsGo(my, y, x, rank, sc, gc);
      }
      gt = setTimeout(function () { go('', ''); }, 3000);
      placeRegion(y, x, function (sc, gc) { go(sc, gc); });
    }
    function gpsGo(my, y, x, rank, sc, gc) {
      if (my !== searchSeq) return;
      /* '어느 지역에서 찾을까요' 의 첫 값을 지금 계신 곳으로 —
         동만 바꾸시면 같은 구의 다른 동을 보실 수 있게 (장소로 찾을 때는 placeUse 가 따로 맞춘다) */
      if (mode === 'gps') areaPreset(sc, gc);
      if (sc && gc) { runSggu(my, y, x, sc, gc); return; }
      if (sc && sc !== rank[0]) rank = [sc, rank[0]];
      runSido(my, y, x, rank);
    }
    /* 구로 받다 실패해 시·도 전체로 되돌아갈 때의 차례 — 둘째 칸이 첫째와 같지 않게 고른다 */
    function rankFrom(sc, y, x) {
      var r = sidoRank(y, x), i;
      for (i = 0; i < r.length; i++) if (r[i] !== sc) return [sc, r[i]];
      return [sc, r[0]];
    }
    /* ── 시·도 전체로 받기 ── 구를 못 알아냈을 때의 대비책. 절대 빈손으로 끝나지 않게 남겨 둔다 */
    function runSido(my, y, x, rank) {
      if (my !== searchSeq) return;
      loadSets(paramSets({ sido: rank[0] }), my, sidoName(rank[0]) + ' 병원 목록을', function (items, total) {
        if (my !== searchSeq) return;
        var near = measure(items, y, x);
        if (near != null && near <= 15) { doneGps(my, items, total); return; }
        /* 시·도 경계 — 가장 가까운 곳이 15km 를 넘으면 두 번째로 가까운 시·도까지만 한 번 더 받아 합친다 */
        setStatus('가까운 곳이 없어 ' + sidoName(rank[1]) + '도 함께 찾는 중…');
        loadSets(paramSets({ sido: rank[1] }), my, sidoName(rank[1]) + ' 병원 목록을', function (more, t2) {
          if (my !== searchSeq) return;
          measure(more, y, x);
          doneGps(my, items.concat(more), total + t2);
        }, function () { doneGps(my, items, total); });
      }, failBox);
    }

    /* ── 이웃 구 고르기 ──
       내 자리에서 3km 떨어진 네 곳(북·남·동·서)이 어느 구인지 카카오 지도에 물어
       내 구와 다른 곳만 모은다. 물어보는 지점은 '내가 있는 자리'가 아니고,
       여기서 얻은 것도 지역 코드뿐이다 — 심평원에는 지역 코드만 간다.
       (구 경계표를 파일에 적으면 250개 구의 이웃 관계를 손으로 넣어야 해 틀리기 쉽고,
        내 구에서 받은 병원 좌표만으로는 '옆 구의 코드'를 알 길이 없다. 이 방법이 가장 싸다.
        시·도가 달라도 받는다 — 서울 강서구 옆 김포시처럼 경계를 넘는 곳이 있다) */
    var NEAR_STEP_KM = 3, NEAR_MAX = 3;
    function nearSggu(y, x, sc, gc, cb) {
      var dLat = NEAR_STEP_KM / 111;
      var cosv = Math.cos(y * Math.PI / 180);
      var dLon = NEAR_STEP_KM / (111 * (Math.abs(cosv) < 0.2 ? 0.2 : cosv));
      var pts = [[y + dLat, x], [y - dLat, x], [y, x + dLon], [y, x - dLon]];
      var left = pts.length, seen = {}, out = [], done = false, t = null;
      seen[sc + '|' + gc] = 1;
      function give() { if (done) return; done = true; if (t) clearTimeout(t); cb(out.slice(0, NEAR_MAX)); }
      t = setTimeout(give, 5000);
      pts.forEach(function (p) {
        placeRegion(p[0], p[1], function (s2, g2) {
          var k = s2 + '|' + g2;
          if (s2 && g2 && !seen[k]) { seen[k] = 1; out.push([s2, g2]); }
          if (--left <= 0) give();
        });
      });
    }

    /* ── 내 '구'로 좁혀 받기 ──
       ① 저장해 둔 목록이 있으면 먼저 보여 드린다(거리는 지금 자리로 다시 잰다).
       ② 그 구로 받는다. 1쪽(1,000곳)이 오면 먼저 보여 드리고 남은 쪽은 뒤에서 이어 합친다.
       ③ 가장 가까운 곳이 멀거나 쓸 만한 곳이 적으면 이웃 구를 조용히 더 받아 합친다. */
    var NEAR_OK_KM = 2;    /* 가장 가까운 곳이 이보다 멀면 구 가장자리에 계신 것으로 본다 */
    var ENOUGH = 10;       /* 거리를 아는 곳이 이만큼은 돼야 넉넉한 것으로 본다 */
    function runSggu(my, y, x, sc, gc) {
      var key = hcKey(sc, gc), saved = hcGet(key), where = areaLabel(sc, gc, '');
      var acc = [], accTotal = 0, painted = false, filled = false, curTail = '';
      function paint(items, total, tail, again) {
        if (my !== searchSeq) return;
        acc = items; accTotal = total; curTail = tail || '';
        measure(items, y, x);
        doneGps(my, items, total, curTail, again);
        painted = true;
      }
      /* ③ 구 경계 보완 */
      function fill(items, total) {
        if (my !== searchSeq || filled) return;
        filled = true;
        var i, near = null, cnt = 0, d;
        for (i = 0; i < items.length; i++) {
          d = items[i].dist;
          if (d == null) continue;
          cnt++;
          if (near === null || d < near) near = d;
        }
        /* 가까운 곳이 2km 안에 있고 쓸 만한 곳이 열 군데가 넘으면 더 받지 않는다.
           (길 건너 더 가까운 병원을 놓치는 경우는 대개 구 가장자리인데, 그때는
            가장 가까운 곳이 멀거나 수가 적게 나온다. 진료과를 고르셨을 때도 이 규칙에 걸린다) */
        if (near !== null && near <= NEAR_OK_KM && cnt >= ENOUGH) return;
        nearSggu(y, x, sc, gc, function (list) {
          if (my !== searchSeq || !list.length) return;
          var sets = [], j, k, ps;
          for (j = 0; j < list.length; j++) {
            ps = paramSets({ sido: list[j][0], sggu: list[j][1] });
            for (k = 0; k < ps.length; k++) sets.push(ps[k]);
          }
          loadSets(sets, my, '이웃 지역 병원 목록을', function (more, t2) {
            if (my !== searchSeq || !more.length) return;
            measure(more, y, x);
            paint(acc.concat(more), accTotal + t2, curTail, true);
          }, function () {}, null, MAX_PAGES_SGGU);
        });
      }
      /* ① 저장해 둔 목록 — 묵은 것을 새 것처럼 보이지 않게 상태줄에 그대로 적는다.
         한 시간 안에 받아 둔 것이면 그대로 쓰고(그 사이 병원이 생기거나 없어지지 않는다),
         그보다 오래됐으면 먼저 보여 드리면서 뒤에서 새로 받아 조용히 갈아 끼운다 */
      if (saved) {
        var fresh = (hcNow() - saved.t) < HC_FRESH;
        paint(saved.items, saved.total,
              fresh ? ' · 조금 전에 받아 둔 목록' : ' · 저장해 둔 목록을 먼저 보여 드려요', false);
        if (fresh) { fill(acc, accTotal); return; }
      }
      /* ② 그 구로 받기 */
      loadSets(paramSets({ sido: sc, sggu: gc }), my, where + ' 병원 목록을', function (items, total) {
        if (my !== searchSeq) return;
        if (!items.length) {                       /* 그 구로는 한 곳도 못 받았다 */
          if (painted) { fill(acc, accTotal); return; }
          runSido(my, y, x, rankFrom(sc, y, x));
          return;
        }
        hcPut(key, items, total);
        paint(items, total, '', painted);
        fill(acc, accTotal);
      }, function (why) {
        if (my !== searchSeq) return;
        if (painted) {                                  /* 저장해 둔 것이라도 보고 계신다 — 다만 새것이 오는 중인 것처럼 두지는 않는다 */
          paint(acc, accTotal, ' · 저장해 둔 목록이에요(새로 받지 못했어요)', true);
          fill(acc, accTotal); return;
        }
        runSido(my, y, x, rankFrom(sc, y, x));
      }, function (part, tc) {                     /* 1쪽이 오면 곧바로 보여 드린다 */
        if (my !== searchSeq || painted) return;
        paint(part, tc, ' · 나머지도 찾는 중…', false);
      }, MAX_PAGES_SGGU);
    }

    /* ── 지역을 골라서 ── 위치를 못 쓸 때와 '다른 지역에서 찾기' 를 누르셨을 때만 */
    function runArea() {
      if (goBtn.__busy) return;
      var my = ++searchSeq, code = selSido.value, sggu = selSggu.value,
          nm = inpName.value.trim(), where = areaLabel(code, sggu, '');
      mode = 'area'; placeClear(); paintDept();
      ctl.style.display = '';
      showBranch(false, true);
      resetList(); busy(true); logSearch();
      emdReset(true);              /* 새로 받는 동안에는 잠가 두되, 고르셨던 동은 기억해 둔다 */
      setStatus(where + ' 병원 목록을 가져오는 중…');
      /* 주소로 열린 지역(urlAreaLock)은 기억하지 않는다 — 위 urlSido 설명을 보시라 */
      if (!urlAreaLock) {
        try { localStorage.setItem('todak_nearby', JSON.stringify({ sido: code, sggu: sggu, cl: selCl.value })); } catch (e) {}
      }
      var retried = false;
      /* fromCache = 저장해 둔 목록을 그대로 보여 드리는 길. 이때는 '받아 온 시각(t)' 을 다시 찍지 않는다 —
         2026-09-28 까지는 여기서도 hcPut 을 불러 t 가 지금으로 갱신되어, 하루 버림(HC_TTL)과
         한 시간 새것 판정(HC_FRESH)이 둘 다 영원히 오지 않았다. 그래서 며칠 묵은 병원 목록이
         '조금 전에 받아 둔 목록'으로 보이고 심평원에 다시 묻지 않았다(문 닫은 병원·바뀐 전화번호). */
      function got(items, total, fromCache) {
        if (my !== searchSeq) return;
        items = dedupe(items);
        /* 2026-07-01 인천 개편(제물포·영종·서해·검단구) — 심평원 자료가 아직 옛 구 코드로 올라와 있으면
           한 번만 옛 코드로 다시 찾는다. 다른 지역에는 해당 없음 */
        if (!items.length && !retried && OLD_SGGU[sggu]) {
          retried = true;
          setStatus(where + ' 병원 목록을 가져오는 중… (예전 구 이름으로 다시 찾는 중)');
          var sets = [], i, j, ps;
          for (i = 0; i < OLD_SGGU[sggu].length; i++) {
            ps = paramSets({ sido: code, sggu: OLD_SGGU[sggu][i], cl: selCl.value, name: nm });
            for (j = 0; j < ps.length; j++) sets.push(ps[j]);
          }
          loadSets(sets, my, where + ' 병원 목록을', got, failBox);
          return;
        }
        busy(false);
        /* 새로 받아 온 구 목록만 하루 저장에 담는다 — 구를 오가며 보실 때 같은 목록을 또 받지 않게.
           (병원 종류·이름으로 좁히신 것은 담지 않는다 — 열쇠가 같아 뒤섞이면 안 된다) */
        if (!fromCache && sggu && !selCl.value && !nm && items.length) hcPut(hcKey(code, sggu), items, total);
        markTiers(items);
        items.sort(function (a, b) { return tierCmp(a, b) || (a.name < b.name ? -1 : 1); });
        areaAll = items; areaTotal = total; areaCode = code; areaSggu = sggu;
        /* 받아온 목록에서 동 이름을 모아 고르기 칸을 채운다 — 시·군·구를 고르셨을 때만 */
        if (sggu && items.length) fillEmd(items); else emdLock();
        paintArea();
      }
      /* 받아 둔 목록이 있으면 그대로 쓴다 — 방금 내 위치로 찾을 때 받아 둔 바로 그 구다.
         그래서 '다른 지역에서 찾기' 를 누르시면 기다림 없이 읍·면·동 칸이 열린다(요청도 늘지 않는다).
         병원 종류·이름으로 더 좁히신 경우에는 조건이 달라 쓰지 않는다 */
      areaTail = '';
      if (sggu && !selCl.value && !nm) {
        var sv = hcGet(hcKey(code, sggu));
        if (sv && sv.items.length) {
          if ((hcNow() - sv.t) >= HC_FRESH) areaTail = ' · 저장해 둔 목록이에요';
          got(sv.items, sv.total, true);       /* 저장해 둔 것을 보여 주는 길 — 시각을 다시 찍지 않는다 */
          return;
        }
      }
      loadSets(paramSets({ sido: code, sggu: sggu, cl: selCl.value, name: nm }), my, where + ' 병원 목록을', got, failBox);
    }
    /* 고르신 동으로 목록을 추려 보여 준다 — 이미 받아온 목록을 거르기만 한다(요청을 한 번 더 보내지 않는다) */
    function paintArea() {
      var sel = selEmd.disabled ? '' : selEmd.value, items = areaAll, out = [], i;
      if (sel) {
        for (i = 0; i < areaAll.length; i++) if (emdOf(areaAll[i]) === sel) out.push(areaAll[i]);
        items = out;
      }
      resetList();
      if (!items.length) { showNone(!!sel); return; }
      all = items;
      setStatus((want && want[2] && DEPT_NM[want[0]] ? want[1] + ' 전문 먼저 · 이름순 · ' : '이름순 · ') + areaLabel(areaCode, areaSggu, sel) + ' · ' + items.length + '곳'
        + ' (내 위치는 쓰지 않아서 거리는 보여 드리지 않아요)' + areaTail);
      deptNote();
      if (!sel) cutBanner(areaTotal, areaAll.length);
      renderMore();
      drawAreaMap(areaLabel(areaCode, areaSggu, sel));   /* 지역으로 찾을 때도 지도를 띄운다 */
    }
    selEmd.addEventListener('change', function () { if (areaAll.length) paintArea(); });
    function showArea(reason, run) {
      mode = 'area'; placeClear(); paintDept();
      searchSeq++;                 /* 오다 만 위치 기준 검색이 이 화면을 덮지 않게 */
      busy(false);
      resetList();
      ctl.style.display = '';
      showBranch(false, true);
      setStatus(reason);
      /* 시·군·구가 이미 잡혀 있으면(대개 지금 계신 구) 곧바로 그 구를 찾아 둔다 —
         그래야 읍·면·동 칸이 같은 화면에서 바로 열려, 동만 바꾸시면 된다.
         받아 둔 목록이 있으면 기다림도 요청도 없다(runArea 안에서 저장분을 먼저 본다) */
      if (run && selSggu.value && !selSggu.disabled) runArea();
    }

    /* ── 장소를 기준으로 ── 그 장소의 좌표를 받아 그 곳을 가운데에 두고 가까운 순으로 보여 드린다.
       내 위치를 쓰지 않으므로 위치 권한 창이 뜨지 않는다.
       병원 목록은 내 위치 기준과 똑같은 길(runGps)로 받는다 — 심평원에 가는 것은 시·도 코드뿐이다. */
    var placeName = '', placeHits = [], placeIdx = 0, placeY = null, placeX = null;
    function placeNote(html) {
      placeNoteEl.innerHTML = html || '';
      placeNoteEl.style.display = html ? '' : 'none';
    }
    function placeClear() {
      placeName = ''; placeHits = []; placeIdx = 0; placeY = null; placeX = null;
      placePick.style.display = 'none';
      placeCtl.style.display = 'none';
      placeNote('');
    }
    function paintPlacePick() {
      if (!isPlace()) { placePick.style.display = 'none'; return; }
      var p = placeHits[placeIdx] || null;
      $('#nb-place-nm', placePick).textContent = '📍 ' + placeName;
      $('#nb-place-ad', placePick).textContent = (p && p.addr) ? p.addr : '이곳을 기준으로 찾았어요';
      $('#nb-place-alt', placePick).style.display = (placeHits.length > 1) ? '' : 'none';
      placePick.style.display = '';
    }
    /* 같은 이름이 여러 곳일 때 — 첫 번째(카카오가 가장 알맞다고 준 곳)로 먼저 보여 드리고,
       무엇을 골랐는지 화면에 적어 바꾸실 수 있게 둔다 */
    function placePop() {
      var pop = document.getElementById('placepop');
      if (!pop) {
        pop = el('<div class="callpop" id="placepop" role="dialog" aria-modal="true" aria-label="장소 고르기" hidden>'
          + '<div class="callpop-card" style="text-align:left; max-height:90%; overflow:auto;">'
          + '<div class="strong" style="font-size:17px;">어느 곳을 말씀하시나요?</div>'
          + '<div class="small muted" style="margin-top:-6px; line-height:1.7;">같은 이름이 여러 곳이라 먼저 나온 곳으로 찾아 드렸어요. 다른 곳이면 골라 주세요.</div>'
          + '<div id="placepop-list" style="display:flex; flex-direction:column; gap:8px;"></div>'
          + '<button class="btn btn-outline btn-block" id="placepop-no" type="button">닫기</button>'
          + '</div></div>');
        ($('.screen') || document.body).appendChild(pop);
        $('#placepop-no', pop).addEventListener('click', function () { pop.hidden = true; });
        pop.addEventListener('click', function (e) { if (e.target === pop) pop.hidden = true; });
      }
      var box = $('#placepop-list', pop);
      box.innerHTML = '';
      placeHits.forEach(function (p, i) {
        var b = el('<button type="button" class="btn ' + (i === placeIdx ? 'btn-primary' : 'btn-outline')
          + '" style="min-height:52px; padding:10px 12px; justify-content:flex-start; text-align:left; white-space:normal;"></button>');
        var w = document.createElement('div');
        w.style.cssText = 'width:100%;';
        var t = document.createElement('div');
        t.style.cssText = 'font-size:14.5px; font-weight:800; line-height:1.5;';
        t.textContent = p.name;
        w.appendChild(t);
        if (p.addr) {
          var a = document.createElement('div');
          a.style.cssText = 'font-size:13px; font-weight:600; opacity:.85; margin-top:2px; line-height:1.6;';
          a.textContent = p.addr;
          w.appendChild(a);
        }
        b.appendChild(w);
        b.addEventListener('click', function () { pop.hidden = true; if (i !== placeIdx) placeUse(i); });
        box.appendChild(b);
      });
      pop.hidden = false;
    }
    function placeUse(i) {
      var p = placeHits[i];
      if (!p) return;
      searchSeq++;               /* 오다 만 이전 검색이 이 화면을 덮지 않게 (진료과를 바꾸실 때도 여기로 온다) */
      placeIdx = i; placeName = p.name; placeY = p.y; placeX = p.x;
      mode = 'place';
      paintDept();
      ctl.style.display = 'none';
      placeCtl.style.display = '';
      placeNote('');
      paintPlacePick();
      showBranch(false, false);
      setStatus(placeCut(placeName, 14) + ' 가까운 병원을 찾는 중…');
      /* 그 좌표가 어느 시·도인지 카카오에 물어 두면 시·도 판정이 더 정확하다.
         못 물어도 그만이다 — 휴대폰 안에서 판정한 차례(sidoRank)를 그대로 쓴다 */
      placeRegion(p.y, p.x, function (sc, gc) {
        if (mode !== 'place' || placeIdx !== i) return;
        var rank = sidoRank(p.y, p.x);
        if (sc) {
          if (sc !== rank[0]) rank = [sc, rank[0]];
          /* 지역 고르기 칸도 그 지역으로 맞춰 둔다 — '다른 지역에서 찾기'로 바로 이어진다 */
          selSido.value = sc;
          fillSggu(selSggu, sc);
          if (gc) selSggu.value = gc;
          urlAreaLock = true;      /* 장소에서 따라온 지역은 '늘 찾으시던 지역'으로 기억하지 않는다 */
        }
        runGps(p.y, p.x, rank, [sc, gc]);   /* 이미 알아낸 지역을 넘긴다 — 두 번 묻지 않게 */
      });
    }
    /* 못 찾았을 때 — 오류 상자를 띄우지 않는다. 한 줄만 조용히 적고 다른 갈래로 넘어간다 */
    function placeMiss(q, fromUrl, back, prevSt) {
      placeName = ''; placeHits = []; placeIdx = 0; placeY = null; placeX = null;
      placePick.style.display = 'none';
      var cut = placeCut(q, 16), nm = mEsc(cut) + '’' + josa(cut, '을', '를');
      if (fromUrl && urlSido) {
        runArea();                 /* 함께 온 지역으로 조용히 */
        placeNote('‘' + nm + ' 못 찾았어요. ' + mEsc(areaLabel(urlSido, urlSggu, '')) + '에서 찾아 드릴게요.');
        return;
      }
      if (fromUrl) {
        start();                   /* 지역도 없으면 평소처럼 내 위치로 */
        placeNote('‘' + nm + ' 못 찾았어요. 내 위치로 찾아 드릴게요.');
        return;
      }
      /* 화면에서 직접 적으신 경우 — 위치 권한을 새로 묻지 않는다. 보고 계시던 자리로 돌려 드린다 */
      mode = back; paintDept();
      if (mode === 'area') { ctl.style.display = ''; showBranch(false, true); }
      else if (mode === 'gps') showBranch(true, false);
      else showBranch(true, true);
      placeCtl.style.display = '';
      setStatus(prevSt);
      placeNote('‘' + nm + ' 못 찾았어요. 이름을 조금 다르게 적어 보시거나, <b>다른 지역에서 찾기</b>로 찾아 보세요.');
      try { $('#nb-place-q', placeCtl).focus(); } catch (e) {}
    }
    function startPlace(q, fromUrl) {
      q = placeTrim(q);
      if (!q) return;
      var back = mode, prevSt = statusEl.style.display === 'none' ? '' : statusEl.textContent;
      var my = ++searchSeq;        /* 오다 만 검색이 이 화면을 덮지 않게 */
      busy(false);
      mode = 'place'; placeName = ''; placeHits = []; placeIdx = 0;
      paintDept();
      placePick.style.display = 'none';
      placeNote('');
      ctl.style.display = 'none';
      placeCtl.style.display = '';
      showBranch(false, false);
      if (fromUrl) resetList();    /* 주소로 들어온 경우엔 빈 화면에서 시작한다 */
      setStatus('‘' + placeCut(q, 16) + '’' + josa(placeCut(q, 16), '이', '가') + ' 어디인지 찾는 중…');
      placeSearch(q, function (hits) {
        if (my !== searchSeq || mode !== 'place') return;
        if (!hits) { placeMiss(q, fromUrl, back, prevSt); return; }
        placeHits = hits;
        placeUse(0);
      });
    }
    placeBtn.addEventListener('click', function (e) {
      e.preventDefault();
      placeCtl.style.display = '';
      try { $('#nb-place-q', placeCtl).focus(); } catch (e2) {}
    });
    $('#nb-place-go', placeCtl).addEventListener('click', function (e) {
      e.preventDefault();
      var box = $('#nb-place-q', placeCtl);
      if (!placeTrim(box.value)) { try { box.focus(); } catch (e2) {} return; }
      startPlace(box.value, false);
    });
    $('#nb-place-q', placeCtl).addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.keyCode === 13) {
        e.preventDefault();
        var box = $('#nb-place-q', placeCtl);
        if (placeTrim(box.value)) startPlace(box.value, false);
      }
    });
    $('#nb-place-alt', placePick).addEventListener('click', function (e) { e.preventDefault(); placePop(); });

    /* ── 들어오면 곧바로 내 위치 기준으로 ── */
    function start() {
      searchSeq++;               /* 오다 만 이전 검색이 이 화면을 덮지 않게 (동의 조회·GPS 를 기다리는 동안이 비어 있었다) */
      /* 내 위치로 다시 찾으시는 길이다 — 지역 칸도 지금 계신 곳으로 되돌려 드린다.
         (앞서 다른 지역을 고르셨더라도, 그 뒤 '내 위치에서 다시 찾기'를 누르셨으니 그것이 뜻이다) */
      areaTouched = false;
      mode = 'gps'; placeClear(); paintDept();
      resetList();
      /* 지역으로 찾을 때 넣은 읍·면·동·이름 조건은 내 위치 기준에서는 쓰지 않는다 */
      ctl.style.display = 'none';
      showBranch(false, false);
      setStatus('내 위치를 확인하는 중…');
      locConsent(function (ok) {
        if (mode !== 'gps') return;
        if (ok !== true) {
          /* 02 위치정보 이용 동의(선택)를 안 하셨거나 철회하신 경우(가장 최근 행의 withdrawn_at),
             확인하지 못한 경우(연결 끊김 등)도 위치를 쓰지 않는 쪽으로 처리한다 */
          showArea(ok === null
            ? '위치 동의를 확인하지 못했어요. 위에서 지역을 골라 찾아 주세요.'
            : '위치 사용에 동의하지 않으셔서 지역으로 찾아요. 위에서 지역을 골라 주세요. (동의는 내 정보 › 내가 동의한 내용 보기에서 켜실 수 있어요)');
          return;
        }
        getGPS(function (y, x) {
          if (mode !== 'gps') return;
          runGps(y, x, sidoRank(y, x));
        }, function () {
          if (mode !== 'gps') return;
          showArea('위치를 확인하지 못했어요(실내·지하에서는 잘 안 잡혀요). 위에서 지역을 골라 찾아 주세요.');
        });
      });
    }

    goBtn.addEventListener('click', function (e) { e.preventDefault(); urlAreaLock = false; runArea(); });
    otherBtn.addEventListener('click', function (e) {
      e.preventDefault();
      showArea('위에서 지역·진료과·병원 종류를 고르고 ‘이 조건으로 찾기’를 눌러 주세요.', true);
      try { selSido.focus(); } catch (eF) {}
    });
    gpsBtn.addEventListener('click', function (e) { e.preventDefault(); start(); });
    paintDept();
    /* '장소로 찾기' 버튼은 카카오 열쇠가 있을 때 낸다. 버튼을 낼지 알아보려고 미리 카카오에
       접속하지는 않는다 — 지역으로만 찾으시는 분은 카카오에 아무것도 보내지 않아야 한다
       (25-terms: '지도를 보여 드릴 때' · '장소 이름으로 찾으실 때'만 카카오맵에 전달된다고 적어 두었다).
       열쇠가 막혀 장소 검색이 정말 안 되는 환경이면, 적어 주신 뒤 '못 찾았어요' 한 줄로 조용히 돌아간다 */
    placeOk = !!(CFG && CFG.kakaoJsKey);
    showBranch(brOther, brGps);
    /* 주소로 장소·지역이 지정돼 들어오셨으면 위치를 묻지 않고 그 기준으로 바로 보여 드린다 */
    if (urlPlace) startPlace(urlPlace, true);
    else if (urlSido) runArea();
    else start();
  }

  /* ── 지역으로 병원 찾아 고르기 팝업 — 84 '내 병원 선택하기' ──
     92 의 지역 검색과 같은 방법이다: 시·도 › 시·군·구 › 읍·면·동(직접 입력) › 병원 종류 › 병원 이름.
     위치(좌표)는 쓰지도, 보내지도 않는다. 고르시면 이름·주소·대표전화를 넘겨준다. */
  function hospPop(onPick) {
    var pop = document.getElementById('hosppop');
    if (!pop) {
      pop = el('<div class="callpop" id="hosppop" role="dialog" aria-modal="true" aria-label="내 병원 선택하기" hidden>'
        + '<div class="callpop-card" style="text-align:left; max-height:90%; overflow:auto;">'
        + '<div class="strong" style="font-size:17px;">내 병원 선택하기</div>'
        + '<div class="small muted" style="margin-top:-6px; line-height:1.7;">지역을 고르고 찾으시면, 고르신 병원의 <b>이름·주소·대표전화</b>를 자동으로 채워 드려요. 위치(GPS)는 쓰지 않아요.</div>'
        + '<select class="input" id="hp-sido" aria-label="시·도"></select>'
        + '<select class="input" id="hp-sggu" aria-label="시·군·구"></select>'
        + '<input class="input" id="hp-emd" type="text" placeholder="읍·면·동 (비워 두셔도 돼요)" aria-label="읍·면·동">'
        + '<select class="input" id="hp-cl" aria-label="병원 종류"></select>'
        + '<input class="input" id="hp-name" type="text" placeholder="병원 이름 (선택)" aria-label="병원 이름">'
        + '<a class="btn btn-primary btn-block" id="hp-go" href="javascript:void(0)">🔎 병원 찾기</a>'
        + '<div class="small muted" id="hp-status" role="status" aria-live="polite" style="display:none; line-height:1.7;"></div>'
        + '<div id="hp-list"></div>'
        + '<button class="btn btn-outline btn-block" id="hp-no" type="button">닫기</button>'
        + '</div></div>');
      ($('.screen') || document.body).appendChild(pop);
      var sdo = $('#hp-sido', pop), sgu = $('#hp-sggu', pop), emd = $('#hp-emd', pop),
          scl = $('#hp-cl', pop), snm = $('#hp-name', pop), sgo = $('#hp-go', pop),
          sst = $('#hp-status', pop), slt = $('#hp-list', pop);
      fillSido(sdo); fillSggu(sgu, sdo.value); fillCl(scl);
      sdo.addEventListener('change', function () { fillSggu(sgu, sdo.value); });
      var rows = [], seen = 0, seq2 = 0;
      var more = el('<a class="btn btn-outline btn-block btn-sm" href="javascript:void(0)" style="margin-top:8px; display:none;">더 보기</a>');
      slt.insertAdjacentElement('afterend', more);
      function say(m) { sst.textContent = m; sst.style.display = m ? '' : 'none'; }
      function draw() {
        var next = rows.slice(seen, seen + 10), i;
        for (i = 0; i < next.length; i++) (function (h) {
          var li = el('<div class="listitem" style="cursor:pointer;"><span class="li-ic">🏥</span>'
            + '<div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div>'
            + '<span class="strong small" style="color:var(--primary-dark);">선택</span></div>');
          $('.li-title', li).textContent = h.name;
          $('.li-sub', li).textContent = (h.cl ? h.cl + ' · ' : '') + (h.addr || '주소 정보 없음');
          li.addEventListener('click', function () {
            pop.hidden = true;
            if (pop.__cb) pop.__cb(h);
          });
          slt.appendChild(li);
        })(next[i]);
        seen += next.length;
        more.textContent = Math.min(10, rows.length - seen) + '곳 더 보기';
        more.style.display = seen < rows.length ? '' : 'none';
      }
      more.addEventListener('click', function (e) { e.preventDefault(); draw(); });
      sgo.addEventListener('click', function (e) {
        e.preventDefault();
        if (sgo.__busy) return;
        var my = ++seq2, p = { sidoCd: sdo.value, numOfRows: '100', pageNo: '1' };
        if (sgu.value) p.sgguCd = sgu.value;
        if (emd.value.trim()) p.emdongNm = emd.value.trim();
        if (scl.value) p.clCd = scl.value;
        if (snm.value.trim()) p.yadmNm = snm.value.trim();
        sgo.__busy = true; sgo.textContent = '찾는 중…'; sgo.style.opacity = '.6';
        slt.innerHTML = ''; rows = []; seen = 0; more.style.display = 'none';
        say(areaLabel(sdo.value, sgu.value, emd.value.trim()) + ' 병원을 찾는 중…');
        fetchHosp(p, function (items) {
          if (my !== seq2) return;
          sgo.__busy = false; sgo.textContent = '🔎 병원 찾기'; sgo.style.opacity = '';
          items.sort(function (a, b) { return a.name < b.name ? -1 : 1; });
          rows = items;
          if (!rows.length) { say('조건에 맞는 병원이 없어요. 읍·면·동이나 병원 이름을 지우고 다시 찾아 보세요.'); return; }
          say('이름순으로 보여 드려요. 내 병원을 눌러 주세요.');
          draw();
        }, function (why) {
          if (my !== seq2) return;
          sgo.__busy = false; sgo.textContent = '🔎 병원 찾기'; sgo.style.opacity = '';
          say(why === 'web' ? '병원 찾기 기능이 아직 열리지 않았어요. 잠시 후 다시 시도해 주세요.'
                            : '공공데이터에서 병원 정보를 받아오지 못했어요. 잠시 후 다시 시도해 주세요.');
        });
      });
      $('#hp-no', pop).addEventListener('click', function () { pop.hidden = true; });
      pop.addEventListener('click', function (e) { if (e.target === pop) pop.hidden = true; });
    }
    pop.__cb = onPick;
    pop.hidden = false;
  }

  /* ── 길찾기 팝업: 네이버 지도 / 카카오맵 (웹 링크·앱 자동 연결 — 별도 API 신청 없음, 좌표는 지도 앱으로만 전달) ── */
  function openMap(url) {
    if (window.TDN && window.TDN.openExternal && isNative) window.TDN.openExternal(url);
    else window.open(url, '_blank');
  }
  function mapPop(h) {
    var name = encodeURIComponent(h.name);
    var hasXY = !!(h.y && h.x);
    var naver = hasXY
      ? 'https://map.naver.com/p/directions/-/' + h.x + ',' + h.y + ',' + name + '/-/transit'
      : 'https://map.naver.com/p/search/' + name;
    var kakao = hasXY
      ? 'https://map.kakao.com/link/to/' + name + ',' + h.y + ',' + h.x
      : 'https://map.kakao.com/link/search/' + name;
    var pop = document.getElementById('mappop');
    if (!pop) {
      pop = el('<div class="callpop" id="mappop" role="dialog" aria-modal="true" aria-label="길찾기 앱 선택" hidden>'
        + '<div class="callpop-card"><div style="font-size:30px;">🗺️</div>'
        + '<div class="strong" style="font-size:16px;" id="mappop-title">어떤 지도로 갈까요?</div>'
        + '<div class="tiny muted" id="mappop-sub" style="margin-top:-4px;"></div>'
        + '<a class="btn btn-block btn-lg" id="mappop-naver" href="#" style="background:#03C75A;color:#fff;justify-content:center;"><span style="font-weight:900;">N</span>&nbsp;네이버 지도로 길찾기</a>'
        + '<a class="btn btn-block btn-lg" id="mappop-kakao" href="#" style="background:#FEE500;color:#191919;justify-content:center;">🗺️ 카카오맵으로 길찾기</a>'
        + '<button class="btn btn-outline btn-block" id="mappop-no" type="button">닫기</button></div></div>');
      ($('.screen') || document.body).appendChild(pop);
      $('#mappop-no', pop).addEventListener('click', function () { pop.hidden = true; });
      pop.addEventListener('click', function (e) { if (e.target === pop) pop.hidden = true; });
    }
    $('#mappop-sub', pop).textContent = h.name;
    var nv = $('#mappop-naver', pop), kk = $('#mappop-kakao', pop);
    nv.onclick = function (e) { e.preventDefault(); pop.hidden = true; openMap(naver); };
    kk.onclick = function (e) { e.preventDefault(); pop.hidden = true; openMap(kakao); };
    pop.hidden = false;
  }

  /* ── 전화 걸기 확인 팝업 (84의 것과 동일 동작 — 91·92에도) ── */
  function injectCallpop() {
    if (document.getElementById('callpop')) return;
    var pop = el('<div class="callpop" id="callpop" role="dialog" aria-modal="true" aria-label="전화 걸기 확인" hidden>'
      + '<div class="callpop-card"><div style="font-size:34px;">📞</div>'
      + '<div class="strong" style="font-size:17px;" id="callpop-title">전화를 걸까요?</div>'
      + '<a class="btn btn-primary btn-block btn-lg" id="callpop-go" href="tel:119" data-direct="1">📞 지금 전화 걸기</a>'
      + '<button class="btn btn-outline btn-block" id="callpop-no" type="button">닫기</button></div></div>');
    ($('.screen') || document.body).appendChild(pop);
    var go = $('#callpop-go', pop), no = $('#callpop-no', pop), tt = $('#callpop-title', pop);
    document.addEventListener('click', function (e) {
      var a = e.target && e.target.closest ? e.target.closest('a') : null;
      if (!a) return;
      var h = a.getAttribute('href') || '';
      if (h.indexOf('tel:') !== 0 || a.hasAttribute('data-direct')) return;
      e.preventDefault(); e.stopImmediatePropagation(); e.stopPropagation();
      var num = h.slice(4);
      tt.textContent = num + '에 전화할까요?';
      go.setAttribute('href', 'tel:' + num);
      pop.hidden = false;
      no.focus();
    }, true);
    function close() { pop.hidden = true; }
    no.addEventListener('click', close);
    go.addEventListener('click', function () { setTimeout(close, 150); });
    pop.addEventListener('click', function (e) { if (e.target === pop) close(); });
  }

  /* ── 분기 ── */
  if (PAGE === '84-care-contacts.html') page84();
  else if (PAGE === '91-nearby-gate.html') { injectCallpop(); page91(); }
  else if (PAGE === '85-nearby-clinic.html') {
    /* 85는 다중 상태 시안(가짜 병원 포함) — 실제 게이트(91)로 바로 보낸다.
       넘기기 전에 들어온 화면(referrer)을 남겨 91 의 ‹ 가 그리로 돌아가게 한다 */
    noteEntry(true);
    location.replace('91-nearby-gate.html');
  }
  else if (PAGE === '92-nearby-list.html') { injectCallpop(); page92(); }
})();
