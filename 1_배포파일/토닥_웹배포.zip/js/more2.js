/* ═══ 토닥 화면 배선 v4 — 약별 부작용(70·74·75)·내 약 주의(71)·찾지 못함(72)·진료 전 리포트(77)·보관함(28)·알림함(20)·대화 검색(22) ═══
   more.js 다음에 로드된다. druginfo.js(window.TDRUG)를 사용한다. */
(function () {
  'use strict';
  var T = window.TD || {};
  var sb = T.sb, $ = T.$, $$ = T.$$, toast = T.toast, koError = T.koError, PAGE = T.PAGE;
  if (!sb || !$) return;

  function ymd(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function kdate(d) { return (d.getMonth() + 1) + '월 ' + d.getDate() + '일'; }
  var WDAY = ['일', '월', '화', '수', '목', '금', '토'];
  function qsParam(k) {
    var m = new RegExp('[?&]' + k + '=([^&]*)').exec(location.search);
    return m ? decodeURIComponent(m[1]) : null;
  }
  function el(html) {
    var d = document.createElement('div');
    d.innerHTML = html;
    return d.firstElementChild;
  }
  var esc = T.esc || function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
  var CFG = window.TODAK_CONFIG || {};
  /* app.js 의 세션 도우미를 쓴다. 웹앱에서 예전 app.js 가 캐시에 남아 새 이 파일과 섞이면
     T.withSession 이 없어 화면이 통째로 멈춘다 — 그때만 쓰는 대체 길을 둔다. */
  function sessGet(cb) {
    if (T.withSession) { T.withSession(cb); return; }
    sb.auth.getSession().then(function (r) {
      cb((r && r.data && r.data.session) || null, (r && r.error) || null);
    }, function (e) { cb(null, e || true); });
  }
  function sessOff(btn) {
    if (T.sessOffline) { T.sessOffline(btn); return; }
    if (btn && T.busy) T.busy(btn, false);
    if (toast) toast('연결이 원활하지 않아요. 잠시 후 다시 시도해 주세요.');
  }
  function uid(cb) {
    sessGet(function (ses, err) {
      if (ses) { cb(ses.user.id); return; }
      /* 토큰이 만료된 채 통신이 나쁘면 getSession 은 세션 없이 error 를 돌려준다(실측 25.5초) —
         로그아웃이 아니다. 01-splash 로 내보내면 app.js 첫머리가 todak_ocr_meds 를 지워
         사진으로 읽은 약이 전부 사라지고, 16 증상 기록·10 진료 질문·58 약 이름처럼 적던 것도
         함께 날아간다. 화면에 머물게 하고 알려만 드린다. (2026-09-28 · app.js withSession 참고) */
      if (err) { sessOff(); return; }
      location.replace('01-splash.html');
    });
  }

  /* ── 이 약을 목록에서 빼는 길 ── 2026-09-27
     '이 약 그만 쓰기' 는 55(오늘의 복약)와 56(복약 설정 · 예전 이름 복약 시간 설정)에만 있었다. 70 → 74·75 로 들어오신
     분은 다 쓴 약·잘못 들어간 약을 뺄 길이 없어 되돌아 나가야 했다.
     여기서 바로 빼지는 않는다 — 되돌릴 수 없는 일이므로 한 번 여쭙는 창이 있는 56 으로 모셔다 드린다.
     (56 은 ?m= 을 받아 그 약 카드를 찾아 테두리를 두르고 무엇을 누르시면 되는지 한 줄로 알려 준다.) */
  function medManageRow(mid) {
    var a = el('<a class="listitem" style="margin-top:10px;"><span class="li-ic">🗂️</span>'
      + '<div class="li-body"><div class="li-title">이 약 시간 바꾸기 · 그만 쓰기</div>'
      + '<div class="li-sub">다 쓰셨거나 잘못 들어간 약이면 목록과 복약 알림에서 뺄 수 있어요</div></div>'
      + '<span class="li-chev">›</span></a>');
    a.href = '56-med-schedule.html?m=' + encodeURIComponent(mid);
    return a;
  }

  /* ── 70 등록한 약 전체 보기 ── */
  function page70() {
    var content = $('.content');
    if (!content || !window.TDRUG) return;
    /* 머리글 부제 — 시안에 '등록한 약 4개 기준'이 박혀 있었는데 배선이 이 자리를 칠하지 않아,
       약이 두 개인 분께도 끝까지 4개로 보였다(거짓 숫자). 가려 둔 채로 시작해 실제 개수를 세어 칠한다. */
    var sub70 = $('.appbar-sub');
    function sub70set(t) { if (!sub70) return; sub70.textContent = t; sub70.removeAttribute('data-demo'); }
    content.innerHTML = '';
    content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💊</span><div class="small">등록하신 약을 기준으로 <b>그 약을 쓰시는 동안 알아 둘 것</b>을 모았어요. 모두 겪는 것은 아니에요.</div></div>'));
    sb.from('medications').select('id,name').eq('active', true).then(function (r) {
      var meds = r.data || [];
      if (!meds.length) {
        sub70set(r && r.error ? '' : '등록한 약 없음');
        content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💡</span><div class="small"><b>아직 등록된 약이 없어요.</b> 아래 약 추가하기로 등록해 주세요.</div></div>'));
        var addA = el('<a class="listitem" href="58-med-manual.html"><span class="li-ic">➕</span><div class="li-body"><div class="li-title">약 추가하기</div><div class="li-sub">이름으로 적거나 사진으로 등록할 수 있어요</div></div><span class="li-chev">›</span></a>');
        content.appendChild(addA);
        return;
      }
      sub70set('등록한 약 ' + meds.length + '개 기준');
      var cancers = [], others = [], subByName = {};
      meds.forEach(function (m) {
        (window.TDRUG.match(m.name).cancer ? cancers : others).push(m);
      });
      /* 04에서 고른 '병원에서 맞는 주사 치료'도 약 목록처럼 보여준다 (medications 테이블에는 없음) */
      sb.from('profiles').select('treatment').maybeSingle().then(function (rp) {
        var inj = ((rp.data && rp.data.treatment && rp.data.treatment.injections) || []).filter(function (n) { return n !== '없어요' && n !== '잘 모르겠어요'; });
        if (!inj.length) return;
        var lab = el('<div class="section-label">병원에서 맞는 주사 치료</div>');
        var first = $('.section-label', content);
        content.insertBefore(lab, first || null);
        var after = lab;
        inj.forEach(function (n) {
          var info = window.TDRUG.match(n);
          var a = el('<a class="listitem"><span class="li-ic" style="background:var(--primary-tint);">💉</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span></a>');
          a.href = info.cancer ? '74-med-effect-detail.html?n=' + encodeURIComponent(n) : '75-med-effect-none.html?n=' + encodeURIComponent(n);
          $('.li-title', a).textContent = n;
          $('.li-sub', a).textContent = info.cancer ? (info.cat + ' · 흔한 불편 ' + info.effects.length + '가지와 병원에 연락할 때') : '목록에서 확인하지 못한 치료예요 — 담당 의사에게 확인해 주세요';
          after.parentNode.insertBefore(a, after.nextSibling); after = a;
        });
      });
      if (cancers.length) {
        content.appendChild(el('<div class="section-label">유방암 치료약</div>'));
        cancers.forEach(function (m) {
          var info = window.TDRUG.match(m.name);
          var a = el('<a class="listitem"><span class="li-ic" style="background:var(--primary-tint);">💊</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span></a>');
          a.href = '74-med-effect-detail.html?m=' + m.id;
          $('.li-title', a).textContent = m.name;
          $('.li-sub', a).textContent = info.cat + ' · 흔한 불편 ' + info.effects.length + '가지와 병원에 연락할 때';
          content.appendChild(a);
        });
      }
      if (others.length) {
        content.appendChild(el('<div class="section-label">평소 드시는 약</div>'));
        others.forEach(function (m) {
          var info = window.TDRUG.match(m.name);
          var a = el('<a class="listitem"><span class="li-ic">🩺</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span></a>');
          a.href = '75-med-effect-none.html?m=' + m.id;
          $('.li-title', a).textContent = m.name;
          $('.li-sub', a).textContent = info.unknown
            ? '목록에서 확인하지 못한 약이에요 — 담당 의사나 약사에게 확인해 주세요'
            : (info.cat ? info.cat + ' · ' : '') + '부작용 안내는 없어요 — 겹치는 약을 볼 때 써요';
          subByName[m.name] = $('.li-sub', a);
          content.appendChild(a);
        });
      }
      /* 다 쓴 약·잘못 들어간 약을 뺄 길 — 목록 화면에서는 56 전체로 보낸다 */
      content.appendChild(el('<a class="listitem" href="56-med-schedule.html" style="margin-top:10px;">'
        + '<span class="li-ic">🗂️</span><div class="li-body"><div class="li-title">약 시간 바꾸기 · 그만 쓰기</div>'
        + '<div class="li-sub">다 쓰신 약이나 잘못 들어간 약을 목록과 복약 알림에서 뺄 수 있어요</div></div>'
        + '<span class="li-chev">›</span></a>'));
      content.appendChild(el('<p class="disclaimer">이 안내는 식약처 허가사항과 공개 자료를 근거로 한 참고 정보예요. 약을 바꾸거나 중단하는 결정은 꼭 담당 의사와 상의하세요.</p>'));

      /* 등록 약이 둘 이상이면 서로 병용금기로 걸리는지 한 번 맞춰 본다.
         토닥이 '먹지 마세요'라고 판단하지 않는다 — 걸린 짝만 그대로 알리고 확인은 담당 의사에게 맡긴다.
         그날치 결과는 sessionStorage 에 담아 두어 목록을 다시 열어도 또 묻지 않는다. */
      if (!window.TDPRM) return;
      fillSubs(subByName);                       /* 이미 받아 둔 게 있으면 먼저 채운다 */
      if (meds.length < 2) return;
      window.TDPRM.pairs(meds.map(function (m) { return m.name; })).then(function (hits) {
        fillSubs(subByName);
        if (!hits || !hits.length) return;
        var txt = hits.map(function (h) { return h.a + gwaWa(h.a) + ' ' + h.b; }).join(', ');
        var b = el('<div class="banner banner--warn"><span class="b-ic">⚠️</span><div class="small"></div></div>');
        $('.small', b).textContent = '함께 드실 때 주의가 필요한 약이 있어요 — ' + txt + '. 담당 의사나 약사에게 확인해 주세요.';
        content.insertBefore(b, content.firstChild);
      }, function () { /* 조회가 안 되면 띠 없이 지금까지대로 */ });
    });
  }

  /* 70 목록의 부제를 '성분 · 만든 곳'으로 — 이미 받아 둔 자료만 쓴다(목록에서 새로 조회하지 않는다) */
  function fillSubs(map) {
    if (!window.TDPRM) return;
    for (var nm in map) {
      if (!Object.prototype.hasOwnProperty.call(map, nm)) continue;
      var d = window.TDPRM.cached(nm);
      if (!d || !d.ok) continue;
      var parts = [];
      if (d.ingr && d.ingr.length) parts.push(d.ingr.slice(0, 2).join(', '));
      if (d.entp) parts.push(d.entp);
      if (parts.length) map[nm].textContent = parts.join(' · ');
    }
  }

  /* ── 74 약별 부작용 안내 ── */
  function page74() {
    var content = $('.content');
    if (!content || !window.TDRUG) return;
    var mid = qsParam('m');
    /* 시안 예시(타목시펜정 20mg·성분 tamoxifen·아침 1번 복용 중)를 조회 응답까지 그대로 보여 주고 있었다.
       느린 회선에서는 몇 초씩 남의 약이 보인다 — 70·77 처럼 들어오는 즉시 비운다. (2026-09-26) */
    content.innerHTML = '';
    content.appendChild(el('<div class="banner banner--info"><span class="b-ic">⏳</span><div class="small">약 정보를 불러오는 중이에요…</div></div>'));
    var sub74 = $('.appbar-sub');
    if (sub74) { sub74.textContent = ''; sub74.removeAttribute('data-demo'); }
    uid(function () {
      var q = sb.from('medications').select('id,name').eq('active', true);
      q.then(function (r) {
        var meds = r.data || [];
        var med = null;
        meds.forEach(function (m) { if (String(m.id) === String(mid)) med = m; });
        var nq = qsParam('n');
        if (!med && nq) med = { id: 0, name: nq };   /* 04에서 고른 주사 치료 */
        if (!med) med = meds.filter(function (m) { return window.TDRUG.match(m.name).cancer; })[0];
        content.innerHTML = '';
        var sub = $('.appbar-sub');
        if (!med) {
          /* 시안 부제('성분 tamoxifen')를 여기서도 치운다 — 약을 못 찾았는데 약 이름이 남으면 안 된다 */
          if (sub) { sub.textContent = ''; sub.removeAttribute('data-demo'); }
          content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💊</span><div class="small">등록된 유방암 치료약이 없어요. 약을 등록하면 여기서 안내를 볼 수 있어요.</div></div>'));
          return;
        }
        var info = window.TDRUG.match(med.name);
        /* 유방암 치료약 목록에 없는 약 — 이 화면은 치료약 안내만 있다. 등록한 약이면 '이 약 확인 결과'(75)로 옮긴다.
           (예전에는 안내 목록이 없어 오류가 나고 분류 칸에 'null'이 보였다 — 2026-10-01 검증. 70·55 는 치료약만 여기로 보내지만
           예전 알림·되돌아가기로 열리는 경우가 있다) */
        if (!info || !info.cancer || Object.prototype.toString.call(info.effects) !== '[object Array]') {
          if (med.id) {
            var fr74 = qsParam('from');
            location.replace('75-med-effect-none.html?m=' + encodeURIComponent(med.id) + (fr74 ? '&from=' + encodeURIComponent(fr74) : ''));
            return;
          }
          content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💊</span><div class="small">이 약의 안내는 아직 토닥에 없어요. 담당 의사나 약사에게 여쭤봐 주세요.</div></div>'));
          return;
        }
        if (sub) { sub.textContent = med.name; sub.removeAttribute('data-demo'); }
        var head = $('.appbar-title');
        if (head) head.textContent = '이 약을 쓰시는 동안';

        content.appendChild(el('<div class="card card--tint"><div class="tiny strong" style="color:var(--primary-dark);">' + info.cat + '</div><div class="card-title" style="margin-top:4px;"></div><div class="card-sub">생길 수 있는 불편과 대처를 모았어요. 모두 겪는 것은 아니에요.</div></div>'));
        $('.card-title', content).textContent = med.name;

        content.appendChild(el('<div class="section-label">이런 불편이 생길 수 있어요</div>'));
        info.effects.forEach(function (ef) {
          var item;
          if (ef.link) {
            item = el('<a class="listitem"><span class="li-ic">🌷</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span></a>');
            item.href = ef.link;
          } else {
            item = el('<div class="listitem"><span class="li-ic">🌷</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div></div>');
          }
          $('.li-title', item).textContent = ef.n;
          $('.li-sub', item).textContent = ef.d || '자세한 안내는 부작용 정보에서 볼 수 있어요';
          content.appendChild(item);
        });

        content.appendChild(el('<div class="banner banner--warn"><span class="b-ic">📞</span><div class="small"><b>이럴 땐 미루지 말고 연락하세요.</b> ' + info.warn + '</div></div>'));
        content.appendChild(el('<div class="banner banner--info"><span class="b-ic">🛑</span><div class="small"><b>토닥은 약을 바꾸거나 끊으라는 안내를 하지 않아요.</b> 용량·중단은 담당 의사가 정하는 일이에요.</div></div>'));
        /* 위 띠 바로 아래에 둔다 — '목록에서 빼는 것'과 '약을 끊는 것'이 다른 일임을 먼저 읽으시게 */
        if (med.id) content.appendChild(medManageRow(med.id));
        content.appendChild(el('<p class="disclaimer">식약처 허가사항·NCI 공개 자료를 근거로 한 참고 정보이며, 개인의 상태에 따라 다를 수 있어요.</p>'));
      });
    });
  }

  /* 받침을 보고 '로/으로'를 고른다 — '(안연고)으로 확인돼요'처럼 읽히지 않게.
     괄호로 끝나는 분류('눈에 바르는 약(안연고)')는 괄호를 뺀 마지막 글자를 본다.
     받침이 없거나(코드값 %28 === 0) 'ㄹ'(8)이면 '로', 아니면 '으로'. */
  function roEuro(s) {
    var t = String(s == null ? '' : s).replace(/[)\]}）】]\s*$/, '');
    var ch = t.charCodeAt(t.length - 1);
    if (!(ch >= 0xac00 && ch <= 0xd7a3)) return '으로';
    var j = (ch - 0xac00) % 28;
    return (j === 0 || j === 8) ? '로' : '으로';
  }

  /* 받침을 보고 '과/와'를 고른다 — '엔허투과 함께 쓰면'처럼 읽히지 않게 */
  function gwaWa(s) {
    var t = String(s == null ? '' : s).replace(/[)\]}）】]\s*$/, '');
    var ch = t.charCodeAt(t.length - 1);
    if (!(ch >= 0xac00 && ch <= 0xd7a3)) return '과';
    return ((ch - 0xac00) % 28 === 0) ? '와' : '과';
  }
  /* 식약처 공식 페이지는 앱 밖 브라우저로 연다(앱 안에서 열면 돌아올 길이 없다) */
  function openOut(url) {
    if (window.TDN && window.TDN.isNative && window.TDN.openExternal) { window.TDN.openExternal(url); return; }
    window.open(url, '_blank');
  }
  function factRow(label, value) {
    var it = el('<div class="col" style="gap:3px;"><div class="tiny muted"></div><div class="small strong" style="line-height:1.6;"></div></div>');
    $('.tiny', it).textContent = label;
    $('.small', it).textContent = value;
    return it;
  }
  /* DUR 한 갈래 — 병용금기는 상대 약 이름과 이유를 함께, 5건이 넘으면 3건만 보이고 '더 보기' */
  function durCard(spec, list) {
    var c = el('<div class="card"><div class="strong" style="font-size:15px;"></div><div class="col gap-10" style="margin-top:9px;"></div></div>');
    $('.strong', c).textContent = spec.label;
    var col = $('.col', c);
    var shown = (list.length > 5) ? 3 : list.length;
    function line(x) {
      var d2 = el('<div class="small" style="line-height:1.7;"></div>');
      d2.textContent = x.mate
        ? (x.mate + gwaWa(x.mate) + ' 함께 쓰면 — ' + (x.why || '식약처 자료에 이유가 적혀 있지 않아요'))
        : (x.why || '식약처 자료에 내용이 적혀 있지 않아요');
      return d2;
    }
    for (var i = 0; i < shown; i++) col.appendChild(line(list[i]));
    if (shown < list.length) {
      /* font-size 를 못 박는다 — 360px 에서 .btn-sm 의 clamp 가 12.5px 까지 내려가 본문 하한 13px 을 깬다 */
      var more = el('<button type="button" class="btn btn-outline btn-sm" style="margin-top:10px; font-size:13.5px;"></button>');
      more.textContent = '더 보기 (' + (list.length - shown) + '건)';
      more.addEventListener('click', function () {
        for (var j = shown; j < list.length; j++) col.appendChild(line(list[j]));
        if (more.parentNode) more.parentNode.removeChild(more);
      });
      c.appendChild(more);
    }
    return c;
  }
  /* ══ 허가사항 본문(효능효과·용법용량) 보여 주기 ══ 2026-09-21 교수님 피드백 셋
     ① "왜 점안액과 안연고로 나뉘는 거야?" — 같은 성분의 안과 복합제는 식약처 허가사항이 두 제형
        (점안액·안연고)의 용법을 한 문서에 함께 적어 둔다(네오덱스안연고·맥시트롤안연고가 그렇다).
        등록하신 약의 제형 토막만 먼저 보여 주고 나머지 제형은 접어 둔다. 가르는 잣대는 native.js
        TDN.mfds 의 것을 그대로 쓴다 — 54 의 '하루 몇 번' 자동 채움과 어긋나면 안 된다.
     ② "쓰는 방법이 3가지라는 거야?" — 번호는 방법이 셋이라는 뜻이 아니라 허가받은 쓰임(질환)이
        여럿이라는 뜻이다. 번호가 둘 이상이면 한 줄 덧붙인다.
     ③ "쓸데없는 내용 때문에 너무 길어진다" — 소아 용량표처럼 표로 적힌 토막은 접어 둔다.
     어느 경우에도 받은 글을 요약하거나 고쳐 쓰지 않는다 — 접어 둘 뿐 전부 볼 수 있다. */
  var DOC_SHORT = 220;      /* 글이 이보다 길면 뒤를 접는다 */
  var DOC_TBL_MIN = 4;      /* 표처럼 생긴 줄이 이만큼 이어지면 표로 본다 */
  var DOC_HALF = 130;       /* 여기까지도 못 채웠으면 다음 줄이 길어도 함께 보여 준다 */
  var DOC_LONG = 500;       /* 다만 한 줄이 이보다 길면 글 벽이 되므로 접는다 */
  /* 표 한 칸(또는 칸을 ' · '로 이어 붙인 한 줄)처럼 보이는가 — 문장으로 끝나면 글로 본다 */
  function docTableLine(t) {
    var s = String(t == null ? '' : t).replace(/\s+/g, ' ').trim();
    if (!s) return false;
    if (s.split(' · ').length >= 3) return true;
    if (s.length > 24) return false;
    if (/[.。]$/.test(s)) return false;
    if (/(다|요|함|음)$/.test(s)) return false;
    /* 머리말('만 7 ~ 12세의 소아:')과 갈래 표시('ㆍ성인 : …')는 표 칸이 아니다 —
       이런 줄이 넷 이어졌다고 표로 접으면 정작 읽어야 할 안내가 접힌다.
       2026-09-27 프레미나정 효능효과에서 '2. 위축성 질염, 외음위축증' 같은 번호 목록 일곱 줄이
       표로 접혀 버렸다(가장 먼저 읽어야 할 내용이다) — 번호 줄과 '(주사제)' 같은 괄호
       머리말도 표 칸으로 보지 않는다. */
    if (/[:：]$/.test(s)) return false;
    if (DOC_MARK.test(s)) return false;
    if (/^[1-9]\s*[.)]\s*(?![0-9])\S/.test(s)) return false;
    if (/^[(（][^)）0-9]*[)）]$/.test(s)) return false;   /* '(주사제)' 는 머리말, '(75%용량)' 은 표 칸 */
    return true;
  }
  /* 본문 → [{ t:'text'|'table', lines:[…] }] · 표로 볼 만큼 이어지지 않으면 그냥 글로 둔다 */
  function docChunks(text) {
    var lines = String(text == null ? '' : text).split('\n');
    var out = [], run = [], buf = [], i, j;
    function pushText() { if (buf.length) { out.push({ t: 'text', lines: buf }); buf = []; } }
    function pushRun() {
      if (!run.length) return;
      if (run.length >= DOC_TBL_MIN) { pushText(); out.push({ t: 'table', lines: run }); }
      else { for (j = 0; j < run.length; j++) buf.push(run[j]); }
      run = [];
    }
    for (i = 0; i < lines.length; i++) {
      if (docTableLine(lines[i])) { run.push(lines[i]); continue; }
      pushRun();
      buf.push(lines[i]);
    }
    pushRun();
    pushText();
    return out;
  }
  /* font-size 를 못 박는다 — 360px 에서 .btn-sm 의 clamp 가 본문 하한 13px 아래로 내려간다 */
  function docBtn(label) {
    var b = el('<button type="button" class="btn btn-outline btn-sm" style="margin-top:10px; font-size:13.5px;"></button>');
    b.textContent = label;
    return b;
  }
  /* 식약처 페이지에서 그대로 넘어온 숫자 문자참조를 글자로 바꿔 보여 준다 —
     2026-09-27 크레스토정 효능효과에 '&#xffee;' 와 '&#8226;' 이 글자 그대로 보였다.
     글을 고치는 것이 아니라 원래 글자로 되돌려 놓는 것이다. */
  function docEnt(t) {
    return String(t == null ? '' : t).replace(/&#(x[0-9a-fA-F]+|[0-9]+);/g, function (all, code) {
      var hex = (code.charAt(0) === 'x' || code.charAt(0) === 'X');
      var n = hex ? parseInt(code.slice(1), 16) : parseInt(code, 10);
      if (!(n > 0 && n <= 0xffff)) return all;
      return String.fromCharCode(n);
    });
  }
  /* 갈래 표시로 시작하는 줄 — 식약처 본문은 ㆍ · ○ * - 를 섞어 쓴다 */
  var DOC_MARK = /^[ \t]*(?:[ㆍ·•●○∙‧￮◦∘＊*]|[-–—](?=[ \t]))[ \t]*(?=\S)/;
  /* 본문 한 토막 — 갈래는 줄을 나눠 ● 로 매달아 쓴다(상담 화면 answerEl 과 같은 결).
     글자는 손대지 않는다. 줄 앞의 기호만 ● 로 바꾸고, 줄이 넘어가면 글이 안쪽으로 들어온다.
     plain 이면 원문 그대로 둔다(표로 적힌 토막은 칸마다 한 줄이라 기호를 붙이면 안 된다). */
  function docBody(s, hidden, plain) {
    var d = el('<div class="small" style="margin-top:9px; line-height:1.8; word-break:keep-all;"></div>');
    if (hidden) d.style.display = 'none';
    if (plain) {
      d.style.whiteSpace = 'pre-wrap';
      d.textContent = docEnt(s);
      return d;
    }
    var lines = docEnt(s).split('\n'), i, m, row, dot;
    for (i = 0; i < lines.length; i++) {
      m = DOC_MARK.exec(lines[i]);
      row = document.createElement('div');
      row.style.whiteSpace = 'pre-wrap';
      if (m) {
        row.setAttribute('style', 'padding-left:14px; text-indent:-14px; margin:0 0 5px; white-space:pre-wrap;');
        /* 점은 글 줄 안에 넣는다(inline-block · vertical-align:middle) — 2026-10-26 사용 의견: 점이 글자보다 위에 떠 보였다.
           예전에는 ● 글자를 0.55em 으로 줄여 줄 위쪽에 띄워 두어 줄 높이까지 같이 줄어 점이 위로 붙었고,
           휴대폰 글자를 크게 쓰시면 em 으로 박은 자리는 그대로라 더 어긋났다. 줄 안에 두면 어느 배율에서나 첫 줄 가운데에 앉는다.
           둘째 줄부터는 들여쓰기 14px · 내어쓰기 −14px 로 글 첫머리에 맞춘다(점 6px + 오른쪽 여백 8px = 14px). */
        dot = document.createElement('span');
        dot.setAttribute('aria-hidden', 'true');
        dot.setAttribute('style', 'display:inline-block; width:6px; height:6px; margin-right:8px; border-radius:50%; background:currentColor; vertical-align:middle; position:relative; top:-1px; text-indent:0;');
        row.appendChild(dot);
        row.appendChild(document.createTextNode(lines[i].slice(m[0].length)));
      } else {
        row.textContent = lines[i];
      }
      d.appendChild(row);
    }
    return d;
  }
  function docTextDiv(s, hidden) { return docBody(s, hidden, false); }
  /* 표로 적힌 토막 — 접은 채로 두고 눌러서 편다(원문 그대로) */
  function docTableFold(lines) {
    var wrap = document.createElement('div');
    var shut = '표로 적힌 부분 보기 (' + lines.length + '줄)';
    var btn = docBtn(shut);
    var box = docBody(lines.join('\n'), true, true);
    btn.addEventListener('click', function () {
      var open = (box.style.display === 'none');
      box.style.display = open ? '' : 'none';
      btn.textContent = open ? '표 접기' : shut;
    });
    wrap.appendChild(btn);
    wrap.appendChild(box);
    return wrap;
  }
  /* 글을 카드에 채운다 — 표는 따로 접고, 글이 길면 뒷줄을 '더 보기' 뒤로 넘긴다.
     줄 가운데서 자르지 않는다 — 어르신이 읽다가 말끝이 끊기면 무슨 말인지 알 수 없다.
     첫 줄은 길더라도 늘 보여 준다(본문이 통째로 접혀 빈 카드처럼 보이면 안 된다). */
  function docFill(host, text) {
    var chunks = docChunks(String(text || '').replace(/\n{2,}/g, '\n').trim());
    var used = 0, cut = false, hidden = [], i, j, c, lines, keep, rest;
    for (i = 0; i < chunks.length; i++) {
      c = chunks[i];
      if (c.t === 'table') { host.appendChild(docTableFold(c.lines)); continue; }
      lines = [];
      for (j = 0; j < c.lines.length; j++) {
        if (String(c.lines[j]).replace(/\s+/g, '') !== '') lines.push(c.lines[j]);
      }
      if (!lines.length) continue;
      if (cut) { hidden.push(host.appendChild(docTextDiv(lines.join('\n'), true))); continue; }
      keep = []; rest = [];
      for (j = 0; j < lines.length; j++) {
        /* 아직 얼마 안 보여 줬는데 다음 줄이 길다고 접으면, 머리말만 남고 정작 용량이 감춰진다
           (알비스정은 '○ 성인 / 1) 위·십이지장궤양' 까지 59자만 보이고 용량이 접혔다).
           절반도 못 채웠으면 그 줄은 길더라도 함께 보여 준다. */
        if (!cut && (!used || used + lines[j].length <= DOC_SHORT
                     || (used < DOC_HALF && lines[j].length <= DOC_LONG))) {
          keep.push(lines[j]); used += lines[j].length;
        } else { cut = true; rest.push(lines[j]); }
      }
      if (keep.length) host.appendChild(docTextDiv(keep.join('\n'), false));
      if (rest.length) hidden.push(host.appendChild(docTextDiv(rest.join('\n'), true)));
    }
    if (!hidden.length) return;
    var more = docBtn('나머지도 보기');
    more.addEventListener('click', function () {
      for (var k = 0; k < hidden.length; k++) hidden[k].style.display = '';
      if (more.parentNode) more.parentNode.removeChild(more);
    });
    host.appendChild(more);
  }
  /* 맨 위 번호(1. 2. 3. · 1) 2) 3))가 몇 개인가 — 몇 가지 쓰임으로 나뉘어 적혀 있는지 세는 데만 쓴다.
     ── 2026-09-27 실제 자료로 확인한 것 ──
     예전 잣대는 소아 용량표의 '7.5ml'·'2.5ml' 과 체표면적표의 '1.27～1.38' 까지 번호로 셌다.
     그래서 번호가 하나도 없는 알파아세트아미노펜정에도 "번호는 …" 설명이 붙었다(거짓 설명).
     이제 점·괄호 뒤에 숫자가 오면 번호로 보지 않고, 1 부터 차례로 이어질 때까지만 센다. */
  function docNumCount(text) {
    var lines = String(text == null ? '' : text).split('\n'), seen = {}, n = 0, i, m;
    for (i = 0; i < lines.length; i++) {
      m = /^\s*([1-9])\s*[.)]\s*(?![0-9])\S/.exec(lines[i]);
      if (!m) continue;
      seen[m[1]] = 1;
    }
    while (seen[String(n + 1)]) n++;
    return n;
  }
  /* 뒤가 잘렸는지는 서버가 알려 준다(eeCut·udCut) — 2026-09-27.
     예전에는 글자 수가 3000 에 닿았는지로 짐작했는데, 서버가 줄 끝에서 자르게 바뀌면서
     글자 수로는 알 수 없게 됐다(잘리지 않은 5,719자 글에 잘렸다는 안내가 붙어 버린다).
     DOC_CAP 은 잘림 표시를 보내지 않는 옛 서버에서만 쓰는 어림값으로 남겨 둔다. */
  var DOC_CAP = 3000;
  function docWasCut(flag, t) {
    if (flag === true) return true;
    if (flag === false) return false;
    return String(t == null ? '' : t).length >= DOC_CAP;
  }
  /* ── 나이대로 갈린 용법 ── 2026-09-21 교수님 피드백
     "타이레놀 쓰는 방법에 소아 용량표(만 7세 23kg 320mg 2포…)가 줄줄이 나와 못 읽는다"
     식약처 허가사항은 한 문서에 어른용과 어린이용을 같이 적어 둔다
     (알파아세트아미노펜정500밀리그람은 '(경구 : 300mg…)' 다음에 '(어린이용 : 80mg, 160mg )'
      '(어린이용 : 액제, 현탁액, 엘릭서제 )' 가 이어진다 — 2026-09-27 실제로 받아 확인했다).
     토닥은 어른 환자분이 쓰는 앱이라, 어린이용 토막은 접어 두고 어른 부분을 먼저 보여 준다.
     지우지 않는다 — 눌러서 원문 그대로 볼 수 있다.
     어른 토막이 하나도 없으면(어린이타이레놀산처럼 그 약 자체가 소아용이면) 아무것도 접지 않는다. */
  var AGE_KID = /(어린이|소아|유아|영아|신생아)/;
  var AGE_GROWN = /(성인|어른|고령|노인|세\s*이상)/;
  /* 머리말처럼 생긴 줄만 토막의 시작으로 본다 — 문장이 괄호로 끝나는 줄은 머리말이 아니다
     ('(몸무게를 아는 경우에는 … 더 적절하다.)' 는 본문이다) */
  function ageHead(line) {
    var s = String(line == null ? '' : line).replace(/\s+/g, ' ').trim(), m;
    if (!s) return '';
    m = /^[(（]\s*([^)）]{1,30})\s*[)）]$/.exec(s);
    if (!m) m = /^[ㆍ·•○*\-–]?\s*([^:：]{1,24})\s*[:：]$/.exec(s);
    if (!m) return '';
    var h = m[1].replace(/\s+$/, '');
    if (/(다|요|함|음)\.?$/.test(h)) return '';
    return h;
  }
  /* 본문 → [{ head, kid, lines }] · 머리말이 없는 앞쪽도 한 토막으로 둔다 */
  function ageSections(text) {
    var lines = String(text == null ? '' : text).split('\n');
    var secs = [], cur = null, i, h;
    for (i = 0; i < lines.length; i++) {
      h = ageHead(lines[i]);
      if (h) {
        cur = { head: h, kid: AGE_KID.test(h) && !AGE_GROWN.test(h), lines: [lines[i]] };
        secs.push(cur);
        continue;
      }
      if (!cur) { cur = { head: '', kid: false, lines: [] }; secs.push(cur); }
      cur.lines.push(lines[i]);
    }
    return secs;
  }
  function secText(sec) { return sec.lines.join('\n').replace(/^\n+/, '').replace(/\n+$/, ''); }
  /* 제형·모양을 가리키는 머리말만 모은다 — 몇 가지로 갈려 있는지 알리는 데만 쓴다(고르지 않는다) */
  var FORM_WORD = /(정제|주사|캡슐|시럽|현탁액|연고|크림|로션|점안|경구|외용|패치|패취|산제|액제|엘릭서|가루|좌제|흡입)/;
  function formLabels(secs) {
    var out = [], seen = {}, i, h;
    for (i = 0; i < (secs || []).length; i++) {
      h = secs[i].head;
      if (!h || !FORM_WORD.test(h) || seen[h]) continue;
      seen[h] = 1; out.push(h);
      if (out.length >= 4) break;
    }
    return out;
  }
  /* 글자가 얼마나 들었나 — 빈 줄뿐인 토막을 '어른 부분이 남았다'로 세지 않으려고 */
  function bulk(s) { return String(s == null ? '' : s).replace(/\s+/g, '').length; }
  /* 허가사항 본문 한 덩이 — 제목 / 출처 / 덧붙이는 한 줄들 / 본문 */
  function docCard(title, text, sub, notes) {
    var c = el('<div class="card"><div class="strong" style="font-size:15px;"></div>'
      + '<p class="tiny muted" style="margin:4px 0 0; line-height:1.6;"></p></div>');
    $('.strong', c).textContent = title;
    $('p', c).textContent = sub || '';
    var i, p;
    for (i = 0; i < (notes || []).length; i++) {
      if (!notes[i]) continue;
      p = el('<div class="banner banner--info" style="margin-top:9px;"><span class="b-ic">💡</span><div class="small"></div></div>');
      $('.small', p).textContent = notes[i];
      c.appendChild(p);
    }
    docFill(c, text);
    return c;
  }
  /* '쓰는 방법' 카드 — 제형이 여럿 적힌 허가사항이면 이 약 제형 토막만 보여 주고 나머지는 접는다 */
  function udCard(udText, name, eeText, udCut) {
    var mf = (window.TDN && TDN.mfds) || null;
    var secs = (mf && mf.formSections) ? mf.formSections(udText) : [];
    var mine = (secs.length && mf.formPick) ? mf.formPick(secs, name) : null;
    var body = udText, others = [], notes = [], tags = [], i;
    for (i = 0; i < secs.length; i++) tags.push(secs[i].tag);
    if (secs.length && mine) {
      body = mine.text;
      for (i = 0; i < secs.length; i++) if (secs[i] !== mine) others.push(secs[i]);
      notes.push('이 약은 식약처 허가사항 하나에 ' + tags.join('·') + ' ' + tags.length + '가지 제형의 쓰는 법이 함께 적혀 있어요. 등록하신 ' + mine.tag + ' 부분만 보여 드려요.');
    } else if (secs.length) {
      notes.push('이 허가사항에는 ' + tags.join('·') + ' 제형의 쓰는 법이 함께 적혀 있어요. 쓰시는 제형에 해당하는 부분만 보시면 돼요.');
    }
    /* 어린이용 토막은 접어 둔다 — 어른 부분이 남고, 그 약 자체가 어린이용이 아닐 때만.
       (어린이타이레놀산·어린이부루펜시럽처럼 이름부터 어린이용인 약은 그 부분이 본문이다) */
    var ages = ageSections(body), kids = [], grown = [], gt;
    for (i = 0; i < ages.length; i++) (ages[i].kid ? kids : grown).push(ages[i]);
    gt = grown.map(secText).join('\n').replace(/^\n+/, '').replace(/\n+$/, '');
    if (kids.length && bulk(gt) >= 20 && !AGE_KID.test(String(name == null ? '' : name))) {
      body = gt;
      notes.push('이 허가사항에는 어린이 용량도 함께 적혀 있어요. 어른이 드시는 부분만 먼저 보여 드리고, 어린이 용량은 아래에 접어 두었어요.');
    } else {
      grown = ages;                      /* 접지 않았으면 전부가 그대로 보인다 */
      kids = [];                         /* 접지 않았으니 단추도 붙이지 않는다(같은 글이 두 번 나온다) */
    }
    /* native.js 가 가를 수 있는 제형(안연고·점안액·정 …)이 아니라 가르지 못했는데,
       보여 주는 쪽이 아직 두 갈래 이상일 때만 왜 여러 개가 나오는지 한 줄 알린다.
       프레미나정이 '(경구 : 정제)'·'(주사제)' 로 갈려 있는 경우다. 마음대로 고르지 않는다
       (54 의 '하루 몇 번'과 어긋나면 안 된다) — 전부 보여 주고 이유만 적는다. */
    if (!secs.length) {
      var fh = formLabels(grown);
      if (fh.length >= 2) {
        notes.push('이 허가사항 하나에 ' + fh.join('·') + ' 처럼 모양이 다른 제형의 쓰는 법이 함께 적혀 있어요. 등록하신 약에 해당하는 부분만 보시면 돼요. 어느 쪽인지 헷갈리면 담당 의사나 약사에게 여쭤보세요.');
      }
    }
    var udNum = docNumCount(body);
    if (udNum >= 2) {
      notes.push('번호는 쓰는 방법이 여러 가지라는 뜻이 아니라, 이 약이 허가받은 쓰임(질환)마다 용량이 따로 적혀 있다는 뜻이에요.'
        + (docNumCount(eeText) === udNum ? ' 위 「이 약은 이런 약이에요」에 적힌 번호와 같아요.' : '')
        + ' 나에게 해당하는 번호는 담당 의사나 약사가 정해 줘요.');
    }
    if (docWasCut(udCut, udText)) notes.push(CUT_NOTE);
    var c = docCard('쓰는 방법', body, '식품의약품안전처 허가사항 · 용법용량', notes);
    for (i = 0; i < others.length; i++) c.appendChild(otherFormFold(others[i]));
    for (i = 0; i < kids.length; i++) c.appendChild(kidFold(kids[i]));
    return c;
  }
  /* 원문이 길어 뒤가 잘렸을 때 — 감추지 않고 알리고, 끝까지 볼 길을 알려 준다 */
  var CUT_NOTE = '식약처 원문이 길어서 여기까지만 가져왔어요. 끝까지 보시려면 아래 「식약처 허가사항 전체 보기」를 눌러 주세요.';
  /* 어린이 용량 토막 — 접어 두고 보고 싶을 때만 편다(원문을 없애지는 않는다) */
  function kidFold(sec) {
    var wrap = document.createElement('div');
    var shut = '어린이 용량 부분도 보기' + (sec.head ? ' (' + sec.head + ')' : '');
    var btn = docBtn(shut);
    var box = docBody(secText(sec), true, false);
    btn.addEventListener('click', function () {
      var open = (box.style.display === 'none');
      box.style.display = open ? '' : 'none';
      btn.textContent = open ? '접기' : shut;
    });
    wrap.appendChild(btn);
    wrap.appendChild(box);
    return wrap;
  }
  /* 등록하신 제형이 아닌 토막 — 접어 두고 보고 싶을 때만 편다(원문을 없애지는 않는다) */
  function otherFormFold(sec) {
    var wrap = document.createElement('div');
    var shut = '다른 제형(' + sec.tag + ') 내용도 보기';
    var btn = docBtn(shut);
    var box = docBody(sec.text, true, false);
    btn.addEventListener('click', function () {
      var open = (box.style.display === 'none');
      box.style.display = open ? '' : 'none';
      btn.textContent = open ? '접기' : shut;
    });
    wrap.appendChild(btn);
    wrap.appendChild(box);
    return wrap;
  }
  /* 효능효과·용법용량을 못 받았을 때 — 빈자리를 두지 않고 어디서 볼 수 있는지 알린다 */
  function docNoneBox() {
    return el('<div class="banner banner--info"><span class="b-ic">📄</span><div class="small">식약처 자료에서 이 약의 <b>효능효과·쓰는 방법 본문은 찾지 못했어요.</b> 아래 「식약처 허가사항 전체 보기」에서 확인하실 수 있어요.</div></div>');
  }
  /* 조회 실패·결과 없음 — 빈 화면을 두지 않는다 */
  function fill75None(body) {
    body.appendChild(el('<div class="banner banner--info"><span class="b-ic">🔎</span><div class="small"><b>목록에서 확인하지 못한 약이에요.</b> 식약처 자료에서 이 이름을 찾지 못했어요. 그래도 등록해 두시면 <b>암 치료약과 겹치는 증상이 있는지 확인</b>하는 데 쓰여요.</div></div>'));
    body.appendChild(el('<div class="banner banner--safe"><span class="b-ic">💊</span><div class="small">이 약이 어떤 약인지는 <b>담당 의사나 약사에게 여쭤보세요.</b> 처방받은 병원·약국이 가장 정확히 알려 드릴 수 있어요.</div></div>'));
    body.appendChild(el('<p class="disclaimer">토닥은 의료기기가 아니며, 약 정보는 참고용이에요.</p>'));
  }
  /* 식약처 공공데이터를 그대로 — 정식 이름 / 성분 / 만든 곳 / 보관법 / 이 약의 주의 / 허가사항 보기 / 고지 */
  function fill75Info(body, d) {
    var facts = el('<div class="card"><div class="col gap-10"></div></div>');
    var col = $('.col', facts);
    col.appendChild(factRow('정식 이름', d.name || '자료에 적혀 있지 않아요'));
    col.appendChild(factRow('성분', (d.ingr && d.ingr.length) ? d.ingr.join(', ') : '자료에 적혀 있지 않아요'));
    col.appendChild(factRow('만든 곳', d.entp || '자료에 적혀 있지 않아요'));
    col.appendChild(factRow('보관법', d.storage || '자료에 적혀 있지 않아요'));
    body.appendChild(facts);

    /* ── 효능효과·용법용량 ── 2026-09-20 교수님 피드백
       "식약처 허가사항에 용법용량이 있는데 왜 안 넣냐" — 허가정보 API 에는 이 두 본문이 없어
       중계 함수가 식약처 공식 페이지에서 뽑아 온다. 몇 초 걸려서 먼저 자리를 잡아 두고 채운다. */
    var docBox = document.createElement('div');
    body.appendChild(docBox);
    if (d.seq && window.TDPRM && window.TDPRM.doc) {
      docBox.appendChild(el('<div class="banner banner--info"><span class="b-ic">⏳</span><div class="small">식약처 허가사항에서 <b>효능효과·용법용량</b>을 가져오는 중이에요…</div></div>'));
      window.TDPRM.doc(d.seq).then(function (doc) {
        docBox.innerHTML = '';
        /* 못 받아왔거나 자료에 없을 때 — 자리를 그냥 비워 두면 화면이 잘린 것처럼 보인다 */
        if (!doc || (!doc.ee && !doc.ud)) { docBox.appendChild(docNoneBox()); return; }
        if (doc.ee) {
          var eeNotes = [];
          if (docNumCount(doc.ee) >= 2) {
            eeNotes.push('번호는 이 약이 허가받은 쓰임(질환)을 하나씩 적어 둔 거예요. 그 가운데 어떤 이유로 드시는지는 담당 의사나 약사에게 여쭤보시면 돼요.');
          }
          if (docWasCut(doc.eeCut, doc.ee)) eeNotes.push(CUT_NOTE);
          docBox.appendChild(docCard('이 약은 이런 약이에요', doc.ee, '식품의약품안전처 허가사항 · 효능효과', eeNotes));
        }
        if (doc.ud) {
          docBox.appendChild(udCard(doc.ud, d.name, doc.ee, doc.udCut));
          docBox.appendChild(el('<p class="tiny muted" style="line-height:1.7;">허가사항에 적힌 일반적인 방법이에요. <b>실제로 드시는 방법은 담당 의사나 약사가 알려 주신 대로 해 주세요.</b></p>'));
        } else {
          docBox.appendChild(el('<div class="banner banner--info"><span class="b-ic">📄</span><div class="small">식약처 자료에 이 약의 <b>쓰는 방법(용법용량)</b>은 글로 적혀 있지 않았어요. 드시는 방법은 담당 의사나 약사가 알려 주신 대로 해 주세요.</div></div>'));
        }
      }, function () { docBox.innerHTML = ''; docBox.appendChild(docNoneBox()); });
    }

    var specs = (window.TDPRM && window.TDPRM.specs) || [], dur = d.dur || {};
    var wrap = document.createElement('div'), any = false;
    for (var i = 0; i < specs.length; i++) {
      var list = dur[specs[i].key];
      if (!list || !list.length) continue;
      any = true;
      wrap.appendChild(durCard(specs[i], list));
    }
    if (any) {
      body.appendChild(el('<div class="section-label">이 약의 주의</div>'));
      body.appendChild(wrap);
      body.appendChild(el('<p class="tiny muted" style="line-height:1.7;">식약처 DUR 품목정보에 적힌 내용을 그대로 옮긴 거예요. 나에게 해당하는지는 담당 의사나 약사가 보고 알려 주셔야 해요.</p>'));
    } else {
      body.appendChild(el('<div class="banner banner--info"><span class="b-ic">🔎</span><div class="small">식약처 DUR 자료에 <b>이 약에 대해 따로 적힌 주의는 없었어요.</b> 주의가 없다는 뜻이 아니라, 그 자료에 적힌 것이 없다는 뜻이에요.</div></div>'));
    }

    if (d.seq) {
      var btn = el('<button type="button" class="btn btn-outline btn-block" style="margin-top:12px;">🔗 식약처 허가사항 전체 보기</button>');
      btn.addEventListener('click', function () { openOut(window.TDPRM.officialUrl(d.seq)); });
      body.appendChild(btn);
      body.appendChild(el('<p class="tiny muted" style="margin-top:6px;">주의사항까지 모두 보시려면 식약처 공식 화면에서 확인해 주세요 — 앱 밖 인터넷 창으로 열려요.</p>'));
    }
    var note = el('<p class="disclaimer" style="margin-top:14px;"></p>');
    note.textContent = (window.TDPRM && window.TDPRM.notice) || '';
    body.appendChild(note);
  }

  /* ── 75 약 정보 — 암 치료약이 아닌 약은 식약처 공공데이터를 그대로 보여준다 ── */
  function page75() {
    var content = $('.content');
    if (!content || !window.TDRUG) return;
    var mid = qsParam('m'), nq = qsParam('n');
    /* 시안 예시(엔테론정50밀리그램 · 한림제약 · '병용금기: 프레미나정과 함께 쓰면…')가 조회 응답까지 보였다.
       드시지도 않는 약의 병용금기를 잘못 읽으실 수 있어 들어오는 즉시 비운다. (2026-09-26) */
    content.innerHTML = '';
    content.appendChild(el('<div class="banner banner--info"><span class="b-ic">⏳</span><div class="small">약 정보를 불러오는 중이에요…</div></div>'));
    var sub75 = $('.appbar-sub');
    if (sub75) { sub75.textContent = ''; sub75.removeAttribute('data-demo'); }
    uid(function () {
      sb.from('medications').select('id,name').eq('active', true).then(function (r) {
        var meds = r.data || [];
        var med = null;
        meds.forEach(function (m) { if (String(m.id) === String(mid)) med = m; });
        if (!med && nq) med = { id: 0, name: nq };      /* 04 에서 고른 주사 치료 */
        var nm = med ? med.name : '이 약';
        var info = window.TDRUG.match(nm);
        var head = $('.appbar-title'); if (head) head.textContent = '약 정보';
        var sub = $('.appbar-sub'); if (sub) { sub.textContent = nm; sub.removeAttribute('data-demo'); }
        content.innerHTML = '';
        var card = el('<div class="card"><div class="card-title"></div><div class="card-sub" style="margin-top:6px;"></div></div>');
        $('.card-title', card).textContent = nm;
        $('.card-sub', card).textContent = info.cancer
          ? (info.cat ? info.cat + roEuro(info.cat) + ' 확인돼요. ' : '') + '식약처에 등록된 내용이에요.'
          : info.cat
            ? info.cat + roEuro(info.cat) + ' 확인돼요. 유방암 치료약이 아니라서 부작용 안내는 없어요.'
            : '유방암 치료약 목록에는 없는 약이에요.';
        content.appendChild(card);
        var body = el('<div></div>');
        content.appendChild(body);
        /* 조회 결과는 body 안을 나중에 채운다 — 빼는 길은 그 아래에 미리 놓아 둔다 */
        if (med && med.id) content.appendChild(medManageRow(med.id));
        body.appendChild(el('<div class="banner banner--info"><span class="b-ic">⏳</span><div class="small">식품의약품안전처 자료에서 이 약을 찾는 중이에요…</div></div>'));
        if (!window.TDPRM) { body.innerHTML = ''; fill75None(body); return; }
        window.TDPRM.lookup(nm, 'full').then(function (d) {
          body.innerHTML = '';
          if (d && d.ok) fill75Info(body, d); else fill75None(body);
        }, function () { body.innerHTML = ''; fill75None(body); });
      });
    });
  }

  /* ── 77 진료 전 리포트 (최근 14일 실데이터) ── */
  /* 최근 7일(오늘 포함) 복약 체크 요약 — '필요할 때만' 약은 세지 않고, 약을 등록하기 전 날도 세지 않는다.
     오늘은 알림 시간이 지난 것(또는 이미 체크한 것)만 센다. */
  var SLOT_TIME = { '아침': '08:00', '점심': '13:00', '저녁': '19:00', '자기전': '22:00' };
  function medSummary(meds, logs, week, now) {
    if (!meds.length) return { text: '등록된 약이 없어요', muted: true };
    var taken = {};
    logs.forEach(function (l) { if (l.taken) taken[l.medication_id + '|' + l.date + '|' + l.slot] = 1; });
    var todayS = ymd(now), nowHM = ('0' + now.getHours()).slice(-2) + ':' + ('0' + now.getMinutes()).slice(-2);
    var due = 0, done = 0, fullDays = 0, dueDays = 0, anyFixed = false;
    for (var i = 0; i < 7; i++) {
      var ds = ymd(new Date(week.getFullYear(), week.getMonth(), week.getDate() + i));
      var dDue = 0, dDone = 0;
      meds.forEach(function (m) {
        /* 드시는 시간을 바꾼 약은 그날의 시간으로 센다(features.js medSlotsOn · 2026-10-26) — 바꾼 날 앞의 체크가 빠져 보이지 않게 */
        var slots = ((T.medSlotsOn ? T.medSlotsOn(m, ds) : (m.schedule && m.schedule.slots)) || []).filter(function (s) { return s !== '필요시'; });
        if (slots.length) anyFixed = true;
        var cd = m.created_at ? new Date(m.created_at) : null;
        var cS = cd && !isNaN(cd) ? ymd(cd) : '', cHM = cS ? ('0' + cd.getHours()).slice(-2) + ':' + ('0' + cd.getMinutes()).slice(-2) : '';
        if (cS && cS > ds) return;
        slots.forEach(function (slot) {
          var hit = !!taken[m.id + '|' + ds + '|' + slot];
          if (!hit) {
            var t = ('0' + ((m.schedule.times && m.schedule.times[slot]) || SLOT_TIME[slot] || '00:00')).slice(-5);
            if (ds === todayS && t > nowHM) return;   /* 오늘 아직 시간이 안 된 복약 */
            if (ds === cS && t < cHM) return;         /* 등록한 날, 등록하기 전 시간의 복약 */
          }
          dDue++;
          if (hit) dDone++;
        });
      });
      if (!dDue) continue;
      dueDays++; due += dDue; done += dDone;
      if (dDone >= dDue) fullDays++;
    }
    if (!anyFixed) return { text: '정해진 시간에 쓰는 약이 없어요 (필요할 때만 쓰는 약만 등록돼 있어요)', muted: true };
    if (!due) return { text: '아직 셀 수 있는 복약 기록이 없어요', muted: true };
    return { html: '예정된 복약 <b>' + due + '회 중 ' + done + '회</b> 체크하셨어요 · 모두 챙긴 날 <b>' + fullDays + '일</b> / ' + dueDays + '일' };
  }

  function page77() {
    var content = $('.content');
    if (!content) return;
    /* 시안의 예시 기록(이름·통계·공유 버튼)이 불러오는 동안 보이지 않게 바로 비운다 */
    var sub0 = $('.appbar-sub');
    if (sub0) { sub0.textContent = '최근 2주 요약'; sub0.removeAttribute('data-demo'); }
    content.innerHTML = '';
    content.appendChild(el('<div class="banner banner--info"><span class="b-ic">⏳</span><div class="small">기록을 불러오는 중이에요…</div></div>'));
    /* 통신이 멈추면(응답도 거절도 없으면) '불러오는 중이에요…'가 영원히 남았다 (2026-10-01 새벽 검증).
       홈의 두 고리처럼 8초를 두고 못 불러왔을 때와 같은 말로 바꾼다. 뒤늦게 응답이 오면 아래에서 다시 그린다 */
    var got77 = false;
    setTimeout(function () {
      if (got77) return;
      content.innerHTML = '';
      content.appendChild(el('<div class="banner banner--warn"><span class="b-ic">📶</span><div class="small">기록을 불러오지 못했어요. 연결을 확인하고 다시 열어 주세요.</div></div>'));
    }, 8000);
    uid(function (id) {
      var today = new Date();
      var since = new Date(); since.setDate(since.getDate() - 13);
      var week = new Date(); week.setDate(week.getDate() - 6);
      Promise.all([
        sb.from('profiles').select('name,treatment').eq('id', id).maybeSingle(),
        sb.from('checkins').select('date,mood,symptoms,intensity').gte('date', ymd(since)),
        sb.from('medications').select('id,schedule,created_at').eq('active', true),
        sb.from('med_logs').select('medication_id,date,slot,taken').gte('date', ymd(week))
      ]).then(function (res) {
        got77 = true;
        var rp = res[0], rc = res[1], rm = res[2], rl = res[3];
        if (rp.error || rc.error) {
          content.innerHTML = '';
          content.appendChild(el('<div class="banner banner--warn"><span class="b-ic">📶</span><div class="small">기록을 불러오지 못했어요. 연결을 확인하고 다시 열어 주세요.</div></div>'));
          return;
        }
        var name = (rp.data && rp.data.name) || '회원';
        var treat = (rp.data && rp.data.treatment) || {};
        var rows = rc.data || [];
        var sub = $('.appbar-sub');
        if (sub) sub.textContent = /^\d{4}-\d{2}-\d{2}$/.test(treat.next_visit || '') ? (kdate(new Date(treat.next_visit + 'T00:00:00')) + ' 진료용') : '최근 2주 요약';

        /* 통계 계산 */
        var moods = { good: 0, mid: 0, bad: 0 };
        var symCount = {}, symLevel = {};
        rows.forEach(function (row) {
          if (row.mood >= 4) moods.good++;
          else if (row.mood === 3) moods.mid++;
          else if (row.mood) moods.bad++;
          (row.symptoms || []).forEach(function (s) {
            symCount[s] = (symCount[s] || 0) + 1;
            var lv = row.intensity && row.intensity[s];
            if (lv) { symLevel[s] = symLevel[s] || {}; symLevel[s][lv] = (symLevel[s][lv] || 0) + 1; }
          });
        });
        var top = Object.keys(symCount).sort(function (a, b) { return symCount[b] - symCount[a]; }).slice(0, 3);
        var med = (rm.error || rl.error)
          ? { text: '복약 기록을 불러오지 못했어요', muted: true }
          : medSummary(rm.data || [], rl.data || [], week, today);
        var qList = T.vq ? T.vq.list(T.vq.read()) : [];

        content.innerHTML = '';
        content.appendChild(el('<div class="banner banner--info"><span class="b-ic">📋</span><div class="small">최근 기록을 정리했어요. <b>진료 때 이 화면을 보여 드리면</b> 짧은 시간에 잘 전달하실 수 있어요.</div></div>'));

        var card = el('<div class="card"><div class="row" style="justify-content:space-between; align-items:flex-start;"><div><div class="strong" style="font-size:16px;">진료 전 요약</div><div class="tiny muted"></div></div><span style="font-size:22px;">🎀</span></div><div class="rep-body"></div></div>');
        $('.tiny.muted', card).textContent = name + ' · ' + kdate(since) + ' ~ ' + kdate(today) + ' (14일)';
        var body = $('.rep-body', card);

        body.appendChild(el('<div class="tiny strong" style="color:var(--primary-dark); margin-top:14px;">가장 자주 있었던 증상</div>'));
        if (!top.length) {
          body.appendChild(el('<div class="small muted" style="margin-top:6px;">이 기간에는 컨디션 기록이 없어요.</div>'));
        } else {
          var wrap = el('<div class="col gap-6" style="margin-top:6px;"></div>');
          var SEVC = { '없음': 'sev--mild', '약함': 'sev--mild', '보통': 'sev--mod', '심함': 'sev--sev', '매우 심함': 'sev--sev' };
          top.forEach(function (s) {
            var lvs = symLevel[s] || {};
            var best = Object.keys(lvs).sort(function (a, b) { return lvs[b] - lvs[a]; })[0];
            var row = el('<div class="row" style="align-items:center; gap:8px;"><span class="sev" style="flex:0 0 auto;"></span><span class="small grow"></span></div>');
            var sv = $('.sev', row);
            sv.textContent = best || '기록';
            sv.className = 'sev ' + (SEVC[best] || 'sev--mild');
            $('.small', row).innerHTML = '<b>' + esc(s) + '</b> — 14일 중 <b>' + symCount[s] + '일</b>';
            wrap.appendChild(row);
          });
          body.appendChild(wrap);
        }

        body.appendChild(el('<div class="tiny strong" style="color:var(--primary-dark); margin-top:14px;">컨디션</div>'));
        body.appendChild(el('<div class="small" style="margin-top:6px;">좋음 <b>' + moods.good + '일</b> · 보통 <b>' + moods.mid + '일</b> · 힘듦 <b>' + moods.bad + '일</b> (기록 ' + rows.length + '일)</div>'));

        body.appendChild(el('<div class="tiny strong" style="color:var(--primary-dark); margin-top:14px;">복약 (최근 7일)</div>'));
        var medEl = el('<div class="small" style="margin-top:6px;"></div>');
        if (med.html) medEl.innerHTML = med.html; else medEl.textContent = med.text;
        if (med.muted) medEl.className += ' muted';
        body.appendChild(medEl);
        content.appendChild(card);

        if (qList.length) {
          content.appendChild(el('<div class="section-label">여쭤볼 질문</div>'));
          var qc = el('<div class="card card--flat" style="border:1px solid var(--outline);"><div class="col gap-10"></div></div>');
          var col = $('.col', qc);
          qList.forEach(function (q2, i2) {
            col.appendChild(el('<div class="row" style="align-items:flex-start; gap:10px;"><span class="strong" style="color:var(--primary); flex:0 0 auto;">' + (i2 + 1) + '</span><div class="small grow"></div></div>'));
            $$('.small', qc)[i2].textContent = q2;
          });
          content.appendChild(qc);
        } else {
          content.appendChild(el('<a class="listitem" href="10-consult-questions.html"><span class="li-ic">📝</span><div class="li-body"><div class="li-title">여쭤볼 질문 만들기</div><div class="li-sub">증상을 고르면 질문으로 정리해 드려요</div></div><span class="li-chev">›</span></a>'));
        }
        content.appendChild(el('<p class="disclaimer">이 요약은 회원님이 기록하신 내용을 그대로 정리한 것으로, 진단이나 평가가 아니에요.</p>'));
      }, function () {
        content.innerHTML = '';
        content.appendChild(el('<div class="banner banner--warn"><span class="b-ic">📶</span><div class="small">기록을 불러오지 못했어요. 연결을 확인하고 다시 열어 주세요.</div></div>'));
      });
    });
  }

  /* ── 28 진료 메모 보관함 ── */
  function page28() {
    var content = $('.content');
    if (!content) return;
    /* 시안의 예시 메모(지난 진료·통계)가 보이지 않게 바로 비우고,
       이 휴대폰에 저장된 질문부터 그린다 (다음 진료 줄은 서버에서 불러온 뒤 위에 끼운다) */
    content.innerHTML = '';
    content.appendChild(el('<div class="banner banner--info"><span class="b-ic">🗂️</span><div class="small">진료 준비에서 만든 질문이 <b>이 휴대폰에</b> 저장돼 있어요. 진료 때 바로 열어 보세요.</div></div>'));
    var lab = el('<div class="section-label">저장된 질문</div>');
    content.appendChild(lab);
    var v = T.vq ? T.vq.read() : null;
    var list = T.vq ? T.vq.list(v) : [];
    if (list.length) {
      var qc = el('<div class="card card--flat" style="border:1px solid var(--outline);"><div class="tiny muted"></div><div class="col gap-10" style="margin-top:8px;"></div></div>');
      var when = v && /^\d{4}-\d{2}-\d{2}$/.test(v.at || '') ? kdate(new Date(v.at + 'T00:00:00')) + '에 정리한 ' : '';
      $('.tiny.muted', qc).textContent = when + '질문 ' + list.length + '개';
      var col = $('.col', qc);
      list.forEach(function (q2, i2) {
        var row = el('<div class="row" style="align-items:flex-start; gap:10px;"><span class="strong" style="color:var(--primary); flex:0 0 auto;">' + (i2 + 1) + '</span><div class="small grow"></div></div>');
        $('.small', row).textContent = q2;
        col.appendChild(row);
      });
      content.appendChild(qc);
      content.appendChild(el('<a class="btn btn-outline btn-block btn-sm" href="10-consult-questions.html" style="margin-top:10px;">✏️ 질문 고치기</a>'));
    } else {
      content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💡</span><div class="small">아직 저장된 질문이 없어요. 진료 준비에서 증상을 고르면 질문이 만들어져요.</div></div>'));
      content.appendChild(el('<a class="btn btn-primary btn-block" href="10-consult-questions.html">📝 질문 만들러 가기</a>'));
    }
    /* 진료 준비(10)로 가는 형제 링크는 방문 스택을 쌓지 않게 replace */
    $$('a', content).forEach(function (a) {
      if ((a.getAttribute('href') || '').split('#')[0] === '10-consult-questions.html') {
        a.addEventListener('click', function (e) { e.preventDefault(); location.replace('10-consult-questions.html'); });
      }
    });
    uid(function (id) {
      sb.from('profiles').select('treatment').eq('id', id).maybeSingle().then(function (rp) {
        var treat = (rp.data && rp.data.treatment) || {};
        if (!/^\d{4}-\d{2}-\d{2}$/.test(treat.next_visit || '')) return;
        var vd = new Date(treat.next_visit + 'T00:00:00');
        var dv = Math.ceil((vd - new Date(ymd(new Date()) + 'T00:00:00')) / 86400000);
        var a = el('<a class="listitem" href="77-visit-report.html" style="border-color:var(--primary); background:var(--primary-tint);"><span class="li-ic" style="background:var(--white);">📋</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="pill pill--brand"></span></a>');
        $('.li-title', a).textContent = kdate(vd) + ' 진료 준비';
        $('.li-sub', a).textContent = '진료 전 리포트 보기';
        $('.pill', a).textContent = dv < 0 ? '지남' : dv === 0 ? '오늘' : dv + '일 뒤';
        content.insertBefore(a, lab);
      });
    });
  }

  /* 'H:MM'·'HH:MM' → 'HH:MM'(시각이 아니면 null) · 'HH:MM' → '오후 8:00'(timepick.js TDT.fmt · 23 알림 설정과 같은 모양) */
  function hmNorm(s) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(typeof s === 'string' ? s : '');
    if (!m || +m[1] > 23 || +m[2] > 59) return null;
    return ('0' + (+m[1])).slice(-2) + ':' + m[2];
  }
  function hm12(hm) { var h = +hm.slice(0, 2); return (h < 12 ? '오전 ' : '오후 ') + ((h % 12) || 12) + ':' + hm.slice(3); }
  /* ── 20 (웹 · 아이폰 홈 화면 앱) — 기기에 예약 목록이 없으므로, 서버(push-send)가 보내는 규칙을
     지금 설정으로 풀어서 보여 준다: 기록(매일)·마음 체크(매주 월요일)는 23 에서 고른 시각(notif_prefs.record_time · mood_time,
     기본 20:00 · 10:00) · 복약 시간대 · 진료 D-7/D-1 09:00 ── */
  function page20web(content) {
    var ios = /iPhone|iPad|iPod/i.test(navigator.userAgent);
    var standalone = !!(navigator.standalone || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches));
    var canPush = ('serviceWorker' in navigator) && ('PushManager' in window) && !!window.Notification;
    var perm = window.Notification ? Notification.permission : 'default';
    var wait = el('<div class="banner banner--info"><span class="b-ic">⏳</span><div class="small">알림 설정을 확인하는 중이에요…</div></div>');
    content.appendChild(wait);
    function fail() {
      if (wait.parentNode) wait.parentNode.removeChild(wait);
      content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💤</span><div class="small">알림 설정을 불러오지 못했어요.</div></div>'));
    }
    uid(function (id) {
      Promise.all([
        sb.from('consent_records').select('notifications,withdrawn_at').eq('user_id', id).order('consented_at', { ascending: false }).order('id', { ascending: false }).limit(1),
        sb.from('profiles').select('notif_prefs,treatment').eq('id', id).maybeSingle(),
        sb.from('medications').select('id,schedule').eq('active', true)
      ]).then(function (res) {
        var rc = res[0], rp = res[1], rm = res[2];
        if (rc.error || rp.error) return fail();
        if (wait.parentNode) wait.parentNode.removeChild(wait);
        var cr = rc.data && rc.data[0];
        var consent = !!(cr && cr.notifications && !cr.withdrawn_at);   /* 가장 최근 행 하나 · 철회됐으면 동의 아님 (push-send 와 같은 규칙) */
        var np = (rp.data && rp.data.notif_prefs) || {};
        var pref = function (k) { return (k in np) ? !!np[k] : true; };
        var treat = (rp.data && rp.data.treatment) || {};
        var st, ready = false;
        if (!consent) st = ['🔕', '<b>알림 수신에 동의하지 않으셔서</b> 알림을 보내지 않아요.'];
        else if (ios && !standalone) st = ['📲', '아이폰에서는 <b>홈 화면에 추가한 뒤</b> 알림을 켤 수 있어요. 사파리 아래 공유 버튼 → "홈 화면에 추가"'];
        else if (!canPush) st = ['📵', '지금 쓰시는 인터넷 창에서는 알림을 받을 수 없어요.'];
        else if (perm === 'denied') st = ['🔕', '<b>이 기기에서 토닥 알림이 꺼져 있어요.</b> 기기 설정에서 토닥 알림을 허용해 주세요.'];
        else if (perm !== 'granted') st = ['🔔', '<b>아직 알림을 켜지 않으셨어요.</b> 알림 설정에서 켜시면 아래 시간에 알려 드려요.'];
        else ready = true;                                /* 켜져 있으면 안내 띠 없이 목록만(교수님 2026-09-28) — 알림이 오지 않는 까닭이 있을 때만 띠를 둔다 */
        if (st) content.appendChild(el('<div class="banner banner--warn"><span class="b-ic">' + st[0] + '</span><div class="small">' + st[1] + '</div></div>'));
        if (!consent) return;

        var list = [];
        /* 기록·마음 체크 시각 — 23 알림 설정에서 고른 값. 없거나 이상하면 기본값(native.js notifPrefs · push-send 와 같은 규칙) */
        var recT = hmNorm(np.record_time) || '20:00', moodT = hmNorm(np.mood_time) || '10:00';
        if (pref('record_remind')) list.push(['📈', '오늘 하루 어떠셨어요? — 컨디션과 증상을 1분만 기록해 보세요 🌷', '매일 ' + hm12(recT)]);
        if (pref('mood_check')) list.push(['🌤️', '마음 건강 체크 — 이번 주 마음은 어떠세요? 기록에 남겨 보세요', '매주 월요일 ' + hm12(moodT)]);
        var medFail = !!(pref('med_remind') && rm.error);
        if (pref('med_remind') && !rm.error) {
          var R = window.TDN && window.TDN.route, seen = {}, meds = [];
          (rm.data || []).forEach(function (m) {
            var sc = m.schedule || {};
            (sc.slots || []).forEach(function (slot) {
              if (slot === '필요시') return;
              var t = String((sc.times && sc.times[slot]) || SLOT_TIME[slot] || '');
              if (!/^\d{1,2}:\d{2}$/.test(t)) return;
              t = ('0' + t).slice(-5);
              var body = (R && R.notifyBody && R.ofMed) ? R.notifyBody(R.ofMed(m), slot) : slot + ' 약 드실 시간이에요';
              if (seen[t + '|' + body]) return;              /* 같은 시각·같은 문구는 한 번만 울린다 */
              seen[t + '|' + body] = 1;
              meds.push([t, body]);
            });
          });
          meds.sort(function (a, b) { return a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0; });
          meds.forEach(function (x) { list.push(['💊', '토닥 — ' + x[1], '매일 ' + hm12(x[0])]); });
        }
        if (pref('visit_remind') && /^\d{4}-\d{2}-\d{2}$/.test(treat.next_visit || '')) {
          var now = new Date();
          [[7, '일주일 뒤 진료예요. 여쭤볼 것을 미리 정리해 보세요'], [1, '내일 진료예요. 진료 준비에서 질문을 확인해 보세요']].forEach(function (p) {
            var d = new Date(treat.next_visit + 'T09:00:00');
            d.setDate(d.getDate() - p[0]);
            if (d <= now) return;                             /* 이미 지난 알림은 빼고 */
            list.push(['📅', '진료가 다가와요 — ' + p[1], kdate(d) + ' (' + WDAY[d.getDay()] + ') 오전 9:00']);
          });
        }
        content.appendChild(el('<div class="section-label">' + (ready ? '켜 두신 알림 ' + list.length + '개' : '알림을 켜면 이렇게 알려 드려요') + '</div>'));
        if (medFail) content.appendChild(el('<div class="banner banner--warn"><span class="b-ic">💊</span><div class="small">복약 알림 시간을 불러오지 못했어요. 인터넷 연결을 확인한 뒤 다시 열어 주세요.</div></div>'));
        if (!list.length && !medFail) content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💤</span><div class="small">켜 두신 알림 항목이 없어요. 알림 설정에서 항목을 켜 주세요.</div></div>'));
        list.forEach(function (x) {
          var item = el('<div class="listitem"><span class="li-ic">' + x[0] + '</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div></div>');
          $('.li-title', item).textContent = x[1];
          $('.li-sub', item).textContent = x[2];
          content.appendChild(item);
        });
        content.appendChild(el('<a class="listitem" href="23-notif-settings.html?from=20-notifications.html"><span class="li-ic">⚙️</span><div class="li-body"><div class="li-title">' + (ready ? '알림 설정 바꾸기' : '알림 설정 열기') + '</div></div><span class="li-chev">›</span></a>'));
      }, fail);
    });
  }

  /* ── 20 알림함 — 예약된 알림 보기 ── */
  function page20() {
    var content = $('.content');
    if (!content) return;
    var head = $('.appbar a[href="javascript:void(0)"]');
    if (head) head.style.display = 'none';   /* '모두 읽음'은 이 구조에선 의미 없음 */
    content.innerHTML = '';
    /* 맨 위 '앞으로 울릴 예약된 알림이에요…' 안내는 뺐다(교수님 2026-09-28) — 목록과 '알림 설정 바꾸기'만 둔다 */
    var isNative = window.TDN && window.TDN.isNative;
    if (!isNative) { page20web(content); return; }
    if (!(window.Capacitor && Capacitor.Plugins && Capacitor.Plugins.LocalNotifications)) {
      content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💤</span><div class="small">알림 목록을 불러오지 못했어요.</div></div>'));
      return;
    }
    Capacitor.Plugins.LocalNotifications.getPending().then(function (r) {
      var list = (r && r.notifications) || [];
      if (!list.length) {
        content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💤</span><div class="small">예약된 알림이 없어요. 알림 설정에서 켜 주세요.</div></div>'));
        content.appendChild(el('<a class="listitem" href="23-notif-settings.html?from=20-notifications.html"><span class="li-ic">🔔</span><div class="li-body"><div class="li-title">알림 설정 열기</div></div><span class="li-chev">›</span></a>'));
        return;
      }
      function schedText(n) {
        var s = n.schedule || {};
        var hm = function (h, mi) { return hm12(('0' + (h || 0)).slice(-2) + ':' + ('0' + (mi || 0)).slice(-2)); };
        if (s.on && s.on.weekday) return '매주 월요일 ' + hm(s.on.hour, s.on.minute);
        if (s.on) return '매일 ' + hm(s.on.hour, s.on.minute);
        if (s.at) { var d = new Date(s.at); return kdate(d) + ' (' + WDAY[d.getDay()] + ') ' + hm(d.getHours(), d.getMinutes()); }
        return '';
      }
      list.sort(function (a, b) { return a.id - b.id; });
      content.appendChild(el('<div class="section-label">예약된 알림 ' + list.length + '개</div>'));
      list.forEach(function (n) {
        var ic = n.id === 1 ? '📈' : n.id === 2 ? '🌤️' : (n.id === 3 || n.id === 4) ? '📅' : '💊';
        var item = el('<div class="listitem"><span class="li-ic">' + ic + '</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div></div>');
        $('.li-title', item).textContent = n.title + (n.body ? ' — ' + n.body : '');
        $('.li-sub', item).textContent = schedText(n);
        content.appendChild(item);
      });
      content.appendChild(el('<a class="listitem" href="23-notif-settings.html?from=20-notifications.html"><span class="li-ic">⚙️</span><div class="li-body"><div class="li-title">알림 설정 바꾸기</div></div><span class="li-chev">›</span></a>'));
    }, function () {
      content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💤</span><div class="small">알림 목록을 불러오지 못했어요.</div></div>'));
    });
  }

  /* ── 22 대화 검색 ── */
  function page22() {
    var content = $('.content');
    var bar = $('.appbar .grow');
    if (!content || !bar) return;
    var Q22 = 'todak_q22';      /* 결과를 눌러 07 로 갈 때 적어 두는 검색어 (sessionStorage — 이 창에서만, 되살린 뒤 지움) */
    /* 가짜 검색줄 → 진짜 입력 */
    var q0 = '';
    /* 검색줄을 감싼 칸(.appbar .grow)도 flex:1 인데 min-width 가 auto 라, 안에 든 <input> 의
       '글자 수 기준 고유 폭'(size=20)이 그대로 최소폭이 되어 앱바를 밀어냈다.
       입력칸에만 min-width:0 을 줘도 이 칸이 늘어나 그대로 밀렸다 — 감싼 칸까지 0 으로 둔다.
       (360px·글자 130% 에서 +36px → 0px 로 측정 확인 · 2026-09-28) */
    try { bar.style.minWidth = '0'; } catch (eMW) {}
    bar.innerHTML = '<span style="font-size:15px;">🔎</span>';
    var inp = document.createElement('input');
    inp.type = 'text';
    inp.placeholder = '지난 대화에서 찾기';
    /* 44px — 검색줄이 21px 이라 띠를 눌러도 글자를 쓸 수 없었다 (2026-09-27) */
    /* min-width:0 — 이것이 없으면 flex 칸의 기본 min-width:auto 가 <input> 의 '글자 수 기준
       고유 폭'이 되어, 시스템 글자 크기를 키우면 검색칸이 같이 넓어져 앱바를 밀어냈다.
       130% 360px 에서 화면이 +36px · 150% 에서 +81px 밀리고 ✕(지우기)가 화면 밖으로 나갔다 (2026-09-28). */
    inp.setAttribute('style', 'flex:1; min-width:0; border:none; outline:none; background:transparent; font-size:14.5px; font-family:inherit; color:var(--on-surface); min-height:44px;');
    bar.appendChild(inp);
    var clearB = el('<span role="button" tabindex="0" aria-label="검색어 지우기" style="color:var(--outline-strong); font-size:15px; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; min-width:44px; min-height:44px;">✕</span>');
    bar.appendChild(clearB);
    clearB.addEventListener('click', function () { inp.value = ''; render([], ''); inp.focus(); });

    function render(rows, q) {
      content.innerHTML = '';
      if (!q) {
        content.appendChild(el('<div class="banner banner--info"><span class="b-ic">🔎</span><div class="small">궁금했던 내용을 검색하면 <b>지난 대화</b>에서 찾아 드려요. (예: 저림, 홍삼, 관절)</div></div>'));
        return;
      }
      content.appendChild(el('<div class="section-label">검색 결과 ' + rows.length + '개</div>'));
      if (!rows.length) {
        content.appendChild(el('<div class="banner banner--info"><span class="b-ic">💬</span><div class="small">지난 대화에서 찾지 못했어요. 상담에서 새로 물어보세요.</div></div>'));
      }
      rows.forEach(function (m) {
        var d = new Date(m.created_at);
        var item = el('<a class="listitem"><span class="li-ic">' + (m.role === 'user' ? '🙋' : '🎀') + '</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span></a>');
        /* 그 말풍선으로 — 상담 화면이 ?mid= 를 읽어 그 대화를 보여 준다.
           from 을 붙여 07 앱바 ‹ 와 휴대폰 뒤로가기가 검색 화면으로 돌아오게 한다(app.js FROM_BACK · native.js) */
        item.setAttribute('href', '07-chat.html' + (m.id ? '?mid=' + encodeURIComponent(m.id) + '&' : '?') + 'from=22-search.html');
        /* 07 에서 ‹·뒤로로 돌아오면 이 화면은 새로 열린다 — 누를 때만 검색어를 적어 두고, 돌아와서 되살린 뒤 지운다 */
        item.addEventListener('click', function () {
          try { sessionStorage.setItem(Q22, JSON.stringify({ q: q, t: Date.now() })); } catch (e) {}
        });
        var txt = m.content.replace(/\s+/g, ' ');
        var at = txt.indexOf(q);
        var start = Math.max(0, at - 10);
        $('.li-title', item).textContent = (start > 0 ? '…' : '') + txt.slice(start, start + 34) + (txt.length > start + 34 ? '…' : '');
        $('.li-sub', item).textContent = (m.role === 'user' ? '내 질문' : '토닥 답변') + ' · ' + kdate(d) + ' (' + WDAY[d.getDay()] + ')';
        content.appendChild(item);
      });
      var ask = el('<a class="listitem" href="07-chat.html" style="background:var(--primary-tint); border-color:var(--primary-light);"><span class="li-ic">💬</span><div class="li-body"><div class="li-title">이 내용 새로 물어보기</div><div class="li-sub">상담 화면으로 가요</div></div><span class="li-chev">›</span></a>');
      content.appendChild(ask);
    }
    /* 불러오기 실패(r.error·reject) — '검색 결과 0 · 찾지 못했어요'로 안내하지 않고, 이전 검색 결과도 치운다 (4차) */
    function renderFail() {
      content.innerHTML = '';
      content.appendChild(el('<div class="banner banner--warn"><span class="b-ic">📶</span><div class="small">대화 기록을 불러오지 못했어요. 연결을 확인하고 다시 열어 주세요.</div></div>'));
    }
    var timer = null, seq = 0;
    function search() {
      var q = inp.value.trim();
      clearTimeout(timer);
      if (q.length < 2) { ++seq; render([], ''); return; }   /* 지운 뒤 늦게 온 응답이 덮지 않게 */
      timer = setTimeout(function () {
        var my = ++seq;
        sb.from('chat_messages').select('id,role,content,created_at')
          .ilike('content', '%' + q + '%')
          .order('created_at', { ascending: false }).limit(20)
          .then(function (r) {
            if (my !== seq) return;
            if (!r || r.error) { renderFail(); return; }
            render(r.data || [], q);
          }, function () {
            if (my === seq) renderFail();
          });
      }, 350);
    }
    inp.addEventListener('input', search);
    /* 검색 결과 → 07 → 돌아온 경우: 적어 둔 검색어(30분 안)를 입력칸에 넣고 결과를 다시 그린다. 한 번 쓰면 지운다 */
    var back = null;
    try {
      back = JSON.parse(sessionStorage.getItem(Q22) || 'null');
      sessionStorage.removeItem(Q22);
    } catch (e) { back = null; }
    if (back && typeof back.q === 'string' && back.q.length >= 2 && Date.now() - back.t < 30 * 60 * 1000) {
      inp.value = back.q;
      render([], '');       /* 시안 예시 목록을 먼저 치운다 — 결과가 오면 바로 바뀐다 */
      search();
    } else {
      render([], '');
      inp.focus();
    }
  }


  /* ── 25 약관·동의 내용 — 가로 탭 6개 ──
     서비스 이용약관 · 개인정보 수집·이용 · 민감정보 · 위치 · 알림 (= 02 동의 목록 순서) · 개인정보 처리방침.
     02 의 '보기'는 ?tab=terms|collect|health|location|notify&from=02-consent.html 로 온다.
     24 등 예전 주소(?tab=privacy)도 그대로 처리방침 탭을 연다. */
  function page25() {
    var tabs = $$('.doc-tab[data-tab]');
    var panels = $$('.doc-panel[data-panel]');
    if (!tabs.length || !panels.length) return;
    var ITEM = { terms: 0, collect: 1, health: 2, location: 3, notify: 4 };   /* 02 동의 목록의 몇 번째 항목인지 */
    var cur = 'terms';
    var content = $('.content');

    var from = qsParam('from');
    var review = qsParam('review') === '1';
    var inFlow = from === '02-consent.html' && !review;          /* 가입 중 동의 목록에서 '보기'로 온 경우 */
    var foot = $('#docFooter'), agree = $('#docAgree');

    function paintFooter() {
      if (!foot || !agree) return;
      foot.hidden = !inFlow;
      if (!inFlow) return;
      var NAME = { terms: '서비스 이용약관', collect: '개인정보 수집·이용', health: '민감정보 처리', location: '위치정보 이용', notify: '알림 수신' };
      agree.textContent = ITEM.hasOwnProperty(cur) ? NAME[cur] + '에 동의하기' : '확인';
    }
    function show(key, keepScroll) {
      var ok = panels.some(function (p) { return p.getAttribute('data-panel') === key; });
      if (!ok) key = 'terms';
      cur = key;
      var onTab = null;
      tabs.forEach(function (t) {
        var on = t.getAttribute('data-tab') === key;
        t.classList[on ? 'add' : 'remove']('is-on');
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        if (on) onTab = t;
      });
      panels.forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== key; });
      /* 고른 탭이 탭 줄 가운데 오게 (가로만 움직인다) */
      if (onTab && onTab.parentNode) {
        var bar = onTab.parentNode;
        bar.scrollLeft = Math.max(0, onTab.offsetLeft - (bar.clientWidth - onTab.offsetWidth) / 2);
      }
      if (content && !keepScroll) content.scrollTop = 0;
      paintFooter();
    }
    tabs.forEach(function (t) {
      t.addEventListener('click', function () { show(t.getAttribute('data-tab')); });
    });

    /* 긴 문안은 눌러서 펼친다 — 26 도움말과 같은 방식 */
    $$('.faq').forEach(function (box) {
      var q = $('.faq-q', box), a = $('.faq-a', box), chev = $('.li-chev', box);
      if (!q || !a) return;
      q.style.cursor = 'pointer';
      function toggle(e) {
        if (e && e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
        if (e) e.preventDefault();
        var open = a.hidden;
        a.hidden = !open;
        box.classList[open ? 'add' : 'remove']('open');
        q.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (chev) chev.textContent = open ? '－' : '＋';
      }
      q.addEventListener('click', toggle);
      q.addEventListener('keydown', toggle);
    });

    /* 해시(#rights · #overseas 등)가 있으면 그 항목이 든 탭이 우선이다 */
    var tab = qsParam('tab');
    if (tab === 'policy') tab = 'privacy';
    var h = (location.hash || '').replace('#', '');
    var target = h ? document.getElementById(h) : null;
    var holder = null;
    if (target) panels.forEach(function (p) { if (p.contains(target)) holder = p; });
    if (holder) {
      show(holder.getAttribute('data-panel'), true);
      if ((target.className || '').indexOf('faq') > -1) {
        var tq = $('.faq-q', target);
        if (tq) tq.click();
      }
      setTimeout(function () { try { target.scrollIntoView(true); } catch (e) {} }, 30);
    } else {
      show(tab || 'terms');
    }

    /* 돌아가기 — 가입 중이면 동의 목록으로, 내가 동의한 내용(열람)에서 왔으면 열람으로 */
    var back = $('.appbar .back');
    if (back && from && /^[\w.-]+\.html$/.test(from)) {
      back.setAttribute('href', (from === '02-consent.html' && review) ? '02-consent.html?review=1' : from);
    }

    /* '동의하기' — 이 항목을 체크한 채로 동의 목록에 돌아간다.
       동의 기록(consent_records)은 여기서 만들지 않는다. 02 가 쓰는 임시 체크(sessionStorage)에만
       표시해 두고, 저장은 여전히 02 에서 '동의하고 계속하기'를 누르는 순간 화면의 체크대로 한다. */
    if (agree) agree.addEventListener('click', function (e) {
      e.preventDefault();
      var go = function () { location.replace('02-consent.html'); };
      if (!ITEM.hasOwnProperty(cur)) return go();
      var idx = ITEM[cur], KEY = 'todak_consent_draft', V = T.DOC_VERSION;
      sb.auth.getSession().then(function (rs) {
        var u = rs && rs.data && rs.data.session && rs.data.session.user;
        if (!u || !V) return go();
        var d = null;
        try { d = JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch (e1) { d = null; }
        var same = !!(d && d.v === V && d.uid === u.id && d.c && d.c.length === 5);
        var c = same ? d.c.slice() : [false, false, false, false, false];
        c[idx] = true;
        /* a = 만 19세 확인 체크 (02 가 따로 들고 있다) — 이미 눌러 두셨으면 그대로 살린다 */
        try { sessionStorage.setItem(KEY, JSON.stringify({ v: V, uid: u.id, c: c, a: !!(same && d.a) })); } catch (e2) {}
        go();
      }, go);
    });
  }

  /* ── 26 도움말: FAQ 펼치기 (문의 창구는 두지 않는다 — 교수님 결정) ── */
  function page26() {
    /* FAQ: 누르면 답이 아래로 펼쳐진다 */
    var faqs = $$('.faq');
    faqs.forEach(function (box) {
      var q = $('.faq-q', box), a = $('.faq-a', box), chev = $('.li-chev', box);
      if (!q || !a) return;
      q.style.cursor = 'pointer';
      function toggle(e) {
        if (e && e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
        if (e) e.preventDefault();
        var open = a.hidden;
        a.hidden = !open;
        box.classList.toggle('open', open);
        q.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (chev) chev.textContent = open ? '－' : '＋';
      }
      q.addEventListener('click', toggle);
      q.addEventListener('keydown', toggle);
    });

    /* 검색: 질문·답에서 찾아 해당 항목만 남긴다 */
    var box = $('#faq-search');
    if (!box) return;
    var label = $$('.section-label').filter(function (el) { return el.textContent.indexOf('자주 묻는 질문') > -1; })[0];
    var empty = document.createElement('div');
    empty.className = 'small muted';
    empty.style.cssText = 'padding:14px 4px;';
    empty.hidden = true;
    if (faqs.length) faqs[faqs.length - 1].parentNode.insertBefore(empty, faqs[faqs.length - 1].nextSibling);

    function run() {
      var k = box.value.trim().toLowerCase();
      var hit = 0;
      faqs.forEach(function (f) {
        var on = !k || f.textContent.toLowerCase().indexOf(k) > -1;
        f.hidden = !on;
        if (on) hit++;
      });
      if (label) label.textContent = k ? '검색 결과' : '자주 묻는 질문';
      empty.hidden = !(k && hit === 0);
      if (!empty.hidden) empty.textContent = '‘' + box.value.trim() + '’에 대한 내용을 찾지 못했어요. 다른 낱말로 찾아보세요.';
    }
    box.addEventListener('input', run);
    box.addEventListener('search', run);
  }

  /* ── 69 건강기능식품 확인 — 판정하지 않고, 알려진 주의점과 여쭤볼 문장만 ── */
  var SUPP = [
    { pat: /홍삼|인삼|고려삼|산삼/, name: '홍삼 · 인삼', lv: 'warn', known: '피가 잘 멎지 않게 할 수 있다는 보고가 있어요. 호르몬과 관련해서는 세포 실험 단계의 보고만 있고 사람에서의 영향은 아직 분명하지 않아요.', ask: '홍삼을 선물받았는데, 지금 제가 먹는 약이랑 같이 먹어도 될까요? 수술 전에는 언제부터 쉬어야 할까요?' },
    { pat: /오메가|생선기름|어유|EPA|DHA/i, name: '오메가3', lv: 'info', known: '많이 드시면 피가 잘 멎지 않을 수 있어요. 수술·시술 전에는 며칠 쉬라고 하는 병원이 많아요.', ask: '오메가3를 먹고 있는데 지금 치료 중에도 계속 먹어도 될까요? 수술 전에는 언제 끊을까요?' },
    { pat: /비타민\s*D|비타민디|콜레칼시페롤/i, name: '비타민 D', lv: 'info', known: '호르몬치료 중 뼈 건강을 위해 권하는 경우가 많아요. 다만 용량은 혈액검사 결과에 따라 정하는 게 좋아요.', ask: '비타민 D를 먹으려는데 하루 얼마나 먹으면 될까요? 혈액검사로 확인이 필요할까요?' },
    { pat: /유산균|프로바이오|락토/i, name: '유산균(프로바이오틱스)', lv: 'warn', known: '백혈구가 낮은 시기(주사 후 7~14일)에는 살아 있는 균 제품을 피하라는 안내가 있어요.', ask: '항암 중인데 유산균을 먹어도 될까요? 백혈구가 낮을 때는 어떻게 할까요?' },
    { pat: /밀크씨슬|실리마린|엉겅퀴/i, name: '밀크씨슬', lv: 'warn', known: '간에서 약이 분해되는 속도를 바꿀 수 있다는 보고가 있어요. 항암제·표적치료제와 겹칠 수 있어요.', ask: '밀크씨슬을 먹고 있는데 지금 쓰는 약과 겹치지 않을까요?' },
    { pat: /커큐민|강황|울금/i, name: '커큐민(강황)', lv: 'warn', known: '일부 항암제의 효과에 영향을 줄 수 있다는 실험 보고가 있어요. 피도 잘 멎지 않게 할 수 있어요.', ask: '강황(커큐민) 제품을 먹어도 될까요? 항암 중에는 쉬는 게 나을까요?' },
    { pat: /이소플라본|콩\s*추출|대두/i, name: '이소플라본(콩 추출물)', lv: 'warn', known: '음식으로 먹는 두부·콩은 괜찮다는 자료가 많지만, 농축한 보충제는 호르몬치료 중 피하라고 안내하는 병원이 많아요.', ask: '이소플라본 보충제를 먹어도 될까요? 두부·콩 음식은요?' },
    { pat: /상황버섯|차가버섯|영지|버섯/i, name: '버섯 추출물', lv: 'warn', known: '면역에 영향을 준다는 광고가 많지만 사람에서 확인된 자료는 적고, 간에 부담을 준 사례 보고가 있어요.', ask: '상황버섯(차가버섯) 달인 물을 먹어도 될까요? 간 수치에 영향이 있을까요?' },
    { pat: /종합비타민|멀티비타민/i, name: '종합비타민', lv: 'info', known: '보통 용량은 대개 괜찮지만, 항산화 성분을 고용량으로 드시는 건 항암·방사선 중에 피하라는 안내가 있어요.', ask: '종합비타민을 먹어도 될까요? 고용량 비타민은 피해야 할까요?' },
    { pat: /자몽/, name: '자몽(주스 포함)', lv: 'warn', known: '여러 약의 분해를 방해해 약 농도를 올릴 수 있어요. 표적치료제·일부 항암제와 겹칠 수 있어요.', ask: '자몽이나 자몽주스는 먹으면 안 될까요?' },
    { pat: /세인트존스|성요한/i, name: '세인트존스워트', lv: 'warn', known: '약이 몸에서 너무 빨리 빠져나가게 해서 항암제·표적치료제 효과를 떨어뜨릴 수 있어요.', ask: '세인트존스워트 제품을 먹고 있는데 지금 약과 겹치나요?' },
    { pat: /멜라토닌/, name: '멜라토닌', lv: 'info', known: '잠에 도움을 주려고 쓰지만, 호르몬치료 중 영향은 아직 자료가 충분하지 않아요.', ask: '잠이 안 와서 멜라토닌을 먹으려는데 괜찮을까요?' }
  ];
  /* ── 69 에 더한 목록 (2026-09-28) ──
     교수님이 '경옥고'를 찾으셨는데 '목록에 없어요'가 떴다. 유방암 치료 중인 분들이 실제로 많이 물어보시는
     한약·건강기능식품을 SUPP 와 같은 틀(알려진 내용 · 주의할 점 · 진료 때 여쭤볼 말)로 더했다.
       · SUPP(위 12종)는 서버(chat/index.ts)와 pat·name·known 이 글자까지 같아야 하는 검토본이라 손대지 않는다.
         MORE69 는 69 화면에서만 쓴다. 이름을 'SUPP…' 로 시작하게 바꾸지 말 것 — _build_kb.py 가 'var SUPP' 로
         시작하는 첫 목록을 읽어 AI 상담 색인과 서버 동기화 검사에 쓴다. (상담에서도 쓰려면 _build_kb.py 가 이 목록을 따로 읽어야 한다)
       · 출처는 항목마다 주석으로 적고, 카드 아래에도 짧게(src) 보인다. 쓴 곳 — 식약처: 건강기능식품 기능성 원료 고시·
         개별인정 원료의 섭취 시 주의사항·「의약품 병용 섭취정보」(33종)·의약품 허가사항(의약품안전나라) / 국가암정보센터:
         '항암치료 중 건강식품·한약' 질문과 답변 / NCCIH / MSKCC About Herbs / NCI PDQ / 미국 FDA 허가사항(openFDA) /
         토닥 음식 안내(09·60~68·94·95 — 이미 검토된 화면 문장). 원문을 옮기지 않고 쉬운 말로 다시 썼다 (2026-09-28 확인).
       · 사람 근거가 적으면 적다고 쓴다. '먹어도 된다/안 된다'는 쓰지 않는다 — 기관이 '피하라'고 적은 것은
         '…라고 안내해요'로 누가 그렇게 말했는지 밝힌다. 판정은 담당 의사·약사.
       · 앞에 둔 것이 먼저 걸린다(find69). 영지·차가·동충하초는 SUPP '버섯 추출물'보다, 크릴오일은 SUPP '오메가3'보다
         먼저 봐야 해서 MORE69 를 SUPP 앞에서 찾는다. 그래서 MORE69 에는 SUPP 12종의 이름에 걸리는 pat 을 넣지 않는다.
       · 한 글자짜리 흔한 말에 걸리지 않게 조심했다 — '차가'는 '차가운'에, '콩'은 '콩팥'에, '술'은 '수술'에,
         '마카'는 '마카롱'에 걸린다. */
  var MORE69 = [
    /* 식약처 의약품 허가사항(경방경옥고 등: 생지황즙·복령·인삼·꿀 / '다른 약물 투여 중인 환자'·'식욕부진, 구역, 구토의 증상이 있는 환자' 상의)
       · 식약처 인삼 기능성 원료 섭취 시 주의(당뇨치료제·혈액항응고제) · 국가암정보센터(항암 중 보약·한약은 담당 의사와 상의) */
    { pat: /경옥고|瓊玉膏/, name: '경옥고', kind: 'herbal', lv: 'warn',
      known: '생지황·복령·인삼·꿀로 만든 한약(일반의약품)이에요. 유방암 치료 중 효과나 안전성을 따로 확인한 사람 연구는 거의 없어요.',
      care: ['인삼이 들어 있어요 — 인삼·홍삼처럼 당뇨약이나 혈액을 묽게 하는 약(와파린·아스피린 등)을 드시면 주의가 필요해요(식약처).',
        '허가사항에 ‘다른 약을 드시는 분’, ‘식욕부진·구역·구토가 있는 분’은 의사·약사와 상의하라고 적혀 있어요 — 항암으로 속이 울렁거리는 시기라면 더 여쭤보세요.',
        '꿀이 절반 가까이 들어 있어요 — 혈당이 높으신 분은 함께 확인해 주세요.',
        '국가암정보센터는 항암치료 중 보약·한약을 드시기 전에 담당 의사와 상의하라고 안내해요.'],
      ask: '경옥고를 선물받았는데 인삼이 들어 있대요. 지금 치료 중에 먹어도 될까요? 수술이나 항암 앞뒤로 쉬어야 할 때가 있을까요?',
      src: '식약처 허가사항 · 국가암정보센터' },
    /* 구성(녹용·사향·당귀·산수유, 꿀) · MSKCC Dong quai(ER 양성 유방암 세포·동물 실험에서 성장 촉진, 호르몬 민감 암은 상의, 와파린 출혈)
       · 국가암정보센터(항암 중 보약) — 녹용은 기관 자료에 사람 근거가 거의 없다 */
    { pat: /공진단|拱辰丹/, name: '공진단', kind: 'herbal', lv: 'warn',
      known: '녹용·사향·당귀·산수유를 꿀로 빚은 한약이에요. 유방암 치료 중 효과나 안전성을 확인한 사람 연구는 거의 없어요.',
      care: ['당귀가 들어 있어요 — 실험에서 유방암 세포를 자라게 했다는 보고가 있어, 호르몬 수용체 양성이면 꼭 먼저 여쭤보라고 안내해요(MSKCC). 피가 잘 멎지 않게 할 수도 있어요.',
        '녹용은 사람에게서 확인된 근거가 적어요.',
        '만드는 곳마다 들어가는 재료와 양이 달라요 — 받으신 제품의 재료를 적어 가시면 좋아요.',
        '국가암정보센터는 항암치료 중 보약·한약을 드시기 전에 담당 의사와 상의하라고 안내해요.'],
      ask: '공진단을 선물받았는데 당귀·녹용이 들어 있대요. 호르몬치료 중인데 먹어도 될까요?',
      src: 'MSKCC · 국가암정보센터' },
    /* 녹용 — MSKCC·NCCIH 에 따로 정리된 항목이 없고 사람 근거가 거의 없다(2026-09-28 확인). 국가암정보센터(항암 중 보약·한약)만 쓴다 */
    { pat: /녹용|鹿茸|사슴\s*뿔|deer\s*antler/i, name: '녹용', kind: 'herbal', lv: 'warn',
      known: '사슴의 어린 뿔을 말린 한약재로, 보약·진액에 많이 들어가요. 유방암 치료 중 효과나 안전성을 확인한 사람 연구는 거의 없어요 — 사람에게서 확인된 근거가 적어요.',
      care: ['녹용 진액·보약은 다른 약재와 섞어 만드는 경우가 많아요 — 함께 든 재료(예: 당귀·인삼)에 따라 주의할 점이 달라져요.',
        '국가암정보센터는 항암치료 중 보약·한약은 약과 어떻게 겹치는지 잘 알려져 있지 않아, 담당 의사와 먼저 상의하라고 안내해요.'],
      ask: '녹용이 든 보약을 권유받았는데, 지금 치료 중에 먹어도 될까요? 간 수치 검사가 필요할까요?',
      src: '국가암정보센터' },
    /* NCI PDQ Gerson therapy(커피 관장 — 관련됐을 수 있는 사망 3건 보고, 관장을 자주 하면 혈액 성분 변화, FDA 미승인, 연구 근거 약함).
       '커피'가 음식 목록(커피·차)에 먼저 걸려 '평소 드시는 음료예요'로 나오지 않게 여기 둔다 */
    { pat: /커피\s*관장|coffee\s*enema|거슨|gerson/i, name: '커피 관장', kind: 'other', lv: 'warn', pill: '! 하시기 전에 꼭 물어보세요',
      known: '‘몸속 독소를 뺀다’며 알려진 방법(거슨 요법의 하나)이에요. 암 치료에 도움이 된다는 믿을 만한 근거는 없고, 미국 FDA는 거슨 요법을 어떤 병의 치료로도 승인하지 않았어요.',
      care: ['커피 관장과 관련됐을 수 있는 사망 사례가 보고됐어요(NCI).',
        '관장을 자주 하면 몸속 혈액 성분이 흐트러질 수 있어요(NCI).',
        '변비 때문이라면 식사 카드와 담당 의사가 알려 준 방법을 먼저 따라 주세요.'],
      links: ['64'],
      ask: '커피 관장을 권유받았는데, 치료 중에 해도 될까요?',
      src: 'NCI' },
    /* 국가암정보센터(개소주·잉어즙·붕어즙·가물치즙·장어즙 등 — 항암치료 중 주의) · 72·09 화면(성분 불명확한 달인 물은 확인이 어렵다)
       · 61(단백질은 살코기·생선·두부로) */
    { pat: /흑염소|염소\s*(즙|진액|탕|엑기스|중탕)|개소주|잉어\s*(즙|진액|엑기스|중탕)|붕어\s*(즙|진액|엑기스|중탕)|가물치|장어\s*(즙|진액|엑기스|중탕)|자라\s*(즙|진액|엑기스)/, name: '흑염소·잉어·붕어 달인 즙', kind: 'herbal', lv: 'warn',
      known: '건강원에서 달여 만든 즙·진액이에요. 기운을 차리라고 많이 권하시지만, 유방암 치료 중 효과를 확인한 사람 연구는 없어요.',
      care: ['국가암정보센터는 개소주·잉어즙·붕어즙·가물치즙·장어즙 같은 건강 보조 식품을 항암치료 중에는 주의하라고 안내해요.',
        '건강원마다 함께 넣는 재료(한약재 등)가 달라 무엇이 들었는지 알기 어려워요 — 간에 부담이 되거나 약과 겹칠 수 있어요.',
        '입맛이 없어 단백질을 채우고 싶으시면 살코기·생선·두부로 채우는 방법이 식사 카드에 있어요.'],
      links: ['61'],
      ask: '가족이 흑염소(잉어즙)를 달여 왔는데, 지금 항암 중에 먹어도 될까요?',
      src: '국가암정보센터 · 토닥 음식 안내' },
    /* MSKCC Kudzu(에스트로겐 작용·타목시펜 작용 방해 가능 — 호르몬 민감 암은 피하라, 간·콩팥 사례, 당뇨약 동물 실험, 사람 근거 불분명) */
    { pat: /칡|갈근|葛根|kudzu/i, name: '칡(갈근)·칡즙', kind: 'herbal', lv: 'warn',
      known: '칡뿌리(갈근)에는 콩의 이소플라본과 비슷한 성분이 들어 있어요. 칡즙·칡차로 드시는 분이 많아요. 사람 연구가 적고, 어떤 병에 도움이 되는지 분명하지 않아요.',
      care: ['여성호르몬처럼 작용하고 타목시펜의 작용을 방해할 수 있어, 호르몬에 민감한 암이면 피하라고 안내해요(MSKCC).',
        '간·콩팥에 이상이 생긴 사례 보고가 있어요.',
        '당뇨약과 함께 드시면 혈당이 더 내려갈 수 있다는 동물 실험 보고가 있어요.'],
      ask: '칡즙이 좋다고 들었는데, 호르몬치료 중에도 먹어도 될까요?',
      src: 'MSKCC' },
    /* 쌍화탕(백작약·숙지황·당귀·천궁·황기·계피·감초·생강·대추) — 약국 쌍화탕은 의약품, 편의점 쌍화 음료는 식품
       · 식약처 병용 섭취정보(당귀: 항응고제·항혈소판제 출혈) · MSKCC Dong quai
       · 감초가 든 의약품 허가사항(장기 연용 시 위알도스테론증 — 혈압 상승·부종·저칼륨) */
    { pat: /쌍화/, name: '쌍화탕', kind: 'herbal', lv: 'warn',
      known: '백작약·숙지황·당귀·천궁·황기·계피·감초 등으로 만든 한약이에요. 약국에서 파는 쌍화탕은 의약품이고, 편의점의 쌍화 음료는 식품이라 들어 있는 양이 달라요.',
      care: ['당귀가 들어 있어요 — 실험에서 유방암 세포를 자라게 했다는 보고가 있어 호르몬 수용체 양성이면 먼저 여쭤보라고 안내해요(MSKCC). 혈액을 묽게 하는 약과 함께면 피가 잘 멎지 않을 수 있어요(식약처).',
        '감초가 들어 있어요 — 감초가 든 약을 오래 드시면 혈압이 오르거나 몸이 붓고 칼륨이 줄 수 있다고 허가사항에 적혀 있어요.',
        '감기 기운에 여러 병 드시는 경우가 많아요 — 드신 양과 기간을 진료 때 말씀해 주세요.'],
      ask: '감기 기운이 있을 때 쌍화탕을 먹어도 될까요? 당귀·감초가 들어 있다던데 지금 약과 괜찮을까요?',
      src: '식약처 · MSKCC' },
    /* 식약처 허가사항(우황청심원: 고혈압·고령자·심장·신장 장애·부종·치료 중인 환자는 복용 전 상의 / 복용 중 뇨량 감소·부종·혈압 상승·두통 시 중지
       / 감초 장기 연용 → 위알도스테론증) */
    { pat: /우황\s*청심|청심환|청심원/, name: '우황청심원', kind: 'herbal', lv: 'warn',
      known: '우황·인삼·감초 등 여러 약재가 든 한약(일반의약품)이에요. 가슴이 두근거리거나 긴장될 때 드시는 분이 많아요.',
      care: ['허가사항에 혈압이 높은 분, 고령자, 심장·콩팥이 약한 분, 몸이 붓는 분, 의사의 치료를 받고 있는 분은 드시기 전에 의사·약사와 상의하라고 적혀 있어요.',
        '감초가 들어 있어 오래 드시면 혈압이 오르거나 붓고 칼륨이 줄 수 있어요.',
        '드신 뒤 소변이 줄거나, 얼굴·손발이 붓거나, 혈압이 오르거나 머리가 아프면 그만 드시고 의사·약사와 상의하라고 허가사항에 적혀 있어요.',
        '긴장·불안이 자주 있으시면 담당 의사와도 이야기해 보세요.'],
      links: ['47'],
      ask: '긴장될 때 우황청심원을 먹곤 하는데, 지금 치료 중에도 먹어도 될까요?',
      src: '식약처 허가사항' },
    /* 십전대보탕(팔물탕 + 황기·육계: 인삼·백출·복령·감초·숙지황·백작약·천궁·당귀) · 식약처 인삼 주의·병용 섭취정보(당귀·감초)
       · MSKCC Dong quai · 국가암정보센터(항암 중 보약) */
    { pat: /십전\s*대보|十全大補/, name: '십전대보탕', kind: 'herbal', lv: 'warn',
      known: '인삼·백출·복령·감초·숙지황·백작약·천궁·당귀·황기·육계로 만든 보약 처방이에요. 수술 뒤나 기운이 없을 때 많이 권해요. 유방암 치료 중 효과와 안전성을 확인한 사람 연구는 적어요.',
      care: ['인삼이 들어 있어 당뇨약이나 혈액을 묽게 하는 약을 드시면 주의가 필요해요(식약처).',
        '당귀가 들어 있어요 — 실험에서 유방암 세포를 자라게 했다는 보고가 있어 호르몬 수용체 양성이면 먼저 여쭤보라고 안내해요(MSKCC).',
        '감초가 들어 있어 오래 드시면 혈압이 오르거나 붓고 칼륨이 줄 수 있어요.',
        '국가암정보센터는 항암치료 중 보약을 드시기 전에 담당 의사와 상의하라고 안내해요.'],
      ask: '수술 뒤 기운 차리라고 십전대보탕을 권유받았는데, 지금 치료 중에 먹어도 될까요?',
      src: '식약처 · MSKCC · 국가암정보센터' },
    /* MSKCC Dong quai(호르몬 민감 암 악화 가능 — ER 양성 유방암 세포·동물 실험, 와파린 출혈, 사람 근거 불충분)
       · 식약처 병용 섭취정보(당귀: 항응고제·항혈소판제 출혈, 일부 항우울제 약효 과도, 혈압약 효과 증가) */
    { pat: /당귀|dong\s*quai|angelica/i, name: '당귀', kind: 'herbal', lv: 'warn',
      known: '생리통·갱년기 증상에 쓰는 한약재예요. 쌍화탕·십전대보탕·공진단 같은 한약에도 들어 있어요. 사람에게서 효과가 분명하게 확인되지는 않았어요.',
      care: ['실험에서 유방암 세포와 호르몬 수용체 양성 종양을 자라게 했다는 보고가 있어, 호르몬에 민감한 유방암이면 병을 악화시킬 수 있다고 안내해요(MSKCC).',
        '혈액을 묽게 하는 약(와파린·아스피린 등)과 함께 드시면 피가 잘 멎지 않을 수 있어요(식약처).',
        '일부 항우울제·혈압약의 효과를 지나치게 키울 수 있다고 식약처 병용 섭취정보에 적혀 있어요.'],
      ask: '당귀가 든 한약을 먹어도 될까요? 호르몬 수용체 양성이라 걱정돼요.',
      src: 'MSKCC · 식약처' },
    /* 식약처 개별인정 원료 '백수오 등 복합추출물'(제2010-20호, 갱년기 여성 건강) 섭취 시 주의사항(항응고제·항혈전제 상담, 알레르기)
       · 2015년 이엽우피소 혼입 조사(식약처) */
    { pat: /백수오|이엽우피소|estro\s*-?\s*g(?!en)|에스트로지/i, name: '백수오', kind: 'supplement', lv: 'warn',
      known: '갱년기 여성 건강에 도움을 줄 수 있다고 인정된 건강기능식품 원료(백수오 등 복합추출물)예요. 유방암 환자에게서 안전성을 확인한 자료는 거의 없어요.',
      care: ['갱년기 증상을 겨냥한 제품이라, 호르몬 수용체 양성이거나 호르몬치료 중이시면 시작하기 전에 꼭 여쭤보세요.',
        '식약처 주의사항에 혈액을 묽게 하는 약(항응고제·항혈전제)을 드시면 전문가와 상담하라고 적혀 있어요.',
        '예전에 모양이 비슷한 이엽우피소가 섞인 제품이 식약처 조사에서 문제가 된 적이 있어요.'],
      links: ['35'],
      ask: '갱년기 증상 때문에 백수오 제품을 권유받았는데, 호르몬치료 중에도 먹어도 될까요?',
      src: '식약처' },
    /* MSKCC Licorice(고혈압·저칼륨·부정맥, 에스트로겐 작용, 이뇨제·스테로이드) · 식약처 병용 섭취정보(감초: 디곡신·혈압약·스테로이드·여성호르몬제 등) */
    { pat: /감초|licorice|liquorice/i, name: '감초', kind: 'herbal', lv: 'warn',
      known: '단맛을 내는 한약재로, 많은 한약과 한방 음료에 조금씩 들어 있어요.',
      care: ['많이·오래 드시면 혈압이 오르고, 몸속 칼륨이 줄어 붓거나 기운이 빠지고 심장 박동이 불규칙해질 수 있어요(MSKCC).',
        '혈압약·이뇨제·스테로이드약·심장약(디곡신)과 함께 드시면 영향을 줄 수 있어요(식약처).',
        '여성호르몬과 비슷한 작용이 있다는 자료가 있어요(MSKCC).'],
      ask: '한약에 감초가 들어 있다는데, 제가 먹는 혈압약(이뇨제)과 같이 먹어도 될까요?',
      src: 'MSKCC · 식약처' },
    /* MSKCC Reishi(와파린 출혈, 분말 간독성 사례, 면역억제제, 항산화로 항암제 간섭 이론, 포자 분말이 종양표지자 CA72-4 상승) · 국가암정보센터(영지버섯 주의) */
    { pat: /영지|reishi|ganoderma|lingzhi/i, name: '영지버섯', kind: 'herbal', lv: 'warn',
      known: '면역을 돕는다며 달인 물·분말·추출물로 드시는 분이 많아요. 암 치료에 도움이 되는지는 사람 연구가 적어 분명하지 않아요.',
      care: ['혈액을 묽게 하는 약과 함께 드시면 피가 잘 멎지 않을 수 있어요.',
        '분말 제품을 드신 뒤 간이 크게 상한 사례 보고가 있어요.',
        '항암제 작용을 방해할 수 있다는 이론적 우려가 있고, 종양표지자(암 수치) 검사 하나를 올렸다는 보고도 있어요.',
        '국가암정보센터는 항암치료 중 영지버섯 같은 건강 보조 식품을 주의하라고 안내해요.'],
      ask: '영지버섯 달인 물을 먹고 있는데, 항암 중에도 괜찮을까요? 간 수치나 암 수치 검사에 영향이 있을까요?',
      src: 'MSKCC · 국가암정보센터' },
    /* MSKCC Chaga(분말을 몇 달 먹은 뒤 콩팥 손상·투석·말기 신부전 사례, 와파린 출혈, 혈당 저하, 사람 임상 연구 없음) */
    { pat: /차가\s*버섯|차가\s*(차|분말|가루|추출)|^\s*차가\s*$|chaga/i, name: '차가버섯', kind: 'herbal', lv: 'warn',
      known: '자작나무에 붙어 자라는 버섯으로, 차나 분말로 드시는 분이 많아요. 사람을 대상으로 효과와 안전성을 확인한 연구는 없어요.',
      care: ['가루를 매일 여러 숟가락씩 몇 달 드신 분이 콩팥이 크게 상해 투석까지 받은 사례 보고가 있어요.',
        '혈액을 묽게 하는 약과 함께 드시면 피가 잘 멎지 않을 수 있어요.',
        '당뇨약과 함께 드시면 혈당이 더 내려갈 수 있어요.'],
      ask: '차가버섯 가루를 먹고 있는데 콩팥이나 지금 먹는 약에 영향이 없을까요?',
      src: 'MSKCC' },
    /* MSKCC Cordyceps(출혈 — 발치 후 출혈 사례, 혈당 저하, 사람 근거 불충분) · 국가암정보센터(동충하초 주의) */
    { pat: /동충하초|cordyceps|코디세핀/i, name: '동충하초', kind: 'herbal', lv: 'warn',
      known: '곤충에서 자라는 버섯의 한 종류로 한약·건강식품에 쓰여요. 사람 연구에서 효과는 뚜렷하지 않아요.',
      care: ['피가 잘 멎지 않게 할 수 있어요 — 매일 드시던 분이 이를 뽑은 뒤 피가 많이 난 사례 보고가 있어요.',
        '혈당을 낮출 수 있어 당뇨약을 드시면 확인이 필요해요.',
        '국가암정보센터는 항암치료 중 동충하초 같은 건강 보조 식품을 주의하라고 안내해요.'],
      ask: '동충하초 제품을 먹고 있는데 지금 치료 중에도 괜찮을까요?',
      src: 'MSKCC · 국가암정보센터' },
    /* MSKCC Noni(급성 간염·간이식까지 간 사례, 고칼륨 — 콩팥 질환, 와파린·항산화 간섭, 사람 항암 근거 없음) · 국가암정보센터(노니주스 주의) · 09 */
    { pat: /노니|noni/i, name: '노니', kind: 'supplement', lv: 'warn',
      known: '열대 과일로 만든 주스·분말이에요. 암에 좋다는 광고가 많지만 사람에게서 확인된 근거는 없어요.',
      care: ['간이 심하게 상한 사례 보고가 여러 건 있어요.',
        '칼륨이 많아 콩팥이 약하신 분은 칼륨이 지나치게 오를 수 있어요.',
        '항산화 성분이 항암·방사선 치료에 영향을 줄 수 있다는 우려가 있어요.',
        '국가암정보센터는 항암치료 중 노니주스 같은 건강 보조 식품을 주의하라고 안내해요.'],
      ask: '노니 주스를 권유받았는데 간이나 콩팥에 부담이 없을까요?',
      src: 'MSKCC · 국가암정보센터' },
    /* 식약처 점검(2019 — 새싹보리 분말 부적합: 대장균·금속성 이물) · 국가암정보센터(녹즙 주의). 효과 근거는 기관 자료에 없다 */
    { pat: /새싹\s*보리|보리\s*새싹|보리순|barley\s*grass/i, name: '새싹보리', kind: 'food', lv: 'info',
      known: '어린 보리싹을 말려 가루로 만든 일반 식품이에요(건강기능식품이 아니에요). 사람에게서 확인된 효과 근거는 적어요.',
      care: ['식약처 점검에서 일부 새싹보리 분말이 대장균·금속성 이물(쇳가루) 기준을 넘어 부적합으로 나온 적이 있어요.',
        '물에 타서 녹즙처럼 매일 드시는 경우가 많은데, 국가암정보센터는 항암치료 중 녹즙 같은 건강 보조 식품을 주의하라고 안내해요.'],
      links: ['66'],
      ask: '새싹보리 가루를 매일 타 먹고 있는데, 지금 치료 중에도 괜찮을까요?',
      src: '식약처 · 국가암정보센터' },
    /* MSKCC Maca(호르몬 민감 암 — 치료에 영향 가능, 사람 연구 몇 개뿐) */
    { pat: /마카(?!롱|다미아|로니|오)|maca\b/i, name: '마카', kind: 'supplement', lv: 'warn',
      known: '페루의 뿌리채소로, 기운·갱년기 증상에 좋다고 광고해요. 사람 연구가 몇 개 없어 효과는 분명하지 않아요.',
      care: ['호르몬에 민감한 유방암이면 치료에 영향을 줄 수 있어 먼저 여쭤보라고 안내해요(MSKCC).',
        '갱년기 홍조 때문에 찾으셨다면 홍조를 다루는 방법도 함께 보세요.'],
      links: ['35'],
      ask: '마카 제품을 먹어 보려는데, 호르몬치료 중에도 괜찮을까요?',
      src: 'MSKCC' },
    /* 식약처 병용 섭취정보(석류: CYP2C9 로 분해되는 약 — 타목시펜·와파린 등의 효능 감소·부작용) · MSKCC Pomegranate(와파린 출혈, 사람 호르몬 지표와 뚜렷한 연관 없음)
       · 09(이소플라본·석류 고농축 보충제 — 호르몬치료 방해 우려, '지금은 쉬어가요') */
    { pat: /석류\s*(즙|추출|농축|진액|엑기스|콜라겐|젤리|정|환|캡슐|분말|스틱|원액)|pomegranate/i, name: '석류 농축즙·추출물', kind: 'supplement', lv: 'warn',
      known: '갱년기에 좋다며 농축즙·젤리·정제로 드시는 분이 많아요. 호르몬치료 효과를 방해할 수 있다는 우려가 있지만, 사람 연구에서 분명하게 확인된 것은 아니에요.',
      care: ['타목시펜·와파린처럼 몸속에서 같은 효소로 분해되는 약의 효과와 부작용에 영향을 줄 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
        '토닥 음식 안내에서는 호르몬치료 중 고농축 석류 보충제를 ‘지금은 쉬어가요’에 두고 있어요.',
        '과일로 드시는 석류는 음식이에요 — 여기서는 농축·추출 제품 이야기예요.'],
      links: ['09'],
      ask: '석류 농축즙을 먹고 있는데, 타목시펜(호르몬약)이랑 같이 먹어도 될까요?',
      src: '식약처 · MSKCC · 토닥 음식 안내' },
    /* 식약처 감마리놀렌산 함유 유지(기능성) · 식약처 병용 섭취정보(항응고제·항혈소판제 출혈, 페노티아진 발작) · MSKCC Evening primrose oil(출혈, 혈압 상승, 유방통 근거 엇갈림) */
    { pat: /달맞이|감마\s*리놀렌|evening\s*primrose|보라지|borage/i, name: '달맞이꽃종자유(감마리놀렌산)', kind: 'supplement', lv: 'info',
      known: '감마리놀렌산이 든 기름으로, 식약처가 혈중 콜레스테롤·혈행 개선, 월경 전 불편감 개선 등의 기능성을 인정한 원료예요. 유방 통증·홍조에 쓰기도 하지만 효과는 연구마다 엇갈려요.',
      care: ['혈액을 묽게 하는 약(와파린·아스피린 등)과 함께 드시면 피가 잘 멎지 않을 수 있어요(식약처) — 수술·시술 전에는 꼭 말씀해 주세요.',
        '일부 정신과 약(페노티아진 계열)과 함께 드시면 경련 위험이 올라갈 수 있다고 해요(식약처).',
        '혈압을 올릴 수 있다는 자료도 있어요(MSKCC).'],
      ask: '달맞이꽃종자유를 먹고 있는데, 수술(항암) 전에는 쉬어야 할까요?',
      src: '식약처 · MSKCC' },
    /* MSKCC Flaxseed(식물성 에스트로겐 — ER 양성은 의사와 상의, 유방암 근거 제한·엇갈림)
       · NCCIH Flaxseed(날것·덜 익은 씨는 먹지 말 것, 위장 증상, 항응고제와 이론적 상호작용) */
    { pat: /아마\s*씨|아마인|flax|린시드|linseed/i, name: '아마씨', kind: 'supplement', lv: 'warn',
      known: '오메가3 계열 지방과 리그난(식물성 에스트로겐)이 든 씨앗이에요. 볶은 가루를 음식에 뿌려 드시기도 해요. 유방암 환자 연구는 적고 결과도 엇갈려요.',
      care: ['식물성 에스트로겐이 들어 있어 호르몬 수용체 양성 유방암이면 드시기 전에 여쭤보라고 안내해요(MSKCC).',
        '날것이나 덜 익은 아마씨는 몸에 해로운 성분이 있을 수 있어 날로 드시지 말라고 안내해요(NCCIH).',
        '많이 드시면 배에 가스가 차거나 설사가 생길 수 있고, 혈액을 묽게 하는 약과 겹칠 수 있다는 이론적 우려가 있어요(NCCIH).'],
      ask: '아마씨 가루를 먹으려는데, 호르몬치료 중에도 괜찮을까요?',
      src: 'MSKCC · NCCIH' },
    /* MSKCC Royal jelly(실험에서 에스트로겐 작용 — ER 양성 유방암은 피하라, 벌 제품 알레르기·천식·아나필락시스, 와파린 사례) */
    { pat: /로[열얄]\s*젤리|royal\s*jelly|왕유/i, name: '로열젤리', kind: 'supplement', lv: 'warn',
      known: '일벌이 여왕벌에게 먹이는 물질로, 건강식품으로 드시는 분이 많아요. 사람에게서 효과를 확인한 연구는 적어요.',
      care: ['실험에서 여성호르몬 같은 작용이 보여, 에스트로겐 수용체 양성 유방암이면 피하라고 안내해요(MSKCC).',
        '벌 제품 알레르기나 천식이 있으면 심한 알레르기(호흡곤란)가 생긴 사례가 있어요.',
        '와파린을 드시면 피가 잘 멎지 않을 수 있다는 사례 보고가 있어요.'],
      ask: '로열젤리를 선물받았는데, 호르몬 수용체 양성이어도 먹어도 될까요?',
      src: 'MSKCC' },
    /* 식약처 프로폴리스추출물(항산화·구강 항균, 알레르기 주의) · MSKCC Propolis(벌침·꿀·돼지풀·국화 알레르기는 피하라, 응고 시간 연장 — 와파린, 구내염 근거 엇갈림) */
    { pat: /프로폴리스|propolis/i, name: '프로폴리스', kind: 'supplement', lv: 'info',
      known: '꿀벌이 나무 진을 모아 만든 물질로, 식약처가 항산화·입안 항균 기능성을 인정한 원료예요. 항암 중 입안 헐음에 써 본 연구는 결과가 엇갈려요.',
      care: ['벌·꿀·돼지풀·국화에 알레르기가 있으면 피하라고 안내해요(MSKCC·식약처).',
        '피가 굳는 시간을 늘릴 수 있어 와파린을 드시면 먼저 여쭤보세요(MSKCC).',
        '입안이 헐었을 때는 담당 의사가 알려 준 입안 관리 방법을 먼저 따라 주세요.'],
      links: ['62'],
      ask: '입안이 헐어서 프로폴리스를 써 보려는데, 항암 중에도 괜찮을까요?',
      src: '식약처 · MSKCC' },
    /* 식약처 개별인정 원료 크릴오일(제2023-13호 등) 섭취 시 주의사항(알레르기 체질 주의, 항응고제·항혈소판제 상담) · 식약처 병용 섭취정보(EPA·DHA: 항응고제 출혈) */
    { pat: /크릴|krill/i, name: '크릴오일', kind: 'supplement', lv: 'info',
      known: '남극 크릴(작은 새우를 닮은 바다 생물)에서 뽑은 기름으로, 오메가3(EPA·DHA)가 들어 있어요.',
      care: ['오메가3처럼 혈액을 묽게 하는 약과 함께 드시면 피가 잘 멎지 않을 수 있어요 — 수술·시술 전에는 꼭 말씀해 주세요(식약처).',
        '식약처 주의사항에 알레르기 체질이면 섭취에 주의하라고 적혀 있어요.',
        '오메가3 제품과 함께 드시면 같은 성분이 겹쳐요.'],
      ask: '크릴오일을 먹고 있는데, 수술(시술) 전에는 언제부터 쉬어야 할까요?',
      src: '식약처' },
    /* 식약처 코엔자임Q10(항산화·높은 혈압 감소) · 식약처 병용 섭취정보(혈압약 — 급격한 저혈압, 항응고제 효과 감소)
       · NCI PDQ Coenzyme Q10(유방암 236명 무작위 시험 — 피로·삶의 질 차이 없음, 항산화 보충제와 재발 증가 관찰 연구) */
    { pat: /코엔자임|코큐텐|co\s*q\s*10|q10|coenzyme|유비퀴놀|유비퀴논|ubiqui/i, name: '코엔자임Q10', kind: 'supplement', lv: 'warn',
      known: '몸에서도 만들어지는 항산화 성분으로, 식약처가 항산화·높은 혈압 감소 기능성을 인정했어요. 유방암 환자 236명 연구에서 피로·삶의 질은 가짜약과 차이가 없었어요.',
      care: ['항암·방사선 중 항산화 보충제를 드신 분의 재발이 더 많았다는 관찰 연구가 있어, 치료 중에는 먼저 여쭤보세요(NCI).',
        '혈압약과 함께 드시면 혈압이 많이 내려갈 수 있고, 혈액을 묽게 하는 약(와파린)의 효과를 약하게 할 수 있어요(식약처).'],
      ask: '코엔자임Q10을 먹고 있는데 항암(방사선) 중에도 계속 먹어도 될까요?',
      src: 'NCI · 식약처' },
    /* 식약처 영양성분 셀레늄(유해산소로부터 세포 보호에 필요) · MSKCC Selenium(고용량 중독: 근육 약화·피로·손발톱·머리카락 변화·마늘 냄새, 암 예방 근거 없음, 치료 중엔 상의) */
    { pat: /셀레늄|셀렌|selenium/i, name: '셀레늄', kind: 'supplement', lv: 'info',
      known: '식약처가 ‘유해산소로부터 세포를 보호하는 데 필요’하다고 인정한 영양성분이에요. 암을 막는다는 뚜렷한 근거는 없어요.',
      care: ['고용량을 오래 드시면 머리카락·손발톱 변화, 근육 약화, 피로, 입에서 마늘 냄새 같은 중독 증상이 생길 수 있어요(MSKCC).',
        '종합비타민에도 들어 있어 여러 제품을 함께 드시면 양이 겹쳐요.',
        '항암·방사선 치료 중에 드시려면 먼저 담당 의사와 상의하라고 안내해요(MSKCC).'],
      ask: '셀레늄을 따로 먹어도 될까요? 종합비타민이랑 겹치지 않을까요?',
      src: '식약처 · MSKCC' },
    /* 식약처 영양성분 아연(정상 면역·세포분열) · MSKCC Zinc(맛 변화·구내염 근거 엇갈림, 고용량 장기 → 구리 결핍, 항생제와 2~4시간 간격, 메스꺼움) · 65 */
    { pat: /아연|zinc/i, name: '아연', kind: 'supplement', lv: 'info',
      known: '식약처가 정상적인 면역 기능·세포 분열에 필요하다고 인정한 영양성분이에요. 치료 중 맛 변화나 입안 헐음에 도움이 되는지는 연구 결과가 엇갈려요.',
      care: ['고용량을 오래 드시면 구리가 부족해지고 면역이 떨어질 수 있어요(MSKCC).',
        '일부 항생제와 함께 드시면 서로 흡수를 방해해 시간을 띄워야 해요(MSKCC).',
        '메스꺼움·속 불편함이 생길 수 있어요.'],
      links: ['65'],
      ask: '맛이 이상해서 아연을 먹어 보려는데, 지금 약이랑 같이 먹어도 될까요?',
      src: '식약처 · MSKCC' },
    /* NCI PDQ Vitamin C(주사: 콩팥 질환·G6PD 결핍·혈색소증 주의, 일부 항암제 작용 저하는 실험 보고, FDA 암 치료 미승인)
       · 09(고용량 항산화제 — 항암·방사선 중 복용이 재발 위험과 연관된 연구) */
    { pat: /비타민\s*[cC](?![a-zA-Z])|비타민\s*씨|vitamin\s*c\b|아스코르브|고용량\s*비타민(?!\s*[A-Za-z0-9가-힣])|메가\s*도스|비타민\s*(주사|수액)/i, name: '비타민 C(고용량·주사)', kind: 'supplement', lv: 'warn',
      known: '과일·채소나 일반 건강기능식품으로 드시는 양과, 하루 몇 g씩 드시거나 주사로 맞는 고용량은 따로 봐야 해요. 비타민 C 주사가 암 치료에 효과가 있다는 근거는 아직 없어요(미국 FDA 미승인).',
      care: ['항암·방사선 중 고용량 항산화제(비타민 A·C·E 등)를 드신 분의 재발 위험이 높았다는 연구가 있어요(토닥 음식 안내).',
        '콩팥이 약하신 분은 주사 뒤 콩팥 기능이 나빠진 사례가 있고, 타고난 효소 결핍(G6PD 결핍)이 있으면 적혈구가 깨질 수 있어요(NCI).',
        '실험에서는 일부 항암제의 작용을 약하게 했다는 보고가 있어요(NCI).',
        '주사로 맞으셨다면 맞은 날짜와 양을 진료 때 알려 주세요.'],
      links: ['09'],
      ask: '비타민 C 주사(고용량)를 권유받았는데, 항암 중에 맞아도 될까요?',
      src: 'NCI · 토닥 음식 안내' },
    /* MSKCC Vitamin E(하루 400IU 넘는 고용량 — 항응고제 출혈·수술 전 알릴 것, 항산화로 항암·방사선 간섭 우려) · 09(고용량 항산화제) */
    { pat: /비타민\s*[eE](?![a-zA-Z])|vitamin\s*e\b|토코페롤|tocopherol/i, name: '비타민 E', kind: 'supplement', lv: 'warn',
      known: '항산화 영양성분이에요. 종합비타민에 든 양과 달리 고용량 단일 제품은 따로 봐야 해요.',
      care: ['하루 400IU가 넘는 고용량은 혈액을 묽게 하는 약과 함께 드시면 피가 잘 멎지 않을 수 있어요 — 수술 전에는 꼭 말씀해 주세요(MSKCC).',
        '항암·방사선 중 고용량 항산화제는 재발 위험과 연관됐다는 연구가 있어요(토닥 음식 안내).'],
      links: ['09'],
      ask: '비타민 E를 먹고 있는데 수술(항암) 전에는 쉬어야 할까요?',
      src: 'MSKCC · 토닥 음식 안내' },
    /* 식약처 영양성분 칼슘(뼈·치아·골다공증 위험 감소) · 09(호르몬치료 중 뼈 건강에 칼슘·비타민 D, 용량은 검사로)
       · 골다공증약(알렌드로네이트) 허가사항 — 칼슘·제산제 등이 흡수를 방해(openFDA 라벨 7.1) · 67 */
    { pat: /칼슘|calcium|칼마디/i, name: '칼슘', kind: 'supplement', lv: 'info',
      known: '뼈와 치아를 만드는 데 필요한 영양성분이에요. 호르몬치료 중에는 뼈 건강을 위해 비타민 D와 함께 권하는 경우가 많아요. 용량은 검사 결과와 식사량에 따라 정해요.',
      care: ['먹는 골다공증약(알렌드로네이트 등)과 같이 드시면 약이 잘 흡수되지 않아요 — 약 허가사항에 시간을 띄워 드시라고 적혀 있어요.',
        '음식으로 드시는 양도 함께 따져요 — 뼈 건강 식사 카드에 음식으로 채우는 방법이 있어요.'],
      links: ['67'],
      ask: '칼슘을 따로 먹어야 할까요? 골다공증약이랑은 몇 시간 띄워 먹으면 될까요?',
      src: '식약처 · 골다공증약 허가사항 · 토닥 음식 안내' },
    /* 식약처 영양성분 마그네슘(에너지 이용·신경·근육) · 산화마그네슘은 국내 변비약 성분 · 골다공증약 허가사항(칼슘 등 다가 양이온이 흡수 방해) */
    { pat: /마그네슘|magnesium/i, name: '마그네슘', kind: 'supplement', lv: 'info',
      known: '에너지 이용과 신경·근육 기능에 필요한 영양성분이에요(식약처). 다리에 쥐가 날 때나 잠을 위해 드시는 분이 많아요.',
      care: ['변비약(산화마그네슘)으로도 쓰이는 성분이라 많이 드시면 설사가 생길 수 있어요 — 설사하는 시기라면 먼저 말씀해 주세요.',
        '먹는 골다공증약과 같이 드시면 약이 잘 흡수되지 않아 시간을 띄워야 해요(허가사항).'],
      links: ['63'],
      ask: '마그네슘을 먹어도 될까요? 다른 약이랑 몇 시간 띄워야 할까요?',
      src: '식약처 · 골다공증약 허가사항' },
    /* 식약처 영양성분 철(산소 운반·혈액 생성) · 골다공증약 허가사항(다가 양이온) · 철분제 허가사항(변비·위장 장애·흑색변) */
    { pat: /철분|철\s*보충|헴철|iron\b|훼럼|페로바/i, name: '철분', kind: 'supplement', lv: 'info',
      known: '피를 만들고 산소를 나르는 데 필요한 영양성분이에요(식약처). 치료 중 빈혈은 원인이 여러 가지라, 철분이 필요한지는 혈액검사로 먼저 확인해요.',
      care: ['변비·속 쓰림·메스꺼움이 생길 수 있고 변이 검게 보일 수 있어요.',
        '먹는 골다공증약과 같이 드시면 약이 잘 흡수되지 않아 시간을 띄워야 해요(허가사항).',
        '종합비타민에도 들어 있어 겹칠 수 있어요.'],
      links: ['64'],
      ask: '빈혈이 있다고 해서 철분제를 먹으려는데, 혈액검사로 먼저 확인해야 할까요?',
      src: '식약처 · 의약품 허가사항' },
    /* 식약처 개별인정 콜라겐펩타이드 섭취 시 주의사항(영유아·임산부 피할 것, 알레르기 체질 주의) · 61(단백질은 음식으로) */
    { pat: /콜라겐|collagen/i, name: '콜라겐', kind: 'supplement', lv: 'info',
      known: '단백질의 한 종류예요. 피부 보습 등의 기능성을 인정받은 제품이 있지만, 유방암 치료와 관련해 확인된 효과는 없어요.',
      care: ['식약처 주의사항에 알레르기 체질이면 주의하라고 적혀 있어요 — 생선 껍질 같은 원료를 성분표에서 확인해 주세요.',
        '석류·비타민 C 같은 다른 성분이 섞인 제품이 많아요 — 섞인 성분도 함께 확인해 주세요.',
        '치료 중 단백질은 살코기·생선·두부 같은 음식으로 채우는 방법이 식사 카드에 있어요.'],
      links: ['61'],
      ask: '콜라겐 제품을 먹고 있는데, 지금 치료 중에도 계속 먹어도 될까요?',
      src: '식약처 · 토닥 음식 안내' },
    /* 글루타치온 — 기관 자료에 정리된 사람 근거가 적다(MSKCC 개별 항목 없음, 2026-09-28 확인).
       항산화 보충제 일반 원칙만 쓴다: NCI PDQ(항산화 보충제와 재발 증가 관찰 연구) · 09(고용량 항산화제) */
    { pat: /글루타치온|glutathione|백옥\s*주사/i, name: '글루타치온', kind: 'supplement', lv: 'warn',
      known: '몸에서 만들어지는 항산화 성분으로, 먹는 제품이나 미백 목적의 주사(백옥주사)로 쓰여요. 사람에게서 확인된 근거가 적어요.',
      care: ['항산화 성분이에요 — 항암·방사선 중 항산화 보충제를 드신 분의 재발이 더 많았다는 연구가 있어, 치료 중에는 먼저 여쭤보세요(NCI·토닥 음식 안내).',
        '주사로 맞으셨다면 맞은 날짜를 진료 때 알려 주세요.'],
      ask: '글루타치온(백옥주사)을 맞아도 될까요? 항암 중에는 어떻게 할까요?',
      src: 'NCI · 토닥 음식 안내' },
    /* 식약처 마리골드꽃추출물(황반색소밀도 유지 / 섭취 시 주의: 흡연자는 전문가 상담, 과다 섭취 시 피부 황색) · 타목시펜 허가사항(눈 이상 보고) */
    { pat: /루테인|lutein|마리골드|지아잔틴|zeaxanthin/i, name: '루테인', kind: 'supplement', lv: 'info',
      known: '식약처가 ‘노화로 줄어들 수 있는 황반색소밀도를 유지해 눈 건강에 도움’ 기능성을 인정한 원료(마리골드꽃추출물)예요. 유방암 치료와 관련한 주의 자료는 적어요.',
      care: ['식약처 주의사항에 흡연자는 전문가와 상담하라고 적혀 있어요.',
        '많이 드시면 피부가 잠깐 누렇게 보일 수 있어요.',
        '타목시펜을 드시는 중 눈이 침침하거나 잘 안 보이면, 건강기능식품보다 먼저 담당 의사에게 알려 주세요 — 타목시펜 허가사항에 눈 이상이 적혀 있어요.'],
      ask: '눈 건강 때문에 루테인을 먹으려는데, 지금 약이랑 같이 먹어도 될까요?',
      src: '식약처 · 타목시펜 허가사항' },
    /* 식약처 녹차 추출물(기능성 / 섭취 시 주의: 간질환·의약품 복용 시 상담, 식후 섭취, 카페인 초조·불면)
       · 식약처 병용 섭취정보(녹차: 아세트아미노펜 등 간에 부담 주는 약과 간독성) · MSKCC Green tea(고용량 추출물 간독성, EGCG 와 타목시펜 농도) */
    { pat: /녹차\s*(추출|카테킨|캡슐|정(?!말|도)|환(?!자)|분말|엑기스)|카테킨|catechin|egcg|green\s*tea\s*extract/i, name: '녹차 추출물(카테킨)', kind: 'supplement', lv: 'warn',
      known: '식약처가 항산화·체지방 감소·콜레스테롤 개선 기능성을 인정한 원료예요. 마시는 녹차보다 훨씬 진한 양이 들어 있어요.',
      care: ['식약처 주의사항에 간 질환이 있거나 약을 드시면 전문가와 상담하고, 식사 후에 드시라고 적혀 있어요. 카페인 때문에 초조하거나 잠이 안 올 수 있어요.',
        '고용량 추출물을 드신 뒤 간이 상한 사례가 보고됐어요(MSKCC).',
        '타이레놀(아세트아미노펜)처럼 간에 부담을 줄 수 있는 약과 함께 드시면 간 독성이 커질 수 있어요(식약처).',
        '실험 단계에서 타목시펜 농도에 영향을 줬다는 보고가 있어요(MSKCC).'],
      ask: '녹차 추출물(카테킨) 다이어트 제품을 먹어도 될까요? 간 수치가 걱정돼요.',
      src: '식약처 · MSKCC' },
    /* MSKCC Garlic(보충제는 수술 1~2주 전 중단, 와파린 등 항응고제 — 출혈) · 식약처 병용 섭취정보(마늘: 항응고제 출혈, 아스피린과 알레르기) */
    { pat: /흑마늘|마늘\s*(진액|즙|환(?!자)|정(?!말|도)|캡슐|추출|보충|분말|엑기스|농축|오일)|garlic/i, name: '흑마늘·마늘 진액', kind: 'supplement', lv: 'warn',
      known: '음식으로 드시는 마늘과 달리, 진액·환·캡슐처럼 농축한 제품은 따로 봐야 해요. 사람 연구에서 효과는 대부분 뚜렷하지 않아요.',
      care: ['피가 잘 멎지 않게 할 수 있어 수술 1~2주 전에는 마늘 보충제를 멈추라고 안내해요(MSKCC).',
        '혈액을 묽게 하는 약(와파린·아스피린 등)과 함께 드시면 출혈 위험이 커질 수 있어요(식약처).',
        '반찬·양념으로 드시는 마늘은 음식이에요.'],
      ask: '흑마늘 진액을 먹고 있는데 수술 전에는 언제부터 쉬어야 할까요?',
      src: 'MSKCC · 식약처' },
    /* 식약처 은행잎 추출물(기억력·혈행 개선 / 주의: 수술 전후 환자·항응고제 복용 시) · 식약처 병용 섭취정보(항경련제·항우울제 — 세로토닌 증후군 등)
       · MSKCC Ginkgo(발작 위험). 기넥신·타나민은 같은 성분의 처방약 */
    { pat: /은행\s*잎|은행\s*추출|은행엽|징코|ginkgo|기넥신|타나민/i, name: '은행잎 추출물', kind: 'supplement', lv: 'warn',
      known: '식약처가 기억력·혈행 개선 기능성을 인정한 원료예요. 병원에서 처방하는 혈액순환제에도 같은 성분이 있어요.',
      care: ['식약처 주의사항에 수술 전후 환자와 혈액을 묽게 하는 약을 드시는 분은 섭취에 주의하라고 적혀 있어요.',
        '경련을 겪으신 적이 있으면 경련 위험이 올라갈 수 있어요(MSKCC).',
        '일부 항우울제와 함께 드시면 세로토닌 증후군(정신이 흐려짐·떨림·근육 이상 등)이 생길 수 있다고 해요(식약처).'],
      ask: '은행잎 추출물을 먹고 있는데 수술(항암) 전에는 쉬어야 할까요? 지금 약이랑 겹치지 않을까요?',
      src: '식약처 · MSKCC' },
    /* 식약처 알로에 겔(피부·장·면역) / 알로에 전잎(배변 활동 / 주의: 위·신장·간질환·의약품 복용 시 상담) · 식약처 병용 섭취정보(이뇨제·변비약 — 저칼륨)
       · NCCIH Aloe vera(먹는 알로에 라텍스 — 복통·설사, 잎 추출물 급성 간염 사례) */
    { pat: /알로에|aloe/i, name: '알로에', kind: 'supplement', lv: 'warn',
      known: '식약처는 알로에 겔(피부·장 건강·면역)과 알로에 전잎(배변 활동)을 서로 다른 기능성으로 인정했어요. 전잎 제품은 변비약처럼 작용해요.',
      care: ['전잎 제품은 위·콩팥·간 질환이 있거나 약을 드시면 전문가와 상담하라고 식약처 주의사항에 적혀 있어요. 배가 아프거나 설사가 날 수 있어요.',
        '이뇨제·변비약과 함께 드시면 몸속 칼륨이 줄 수 있어요(식약처).',
        '먹는 알로에 제품을 드신 뒤 간염이 생긴 사례 보고가 있어요(NCCIH).'],
      links: ['64'],
      ask: '변비 때문에 알로에 제품을 먹으려는데, 지금 치료 중에도 괜찮을까요?',
      src: '식약처 · NCCIH' },
    /* 식약처 스피루리나(피부·항산화·콜레스테롤) · 식약처 병용 섭취정보(항응고제 출혈, 면역억제제 효과 감소) · MSKCC Blue-green algae(독성 조류 오염 — 간 손상 등, 암 치료·예방 근거 없음) */
    { pat: /스피루리나|spirulina|남조류|블루\s*그린\s*알지/i, name: '스피루리나', kind: 'supplement', lv: 'info',
      known: '식약처가 피부 건강·항산화·콜레스테롤 개선 기능성을 인정한 조류(말) 원료예요. 암을 치료하거나 막는다는 근거는 없어요.',
      care: ['간을 해치는 독소를 만드는 다른 조류가 섞여 오염된 제품이 문제가 된 적이 있어요(MSKCC).',
        '혈액을 묽게 하는 약과 함께 드시면 출혈 위험이 커지고, 면역억제제의 효과를 줄일 수 있어요(식약처).'],
      ask: '스피루리나를 먹고 있는데, 지금 치료 중에도 계속 먹어도 될까요?',
      src: '식약처 · MSKCC' },
    /* 식약처 클로렐라(피부·항산화·면역·콜레스테롤) · 식약처 병용 섭취정보(항응고제 출혈, 면역 자극 — 면역억제제 방해) */
    { pat: /클로렐라|chlorella/i, name: '클로렐라', kind: 'supplement', lv: 'info',
      known: '식약처가 피부 건강·항산화·면역력 증진·콜레스테롤 개선 기능성을 인정한 조류(말) 원료예요. 암과 관련해 사람에게서 확인된 근거는 적어요.',
      care: ['혈액을 묽게 하는 약과 함께 드시면 출혈 위험이 커질 수 있어요(식약처).',
        '면역을 자극해 면역억제제 치료를 방해할 수 있다고 해요(식약처).'],
      ask: '클로렐라를 먹고 있는데, 지금 치료 중에도 계속 먹어도 될까요?',
      src: '식약처' },
    /* 식약처 글루코사민(관절·연골 / 주의: 간·심장질환·수술 전후·고혈압·당뇨·천식·항응고제 상담, 게·새우 알레르기)
       · 식약처 병용 섭취정보(글루코사민: 항암제 에토포시드·독소루비신 약효 감소, 항응고제) · NCCIH(와파린 출혈) · 09·34(관절통은 운동 근거) */
    { pat: /글루코사민|glucosamine|콘드로이친|chondroitin|엔에이지|아세틸\s*글루코사민/i, name: '글루코사민', kind: 'supplement', lv: 'warn',
      known: '식약처가 관절·연골 건강 기능성을 인정한 원료예요. 호르몬치료로 생긴 관절통에 도움이 된다는 확실한 근거는 없어요 — 사람 연구에서 통증이 준 것이 확인된 건 운동이에요.',
      care: ['일부 항암제(독소루비신·에토포시드)의 효과를 줄일 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
        '와파린을 드시면 출혈 위험이 커질 수 있어요(식약처·NCCIH).',
        '게·새우 알레르기가 있거나, 당뇨·간·심장 질환·고혈압이 있거나, 수술 전후라면 전문가와 상담하라고 식약처 주의사항에 적혀 있어요.'],
      links: ['34'],
      ask: '관절이 아파서 글루코사민을 먹으려는데, 지금 항암제(호르몬약)랑 같이 먹어도 될까요?',
      src: '식약처 · NCCIH · 토닥 관절통 안내' },
    /* MSKCC Black cohosh(간 손상 사례, 유방암 환자 안전성 불분명, 타목시펜 작용 방해 가능, 치료로 생긴 홍조에 근거 엇갈림)
       · 09(홍조 때문에 찾는 승마·이소플라본 보충제 — 유방암 환자에게 권하지 않음, 담당 선생님과 상의) */
    { pat: /승마|블랙\s*코호시|black\s*cohosh|레미페민|remifemin/i, name: '승마(블랙코호시)', kind: 'supplement', lv: 'warn',
      known: '갱년기 홍조에 많이 쓰는 식물 원료예요. 유방암 치료로 생긴 홍조에 효과가 있는지는 연구 결과가 엇갈려요.',
      care: ['간이 상한 사례가 보고돼 있어요(MSKCC).',
        '유방암 환자에게 안전한지는 분명하지 않고, 타목시펜 작용을 방해할 수 있다는 우려가 있어요(MSKCC).',
        '토닥 음식 안내에서도 홍조 때문에 찾으시는 승마·이소플라본 보충제는 유방암 환자에게 권하지 않는다며, 담당 의사와 상의하시라고 안내해요.'],
      links: ['35'],
      ask: '홍조 때문에 승마(블랙코호시) 제품을 먹어 보려는데, 타목시펜이랑 같이 먹어도 될까요?',
      src: 'MSKCC · 토닥 음식 안내' },
    /* NCI PDQ Mistletoe extracts(유럽에서 많이 처방, FDA 미승인, 유방암 생존·부작용 연구는 설계 한계로 조심해서 읽을 것,
       주사 부위 반응·두통·발열·오한, 드물게 아나필락시스) */
    { pat: /겨우살이|미슬토|mistletoe|압노바|헬릭소|이스카도르|iscador|viscum|비스쿰/i, name: '겨우살이(미슬토)', kind: 'herbal', lv: 'warn', pill: '! 맞거나 드시기 전에 꼭 물어보세요',
      known: '유럽에서 암 환자에게 주사로 많이 쓰는 식물 추출물이에요. 생존이나 삶의 질이 나아졌다는 보고가 있지만, 참여한 사람이 적거나 방법이 허술한 연구가 많아 확실하다고 보기 어려워요. 미국 FDA는 암 치료제로 승인하지 않았어요.',
      care: ['주사 부위가 붓고 아프거나 두통·열·오한이 생길 수 있고, 드물게 심한 알레르기(쇼크)가 보고됐어요(NCI).',
        '달여 마시는 겨우살이 차는 병원 주사제와 다른 것이에요 — 드신다면 진료 때 꼭 말씀해 주세요.',
        '지금 받는 항암치료와 함께 맞으시려면 담당 의사와 먼저 상의해 주세요.'],
      ask: '겨우살이(미슬토) 주사를 권유받았는데, 지금 받는 치료와 같이 맞아도 될까요?',
      src: 'NCI' },
    /* 국가암정보센터 Q&A(개똥쑥 등 — 과학적 자료가 없고, 항암제와의 상호작용이 알려져 있지 않아 독성·효과 저하 가능, 의료진과 상담) · 09(사람 근거 없음) */
    { pat: /개똥쑥|아르테미시|artemisia\s*annua|sweet\s*wormwood|청호/i, name: '개똥쑥', kind: 'herbal', lv: 'warn',
      known: '암에 좋다는 광고가 많은 식물이에요. 사람을 대상으로 확인된 근거는 없어요.',
      care: ['국가암정보센터는 개똥쑥 같은 건강식품·한약이 항암제와 어떻게 상호작용하는지 잘 알려져 있지 않고, 독성을 일으키거나 항암제 효과를 떨어뜨릴 수도 있어 담당 의사와 먼저 상의하라고 안내해요.'],
      ask: '개똥쑥 달인 물을 권유받았는데, 항암 중에 먹어도 될까요?',
      src: '국가암정보센터 · 토닥 음식 안내' },
    /* 식약처 병용 섭취정보(크랜베리: 항응고제가 오래 남아 출혈, 아스피린과 살리실산 알레르기, CYP2C9 로 분해되는 약 — 타목시펜·와파린 등) */
    { pat: /크랜베리|크렌베리|cranberry/i, name: '크랜베리', kind: 'supplement', lv: 'warn',
      known: '방광염 예방 등으로 많이 드시는 열매 추출물이에요.',
      care: ['혈액을 묽게 하는 약(와파린)이 몸에 오래 남아 출혈 위험이 있어요(식약처).',
        '타목시펜처럼 몸속에서 같은 효소로 분해되는 약과 상호작용이 일어날 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
        '아스피린과 함께 드시면 발진·가려움 같은 알레르기 반응이 생길 수 있어요(식약처).'],
      ask: '방광염 때문에 크랜베리를 먹으려는데, 타목시펜이랑 같이 먹어도 될까요?',
      src: '식약처' },
    /* 식약처 쏘팔메토 열매 추출물(전립선 건강 / 주의: '성인남성만 섭취할 것', 수술 전후·출혈성 질환·항응고제 상담)
       · 식약처 병용 섭취정보(이론적으로 여성호르몬 치료 방해) */
    { pat: /쏘팔메토|소팔메토|saw\s*palmetto/i, name: '쏘팔메토', kind: 'supplement', lv: 'warn',
      known: '식약처가 ‘전립선 건강 유지’ 기능성을 인정한 원료로, 섭취 시 주의사항에 ‘성인 남성만 섭취할 것’이라고 적혀 있어요.',
      care: ['이론적으로 여성호르몬 치료를 방해할 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
        '수술 전후이거나 혈액을 묽게 하는 약을 드시면 전문가와 상담하라고 해요(식약처).'],
      ask: '남편이 먹는 쏘팔메토를 같이 먹어도 될까요?',
      src: '식약처' },
    /* 식약처 병용 섭취정보(오미자: 진정제·알코올과 중추신경 억제 과도, 와파린 항응고 지속 — 출혈) */
    { pat: /오미자|schisandra/i, name: '오미자', kind: 'herbal', lv: 'info',
      known: '오미자차·오미자청으로 많이 드시고, 건강기능식품 원료로도 쓰여요.',
      care: ['와파린을 드시면 항응고 효과가 오래가 출혈 위험이 있어요(식약처).',
        '수면제·진정제·술과 함께 드시면 졸림·처짐이 심해질 수 있어요(식약처).'],
      ask: '오미자차를 자주 마시는데, 지금 먹는 약이랑 괜찮을까요?',
      src: '식약처' },
    /* 식약처 병용 섭취정보(가시오가피: 면역억제제 효과 감소, 항응고제 출혈, 디곡신 증가, 정신신경용제·에스트라디올 등, 당뇨약 저혈당, 수면제 졸음) */
    { pat: /오가피|siberian\s*ginseng|eleuthero/i, name: '가시오가피', kind: 'herbal', lv: 'warn',
      known: '인삼처럼 기운을 돋운다고 쓰는 한약재·건강기능식품 원료예요.',
      care: ['혈액을 묽게 하는 약과 함께 드시면 출혈 위험이 커질 수 있어요(식약처).',
        '심장약(디곡신)·여성호르몬제·여러 정신건강의학과 약·수면제 등과 상호작용이 있을 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
        '당뇨약과 함께 드시면 혈당이 너무 내려갈 수 있어요(식약처).'],
      ask: '오가피 진액을 먹고 있는데, 지금 먹는 약이랑 겹치지 않을까요?',
      src: '식약처' }
  ];

  /* SUPP 12종에 덧붙이는 '주의할 점'·식사 카드·같이 찾아볼 것 (SUPP 줄은 서버와 같아야 해서 따로 둔다 — 이름으로 잇는다) */
  var EXTRA69 = {
    /* NCCIH Asian ginseng(홍삼 = 쪄서 말린 인삼) · 식약처 홍삼·인삼 섭취 시 주의(당뇨치료제·혈액항응고제) · 식약처 병용 섭취정보(인삼: 이마티닙 간독성, 항응고제)
       · 국가암정보센터(홍삼·인삼·산삼·수삼 — 항암치료 중 주의) */
    '홍삼 · 인삼': { care: ['홍삼은 인삼을 쪄서 말린 것이에요 — 같은 인삼이라 주의할 점도 같아요. 수삼·산삼·장뇌삼·흑삼·인삼차도 마찬가지예요.',
      '식약처 주의사항에 당뇨약이나 혈액을 묽게 하는 약을 드시면 섭취에 주의하라고 적혀 있어요.',
      '표적항암제(이마티닙)와 함께 드시면 간에 독성이 생길 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
      '국가암정보센터는 항암치료 중 홍삼·인삼·산삼 같은 건강 보조 식품을 주의하라고 안내해요.'],
      also: ['경옥고', '공진단', '십전대보탕'], src: '식약처 · NCCIH · 국가암정보센터' },
    /* 식약처 병용 섭취정보(EPA·DHA: 항응고제 출혈, 당뇨약 효과 감소) · 09(호르몬치료 관절통 — 249명 무작위 시험에서 위약과 차이 없음) */
    '오메가3': { care: ['혈액을 묽게 하는 약과 함께 드시면 출혈 위험이 커지고, 당뇨약 효과를 줄일 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
      '호르몬치료 관절통에는 249명이 참여한 시험에서 가짜약과 차이가 없었어요(토닥 음식 안내).',
      '크릴오일에도 같은 성분이 들어 있어 함께 드시면 겹쳐요.'],
      links: ['34'], also: ['크릴오일'], src: '식약처 · 토닥 음식 안내' },
    /* 09·67(칼슘·비타민 D — 호르몬치료 중 뼈 건강, 용량은 검사로) */
    '비타민 D': { care: ['칼슘과 함께 뼈 건강을 위해 권하는 경우가 많아요 — 뼈 건강 식사 카드를 함께 보세요.',
      '종합비타민·칼슘 제품에도 들어 있는 경우가 많아요 — 겹치지 않게 성분표를 확인해 주세요.'],
      links: ['67'], also: ['칼슘'], src: '토닥 음식 안내' },
    /* 식약처 병용 섭취정보(프로바이오틱스: 항생제와 2시간 이상 간격, 면역억제제 방해) · 66 */
    '유산균(프로바이오틱스)': { care: ['항생제와 함께 드시면 효과가 줄 수 있어 2시간 이상 띄우라고 식약처 병용 섭취정보에 적혀 있어요.',
      '면역억제제의 효과를 방해할 수 있어요(식약처).',
      '백혈구가 낮은 시기의 식사·위생은 ‘면역이 약한 시기’ 식사 카드에 있어요.'],
      links: ['66'], src: '식약처 · 토닥 음식 안내' },
    /* 식약처 병용 섭취정보(밀크씨슬: 타목시펜 흡수량 증가, 라록시펜, 당뇨약 저혈당) · 식약처 밀크씨슬 추출물 주의(알레르기, 설사·위통·복부팽만) */
    '밀크씨슬': { care: ['몸에 흡수되는 타목시펜의 양을 늘릴 수 있다고 식약처 병용 섭취정보에 적혀 있어요.',
      '간 건강 기능성을 인정받은 원료지만, 항암 중 간 수치가 올랐을 때 스스로 드시기보다 먼저 여쭤보세요.',
      '설사·배 아픔·배에 가스가 차면 주의하라고 식약처 주의사항에 적혀 있어요.'],
      src: '식약처' },
    /* 09(고용량 커큐민 보충제 — 타목시펜 혈중 농도를 낮춘 사람 연구, 카레·양념은 괜찮음) · MSKCC Turmeric(실험에서 독소루비신·사이클로포스파마이드 등 작용 방해)
       · 식약처 병용 섭취정보(울금: 항응고제 출혈, 위산억제제 효과 감소, 당뇨약 저혈당) */
    '커큐민(강황)': { care: ['고용량 커큐민 보충제가 타목시펜 혈중 농도를 낮췄다는 사람 연구가 있어요(토닥 음식 안내). 카레·양념 정도는 음식이에요.',
      '실험에서 독소루비신·사이클로포스파마이드 같은 일부 항암제의 작용을 막았다는 보고가 있어요(MSKCC).',
      '혈액을 묽게 하는 약과는 출혈, 당뇨약과는 저혈당 위험이 있어요(식약처).'],
      links: ['09'], src: '식약처 · MSKCC · 토닥 음식 안내' },
    /* 식약처 대두이소플라본(뼈 건강 / 주의: '에스트로겐 호르몬에 민감한 사람은 섭취에 주의') · 식약처 병용 섭취정보(대두: 갑상선 호르몬제 효과 저해 등) · 94 */
    '이소플라본(콩 추출물)': { care: ['식약처 주의사항에 ‘에스트로겐 호르몬에 민감한 사람은 섭취에 주의’라고 적혀 있어요.',
      '두부·두유·된장 같은 콩 음식은 따로 봐요 — 콩 식사 카드를 보세요.',
      '갑상선 호르몬제의 효과를 떨어뜨릴 수 있어요(식약처).'],
      links: ['94'], also: ['칡즙', '승마'], src: '식약처 · 토닥 음식 안내' },
    /* 국가암정보센터 Q&A(상황버섯·아가리쿠스·영지·동충하초 — 과학적 자료 없음, 항암제와 상호작용 불명, 의료진 상담) */
    '버섯 추출물': { care: ['국가암정보센터는 상황버섯·아가리쿠스·영지·동충하초 같은 건강 보조 식품을 항암치료 중에는 주의하라고 안내해요 — 항암제와 어떻게 겹치는지 잘 알려져 있지 않아서예요.',
      '반찬으로 익혀 드시는 표고·느타리 같은 버섯은 음식이에요.'],
      also: ['영지버섯', '차가버섯', '동충하초'], src: '국가암정보센터' },
    /* 09(고용량 항산화제 A·C·E·베타카로틴 — 항암·방사선 중 재발 위험과 연관, 일반 용량 종합비타민은 대체로 괜찮음) */
    '종합비타민': { care: ['고용량 항산화제(비타민 A·C·E·베타카로틴)는 항암·방사선 중 재발 위험과 연관됐다는 연구가 있어요(토닥 음식 안내).',
      '셀레늄·철분·비타민 D 등 다른 제품과 함께 드시면 성분이 겹칠 수 있어요.'],
      links: ['09'], also: ['비타민 C', '비타민 E', '셀레늄'], src: '토닥 음식 안내' },
    /* 09(자몽 영향은 3~7일, 세비야오렌지·포멜로) · 미국 FDA 허가사항(openFDA 2026-09-28 확인: 팔보시클립·아베마시클립·에베로리무스·라파티닙·네라티닙 — 자몽 피할 것,
       올라파립(Lynparza) — 자몽·세비야오렌지 피할 것. 리보시클립·투카티닙·탈라조파립·알펠리십·엘라세스트란트 라벨에는 자몽 문구가 없다).
       2026-09-28 검토: 올라파립이 빠져 있어 BRCA 유방암으로 린파자를 드시는 분이 '내 약은 해당이 없다'고 읽을 수 있었다 — 더하고, 목록이 전부가 아니라고 적는다 */
    '자몽(주스 포함)': { care: ['자몽의 영향은 마신 뒤 하루가 지나도 남고 사라지는 데 3~7일이 걸려요 — 약 먹는 시간만 피하는 것으로는 부족하다고 음식 안내에 나와요.',
      '유방암에 쓰는 먹는 표적치료제 가운데 팔보시클립(입랜스)·아베마시클립(버제니오)·에베로리무스(아피니토)·라파티닙·네라티닙·올라파립(린파자)은 허가사항에 자몽을 피하라고 적혀 있어요(미국 FDA 허가사항). 이 밖의 약도 해당할 수 있어 드시는 약은 담당 약사에게 확인해 주세요.',
      '세비야오렌지(쓴 오렌지)·포멜로(문단)에도 비슷한 성분이 있어요.'],
      links: ['09'], src: '미국 FDA 허가사항 · 토닥 음식 안내' },
    /* 09(세인트존스워트 — 타목시펜·항암제 효과를 떨어뜨린다는 사람 연구) · 47 */
    '세인트존스워트': { care: ['타목시펜·항암제 효과를 떨어뜨린다는 사람 대상 연구가 있다고 음식 안내에 나와요.',
      '마음이 많이 힘드시면 제품보다 먼저 담당 의사와 이야기해 보세요.'],
      links: ['47'], src: '토닥 음식 안내' },
    /* 식약처(국내 멜라토닌은 전문의약품 — 해외직구 수면 제품에서 멜라토닌 검출 주의) · MSKCC Melatonin(호르몬 민감 암 — 에스트로겐 양에 영향, 와파린 출혈, 졸음)
       · NCCIH Melatonin(제품 표시량과 실제 함량 불일치) · 46 */
    '멜라토닌': { care: ['우리나라에서는 멜라토닌이 의사 처방이 필요한 전문의약품이에요 — 해외 직구 수면 제품에서 멜라토닌이 나와 식약처가 주의를 당부했어요.',
      '호르몬에 민감한 유방암이면 몸속 에스트로겐 양에 영향을 줄 수 있어 먼저 여쭤보라고 안내해요(MSKCC).',
      '혈액을 묽게 하는 약과 함께 드시면 피가 잘 멎지 않을 수 있고, 졸음이 올 수 있어요(MSKCC).',
      '해외 제품은 표시된 양과 실제 든 양이 크게 다른 경우가 많았어요(NCCIH).'],
      links: ['46'], src: '식약처 · MSKCC · NCCIH' }
  };

  /* ── 음식 (2026-09-28) — '바나나'가 '목록에 없어요'로 나왔다.
     평소 드시는 음식은 판정할 대상이 아니다 — '이건 음식이에요'로 알려 드리고 맞는 식사 카드로 모신다.
     한 줄 설명은 토닥 식사 카드(09·60~68·94·95)에 이미 있는 문장만 옮겼다 — 여기서 새 의학 주장을 만들지 않는다.
     (포멜로·녹즙처럼 조심할 점이 있는 것만 lv:'warn') 순서가 뜻을 갖는다 — 날것·술·콩이 과일·채소보다 먼저.
     not — 음식 낱말이 들어 있지만 음식이 아닌 이름 (2026-09-28 검토에서 잡은 것: 맥주효모→술, milk thistle→우유, soy isoflavone→콩,
     돼지감자→고기, 죽염→죽, 레몬밤→귤, 포도당·포도씨유→과일, pineapple→사과, '한약이라면'→라면). 걸리면 그 음식으로 보지 않는다.
     한 글자 음식(감·밤·무·파·굴·게)은 그 글자만 적으셨을 때만 잡는다. ── */
  var FOOD69 = [
    { pat: /생선회|^\s*회\s*$|회\s*(를|을|는|도|랑|하고|먹)|초밥|스시|육회|생굴|굴\s*회|날\s*달걀|날\s*계란|생\s*달걀|날것|날\s*음식|sushi/i, name: '회·초밥·육회·생굴', lv: 'warn',
      note: '백혈구가 낮은 시기에는 회·육회·생굴·날달걀처럼 익히지 않은 음식을 쉬어 가라고 ‘면역이 약한 시기’ 식사 카드에 나와요.', links: ['66'] },
    { pat: /포멜로|문단|세비야|쓴\s*오렌지|pomelo/i, name: '포멜로·세비야오렌지', lv: 'warn',
      note: '자몽과 비슷한 성분이 있어, 자몽처럼 일부 약이 몸에 필요 이상으로 남을 수 있다고 음식 안내에 나와요. 드시는 약이 해당하는지 담당 의사·약사에게 확인해 주세요.', links: ['09'], also: ['자몽'] },
    /* 국가암정보센터(녹즙 — 항암치료 중 주의) */
    { pat: /녹즙|(케일|신선초|명일엽|야채|채소)\s*즙/, name: '녹즙', lv: 'warn', juice: true,
      note: '국가암정보센터는 항암치료 중 녹즙 같은 건강 보조 식품을 주의하라고 안내해요. 백혈구가 낮은 시기의 음식 위생은 ‘면역이 약한 시기’ 카드를 보세요.', links: ['66'], src: '국가암정보센터 · 토닥 식사 카드' },
    { pat: /석류/, name: '석류(과일)',
      note: '과일로 드시는 석류는 음식이에요. 농축즙·추출물 같은 고농축 제품은 호르몬치료 중 ‘지금은 쉬어가요’에 두고 있어요(음식 안내).', links: ['09'], also: ['석류 농축즙'] },
    { pat: /표고|느타리|새송이|팽이|양송이|목이\s*버섯|송이\s*버섯|버섯\s*(볶음|반찬|전골|국|찌개|요리|구이|무침)/, name: '반찬 버섯',
      note: '반찬으로 익혀 드시는 버섯은 음식이에요. 상황버섯·차가버섯·영지 같은 달인 물·추출물은 따로 찾아보세요.', links: ['09'], also: ['상황버섯', '차가버섯', '영지버섯'] },
    { pat: /두부|두유|(^|[^땅홍])콩(?!팥)|된장|청국장|낫또|서리태|약콩|비지|soy|tofu/i, not: /soy\s*isoflavone/i, name: '콩 음식(두부·두유·된장)',
      note: '두부·두유·된장 같은 일상 콩 음식은 끊을 필요가 없고, 오히려 도움이 된다는 연구도 있다고 음식 안내에 나와요. 다만 고농축 이소플라본 ‘보충제’는 따로 봐야 해요.', links: ['94'], also: ['이소플라본'] },
    { pat: /(^|[\s,·\/(])술(?=$|[\s,·\/)은을이도한과만랑는로하마먹잔])|술자리|음주|맥주|와인|포도주|막걸리|소주|양주|위스키|알코올|알콜|사케|청주|하이볼|칵테일|alcohol|beer|wine/i, not: /맥주\s*효모|beer\s*yeast|brewer/i, name: '술',
      note: '유방암은 ‘몇 잔까지 괜찮다’보다 ‘안 마시는 쪽’을 권하는 암이라고 안내해요 — 술이 몸의 여성호르몬 수치를 올리기 때문이에요.', links: ['95'] },
    { pat: /보리차|옥수수차|둥굴레|숭늉/, name: '보리차·숭늉',
      note: '메스꺼울 때·입안이 헐었을 때·변비일 때 미지근하게 조금씩 드시기 좋은 음료로 식사 카드에 나와요.', links: ['60', '64'] },
    { pat: /커피|아메리카노|라떼|믹스\s*커피|디카페인|에스프레소|coffee|홍차|녹차|말차|카페인|에너지\s*음료/i, name: '커피·차',
      note: '평소 드시는 음료예요. 설사할 때는 커피·녹차·홍차가 장운동을 재촉하고, 메스꺼울 때는 진한 커피가 속을 더 불편하게 할 수 있다고 식사 카드에 나와요. 커피·녹차로 물을 대신하지는 마세요.', links: ['63', '60', '64'], also: ['녹차 추출물'] },
    { pat: /우유|요구르트|요거트|치즈|유제품|milk|yogurt|cheese/i, not: /milk\s*thistle/i, name: '우유·유제품',
      note: '뼈 건강에 도움이 되는 음식이에요. 설사할 때는 우유가 잠시 안 받을 수 있고, 백혈구가 낮은 시기에는 살균 표시가 있는 제품을 고르라고 식사 카드에 나와요.', links: ['67', '63', '66'] },
    { pat: /고기|쇠고기|소고기|돼지|닭고기|닭가슴살|삼겹살|오리고기|육류|스테이크|meat|beef|pork|chicken/i, not: /돼지\s*감자/, name: '고기',
      note: '치료 중엔 단백질이 오히려 필요해요. 가공육·붉은 고기는 ‘줄이기’를 권하는 것이지 ‘금지’가 아니라고 음식 안내에 나와요.', links: ['61', '09'] },
    { pat: /생선|고등어|연어|참치|갈치|조기|명태|동태|대구|멸치|꽁치|새우|오징어|조개|^\s*(굴|게)\s*$|fish|salmon|tuna/i, name: '생선·해산물', weak: true,
      note: '단백질을 채우기 좋은 음식이에요. 백혈구가 낮은 시기에는 속까지 익혀 드시라고 ‘면역이 약한 시기’ 카드에 나와요.', links: ['61', '66'] },
    { pat: /계란|달걀|\beggs?\b/i, name: '달걀',
      note: '계란찜·삶은 달걀처럼 부드러운 단백질 음식으로 여러 식사 카드에 나와요. 백혈구가 낮은 시기에는 노른자까지 익혀 드시라고 안내해요.', links: ['61', '66'] },
    { pat: /김치|깍두기|나박김치|총각김치|열무김치/, name: '김치',
      note: '백혈구가 낮은 시기에는 생김치 대신 익힌 김치를 권하고, 입안이 헐었을 때·설사할 때는 매운 김치찌개를 쉬어 가라고 식사 카드에 나와요.', links: ['65', '62', '63'] },
    { pat: /매운|매콤|떡볶이|짬뽕|라면|고추|낙지\s*볶음|마라|불닭|spicy/i, not: /[이하다]라면/, name: '매운 음식',
      note: '메스꺼울 때·입안이 헐었을 때·설사할 때는 맵고 짠 음식을 쉬어 가라고 식사 카드에 나와요.', links: ['60', '62', '63'] },
    { pat: /바나나|banana/i, name: '바나나',
      note: '설사할 때 칼륨을 순하게 채우는 과일로, 입안이 헐었을 때는 새콤하지 않아 덜 쏘는 과일로 식사 카드에 나와요.', links: ['63', '62'] },
    { pat: /사과|^\s*배\s*$|배즙|배숙|익힌\s*배|apple|pear/i, not: /pineapple/i, name: '사과·배',
      note: '설사할 때는 생과일보다 익힌 사과·배가 순하고, 변비일 때는 배·배숙이 좋다고 식사 카드에 나와요.', links: ['63', '64'] },
    { pat: /수박|참외|멜론|melon/i, name: '수박·참외',
      note: '메스꺼울 때는 수분이 많고 향이 약한 과일로, 입안이 헐었을 때는 덜 쏘는 과일로 식사 카드에 나와요.', links: ['60', '62'] },
    { pat: /귤|오렌지|한라봉|천혜향|레드향|레몬|유자|라임|감귤|orange|lemon/i, not: /레몬\s*밤|lemon\s*balm/i, name: '귤·오렌지',
      note: '평소 드시는 과일이에요. 입안이 헐었을 때는 신 과일이 헌 자리를 쏠 수 있다고 식사 카드에 나와요. 자몽·세비야오렌지·포멜로는 약과 겹칠 수 있어 따로 봐야 해요.', links: ['62', '09'], also: ['자몽'] },
    { pat: /포도|딸기|블루베리|키위|복숭아|자두|곶감|홍시|단감|망고|파인애플|체리|토마토|과일|^\s*감\s*$|pineapple|fruit|berry/i, not: /포도\s*(당|씨)/, name: '과일', weak: true,
      note: '평소 드시는 과일이에요. 백혈구가 낮은 시기에도 흐르는 물에 잘 씻어 드시면 되고, 무조건 끊는다고 감염이 준다는 근거는 없다고 식사 카드에 나와요.', links: ['66', '09'] },
    { pat: /브로콜리|양배추|당근|시금치|채소|야채|샐러드|오이|상추|깻잎|나물|양상추|파프리카|^\s*(무|파)\s*$|vegetable|salad/i, name: '채소', weak: true,
      note: '평소 드시는 채소예요. 백혈구가 낮은 시기에도 흐르는 물에 잘 씻어 드시면 되고, 끊을 필요는 없다고 식사 카드에 나와요.', links: ['66', '64'] },
    { pat: /호박/, name: '호박', juice: true,
      note: '호박은 음식이에요 — 입맛이 없을 때·입안이 헐었을 때 식사 카드에 호박죽·단호박이 나와요. 건강원에서 만든 호박즙은 다른 재료(한약재 등)가 섞였는지 확인해 주세요 — 여러 가지가 섞인 즙은 무엇이 들었는지 알기 어려워요.', links: ['61', '62'] },
    { pat: /감자|고구마/, not: /돼지\s*감자/, name: '감자·고구마',
      note: '고구마는 변비일 때, 삶은 감자는 설사할 때 칼륨을 채우는 음식으로 식사 카드에 나와요.', links: ['64', '63'] },
    { pat: /미역|다시마|해조|파래|^\s*김\s*$|seaweed/i, name: '미역·다시마',
      note: '변비일 때 물을 머금어 변을 부드럽게 하고, 뼈 건강 식사에도 나오는 음식이에요.', links: ['64', '67'] },
    { pat: /견과|호두|아몬드|땅콩|^\s*(잣|밤)\s*$|캐슈|피스타치오|마카다미아|\bnuts?\b/i, name: '견과류',
      note: '평소 드시는 음식이에요. 입안이 헐었을 때는 견과처럼 딱딱하고 거친 음식이 헌 자리를 건드릴 수 있다고 식사 카드에 나와요.', links: ['62'] },
    { pat: /생강|ginger/i, name: '생강',
      note: '양념으로 드시는 생강은 음식이에요. 메스꺼움 때문에 생강 제품을 따로 챙겨 드시려면 시작하기 전에 상의하라고 식사 카드에 나와요.', links: ['60'] },
    { pat: /마늘|양파|대파|부추/, name: '마늘·양파',
      note: '양념·반찬으로 드시는 건 음식이에요. 진액·환처럼 농축한 제품은 따로 봐야 해요.', links: ['09'], also: ['흑마늘'] },
    { pat: /설탕|사탕|초콜릿|초콜렛|과자|케이크|아이스크림|탄산|콜라|사이다|음료수|주스|쥬스|juice|soda|chocolate|candy/i, name: '단 음식·음료', weak: true,
      note: '“설탕을 끊으면 암세포가 굶는다”는 말은 사실이 아니에요. 단 음료·과자를 줄이시라는 건 체중 관리 때문이라고 음식 안내에 나와요.', links: ['68', '09'] },
    { pat: /죽|미음|누룽지|흰밥|쌀밥|잡곡밥|현미|^\s*밥\s*$|빵|떡|국수|칼국수|수제비|rice|bread|noodle/i, not: /죽염/, name: '밥·죽·빵', weak: true,
      note: '평소 드시는 음식이에요. 메스꺼울 때·입안이 헐었을 때는 흰죽·미음·누룽지처럼 부드러운 음식이 편하다고 식사 카드에 나와요.', links: ['60', '62'] },
    { pat: /꿀|조청|올리고당|honey/i, name: '꿀·조청', weak: true,
      note: '평소 드시는 음식이에요. 치료 중 불편한 증상이 있으시면 증상별 식사 카드를 보세요.', links: ['09'] }
  ];
  /* 즙·주스로 물어보시면 66(면역이 약한 시기)의 '갓 짜서 파는 생과일주스' 안내를 덧붙인다 (juice:true 인 항목은 자기 글에 이미 있다) */
  var JUICE69 = /즙|주스|쥬스|juice/i;
  var JUICE69_NOTE = '갓 짜서 파는 생과일주스는 백혈구가 낮은 시기에 피하라고 ‘면역이 약한 시기’ 카드에 나와요.';
  /* 여쭤볼 말의 동사 — 마시는 것이면 '마셔도' ('커피를 평소처럼 먹어도 될까요?'가 어색했다 · 2026-09-28 검토) */
  var DRINK69 = /(주스|쥬스|즙|차$|커피|라떼|아메리카노|우유|두유|요구르트|술|맥주|와인|소주|막걸리|음료|콜라|사이다|\b(juice|coffee|tea|milk|beer|wine)\b)/i;
  /* '추출물·캡슐·진액'처럼 제품 꼴이면 음식 목록을 건너뛴다 ('콩 추출물' → 콩 음식이 아니라 이소플라본) */
  var FORM69 = /추출|농축|보충제|영양제|캡슐|알약|정제|분말|가루|엑기스|진액|건강기능식품|건기식/;
  /* 이름 한 낱말만으로는 무엇인지 모를 때 — 골라 주실 수 있게 칩을 보여 드린다 */
  var GENERIC69 = [
    { pat: /^(비타민|비타민제|vitamins?)$/i, pick: ['비타민 D', '비타민 C', '비타민 E', '종합비타민'] },
    { pat: /^(영양제|건강기능식품|건기식|보충제|보조제|건강식품)$/, pick: ['오메가3', '유산균', '비타민 D', '밀크씨슬', '홍삼', '칼슘'] },
    { pat: /^(한약|보약|탕약|한방|환약|진액)$/, pick: ['경옥고', '공진단', '쌍화탕', '십전대보탕', '우황청심원', '녹용'] },
    { pat: /^(즙|건강즙|달인물|엑기스)$/, pick: ['칡즙', '흑염소', '녹즙', '호박즙', '노니'] }
  ];
  /* 같은 것을 다르게 적으시는 경우 — 'omega3'·'오메가-3'·'비타민 디'·'밀크시슬'. SUPP 의 pat 은 서버와 같아야 해서
     고치지 않고, 적으신 말을 SUPP 가 알아듣는 말로 한 번 더 바꿔 본다 (find69 가 원래 말·띄어쓰기 뺀 말·바꾼 말로 모두 찾는다) */
  var ALIAS69 = [
    [/omega\s*-?\s*3|오메가\s*-?\s*(3|쓰리)|오매가|fish\s*oil|피[쉬시]\s*오일/i, '오메가3'],
    [/vitamin\s*-?\s*d|비타민\s*디|vit\.?\s*d/i, '비타민D'],
    [/probiotic|비피더스|bifido/i, '유산균'],
    [/milk\s*thistle|밀크\s*[씨시]\s*슬/i, '밀크씨슬'],
    [/curcumin|turmeric|쿠르쿠민/i, '커큐민'],
    [/isoflavone|이소\s*플라본/i, '이소플라본'],
    [/mushroom|아가리쿠스|꽃송이|노루\s*궁뎅이|잎새\s*버섯/i, '버섯'],
    [/multi\s*-?\s*vitamin|멀티\s*비타민|종합\s*비타민/i, '종합비타민'],
    [/grapefruit/i, '자몽'],
    [/st\.?\s*john|세인트\s*존/i, '세인트존스'],
    [/melatonin|멜라\s*토닌/i, '멜라토닌'],
    [/red\s*ginseng|정관장|홍\s+삼/i, '홍삼'],
    [/ginseng|수삼|백삼|인\s+삼|흑삼|장뇌삼|산양삼|(^|[^재])미삼|진세노|ginsenoside/i, '인삼']
  ];
  /* 식사 카드·정보 화면 — [파일, 화면 이름, 아이콘]. 69 에서 가면 ‹ 가 69 로 돌아오게 ?from= 을 붙인다 (app.js) */
  var SCR69 = {
    '09': ['09-food-supplement.html', '음식·건강기능식품', '🥗'],
    '34': ['34-detail-arthralgia.html', '관절통·근육통', '🦴'],
    '35': ['35-detail-hotflash.html', '안면홍조·열감', '🔥'],
    '46': ['46-detail-sleep.html', '수면장애', '🌙'],
    '47': ['47-detail-anxiety.html', '불안·재발 걱정', '💭'],
    '60': ['60-food-nausea.html', '메스꺼울 때 식사', '🤢'],
    '61': ['61-food-appetite.html', '입맛 없을 때 식사', '🍽️'],
    '62': ['62-food-mucositis.html', '입안이 헐었을 때 식사', '😷'],
    '63': ['63-food-diarrhea.html', '설사할 때 식사', '🚽'],
    '64': ['64-food-constipation.html', '변비일 때 식사', '🚻'],
    '65': ['65-food-taste.html', '맛이 이상할 때 식사', '👅'],
    '66': ['66-food-immune.html', '면역이 약한 시기 식사', '🍳'],
    '67': ['67-food-bone.html', '뼈 건강 식사', '🥛'],
    '68': ['68-food-weight.html', '살이 찔 때 식사', '⚖️'],
    '70': ['70-med-effects.html', '내 약과 부작용', '🗂️'],
    '71': ['71-my-drug-cautions.html', '내 약 주의사항', '💊'],
    '94': ['94-food-soy.html', '콩·두부·된장', '🫛'],
    '95': ['95-food-alcohol.html', '술, 어떻게 할까요', '🍶']
  };
  /* AI 일반 정보(서버 mode:'lookup')의 종류 이름. 모르는 값은 'unknown' 으로 본다 */
  var KIND69 = { supplement: '건강기능식품', herbal: '한약·약초', food: '음식', drug: '약', other: '', unknown: '' };
  /* AI 가 '먹어도 괜찮아요/안 돼요'처럼 판정하는 문장을 쓰면 그 줄은 보여 주지 않는다 (서버가 먼저 막지만, 한 번 더) */
  var VERDICT69 = /(먹어도|드셔도|복용해도|섭취해도)\s*(괜찮아요|괜찮습니다|됩니다|돼요|좋아요|좋습니다)(?!\s*[?？])|안전해요|안전합니다|(먹으면|드시면|복용하면|섭취하면)\s*안\s*(돼요|됩니다)/;

  /* 69 는 문장이 아니라 '제품 이름'을 받는 칸이다. 두 낱말·12자 안이고 물음표와 서술어 꼬리가 없으면
     증상 낱말이 들어 있어도 이름으로 본다. 마음 위기(crisis)는 짧아도 절대 건너뛰지 않는다. */
  var LOOKUP_SENTENCE_TAIL69 = /(요|습니다|습니까|까요|나요|네요|죠|는데|했어|했어요|같아|같아요|돼|돼요|되나요|아파|아파요|아프다|아픈데|났어|났어요|해|해요|싶어|싶어요)[.!~…]*$/;
  var LOOKUP_ALWAYS_RED69 = /^(가슴\s*통증|흉통|호흡\s*곤란|토혈|의식\s*저하)$/;
  function lookupNameOnly69(q) {
    var s = String(q || '').replace(/^\s+|\s+$/g, '').replace(/\s+/g, ' ');
    if (!s || /[?？]/.test(s) || s.replace(/\s/g, '').length > 12) return false;
    if (LOOKUP_ALWAYS_RED69.test(s)) return false;
    if (s.split(' ').length > 2 || LOOKUP_SENTENCE_TAIL69.test(s)) return false;
    return true;
  }

  function norm69(s) { return String(s || '').replace(/[\s\-·.,\/()]+/g, ''); }
  function variants69(q) {
    var out = [q, norm69(q)];
    ALIAS69.forEach(function (a) { if (a[0].test(q)) out.push(a[1]); });
    return out;
  }
  function hits69(list, vs) {
    return list.filter(function (e) {
      var i;
      if (e.not) for (i = 0; i < vs.length; i++) if (e.not.test(vs[i])) return false;   /* 음식 낱말이 든 음식 아닌 이름 (FOOD69 주석) */
      for (i = 0; i < vs.length; i++) if (e.pat.test(vs[i])) return true;
      return false;
    });
  }
  /* 찾는 순서: MORE69(구체적인 한약·제품) → 음식(제품 꼴이 아니면) → SUPP 12종 → 음식(제품 꼴이어도) → 약(druginfo) → 너무 넓은 말 */
  function find69(q) {
    var vs = variants69(q), form = FORM69.test(q);
    var more = hits69(MORE69, vs), core = hits69(SUPP, vs);
    var all = more.concat(core);
    if (more.length) return { type: 'supp', e: more[0], others: all.slice(1) };
    /* 넓은 음식 묶음(weak — 과일·채소·단 음료…)은 SUPP 에 걸린 게 있으면 양보한다: '자몽주스'는 자몽, '생선기름'은 오메가3, '인삼 사탕'은 인삼 */
    if (!form) { var f = hits69(FOOD69, vs); if (f.length && !(f[0].weak && core.length)) return { type: 'food', e: f[0] }; }
    if (core.length) return { type: 'supp', e: core[0], others: all.slice(1) };
    if (form) { var f2 = hits69(FOOD69, vs); if (f2.length) return { type: 'food', e: f2[0] }; }
    if (window.TDRUG && window.TDRUG.match) {
      var m = null;
      try { m = window.TDRUG.match(q); } catch (eD) { m = null; }
      if (m && !m.unknown) return { type: 'drug', m: m };
    }
    var n = norm69(q);
    for (var g = 0; g < GENERIC69.length; g++) if (GENERIC69[g].pat.test(n)) return { type: 'generic', g: GENERIC69[g] };
    return null;
  }
  /* 받침 따라 '과/와'·'을/를' — 한글이 아니면 둘 다 적는다 */
  function josa69(w, a, b) {
    var s = String(w || ''), c = s.charCodeAt(s.length - 1);
    if (c >= 0xAC00 && c <= 0xD7A3) return ((c - 0xAC00) % 28) ? a : b;
    return a + '(' + b + ')';
  }

  function page69() {
    var inp = $('input.input');
    var chips = $('[data-role="popular"]') || $('.chips');
    var result = $('[data-role="result"]') || $$('.card').filter(function (c) { return c.getAttribute('style') && c.getAttribute('style').indexOf('--warn') > -1; })[0];
    if (!inp || !result) return;
    result.style.display = 'none';                                   /* 입력 전에는 예시(홍삼)를 보이지 않는다 */
    function R(r) { return $('[data-role="' + r + '"]', result); }
    var nameEl = $('.strong', result), pill = $('.pill', result), subEl = R('sub'),
      known = R('known') || $$('p.small', result)[0], ask = R('ask') || $$('.card p.small', result).slice(-1)[0],
      knownLabel = R('known-label'), pointsEl = R('points'), careWrap = R('care-wrap'), careEl = R('care'),
      linksWrap = R('links-wrap'), linksEl = R('links'), alsoWrap = R('also-wrap'), alsoLabel = R('also-label'), alsoEl = R('also'),
      aiNote = R('ai-note'), aiBtn = R('ai-btn'), noInfo = R('noinfo'), srcEl = R('src');
    /* 이름 칸에 몸의 이상을 적으신 경우 (2026-09-28 검토) — '홍삼 먹고 숨이 차요'처럼 적으셔도 여태 홍삼 카드만 떴고,
       목록에 없는 말이면 서버가 위험신호라며 일반 정보를 만들지 않아(error:'red') '불러오지 못했어요'·'다시 찾아보기'만 보였다.
       상담과 같은 기준(chat.js 의 window.TDRED — 이 화면에도 실려 있다)으로 판정해, 결과 카드 맨 위에 상담과 같은 안내 글과
       연결 단추를 붙인다. 기준과 글은 chat.js 것을 그대로 쓰고 여기서 새로 만들지 않는다. 위험신호가 있으면 AI 일반 정보는 묻지 않는다. */
    var RED69 = { crisis: ['11-crisis.html', '📞 마음 상담 전화 연결', 'btn-primary'],
      emergency: ['48-emergency.html', '🚨 119 연결·위험신호 보기', 'btn-danger'],
      today: ['48-emergency.html', '📞 병원 연락처·위험신호 보기', 'btn-primary'] };
    var redBox = el('<div class="banner banner--danger s69-ai" data-role="red" role="alert" hidden><span class="b-ic">🚨</span>'
      + '<div class="grow"><div class="small" data-role="red-text"></div><a class="btn btn-sm btn-block s69-redlink" data-role="red-link"></a></div></div>');
    if (result.firstElementChild) result.insertBefore(redBox, result.firstElementChild.nextSibling);
    var saveBtn = $$('a.btn', result).filter(function (a) { return (a.getAttribute('href') || '').indexOf('10-consult') > -1; })[0] || null;
    var copyBtn = $$('a.btn', result).filter(function (a) { return a.textContent.indexOf('복사') > -1; })[0] || null;
    var cur = '', seq = 0;
    /* 이 화면이 ?from=(예: 07-chat.html)으로 열렸으면 식사 카드에 다녀와도 ‹ 가 그리로 가게 함께 적어 둔다 —
       식사 카드의 ‹ 는 '69-supplement-check.html' 로만 돌아오므로 from 이 사라져 ‹ 가 09 로 갔다 (2026-09-28 검토) */
    var FROM_OK = /^[0-9A-Za-z._-]+\.html$/;
    var from69 = (function () {
      var m = /[?&]from=([^&#]*)/.exec(location.search || ''), v = '';
      try { v = m ? decodeURIComponent(m[1]) : ''; } catch (eF) { v = ''; }
      return FROM_OK.test(v) && v !== PAGE ? v : '';
    })();
    function saveBack() {
      try { sessionStorage.setItem('todak_69_back', JSON.stringify({ q: cur, t: Date.now(), from: from69 })); } catch (eS) {}
    }
    function redLevel(q) {
      var lv = null;
      try { var X = window.TDRED; lv = X && X.detect ? X.detect(q) : null; } catch (eR) { lv = null; }
      return lv && lv !== 'crisis' && lookupNameOnly69(q) ? null : lv;
    }
    function setRed(lv, q) {
      var L = RED69[lv], t = '';
      if (!L) return;
      try { t = window.TDRED && window.TDRED.banner ? window.TDRED.banner(lv, q) : ''; } catch (eB) { t = ''; }
      $('[data-role="red-text"]', redBox).textContent = String(t || '').replace(/^🚨\s*/, '')
        || '지금 몸이 불편하시면 치료받는 병원에 먼저 연락하시고, 급하면 119에 연락하세요.';
      var a = $('[data-role="red-link"]', redBox);
      a.className = 'btn btn-sm btn-block s69-redlink ' + L[2];
      a.href = L[0] + '?from=69-supplement-check.html';
      a.textContent = L[1];
      redBox.hidden = false;
    }
    $('[data-role="red-link"]', redBox).addEventListener('click', saveBack);     /* 다녀오시면(‹) 보던 결과가 그대로 */

    function reset() {
      [pointsEl, careWrap, linksWrap, alsoWrap, aiNote, aiBtn, noInfo, srcEl, redBox].forEach(function (x) { if (x) x.hidden = true; });
      result.removeAttribute('aria-busy');
      if (knownLabel) knownLabel.textContent = '알려진 내용';
      if (aiBtn) { aiBtn.style.opacity = ''; aiBtn.style.pointerEvents = ''; }
    }
    function head(name, pillCls, pillText, sub, border) {
      result.style.display = '';
      result.style.borderColor = border;
      if (nameEl) nameEl.textContent = name;
      if (pill) { pill.className = pillCls; pill.textContent = pillText; }
      if (subEl) subEl.textContent = sub;
    }
    function fill(ul, arr) {
      if (!ul) return;
      ul.innerHTML = '';
      (arr || []).forEach(function (t) { var li = document.createElement('li'); li.textContent = t; ul.appendChild(li); });
    }
    function setCare(arr) { if (careWrap && arr && arr.length) { fill(careEl, arr); careWrap.hidden = false; } }
    function setAsk(t) { if (ask) ask.textContent = '“' + t + '”'; }
    function setSrc(t) { if (srcEl && t) { srcEl.textContent = t; srcEl.hidden = false; } }
    /* 식사 카드로 가는 줄 — 다녀오시면(‹) 보던 결과가 그대로 보이게 찾던 말을 잠깐 적어 둔다 (30분, 이 창 안에서만) */
    function setLinks(keys) {
      if (!linksWrap || !linksEl) return;
      linksEl.innerHTML = '';
      (keys || []).forEach(function (k) {
        var s = SCR69[k];
        if (!s) return;
        var a = el('<a class="listitem s69-link"><span class="li-ic"></span><div class="li-body"><div class="li-title"></div></div><span class="li-chev">›</span></a>');
        a.href = s[0] + '?from=69-supplement-check.html';
        $('.li-ic', a).textContent = s[2];
        $('.li-title', a).textContent = s[1];
        a.addEventListener('click', saveBack);
        linksEl.appendChild(a);
      });
      if (linksEl.children.length) linksWrap.hidden = false;
    }
    /* 함께 찾은 것·같이 찾아볼 것 — 누르면 그 이름으로 다시 찾는다 */
    function setAlso(label, names) {
      if (!alsoWrap || !alsoEl) return;
      alsoEl.innerHTML = '';
      var seen = {};
      (names || []).forEach(function (n) {
        if (!n || seen[n] || n === cur) return;
        seen[n] = 1;
        var c = document.createElement('span');
        c.className = 'chip';
        c.setAttribute('role', 'button');
        c.setAttribute('tabindex', '0');
        c.textContent = n;
        function go(e) { if (e) e.preventDefault(); inp.value = n; show(n, { auto: true, scroll: true }); }
        c.addEventListener('click', go);
        c.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') go(e); });
        alsoEl.appendChild(c);
      });
      if (alsoEl.children.length) { if (alsoLabel) alsoLabel.textContent = label; alsoWrap.hidden = false; }
    }
    function scrollToResult() {
      try { result.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (eY) { try { result.scrollIntoView(); } catch (eY2) {} }
    }

    function showEntry(e, others) {
      var x = EXTRA69[e.name] || {};
      var warn = e.lv === 'warn';
      head(e.name, 'pill ' + (warn ? 'pill--warn' : 'pill--brand'), e.pill || (warn ? '! 꼭 물어보고 드세요' : '물어보고 드시면 좋아요'),
        e.kind === 'food' ? '건강기능식품이 아닌 일반 식품이에요' : '사람마다 상황이 달라요', warn ? 'var(--warn)' : 'var(--secondary)');
      if (known) known.textContent = e.known;
      setCare(e.care || x.care);
      setLinks(e.links || x.links);
      var names = (others || []).map(function (o) { return o.name; });
      if (names.length) setAlso('이 이름도 함께 찾았어요', names);
      else setAlso('같이 찾아볼 만한 것', x.also);
      setAsk(e.ask);
      setSrc('이 내용의 자료: ' + (e.src || x.src || '식품의약품안전처 · NCCIH'));
    }
    function showFood(e, q) {
      var warn = e.lv === 'warn';
      head(e.name, 'pill ' + (warn ? 'pill--warn' : 'pill--brand'), warn ? '! 음식이지만 확인이 필요해요' : '🍽️ 이건 음식이에요',
        warn ? '치료 중 조심할 점이 있는 음식이에요' : '건강기능식품·한약이 아니라 평소 드시는 음식이에요', warn ? 'var(--warn)' : 'var(--secondary)');
      if (knownLabel) knownLabel.textContent = '토닥 식사 카드에 나온 내용';
      if (known) known.textContent = e.note + (!e.juice && JUICE69.test(q) ? ' ' + JUICE69_NOTE : '');
      setLinks(e.links);
      setAlso('같이 찾아볼 만한 것', e.also);
      setAsk('치료 중에 ' + q + josa69(q, '을', '를') + ' 평소처럼 ' + (DRINK69.test(q) ? '마셔도' : '먹어도') + ' 될까요? 지금 제 치료에서 조심할 음식이 있을까요?');
      setSrc('이 내용의 자료: ' + (e.src || '토닥 식사 카드'));
    }
    function showDrug(q, m) {
      head(q, 'pill pill--info', '💊 이건 약이에요', m.cat ? '분류: ' + m.cat : '토닥 약 목록에 있는 약이에요', 'var(--secondary)');
      if (knownLabel) knownLabel.textContent = '이 화면에서 찾는 것';
      if (known) known.textContent = '건강기능식품·한약·음식이에요. 약의 부작용과 주의는 아래 칸에서 보실 수 있어요. 이 약과 함께 드시려는 건강기능식품이 있으면 그 이름을 적어 주세요.';
      setLinks(['70', '71']);
      setAsk('제가 먹는 ' + q + josa69(q, '과', '와') + ' 같이 먹으면 안 되는 음식이나 건강기능식품이 있을까요?');
    }
    function showGeneric(q, g) {
      head(q, 'pill pill--brand', '조금 더 알려 주세요', '어떤 제품인지 골라 주세요', 'var(--outline)');
      if (known) known.textContent = '‘' + q + '’만으로는 어떤 제품인지 알기 어려워요. 통에 적힌 이름을 적어 주시거나 아래에서 골라 주세요.';
      setAlso('이 중에 있나요?', g.pick);
      setAsk(q + josa69(q, '을', '를') + ' 먹으려는데 지금 제가 쓰는 약과 같이 먹어도 될까요?');
    }
    /* 위험신호만 있고 찾은 이름이 없을 때 (안내 글·단추는 setRed 가 위에 붙인다) — '목록에 없어요 · 성분표를 들고…'와
       '‘먹고 나서 피를 토했어요’를 먹으려는데…' 같은 여쭤볼 말이 붙지 않게 따로 적는다 */
    function showRedOnly(q, lv) {
      head(q, 'pill pill--warn', '위 안내를 먼저 봐 주세요', '', 'var(--danger)');
      if (knownLabel) knownLabel.textContent = '위 안내가 왜 보이나요';
      if (known) known.textContent = '적어 주신 말에 몸이나 마음이 불편하다는 말이 있었어요. 드시려는 것이 있으면 이름만 따로 적어 주세요.';
      setAsk(lv === 'crisis' ? '요즘 마음이 많이 힘들어요. 어디서 도움을 받을 수 있을까요?' : '이런 증상이 생기면 언제 병원에 연락해야 할까요?');
    }
    /* 목록에 없을 때 — why: ''(아직 AI 에 묻지 않음) · 'fail' · 'offline' · 'limit' · 'blocked'(서버가 일반 정보를 만들지 않는 이름) */
    function showUnknown(q, why) {
      head(q, 'pill pill--brand', '목록에 없어요', '토닥 자료에서 찾지 못했어요', 'var(--outline)');
      var base = '토닥 목록에서 확인하지 못한 제품이에요. 성분표를 들고 담당 의사나 약사에게 여쭤보시는 게 가장 정확해요.';
      var lead = why === 'fail' ? '지금은 AI 일반 정보를 불러오지 못했어요. '
        : why === 'offline' ? '인터넷에 연결되지 않아 AI 일반 정보를 찾지 못했어요. '
        : why === 'limit' ? '오늘은 AI 확인을 많이 쓰셨어요. 내일 다시 찾아 주세요. ' : '';
      if (known) known.textContent = lead + base;
      if (aiBtn && why !== 'limit' && why !== 'blocked' && CFG.fnBase) {
        aiBtn.textContent = why ? '🔄 AI 상담으로 다시 찾아보기' : '🔎 AI 상담으로 일반 정보 찾아보기';
        aiBtn.hidden = false;
      }
      if (noInfo) { noInfo.href = '72-no-info.html?q=' + encodeURIComponent(q); noInfo.hidden = false; }
      setAsk(q + josa69(q, '을', '를') + ' 먹으려는데 지금 제가 쓰는 약과 같이 먹어도 될까요?');
    }
    function showLoading(q) {
      head(q, 'pill pill--info', 'AI가 찾는 중…', '잠시만 기다려 주세요', 'var(--outline)');
      result.setAttribute('aria-busy', 'true');
      if (known) known.textContent = 'AI가 ‘' + q + '’에 대한 일반 정보를 정리하고 있어요. 10초쯤 걸릴 수 있어요.';
      setAsk(q + josa69(q, '을', '를') + ' 먹으려는데 지금 제가 쓰는 약과 같이 먹어도 될까요?');
    }
    function showAI(q, d) {
      var kind = KIND69[d.kind] || '';
      head(d.item || q, 'pill pill--info', 'AI가 정리한 일반 정보', (kind ? kind + ' · ' : '') + '토닥 자료에 없는 일반 정보예요', 'var(--secondary)');
      if (aiNote) aiNote.hidden = false;
      if (knownLabel) knownLabel.textContent = '알려진 내용 (AI 정리)';
      if (known) known.textContent = d.summary || '요약을 받지 못했어요. 아래 내용을 참고해 주세요.';
      if (pointsEl && d.points.length) { fill(pointsEl, d.points); pointsEl.hidden = false; }
      setCare(d.cautions);
      setLinks(d.kind === 'food' ? ['09'] : d.kind === 'drug' ? ['71'] : []);
      if (noInfo) { noInfo.href = '72-no-info.html?q=' + encodeURIComponent(q); noInfo.hidden = false; }
      setAsk(d.ask || (q + josa69(q, '을', '를') + ' 먹으려는데 지금 제가 쓰는 약과 같이 먹어도 될까요?'));
      setSrc('AI가 정리한 일반 정보예요 — 토닥이 검토한 자료가 아니에요. 드시기 전에 꼭 담당 의사·약사에게 확인해 주세요.');
    }

    /* ── 토닥 목록에 없는 것 — 서버(chat 함수)에 이름 한 줄만 보내 AI 일반 정보를 받는다 (C4 · 2026-09-28)
         · 보내는 것은 { mode:'lookup', item: 적으신 이름 } 뿐 — 약 목록·기록·프로필은 보내지 않는다. 인증 머리글은 상담(chat.js)과 같다.
         · 받은 글은 textContent 로만 넣는다(글자 그대로). 판정하는 줄(VERDICT69)은 뺀다.
         · 이 창에서 한 번 받은 것은 sessionStorage 에 두어 같은 이름을 거듭 묻지 않는다 (실패는 두지 않는다).
         · 글자를 칠 때마다 묻지 않는다 — 'AI 상담으로 찾아보기'를 누르셨을 때와 상담(07) 카드로 넘어오셨을 때만.
           키보드 검색·칩만으로는 보내지 않는다 — 동의서의 'AI 상담 기능을 쓰지 않으시면 OpenAI로 보내지 않아요'와 맞춘다 (리드 2026-09-28) */
    var LK69 = 'todak_lookup69:';
    function lkKey(q) { return LK69 + norm69(q).toLowerCase(); }
    function cached(q) {
      try { var c = JSON.parse(sessionStorage.getItem(lkKey(q)) || 'null'); return c && typeof c.summary === 'string' ? c : null; } catch (e) { return null; }
    }
    function cleanAI(d, q) {
      if (!d || d.ok !== true) return null;
      /* 글자로만 넣으므로 태그가 실행되지는 않지만, '<b>'·'**' 같은 표시가 그대로 보이지 않게 걷어 낸다 */
      function s(v, n) {
        v = String(v == null ? '' : v).replace(/<[^>]{0,40}>/g, '').replace(/\*\*|__|`/g, '').replace(/^[\s\-•·*]+/, '').replace(/\s+/g, ' ').trim();
        return v.length > n ? v.slice(0, n) + '…' : v;
      }
      function arr(v, n) {
        return (Object.prototype.toString.call(v) === '[object Array]' ? v : []).map(function (x) { return s(x, n); })
          .filter(function (x) { return x && !VERDICT69.test(x); }).slice(0, 4);
      }
      var out = { kind: KIND69.hasOwnProperty(d.kind) ? d.kind : 'unknown', item: s(d.item, 40) || q,
        summary: s(d.summary, 260), points: arr(d.points, 160), cautions: arr(d.cautions, 160), ask: s(d.ask, 140) };
      if (VERDICT69.test(out.summary)) out.summary = '';
      if (VERDICT69.test(out.ask)) out.ask = '';
      if (!out.summary && !out.points.length && !out.cautions.length) return null;
      return out;
    }
    function lookup(q) {
      var my = ++seq;
      var c = cached(q);
      if (c) { reset(); showAI(q, c); return; }
      if (!CFG.fnBase || typeof fetch !== 'function') { reset(); showUnknown(q, 'fail'); return; }
      if (navigator.onLine === false) { reset(); showUnknown(q, 'offline'); return; }
      reset(); showLoading(q);
      sessGet(function (ses, err) {
        if (my !== seq) return;
        if (!ses && err) { reset(); showUnknown(q, 'offline'); return; }
        var done = false;
        var timer = setTimeout(function () { fin(null); }, 25000);
        function fin(d, why) {
          if (done) return;
          done = true;
          clearTimeout(timer);
          if (my !== seq) return;                                   /* 그사이 다른 이름을 찾으셨으면 버린다 */
          if (d && d.ok !== true && d.red && RED69[d.red]) {
            reset();
            /* 예전 서버가 짧은 제품 이름을 red 로 돌려준 경우에도 위험신호 안내로 오인하지 않는다. */
            if (d.red !== 'crisis' && lookupNameOnly69(q)) { showUnknown(q, 'blocked'); return; }
            showRedOnly(q, d.red); setRed(d.red, q); return;
          }
          var out = cleanAI(d, q);
          reset();
          if (!out) { showUnknown(q, why || 'fail'); return; }
          try { sessionStorage.setItem(lkKey(q), JSON.stringify(out)); } catch (eS) {}
          showAI(q, out);
        }
        try {
          fetch(CFG.fnBase + '/chat', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ' + ((ses && ses.access_token) || CFG.anonKey),
              'apikey': CFG.anonKey
            },
            body: JSON.stringify({ mode: 'lookup', item: q })
          }).then(function (res) {
            if (!res || res.status === 429) { fin(null, res ? 'limit' : 'fail'); return; }
            if (!res.ok) { fin(null); return; }
            return res.json().then(function (d) { fin(d); }, function () { fin(null); });
          }, function () { fin(null); });
        } catch (eF) { fin(null); }
      });
    }

    /* opt.auto — 목록에 없으면 바로 AI 에 묻는다 (칩·키보드 검색·?q=). 글자를 치는 중에는 묻지 않는다 */
    function show(q, opt) {
      opt = opt || {};
      q = String(q || '').replace(/\s+/g, ' ').trim().slice(0, 40);
      seq++;                                                        /* 오가는 AI 답이 있으면 버린다 */
      cur = q;
      reset();
      if (!q) { result.style.display = 'none'; return; }
      var lv = redLevel(q);
      var hit = lv === 'crisis' ? null : find69(q);    /* 마음 위기 말('죽고 싶어요')에 '죽' 음식 카드가 붙지 않게 */
      if (hit && hit.type === 'supp') showEntry(hit.e, hit.others);
      else if (hit && hit.type === 'food') showFood(hit.e, q);
      else if (hit && hit.type === 'drug') showDrug(q, hit.m);
      else if (hit && hit.type === 'generic') showGeneric(q, hit.g);
      /* '경'처럼 치는 중인 한 글자에 '목록에 없어요'를 띄우지 않는다 — 다만 '쑥'처럼 한 글자 이름을 적고 검색(Enter)을 누르시면 찾는다
         (여태는 검색을 눌러도 아무것도 뜨지 않았다 · 2026-09-28 검토) */
      else if (norm69(q).length < 2 && !opt.auto) { result.style.display = 'none'; return; }
      else if (lv) showRedOnly(q, lv);
      else if (cached(q)) showAI(q, cached(q));
      else if (opt.ai) lookup(q);   /* 저절로 AI 에 묻는 것은 상담에서 넘어왔을 때뿐 — 그 밖에는 'AI 상담으로 찾아보기' 단추를 누르셔야 보낸다 */
      else showUnknown(q, '');
      if (lv) setRed(lv, q);
      if (opt.scroll) scrollToResult();
    }

    var timer = null;
    inp.addEventListener('input', function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        /* 글자가 그대로면 다시 그리지 않는다 — 한글 자판은 검색(Enter)을 누른 뒤에도 글자를 확정하는 input 을 한 번 더 보내곤 해서,
           AI 가 찾는 중이던 것이 버려지고 '목록에 없어요'로 되돌아갔다 (2026-09-28 검토) */
        if (cur && String(inp.value || '').replace(/\s+/g, ' ').trim().slice(0, 40) === cur) return;
        show(inp.value);
      }, 250);
    });
    /* 키보드의 '검색'(Enter) — 찾은 것처럼. 자판을 내려 결과가 가리지 않게 한다 */
    inp.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' || e.isComposing) return;
      e.preventDefault();
      clearTimeout(timer);
      show(inp.value, { auto: true });
      try { inp.blur(); } catch (eB) {}
    });
    /* 72(성분표로 여쭤보는 방법)에 다녀오셔도(‹ 는 69 로 온다) 보던 결과가 남게 */
    if (noInfo) noInfo.addEventListener('click', saveBack);
    if (aiBtn) aiBtn.addEventListener('click', function (e) {
      e.preventDefault();
      if (!cur || aiBtn.style.pointerEvents === 'none') return;
      aiBtn.style.opacity = '.65'; aiBtn.style.pointerEvents = 'none';
      lookup(cur);
    });
    if (chips) $$('.chip', chips).forEach(function (c) {
      if (c.tagName === 'A') return;
      c.classList.remove('chip--on'); c.style.cursor = 'pointer';
      c.addEventListener('click', function (e) {
        e.preventDefault();
        var t = c.textContent.trim();
        if (t.indexOf('＋') === 0) { inp.focus(); return; }
        $$('.chip', chips).forEach(function (o) { o.classList.remove('chip--on'); }); c.classList.add('chip--on');
        inp.value = t; show(t, { auto: true, scroll: true });
      });
    });
    if (saveBtn) saveBtn.addEventListener('click', function (e) {
      e.preventDefault();
      /* 질문 문장은 증상 칩이 아니라 '따로 넣은 질문'으로 저장한다 → 10·28·77 에 그대로 나온다 */
      var q = ask ? ask.textContent.replace(/^“|”$/g, '') : '';
      if (!T.vq) return toast('저장하지 못했어요.');
      T.vq.toast(T.vq.add(q));
    });
    if (copyBtn) copyBtn.addEventListener('click', function (e) {
      e.preventDefault();
      var q = ask ? ask.textContent : '';
      if (navigator.clipboard && q) navigator.clipboard.writeText(q).then(function () { toast('복사했어요'); }, function () { toast('복사하지 못했어요'); });
    });

    /* ── 들어올 때 — ?q=이름 (AI 상담 카드 등, C3) 이면 그 이름을 칸에 넣고 바로 찾는다. ?from= 은 app.js 가 읽는다(뒤로가기).
         ?q= 가 없고 방금 이 화면에서 식사 카드로 다녀오신 거면 보던 결과를 되살린다 (AI 답은 이 창의 저장본으로 — 다시 묻지 않는다) */
    /* 스크립트가 다 실린 뒤에 찾는다 — 위험신호 판정(TDRED)은 이 파일 다음에 실리는 chat.js 에 있다 (2026-09-28 검토) */
    function start() {
      var q0 = '', auto0 = false;
      try { q0 = qsParam('q') || ''; } catch (eQ) { q0 = ''; }          /* 깨진 %xx 주소도 화면을 멈추지 않게 */
      q0 = q0.replace(/\s+/g, ' ').trim().slice(0, 40);
      auto0 = !!q0;
      try {
        var back = JSON.parse(sessionStorage.getItem('todak_69_back') || 'null');
        sessionStorage.removeItem('todak_69_back');
        if (!q0 && back && back.q && Date.now() - back.t < 30 * 60000) {
          q0 = String(back.q).slice(0, 40);
          /* 상담(07)에서 왔다가 식사 카드에 다녀오셨으면 ‹ 는 다시 상담으로 (app.js·native.js 는 이 href 를 누른다) */
          if (!from69 && back.from && FROM_OK.test(back.from) && back.from !== PAGE) {
            from69 = back.from;
            $$('.appbar a.back').forEach(function (b) { b.setAttribute('href', back.from); });
          }
        }
      } catch (eR) {}
      /* 상담(07)의 카드로 넘어오셨으면 이미 AI 상담을 쓰시는 중이라 바로 찾아 드린다 */
      if (q0) { inp.value = q0; show(q0, { auto: auto0, ai: auto0 && /^07-chat\.html/.test(from69 || '') }); }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
    /* 뒤로가기로 이 화면이 기억된 채 돌아오면(bfcache) 다녀올 때 적어 둔 것이 남아, 30분 안에 새로 연 69 가 옛 이름을 되살렸다 */
    window.addEventListener('pageshow', function (e) {
      if (e && e.persisted) { try { sessionStorage.removeItem('todak_69_back'); } catch (eP) {} }
    });
  }

  /* ── 72 정보를 찾지 못했어요 — 69 의 칩에서 ?q=이름 으로 온다 (이름이 없으면 '이 제품') ──
     토닥은 약과 대조하지 않으므로 '지금 드시는 약과 대조했다'는 뜻의 문장은 쓰지 않는다. */
  function josaEul(w) {
    var c = String(w || '').charCodeAt(String(w || '').length - 1);
    if (c >= 0xAC00 && c <= 0xD7A3) return ((c - 0xAC00) % 28) ? '을' : '를';
    return '을(를)';
  }
  function page72() {
    var raw = '';
    try { raw = qsParam('q') || ''; } catch (e) { raw = ''; }       /* 깨진 %xx 주소도 화면을 멈추지 않게 */
    var q = raw.replace(/\s+/g, ' ').trim().slice(0, 40);
    var name = q || '이 제품';
    var head = $('.appbar-title'), sub = $('.appbar-sub');
    if (head && q) head.textContent = q;
    if (sub && q) sub.textContent = '확인 결과';
    $$('.q-name').forEach(function (b) { b.textContent = q ? '‘' + q + '’' : '이 제품'; });
    var askText = name + josaEul(name) + ' 먹어도 될지 궁금해요. 성분표를 가져왔는데 지금 제 치료에 괜찮을까요?';
    var askP = $('[data-role="ask"]');
    if (askP) askP.textContent = '“' + askText + '”';
    /* '진료 질문에 추가' — 이 문장을 진료 준비 질문으로 저장한다 (10·28·77 에 나온다) */
    var addBtn = $$('.content a.btn').filter(function (a) { return (a.getAttribute('href') || '') === '10-consult-questions.html'; })[0];
    if (addBtn) addBtn.addEventListener('click', function (e) {
      e.preventDefault();
      if (!T.vq) return toast('저장하지 못했어요.');
      T.vq.toast(T.vq.add(askText));
    });
  }

  /* ── 71 내 약 주의사항 — 지금 등록된 약 목록(다른 병원·약국에서 보여 드리기용)과 약별 안내로 가는 길.
     약별 음식 주의 자료는 아직 없으므로 약 이름을 지어내 보여 주지 않는다. ── */
  function page71() {
    var box = $('[data-role="my-meds"]');
    if (!box || !window.TDRUG) return;
    box.innerHTML = '';
    box.appendChild(el('<div class="small muted">등록하신 약을 불러오는 중이에요…</div>'));
    function fail() {
      box.innerHTML = '';
      box.appendChild(el('<div class="banner banner--info"><span class="b-ic">📶</span><div class="small">약 목록을 불러오지 못했어요. 잠시 후 다시 열어 주세요.</div></div>'));
    }
    uid(function (id) {
      Promise.all([
        sb.from('medications').select('id,name,dose,created_at').eq('active', true).order('created_at', { ascending: true }),
        sb.from('profiles').select('treatment').eq('id', id).maybeSingle()
      ]).then(function (res) {
        var rm = res[0], rp = res[1];
        if (rm.error) return fail();
        box.innerHTML = '';
        var meds = rm.data || [];
        var inj = ((rp.data && rp.data.treatment && rp.data.treatment.injections) || []).filter(function (n) { return n && n !== '없어요' && n !== '잘 모르겠어요'; });
        if (!meds.length && !inj.length) {
          box.appendChild(el('<div class="banner banner--info"><span class="b-ic">💡</span><div class="small"><b>아직 등록된 약이 없어요.</b> 아래 약 추가하기로 등록해 주세요.</div></div>'));
          box.appendChild(el('<a class="listitem" href="58-med-manual.html"><span class="li-ic">➕</span><div class="li-body"><div class="li-title">약 추가하기</div><div class="li-sub">이름으로 적거나 사진으로 등록할 수 있어요</div></div><span class="li-chev">›</span></a>'));
          return;
        }
        meds.forEach(function (m) {
          var info = window.TDRUG.match(m.name);
          var a = el('<a class="listitem"><span class="li-ic">💊</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span></a>');
          a.href = (info.cancer ? '74-med-effect-detail.html?m=' : '75-med-effect-none.html?m=') + encodeURIComponent(m.id);
          $('.li-title', a).textContent = m.name + (m.dose ? ' · ' + m.dose : '');
          $('.li-sub', a).textContent = info.cat || '목록에서 확인하지 못한 약';
          box.appendChild(a);
        });
        inj.forEach(function (n) {
          var info = window.TDRUG.match(n);
          var a = el('<a class="listitem"><span class="li-ic">💉</span><div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span></a>');
          a.href = (info.cancer ? '74-med-effect-detail.html?n=' : '75-med-effect-none.html?n=') + encodeURIComponent(n);
          $('.li-title', a).textContent = n;
          $('.li-sub', a).textContent = '병원에서 맞는 주사 치료' + (info.cat ? ' · ' + info.cat : '');
          box.appendChild(a);
        });
      }, fail);
    });
  }

  /* ── 90 답변 신고 — answer_reports 에 저장 ── */
  function page90() {
    var content = $('.content');
    var quoteCard = $$('.card--flat', content)[0], done = $$('.card--flat', content).filter(function (c) { return c.textContent.indexOf('접수되었어요') > -1; })[0];
    var sels = $$('.selectable[role="checkbox"]', content), ta = $('textarea', content), cta = $('.footer-actions .btn');
    if (done) done.style.display = 'none';
    var msgId = null, quoteDone = false;
    /* ── 보낼 수 없을 때는 눌리지 않게 ── 2026-09-28
       신고할 답변을 못 불러왔는데도 '신고하기'가 멀쩡히 눌리면, 눌러 봐야 안 된다는 것을 아신다.
       그래서 버튼을 '아직 못 눌러요' 모양으로 바꾸고 까닭을 버튼 바로 위에 한 줄로 적는다.
       (app.css 의 .btn[aria-disabled="true"] — 누르는 것 자체는 막지 않고 까닭을 다시 알려 주는
        것이 이 앱의 방식이다. 저장을 막는 자리는 아래 누름 처리에 그대로 있다.) */
    var ctaHint = null;
    function ctaGate(ok, why) {
      if (!cta) return;
      cta.setAttribute('aria-disabled', ok ? 'false' : 'true');
      var foot = cta.parentNode;
      if (!why) {
        if (ctaHint && ctaHint.parentNode) ctaHint.parentNode.removeChild(ctaHint);
        ctaHint = null;
        if (foot) foot.style.background = '';
        return;
      }
      if (!ctaHint) {
        ctaHint = document.createElement('div');
        ctaHint.className = 'tiny muted';
        ctaHint.setAttribute('role', 'status');
        ctaHint.style.cssText = 'margin-bottom:7px; text-align:center; line-height:1.5;';
        if (foot) foot.insertBefore(ctaHint, cta);
        /* 하단 띠의 바탕은 '높이의 26%' 지점에서야 불투명해진다(app.css). 한 줄이 늘어 띠가
           높아지면 그 투명한 구간이 이 글자까지 내려와 뒤 내용이 비쳐 겹쳐 보인다.
           그래서 이 상태에서만 흐려지는 구간을 위 여백(14px) 안으로 당긴다. */
        if (foot) foot.style.background = 'linear-gradient(180deg, rgba(252,248,249,0) 0px, var(--surface) 14px)';
      }
      ctaHint.textContent = why;
    }
    ctaGate(false, '신고할 답변을 불러오고 있어요.');
    /* 신고 대상: 상담 말풍선의 🚩신고(?mid=메시지id)로 왔으면 그 답변, 아니면 가장 최근 AI 답변 */
    var midM = /[?&]mid=(\d+)/.exec(location.search || '');
    var qm = sb.from('chat_messages').select('id,content,created_at').eq('role', 'assistant');
    qm = midM ? qm.eq('id', Number(midM[1])) : qm.order('created_at', { ascending: false });
    /* 못 불러왔을 때 시안 예시 답변('홍삼은 치료제와 겹칠…')과 시안 시각('오늘 오전 9:43')이
       '신고할 답변' 자리에 그대로 남아 있었다 — 내가 받지도 않은 답변을 신고하는 꼴이라 거짓이다.
       통신이 끊기면 약속이 거절되므로 받는 자리만으로는 한 번도 지워지지 않았다. (2026-09-27) */
    function paintQuote(m, failed) {
      quoteDone = true;
      if (!quoteCard) return;
      var p = $('p', quoteCard), t = $('.tiny', quoteCard);
      if (m) {
        msgId = m.id;
        if (p) p.textContent = '“' + m.content.slice(0, 160) + (m.content.length > 160 ? '…' : '') + '”';
        if (t) t.textContent = kdate(new Date(m.created_at));
        ctaGate(true, '');
      } else {
        if (p) p.textContent = failed ? '신고할 답변을 불러오지 못했어요. 연결을 확인한 뒤 다시 열어 주세요.'
          : '아직 신고할 AI 답변이 없어요.';
        if (t) t.textContent = '';
        ctaGate(false, failed ? '답변을 불러오지 못해 지금은 보낼 수 없어요.' : '신고할 AI 답변이 아직 없어요.');
      }
      /* 시안 가림막(data-demo)은 우리가 칠한 뒤에만 걷는다 — 칠하기 전에 걷으면 예시 답변이 드러난다 */
      if (p) p.removeAttribute('data-demo');
      if (t) t.removeAttribute('data-demo');
    }
    qm.limit(1).then(function (r) {
      var bad = !r || r.error;
      paintQuote(bad ? null : (r.data && r.data[0]), bad);
    }, function () { paintQuote(null, true); });
    /* 통신이 '끊기는' 것이 아니라 '멈추는' 경우에는 받는 자리도, 거절 자리도 불리지 않아
       '불러오고 있어요'가 끝나지 않았다. 8초까지 아무 소식이 없으면 못 불러온 것으로 적는다.
       뒤늦게 답이 오면 paintQuote 가 다시 칠하므로 스스로 낫는다. */
    setTimeout(function () { if (!quoteDone) paintQuote(null, true); }, 8000);
    /* 단일 선택 */
    function setOn(elx, on) { elx.classList[on ? 'add' : 'remove']('selectable--on'); elx.setAttribute('aria-checked', on ? 'true' : 'false'); var b = $('.s-box', elx); if (b) b.textContent = on ? '✓' : ''; }
    sels.forEach(function (elx) { setOn(elx, false); elx.style.cursor = 'pointer'; elx.addEventListener('click', function (e) { e.preventDefault(); sels.forEach(function (o) { setOn(o, o === elx); }); }); });
    if (cta) cta.addEventListener('click', function (e) {
      e.preventDefault();
      /* 접수된 뒤에는 같은 버튼이 '상담으로 돌아가기' — 다시 저장하지 않고 이동만 한다 */
      if (cta.__done) { location.replace('07-chat.html'); return; }
      if (cta.__busy) return;
      /* 답변을 못 불러왔는데도 보내면 대상 없는 신고가 접수되고 환자는 '접수됐어요'를 본다 —
         거짓이라 막는다. (2026-09-28) */
      if (!quoteDone) return toast('답변을 불러오는 중이에요. 잠시만 기다려 주세요.');
      if (!msgId) return toast('신고할 답변을 불러오지 못했어요. 연결을 확인한 뒤 다시 열어 주세요.');
      var picked = sels.filter(function (x) { return x.getAttribute('aria-checked') === 'true'; })[0];
      if (!picked) return toast('어떤 점이 문제였는지 하나 골라 주세요.');
      var reason = $('.s-title', picked) ? $('.s-title', picked).textContent.trim() : '기타';
      T.busy(cta, true, '보내는 중…');
      uid(function (id) {
        sb.from('answer_reports').insert({ user_id: id, message_id: msgId, reason: reason, note: (ta && ta.value.trim()) || null }).then(function (r) {
          T.busy(cta, false);
          if (r.error) return toast(koError(r.error));
          cta.__done = true;
          if (done) { done.style.display = ''; try { done.scrollIntoView({ block: 'center' }); } catch (e3) {} }
          cta.textContent = '상담으로 돌아가기';
          toast('신고가 접수되었어요.');
        }, function () { T.busy(cta, false); toast('연결이 원활하지 않아요. 다시 시도해 주세요.'); });
      });
    });
  }

  /* ── 19 앱 사용법 — 실제 화면 사진 5장 넘기기 (교수님 2026-09-30: 한 장짜리 → 5장) ──
     · '다음'·옆으로 밀기·방향키로 넘기고, 휴대폰 뒤로가기는 앞 장으로 간다(native.js 가 __todakBackStep 을 부른다).
     · 가입 직후(14 → 19)엔 끝·건너뛰기 모두 홈으로. 내 정보에서 다시 볼 때(?from=13-settings.html)는 그 화면으로
       돌아가고, 단추도 '시작하기' 대신 '확인', '건너뛰기' 대신 '닫기'로 쓴다.
     · 화면 사진은 폰 높이마다 칸 높이가 달라서, 사진 속 강조 칸(data-mid)이 칸 가운데 오도록 올려 붙인다. */
  function page19() {
    var slides = $$('[data-role=tut-slide]'), dots = $$('[data-role=tut-dots] i');
    var next = $('[data-role=tut-next]'), skip = $('[data-role=tut-skip]'), stage = $('[data-role=tut-stage]');
    if (!slides.length || !next || !stage) return;
    var mf = /[?&]from=([^&#]*)/.exec(location.search || ''), from = '';
    try { from = mf ? decodeURIComponent(mf[1]) : ''; } catch (e0) { from = ''; }
    if (!/^[0-9A-Za-z._-]+\.html$/.test(from) || from === PAGE) from = '';
    var done = from || '05-home.html', lastText = from ? '확인' : '시작하기';
    if (skip) { skip.setAttribute('href', done); if (from) skip.textContent = '닫기'; }
    var i = 0, n = slides.length;
    function place(root) {
      $$('.tut-shot img', root).forEach(function (im) {
        var box = im.parentNode, w = box.clientWidth, h = box.clientHeight;
        if (!w || !h) return;
        var k = w / 390, full = (parseFloat(im.getAttribute('data-h')) || 844) * k;
        var mid = (parseFloat(im.getAttribute('data-mid')) || 0) * k;
        im.style.top = (-Math.round(Math.max(0, Math.min(full - h, mid - h / 2)))) + 'px';
      });
    }
    function go(k) {
      if (k < 0 || k >= n) return false;
      slides[i].hidden = true; i = k; slides[i].hidden = false;
      dots.forEach(function (d, j) { d.className = j === i ? 'on' : ''; });
      next.textContent = i === n - 1 ? lastText : '다음';
      next.setAttribute('href', i === n - 1 ? done : '#');
      stage.scrollTop = 0;
      place(slides[i]);
      return true;
    }
    next.addEventListener('click', function (e) {
      if (i < n - 1) { e.preventDefault(); go(i + 1); }   /* 마지막 장은 링크 그대로 — 홈 또는 온 화면 */
    });
    var x0 = null, y0 = 0;
    stage.addEventListener('touchstart', function (e) {
      if (!e.touches || e.touches.length !== 1) { x0 = null; return; }
      x0 = e.touches[0].clientX; y0 = e.touches[0].clientY;
    }, { passive: true });
    stage.addEventListener('touchend', function (e) {
      if (x0 === null || !e.changedTouches || !e.changedTouches.length) return;
      var dx = e.changedTouches[0].clientX - x0, dy = e.changedTouches[0].clientY - y0;
      x0 = null;
      if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.5) go(i + (dx < 0 ? 1 : -1));
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight') go(i + 1);
      else if (e.key === 'ArrowLeft') go(i - 1);
    });
    var again = function () { place(slides[i]); };
    window.addEventListener('resize', again);
    if (window.ResizeObserver) { try { new window.ResizeObserver(again).observe(stage); } catch (eRo) {} }
    setTimeout(again, 700);   /* 웹앱은 켜진 직후 화면 높이를 한 번 더 맞춘다(native.js fitScreen) */
    window.__todakBackStep = function () { return go(i - 1); };
    go(0);
  }

  /* ── 분기 ── */
  if (PAGE === '70-med-effects.html') page70();
  else if (PAGE === '25-terms.html') page25();
  else if (PAGE === '26-help.html') page26();
  else if (PAGE === '69-supplement-check.html') page69();
  else if (PAGE === '71-my-drug-cautions.html') page71();
  else if (PAGE === '72-no-info.html') page72();
  else if (PAGE === '90-report-answer.html') page90();
  else if (PAGE === '74-med-effect-detail.html') page74();
  else if (PAGE === '75-med-effect-none.html') page75();
  else if (PAGE === '77-visit-report.html') page77();
  else if (PAGE === '28-note-archive.html') page28();
  else if (PAGE === '20-notifications.html') page20();
  else if (PAGE === '22-search.html') page22();
  else if (PAGE === '19-tutorial.html') page19();
})();
