/* 토닥 — 드래그로 고르는 시간 선택기
   안드로이드 기본 시계 다이얼 대신, 위아래로 밀어서 고르는 방식으로 바꾼다.
   기존 코드는 그대로 둔 채 input 의 .value 만 'HH:MM' 으로 유지하고,
   화면에 보이는 글자는 '오전 8:00' 처럼 읽기 쉬운 형태로 바꾼다. */
(function () {
  'use strict';
  var ITEM = 44;          /* 한 줄 높이 */
  var ROWS = 5;           /* 보이는 줄 수 (가운데가 선택된 값) */
  var PAD = (ROWS - 1) / 2 * ITEM;

  function two(n) { return (n < 10 ? '0' : '') + n; }

  function fmt(hhmm) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(hhmm || '');
    if (!m) return '';
    var h = +m[1], ampm = h < 12 ? '오전' : '오후';
    var h12 = h % 12; if (h12 === 0) h12 = 12;
    return ampm + ' ' + h12 + ':' + m[2];
  }

  function parse(hhmm) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(hhmm || '');
    var h = m ? +m[1] : 8, mi = m ? +m[2] : 0;
    return { pm: h >= 12 ? 1 : 0, h12: (h % 12) || 12, mi: mi };
  }

  var styled = false;
  function injectStyle() {
    if (styled) return; styled = true;
    var css = [
      '.tp-dim{position:fixed;inset:0;background:rgba(20,8,14,.45);z-index:9000;',
      '  display:flex;align-items:flex-end;justify-content:center;}',
      '.tp-sheet{width:100%;max-width:520px;background:var(--surface,#fff);',
      '  border-radius:22px 22px 0 0;padding:18px 16px calc(16px + env(safe-area-inset-bottom));',
      '  box-shadow:0 -8px 30px rgba(0,0,0,.18);}',
      '.tp-title{font-weight:800;font-size:17px;text-align:center;margin:2px 0 14px;}',
      '.tp-wrap{position:relative;display:flex;gap:6px;justify-content:center;',
      '  height:' + (ROWS * ITEM) + 'px;overflow:hidden;}',
      '.tp-band{position:absolute;left:8px;right:8px;top:' + (2 * ITEM) + 'px;height:' + ITEM + 'px;',
      '  background:var(--surface-2,#FBEFF4);border-radius:12px;pointer-events:none;}',
      '.tp-col{position:relative;z-index:1;overflow-y:auto;scroll-snap-type:y mandatory;',
      '  -webkit-overflow-scrolling:touch;scrollbar-width:none;text-align:center;}',
      '.tp-col::-webkit-scrollbar{display:none;}',
      '.tp-col.ampm{width:74px;} .tp-col.hh{width:64px;} .tp-col.mm{width:64px;}',
      '.tp-it{height:' + ITEM + 'px;line-height:' + ITEM + 'px;scroll-snap-align:center;',
      '  font-size:20px;font-weight:700;color:var(--on-surface-variant,#8a7480);}',
      '.tp-it.on{color:var(--primary-dark,#A82C58);font-size:22px;}',
      '.tp-colon{align-self:center;font-size:20px;font-weight:800;padding-bottom:2px;}',
      '.tp-acts{display:flex;gap:10px;margin-top:16px;}',
      '.tp-acts button{flex:1;border:0;border-radius:14px;padding:14px 0;font-size:16px;font-weight:800;}',
      '.tp-cancel{background:var(--surface-3,#F1E6EB);color:var(--on-surface-variant,#7d6a73);}',
      '.tp-ok{background:var(--primary,#C2386A);color:#fff;}'
    ].join('');
    var el = document.createElement('style');
    el.textContent = css;
    document.head.appendChild(el);
  }

  function column(cls, items, index) {
    var col = document.createElement('div');
    col.className = 'tp-col ' + cls;
    var top = document.createElement('div'); top.style.height = PAD + 'px';
    var bot = document.createElement('div'); bot.style.height = PAD + 'px';
    col.appendChild(top);
    items.forEach(function (label) {
      var d = document.createElement('div');
      d.className = 'tp-it'; d.textContent = label;
      col.appendChild(d);
    });
    col.appendChild(bot);
    col._items = items;
    col._index = function () {
      return Math.max(0, Math.min(items.length - 1, Math.round(col.scrollTop / ITEM)));
    };
    col._mark = function () {
      var at = col._index();
      var kids = col.querySelectorAll('.tp-it');
      for (var i = 0; i < kids.length; i++) kids[i].classList.toggle('on', i === at);
    };
    var t = null;
    col.addEventListener('scroll', function () {
      clearTimeout(t); t = setTimeout(col._mark, 60);
    });
    /* 줄을 눌러도 그 값으로 옮겨 간다 */
    col.addEventListener('click', function (e) {
      var it = e.target.closest && e.target.closest('.tp-it');
      if (!it) return;
      var kids = Array.prototype.slice.call(col.querySelectorAll('.tp-it'));
      col.scrollTo({ top: kids.indexOf(it) * ITEM, behavior: 'smooth' });
    });
    setTimeout(function () { col.scrollTop = index * ITEM; col._mark(); }, 0);
    return col;
  }

  function open(current, onPick) {
    injectStyle();
    var cur = parse(current);
    var dim = document.createElement('div');
    dim.className = 'tp-dim';
    dim.setAttribute('role', 'dialog');
    dim.setAttribute('aria-label', '시간 고르기');

    var sheet = document.createElement('div');
    sheet.className = 'tp-sheet';
    sheet.innerHTML = '<div class="tp-title">몇 시에 알려 드릴까요?</div>';

    var wrap = document.createElement('div');
    wrap.className = 'tp-wrap';
    var band = document.createElement('div'); band.className = 'tp-band';
    wrap.appendChild(band);

    var hours = [], mins = [], i;
    for (i = 1; i <= 12; i++) hours.push(String(i));
    for (i = 0; i < 60; i++) mins.push(two(i));

    var cAm = column('ampm', ['오전', '오후'], cur.pm);
    var cHh = column('hh', hours, cur.h12 - 1);
    var cMm = column('mm', mins, cur.mi);
    var colon = document.createElement('div'); colon.className = 'tp-colon'; colon.textContent = ':';
    wrap.appendChild(cAm); wrap.appendChild(cHh); wrap.appendChild(colon); wrap.appendChild(cMm);
    sheet.appendChild(wrap);

    var acts = document.createElement('div');
    acts.className = 'tp-acts';
    var cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'tp-cancel'; cancel.textContent = '취소';
    var ok = document.createElement('button'); ok.type = 'button'; ok.className = 'tp-ok'; ok.textContent = '확인';
    acts.appendChild(cancel); acts.appendChild(ok);
    sheet.appendChild(acts);
    dim.appendChild(sheet);

    function close() {
      if (dim.parentNode) dim.parentNode.removeChild(dim);
      document.documentElement.style.overflow = '';
    }
    cancel.addEventListener('click', close);
    dim.addEventListener('click', function (e) { if (e.target === dim) close(); });
    ok.addEventListener('click', function () {
      /* 값은 반드시 닫기 전에 읽는다 — 화면에서 떼어 내면 스크롤 위치가 0 으로 돌아간다 */
      var pm = cAm._index() === 1, h12 = cHh._index() + 1, mi = cMm._index();
      var h = (h12 % 12) + (pm ? 12 : 0);
      close();
      onPick(two(h) + ':' + two(mi));
    });

    document.documentElement.style.overflow = 'hidden';
    document.body.appendChild(dim);
  }

  var NATIVE = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');

  /* input[type=time] 을 드래그 선택기로 바꾼다.
     .value 는 예전처럼 'HH:MM' 을 돌려주고, 화면에는 '오전 8:00' 이 보인다. */
  function attach(inp) {
    if (!inp || inp.__tp) return inp;
    inp.__tp = true;
    var raw = inp.value || '';
    inp.type = 'text';
    inp.readOnly = true;
    inp.setAttribute('inputmode', 'none');
    inp.setAttribute('autocomplete', 'off');
    inp.style.textAlign = 'center';
    inp.style.cursor = 'pointer';
    Object.defineProperty(inp, 'value', {
      configurable: true,
      get: function () { return raw; },
      set: function (v) { raw = v || ''; NATIVE.set.call(inp, fmt(raw) || ''); }
    });
    inp.value = raw;                                  /* 화면 글자를 한 번 맞춰 둔다 */
    function show(e) {
      if (e) e.preventDefault();
      inp.blur();
      if (document.querySelector('.tp-dim')) return;   /* 한 번에 하나만 */
      open(raw, function (picked) {
        inp.value = picked;
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        inp.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
    /* 누를 때는 기본 동작(포커스·키보드)만 막고, 실제로 여는 것은 click 한 번뿐 */
    inp.addEventListener('mousedown', function (e) { e.preventDefault(); });
    inp.addEventListener('click', show);
    inp.addEventListener('focus', function () { inp.blur(); });
    return inp;
  }

  window.TDT = { attach: attach, fmt: fmt, open: open };
})();
