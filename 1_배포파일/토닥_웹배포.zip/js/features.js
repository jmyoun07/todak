/* ═══ 토닥 화면 배선 v2.1 — 로그인 후 기능 (초기설정·기록·홈·복약·사용기록) ═══
   app.js(로그인·문지기) 다음에 로드된다. 원칙:
   · 시안 요소를 복제/문구교체로만 채운다 (레이아웃 신설 금지)
   · 아직 안 만든 기능의 버튼은 조용히 죽이지 않고 "준비 중" 안내
   · 위치·대화원문은 서버로 보내지 않는다 · app_events 는 이벤트명만
   v2.1 적대검증 반영:
   · 프로필 프리필 완료 전 저장 금지(불러오기 게이트) + 프리필이 사용자 입력을 덮지 않음
   · 주간 위젯 응답 역전 방지(순번 토큰) · 복약 토글 중복탭 방지
   · 자정 넘김 시 화면 재로드(어제 날짜로 저장되는 사고 방지)
   · 접속 횟수: 30분 간격 기준(localStorage), sessionStorage 미사용 */
(function () {
  'use strict';
  var T = window.TD || {};
  var sb = T.sb, $ = T.$, $$ = T.$$, toast = T.toast, busy = T.busy, koError = T.koError, PAGE = T.PAGE;
  if (!sb || !$) return;

  var OPEN = {
    'index.html': 1, '01-splash.html': 1,
    '96-email-signup.html': 1, '97-email-login.html': 1,
    '81-account-recovery.html': 1, '26-help.html': 1, '25-terms.html': 1
  };
  var CFG = window.TODAK_CONFIG || {};
  var esc = T.esc || function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
  function ss(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
  /* 가입 마법사 밖으로 나오면 편집·온보딩 표식을 지운다 (다음 사람·다음 흐름에 새지 않게) */
  if (!/^(03|04|14|53|54|58|59)-/.test(PAGE)) { try { sessionStorage.removeItem('todak_edit'); if (PAGE !== '02-consent.html') sessionStorage.removeItem('todak_onboard'); } catch (e0) {} }

  /* ── 데이터 도우미 ── */
  var _uid = null;
  /* app.js 의 세션 도우미를 쓴다. 웹앱에서 예전 app.js 가 캐시에 남아 새 이 파일과 섞이면
     T.withSession 이 없어 화면이 통째로 멈춘다 — 그때만 쓰는 대체 길을 둔다. */
  function sessGet(cb) {
    if (T.withSession) { T.withSession(cb); return; }
    sb.auth.getSession().then(function (r) {
      cb((r && r.data && r.data.session) || null, (r && r.error) || null);
    }, function (e) { cb(null, e || true); });
  }
  function sessOff(btn) {
    if (T.sessOffline) { T.sessOffline(btn); return; }
    if (btn && T.busy) T.busy(btn, false);
    if (toast) toast('연결이 원활하지 않아요. 잠시 후 다시 시도해 주세요.');
  }
  function uid(cb) {
    if (_uid) return cb(_uid);
    sessGet(function (ses, err) {
      if (ses) { _uid = ses.user.id; cb(_uid); return; }
      /* 토큰이 만료된 채 통신이 나쁘면 getSession 은 세션 없이 error 를 돌려준다(실측 25.5초) —
         로그아웃이 아니다. 01-splash 로 내보내면 app.js 첫머리가 todak_ocr_meds 를 지워
         사진으로 읽은 약이 전부 사라지고, 16 증상 기록·10 진료 질문·58 약 이름처럼 적던 것도
         함께 날아간다. 화면에 머물게 하고 알려만 드린다. (2026-09-28 · app.js withSession 참고) */
      if (err) { sessOff(); return; }
      if (!OPEN[PAGE]) location.replace('01-splash.html'); /* 세션 만료 — 조용히 버리지 않는다 */
    });
  }
  function getProfile(cb) { /* cb(profile, err) — err 가 있으면 profile 은 믿을 수 없다 */
    uid(function (id) {
      sb.from('profiles').select('*').eq('id', id).maybeSingle()
        .then(function (r) { cb(r.data || {}, r.error); }, function (e) { cb({}, e); });
    });
  }
  /* treatment jsonb 의 일부 키만 갱신 — 저장 직전에 다시 읽어 병합한다 (04·73·84가 서로 덮어쓰지 않게) */
  function mergeTreatment(part, done) {
    uid(function (id) {
      sb.from('profiles').select('treatment').eq('id', id).maybeSingle().then(function (r) {
        if (r.error) return done({ error: r.error });
        var t = (r.data && r.data.treatment) || {};
        for (var k in part) t[k] = part[k];
        sb.from('profiles').update({ treatment: t }).eq('id', id).then(done, function (e) { done({ error: e }); });
      }, function (e) { done({ error: e }); });
    });
  }
  T.mergeTreatment = mergeTreatment;
  function saveProfile(patch, done) {
    uid(function (id) { sb.from('profiles').update(patch).eq('id', id).then(done, function (e) { done({ error: e }); }); });
  }
  function logEvent(name, done) {
    uid(function (id) {
      sb.from('app_events').insert({ user_id: id, event: name })
        .then(function () { if (done) done(); }, function () { if (done) done(); });
    });
  }
  /* 사용기록(접속·정보 열람)은 지금 버전 동의(철회 안 됨)를 확인한 뒤에만 남긴다.
     동의 화면(02)에서 나가 버린 분·새 동의문에 아직 동의하지 않은 분의 기록이 남지 않게.
     판정은 app.js 와 같다: 가장 최근 동의 행(consented_at → id 내림차순)이 지금 버전이고 철회되지 않았을 것 (TD.consentValid).
     확인 결과는 30분만 기억한다 — 확인하지 못하면(연결 실패 등) 남기지 않는다. */
  var CONSENT_OK = 'todak_consent_ok';
  function withConsent(cb) {
    var ver = T.DOC_VERSION;
    if (!ver || PAGE === '02-consent.html') return;
    var valid = (typeof T.consentValid === 'function') ? T.consentValid
      : function (row) { return !!(row && row.doc_version === ver && !row.withdrawn_at); };
    uid(function (id) {
      var now = Date.now(), c = null;
      try { c = JSON.parse(sessionStorage.getItem(CONSENT_OK) || 'null'); } catch (e) { c = null; }
      if (c && c.k === id + '|' + ver && now - (+c.t || 0) < 30 * 60 * 1000) { cb(); return; }
      sb.from('consent_records').select('doc_version,withdrawn_at').eq('user_id', id)
        .order('consented_at', { ascending: false }).order('id', { ascending: false }).limit(1)
        .then(function (r) {
          if (!r || r.error || !valid(r.data && r.data[0])) return;
          try { sessionStorage.setItem(CONSENT_OK, JSON.stringify({ k: id + '|' + ver, t: Date.now() })); } catch (e2) {}
          cb();
        }, function () {});
    });
  }

  /* ── 날짜 ── */
  function ymd(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function weekStart(d) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - (x.getDay() + 6) % 7); return x; }
  function addDays(d, n) { var x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; }
  function kdate(d) { return (d.getMonth() + 1) + '월 ' + d.getDate() + '일'; }
  var WDAY = ['일', '월', '화', '수', '목', '금', '토'];

  /* ── 자정 넘김·접속 추적 (로그인 화면들 제외) ──
     웹뷰는 앱을 다시 열어도 리로드되지 않는다. 날짜가 바뀐 채 조작하면
     어제 날짜로 저장되므로, 다시 보일 때 날짜가 다르면 새로 연다. */
  var LOAD_DAY = ymd(new Date());
  function dayChanged() { return ymd(new Date()) !== LOAD_DAY; }
  function markActive() {
    if (PAGE === '02-consent.html') return;       /* 동의 화면(열람 포함)에서는 남기지 않는다 */
    var K = 'todak_last_active', now = Date.now(), last = 0;
    try { last = +localStorage.getItem(K) || 0; } catch (e) {}
    if (now - last <= 30 * 60 * 1000) {           /* 30분 안에 다시 연 것 — 접속으로 세지 않고 시각만 갱신 */
      try { localStorage.setItem(K, String(now)); } catch (e1) {}
      return;
    }
    /* 동의가 확인될 때만 접속으로 세고 시각을 남긴다 (확인 전 시각을 남기면 동의 직후 접속이 빠진다) */
    withConsent(function () {
      logEvent('app_open');
      try { localStorage.setItem(K, String(Date.now())); } catch (e2) {}
    });
  }
  if (!OPEN[PAGE]) {
    markActive();
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState !== 'visible') return;
      if (dayChanged()) { location.reload(); return; }
      markActive();
    });
  }

  /* ── 칩(알약 버튼) ── */
  /* 골랐는지를 화면 읽기(TalkBack·VoiceOver)에도 알린다 — role=checkbox·radio 인데 aria-checked 가 없으면 늘 '선택 안 됨'으로 읽혔다 (2026-10-01 새벽 검증) */
  function chipOn(c, on) {
    c.classList[on ? 'add' : 'remove']('chip--on');
    var r = c.getAttribute('role');
    if (r === 'checkbox' || r === 'radio') c.setAttribute('aria-checked', on ? 'true' : 'false');
  }
  function isChipOn(c) { return c.classList.contains('chip--on'); }
  function chipText(c) { return c.textContent.replace(/\s+/g, ' ').trim(); }
  function bindChip(c, container, opts) {
    var h = function (e) {
      if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
      e.preventDefault();
      T.dirty = 1;
      var to = !isChipOn(c);
      if (opts.single && to) $$('.chip', container).forEach(function (o) { chipOn(o, false); });
      if (to && opts.exclusive) {
        if (chipText(c) === opts.exclusive) $$('.chip', container).forEach(function (o) { if (o !== c) chipOn(o, false); });
        else $$('.chip', container).forEach(function (o) { if (chipText(o) === opts.exclusive) chipOn(o, false); });
      }
      chipOn(c, opts.single ? true : to);
      if (opts.onChange) opts.onChange();
    };
    c.style.cursor = 'pointer';
    c.setAttribute('role', 'checkbox'); c.setAttribute('tabindex', '0');
    c.setAttribute('aria-checked', isChipOn(c) ? 'true' : 'false');
    c.addEventListener('click', h); c.addEventListener('keydown', h);
  }
  function bindChips(container, opts) {
    if (!container) return;
    opts = opts || {};
    $$('.chip', container).forEach(function (c) {
      if (opts.skip && opts.skip.test(chipText(c))) return;
      chipOn(c, false);
      bindChip(c, container, opts);
    });
  }
  function chipValues(container, skipRe) {
    return $$('.chip', container).filter(isChipOn).map(chipText)
      .filter(function (t) { return !(skipRe && skipRe.test(t)); });
  }
  function setChips(container, values, opts) {
    if (!container || !values) return;
    var known = $$('.chip', container).map(chipText);
    $$('.chip', container).forEach(function (c) { if (values.indexOf(chipText(c)) > -1) chipOn(c, true); });
    /* 목록에 없는 저장값(직접 입력분)은 칩으로 만들어 붙인다 */
    values.forEach(function (v) {
      if (known.indexOf(v) > -1) return;
      var base = $('.chip', container);
      if (!base) return;
      var nc = document.createElement('span');
      nc.className = 'chip chip--on';
      nc.setAttribute('style', base.getAttribute('style') || '');
      nc.textContent = v;
      var plus = $$('.chip', container).filter(function (c) { return /^＋/.test(chipText(c)); })[0];
      container.insertBefore(nc, plus || null);
      bindChip(nc, container, opts || {});
    });
  }
  /* "＋ ..." 칩 → 직접 입력창 */
  function bindAddChip(container, placeholder, opts) {
    var add = $$('.chip', container).filter(function (c) { return /^＋/.test(chipText(c)); })[0];
    if (!add) return;
    add.style.cursor = 'pointer';
    add.addEventListener('click', function (e) {
      e.preventDefault();
      var inp = container.__addInput;
      if (!inp) {
        inp = document.createElement('input');
        inp.className = 'input'; inp.type = 'text';
        inp.placeholder = placeholder; inp.style.marginTop = '10px';
        container.parentNode.insertBefore(inp, container.nextSibling);
        container.__addInput = inp;
        var commit = function () {
          var v = inp.value.trim();
          if (!v) return;
          var dup = $$('.chip', container).filter(function (c) { return chipText(c) === v; })[0];
          if (dup) { chipOn(dup, true); }
          else {
            var nc = document.createElement('span');
            nc.className = 'chip chip--on';
            nc.setAttribute('style', add.getAttribute('style') || '');
            nc.textContent = v;
            container.insertBefore(nc, add);
            bindChip(nc, container, opts || {});
          }
          inp.value = '';
          if (opts && opts.exclusive) $$('.chip', container).forEach(function (o) { var t2 = chipText(o); if (t2 === opts.exclusive || t2 === '잘 모르겠어요') chipOn(o, false); });
          if (opts && opts.onChange) opts.onChange();
        };
        inp.addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ev.preventDefault(); commit(); } });
        inp.addEventListener('blur', commit);
      }
      inp.style.display = '';
      inp.focus();
    });
  }

  /* ── 선택 카드(selectable) ── */
  function selOn(el, on) {
    el.classList[on ? 'add' : 'remove']('selectable--on');
    el.setAttribute('aria-checked', on ? 'true' : 'false');
    var b = $('.s-box', el); if (b) b.textContent = on ? '✓' : '';
  }
  function isSelOn(el) { return el.getAttribute('aria-checked') === 'true'; }
  function selTitle(el) {
    var t = $('.s-title', el);
    return t ? t.textContent.replace(/\s+/g, ' ').trim().replace(/^[^가-힣A-Za-z0-9]+\s*/, '') : '';
  }
  function bindSelectables(list, single, onChange) {
    list.forEach(function (el) {
      selOn(el, false);
      var h = function (e) {
        if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
        e.preventDefault();
        T.dirty = 1;
        var to = !isSelOn(el);
        if (single) list.forEach(function (o) { if (o !== el) selOn(o, false); });
        selOn(el, to);            /* 같은 항목을 다시 누르면 해제 — 선택 항목을 되돌릴 수 있게 */
        if (onChange) onChange();
      };
      el.style.cursor = 'pointer';
      el.addEventListener('click', h); el.addEventListener('keydown', h);
    });
  }

  /* 잘못 입력한 칸으로 데려다 놓는다 */
  function focusInput(el) {
    if (!el) return;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    try { el.focus(); } catch (e) {}
  }

  function fieldByLabel(text) {
    return $$('.field').filter(function (f) {
      var l = $('label', f); return l && l.textContent.indexOf(text) > -1;
    })[0] || null;
  }

  /* ── 프로필 불러오기 게이트 ──
     저장 화면(03·04·14)은 기존 저장값을 불러온 뒤에만 저장을 허용한다.
     (불러오기 전에 저장하면 기존 값이 빈 값으로 덮이는 사고 방지) */
  function profileGate(prefill) {
    var g = { ready: false, prof: null };
    g.load = function () {
      getProfile(function (p, err) {
        if (err) return;                 /* 실패 시 ready 유지 안 함 — CTA에서 재시도 */
        g.prof = p; g.ready = true;
        prefill(p);
      });
    };
    g.check = function () {              /* CTA 첫 줄에서 호출 */
      if (g.ready) return true;
      toast('이전에 입력하신 정보를 확인하는 중이에요.\n잠시 후 다시 눌러 주세요.');
      g.load();
      return false;
    };
    g.load();
    return g;
  }

  /* ── 확인 창 (전화 확인 창과 같은 모양 · 휴대폰 뒤로가기로 닫힌다: native.js 가 role=dialog 를 숨긴다) ──
     o = { icon, title, body, yes, no, danger, onYes } — 글자는 모두 textContent 로 넣는다(약 이름 등) */
  function askPop(o) {
    var old = document.getElementById('tdask');
    if (old && old.parentNode) old.parentNode.removeChild(old);
    var pop = document.createElement('div');
    pop.className = 'callpop'; pop.id = 'tdask';
    pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-modal', 'true');
    pop.setAttribute('aria-labelledby', 'tdask-title');
    pop.innerHTML = '<div class="callpop-card"><div style="font-size:32px;" aria-hidden="true"></div>'
      + '<div class="strong" style="font-size:17px; word-break:keep-all;" id="tdask-title"></div>'
      + '<p class="small muted" style="margin:-2px 2px 4px; line-height:1.6; word-break:keep-all;"></p>'
      + '<button type="button" class="btn btn-block btn-lg"></button>'
      + '<button type="button" class="btn btn-outline btn-block"></button></div>';
    var card = pop.firstChild, kids = card.children;
    kids[0].textContent = o.icon || '💬';
    kids[1].textContent = o.title || '';
    kids[2].textContent = o.body || '';
    if (!o.body) kids[2].style.display = 'none';
    var yes = kids[3], no = kids[4];
    yes.className += o.danger ? ' btn-danger' : ' btn-primary';
    yes.textContent = o.yes || '확인';
    no.textContent = o.no || '닫기';
    var prev = document.activeElement;
    function close() {
      pop.hidden = true;
      if (pop.parentNode) pop.parentNode.removeChild(pop);
      try { if (prev && prev.focus) prev.focus(); } catch (e) {}
    }
    /* 세 갈래로 여쭐 때(예: 새로 받아 왔어요 · 따로 넣기 · 닫기) — 가운데 단추 */
    if (o.alt) {
      var alt = document.createElement('button');
      alt.type = 'button';
      alt.className = 'btn btn-outline btn-block';
      alt.textContent = o.alt;
      card.insertBefore(alt, no);
      alt.addEventListener('click', function () { close(); if (o.onAlt) o.onAlt(); });
    }
    no.addEventListener('click', close);
    pop.addEventListener('click', function (e) { if (e.target === pop) close(); });
    pop.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    yes.addEventListener('click', function () { close(); if (o.onYes) o.onYes(); });
    ($('.screen') || document.body).appendChild(pop);
    try { no.focus(); } catch (e3) {}
  }

  /* ── 아직 안 만든 화면으로 가는 링크 → 준비 중 안내 ──
     87·88 은 시안(예시 대화·예시 날짜)이라 실제 화면으로 열지 않고 안내 한 줄로 대신한다 (26 도움말에서 이어짐) */
  var STUB = {
    '93-nearby-fallback.html': '다른 지역에서 찾기는 병원 찾기 화면 안에서 바로 열려요.',
    '87-error-retry.html': '인터넷(와이파이·데이터)이 켜져 있는지 확인한 뒤\n앱을 닫았다가 다시 열어 주세요.',
    '88-empty-states.html': '아직 남긴 기록이 없으면 화면이 비어 보여요.\n기록을 남기시면 그때부터 차곡차곡 보여 드려요.'
  };
  function applyStubs() {
    $$('a[href]').forEach(function (a) {
      var to = (a.getAttribute('href') || '').split('#')[0];
      if (STUB[to]) a.addEventListener('click', function (e) { e.preventDefault(); toast(STUB[to]); });
    });
  }

  /* ── 03 기본 정보 ── */
  function page03() {
    /* 설정에서 들어온 '내 정보 수정'은 03→04→14를 돌고 다시 설정으로 돌아간다 */
    try {
      var ref = document.referrer || '';
      if (ref.indexOf('13-settings') > -1 || ref.indexOf('24-privacy-data') > -1) sessionStorage.setItem('todak_edit', '1');
    } catch (e0) {}
    var b03 = $('.appbar .back');
    if (b03) b03.setAttribute('href', ss('todak_edit') ? '13-settings.html' : '02-consent.html?review=1');
    /* 가입 도중(고치기 아님)의 뒤로가기 = 이 계정에서 나가기.
       예전에는 02 열람 ↔ 03 만 오가서 다른 계정으로 바꾸거나 앱을 닫을 길이 없었다.
       공용 로그아웃(TD.logout)이 있을 때만 확인 창을 띄운다 — 없으면 예전처럼 동의 내용 보기로 간다.
       (휴대폰 뒤로가기도 native.js 가 이 버튼을 눌러 같은 길을 탄다) */
    if (b03 && !ss('todak_edit')) b03.addEventListener('click', function (e) {
      var TDX = window.TD || T;
      if (!TDX || typeof TDX.logout !== 'function') return;
      e.preventDefault();
      askPop({
        icon: '🚪',
        title: '처음 화면으로 나갈까요?',
        body: '지금 계정에서 로그아웃해요. 여기 적으신 내용은 저장되지 않아요. 다른 계정으로 시작하시거나, 같은 계정으로 다시 로그인해 이어서 하실 수 있어요.',
        yes: '로그아웃하고 나가기',
        no: '계속 입력하기',
        onYes: function () { TDX.logout(); }
      });
    });
    var fStage = fieldByLabel('단계'), fTold = fieldByLabel('병기'),
        fType = fieldByLabel('유형'), fCo = fieldByLabel('함께 앓');
    var subEls = fType ? $$('.selectable', fType) : [];
    var toldEls = fTold ? $$('.selectable', fTold) : [];   /* 병기도 이제 selectable */
    var coChips = fCo ? $('.chips', fCo) : null;
    var extra = fCo ? $('input.input', fCo) : null;
    /* 이름·생년월일 — 가입 경로와 상관없이 여기서 받는다 (이메일 가입(96)도 계정만 만든다).
       이미 저장된 값이 있으면(설정에서 고치러 온 경우) 불러와 채운 상태로 보인다. */
    var inName = $('input[aria-label="이름"]'), inBirth = $('input[aria-label="생년월일"]');
    var LIM19 = new Date(); LIM19.setFullYear(LIM19.getFullYear() - 19);   /* 만 19세 되는 마지막 생일 */
    if (inBirth) { inBirth.min = '1920-01-01'; inBirth.max = ymd(LIM19); }
    var touched = {};
    bindChips($('.chips', fStage), { single: true, onChange: function () { touched.stage = 1; } });
    bindSelectables(toldEls, true, function () { touched.told = 1; });
    bindSelectables(subEls, true, function () { touched.sub = 1; });
    bindChips(coChips, { exclusive: '없어요', onChange: function () { touched.co = 1; } });
    if (extra) extra.value = '';

    var gate = profileGate(function (p) {
      /* 이미 손댄 그룹은 덮지 않는다 (늦게 온 응답이 새 선택을 되돌리는 사고 방지) */
      /* 카카오·네이버가 준 것은 실명이 아니라 닉네임일 수 있다.
         간편로그인으로 들어온 경우에는 채우지 않고 환자가 직접 쓰게 한다. */
      var fromOauth = p.login_provider && p.login_provider !== 'email';
      if (inName && p.name && !inName.value && (!fromOauth || p.stage || ss('todak_edit'))) inName.value = p.name;
      if (inBirth && p.birth_date && !inBirth.value) inBirth.value = String(p.birth_date).slice(0, 10);
      if (p.stage && !touched.stage) setChips($('.chips', fStage), [p.stage]);
      if (p.stage_told && !touched.told) toldEls.forEach(function (el) { if (selTitle(el) === p.stage_told) selOn(el, true); });
      if (p.subtype && !touched.sub) subEls.forEach(function (el) { if (selTitle(el) === p.subtype) selOn(el, true); });
      if (p.comorbidities && p.comorbidities.length && coChips && !touched.co) {
        var known = $$('.chip', coChips).map(chipText);
        setChips(coChips, p.comorbidities.filter(function (v) { return known.indexOf(v) > -1; }), { exclusive: '없어요' });
        var rest = p.comorbidities.filter(function (v) { return known.indexOf(v) < 0; });
        if (extra && rest.length && !extra.value) extra.value = rest.join(', ');
      }
    });

    var cta = $('.footer-actions .btn');
    cta.addEventListener('click', function (e) {
      e.preventDefault();
      if (!gate.check()) return;
      var nm = inName ? (inName.value || '').trim() : '';
      var bd = inBirth ? (inBirth.value || '') : '';
      if (inName && !nm) { toast('이름을 입력해 주세요.'); return focusInput(inName); }
      if (inBirth && !bd) { toast('생년월일을 선택해 주세요.'); return focusInput(inBirth); }
      if (inBirth && bd) {
        var by = +bd.slice(0, 4);
        if (by < 1920 || !(new Date(bd + 'T00:00:00') <= LIM19)) {
          toast('생년월일을 다시 확인해 주세요.\n(만 19세 이상만 가입할 수 있어요)');
          return focusInput(inBirth);
        }
      }
      var stage = chipValues($('.chips', fStage))[0];
      if (!stage) { toast('지금 어느 단계인지 골라 주세요.'); try { fStage.scrollIntoView({ block: 'center' }); } catch (e1) {} return; }
      var co = chipValues(coChips);
      var extraTxt = extra ? extra.value.trim() : '';
      if (co.indexOf('없어요') > -1 && !extraTxt) { co = ['없어요']; }   /* '없어요'는 배타 — 단, 직접 적은 질환이 있으면 그것을 살린다 */
      else {
        co = co.filter(function (v) { return v !== '없어요'; });
        if (extraTxt) extraTxt.split(/[,，·]\s*/).forEach(function (v) { if (v && co.indexOf(v) < 0) co.push(v); });
      }
      busy(cta, true, '저장 중…');
      var patch = {
        stage: stage,
        /* 병기 미선택 = '잘 모르겠어요'와 같은 의미로 저장 */
        stage_told: toldEls.filter(isSelOn).map(selTitle)[0] || '잘 모르겠어요',
        subtype: subEls.filter(isSelOn).map(selTitle)[0] || null,
        comorbidities: co
      };
      if (nm) patch.name = nm;
      if (bd) patch.birth_date = bd;
      saveProfile(patch, function (r) {
        if (r && r.error) { busy(cta, false); return toast(koError(r.error)); }
        /* 가입 중 표식은 여기(03 저장)에서만 켠다 — 04 에 다른 길로 들어온 분이 가입 흐름에 다시 빠지지 않게 */
        if (!ss('todak_edit')) { try { sessionStorage.setItem('todak_onboard', '1'); } catch (e5) {} }
        location.href = '04-treatment.html';
      });
    });
  }

  /* ── 04 현재 받는 치료 ── */
  function page04() {
    var fTreat = fieldByLabel('받고 있거나'), fMeds = fieldByLabel('복용 중인 약'), fInj = fieldByLabel('주사 치료');
    var treatEls = fTreat ? $$('.selectable', fTreat) : [];
    var injChips = fInj ? $('.chips', fInj) : null;
    var touched = {};
    bindSelectables(treatEls, false, function () { touched.treat = 1; });
    /* '없어요'·'잘 모르겠어요'는 다른 주사 선택과 배타 */
    bindChips(injChips, { skip: /^＋/, exclusive: '없어요', onChange: function () { touched.inj = 1; } });
    bindAddChip(injChips, '주사 이름을 적어 주세요', { exclusive: '없어요', onChange: function () { touched.inj = 1; } });
    /* 가입 중 표식(todak_onboard)은 03 저장이 켠다 — 그래야 58·53 에서 여기로 돌아온다.
       예전에는 여기서 무조건 켜서, 가입을 마친 분이 약 사진 찍기(53)에서 뒤로 와도 가입 흐름(04→14→19)에 다시 빠졌다.
       표식 없이 들어온 경우는 가입을 마친 분이 다른 길로 온 것이라 '내 정보 고치기'와 같게 다룬다(다음 → 14 → 설정).
       03 에서 막 넘어왔는데 표식이 없는 경우(예전 흐름)만 가입 중으로 본다. */
    if (!ss('todak_edit') && !ss('todak_onboard')) {
      try {
        if ((document.referrer || '').indexOf('03-profile-type') > -1) sessionStorage.setItem('todak_onboard', '1');
        else sessionStorage.setItem('todak_edit', '1');
      } catch (e2) {}
    }
    if (injChips) $$('.chip', injChips).forEach(function (c) {
      if (chipText(c) === '잘 모르겠어요' || chipText(c) === '없어요') {
        c.addEventListener('click', function () {
          if (isChipOn(c)) $$('.chip', injChips).forEach(function (o) {
            var t = chipText(o);
            if (o !== c && t !== '＋ 직접 입력' && t.indexOf('＋') !== 0) chipOn(o, false);
          });
        });
      } else {
        c.addEventListener('click', function () {
          if (isChipOn(c)) $$('.chip', injChips).forEach(function (o) {
            var t = chipText(o);
            if (t === '없어요' || t === '잘 모르겠어요') chipOn(o, false);
          });
        });
      }
    });

    /* 등록된 약 → 실데이터 */
    var medChips = fMeds ? $('.chips', fMeds) : null;
    if (medChips) {
      $$('.chip', medChips).forEach(function (c) { if (!/^＋/.test(chipText(c))) c.parentNode.removeChild(c); });
      var plus = $('.chip', medChips);
      if (plus) {
        plus.style.cursor = 'pointer';
        plus.addEventListener('click', function (e) { e.preventDefault(); leaveTo('58-med-manual.html'); });
      }
      uid(function () {
        sb.from('medications').select('id,name').eq('active', true).then(function (r) {
          (r.data || []).forEach(function (m) {
            var nc = document.createElement('span');
            nc.className = 'chip chip--soft';
            nc.textContent = m.name + ' ✓';
            medChips.insertBefore(nc, plus || null);
          });
        });
      });
    }

    /* 약 등록(58·53)으로 잠깐 나갔다 오면 화면이 새로 열리므로, 나가기 전에 고른 것을 먼저 저장한다 */
    function collect() { return { treatments: treatEls.filter(isSelOn).map(selTitle), injections: chipValues(injChips, /^＋/) }; }
    function leaveTo(href) {
      if (!touched.treat && !touched.inj) { location.href = href; return; }
      toast('고르신 것을 저장하고 넘어갈게요');
      mergeTreatment(collect(), function () { location.href = href; });
    }
    $$('a[href*="53-med-scan"], a[href*="58-med-manual"]').forEach(function (a) {
      a.addEventListener('click', function (e) { e.preventDefault(); leaveTo(a.getAttribute('href')); });
    });
    var gate = profileGate(function (p) {
      var t = p.treatment || {};
      if (t.treatments && !touched.treat) treatEls.forEach(function (el) { if (t.treatments.indexOf(selTitle(el)) > -1) selOn(el, true); });
      if (t.injections && injChips && !touched.inj) setChips(injChips, t.injections, { skip: /^＋/ });
    });

    var cta = $('.footer-actions .btn');
    cta.addEventListener('click', function (e) {
      e.preventDefault();
      if (!gate.check()) return;
      busy(cta, true, '저장 중…');
      mergeTreatment(collect(), function (r) {
        if (r && r.error) { busy(cta, false); return toast(koError(r.error)); }
        location.href = '14-concerns.html';
      });
    });
  }

  /* ── 14 맞춤 설정(걱정 부작용) ── */
  function page14() {
    var chips = $('.chips');
    var touched = {};
    /* 홈의 '내가 신경 쓰는 부작용 고르기'에서 온 경우(?from=05-home.html · 예전 from=home 도 허용) — 가입 단계 표시를 숨기고 저장 뒤 홈으로 */
    var FROM_HOME = /[?&]from=(home|05-home\.html)(&|$)/.test(location.search || '');
    if (FROM_HOME) {
      var b14 = $('.appbar .back'); if (b14) b14.setAttribute('href', '05-home.html');
      var st14 = $('.steps'); if (st14 && st14.parentNode) st14.parentNode.style.display = 'none';
    }
    bindChips(chips, { onChange: function () { touched.c = 1; } });
    var gate = profileGate(function (p) {
      if (p.concerns && p.concerns.length && !touched.c) setChips(chips, p.concerns);
    });
    var cta = $('.footer-actions .btn');
    if (FROM_HOME && cta) cta.textContent = '저장하기';
    cta.addEventListener('click', function (e) {
      e.preventDefault();
      if (!gate.check()) return;
      busy(cta, true, '저장 중…');
      saveProfile({ concerns: chipValues(chips) }, function (r) {
        if (r && r.error) { busy(cta, false); return toast(koError(r.error)); }
        var editing = false;
        try { editing = sessionStorage.getItem('todak_edit') === '1'; sessionStorage.removeItem('todak_edit'); } catch (e4) {}
        location.href = FROM_HOME ? '05-home.html' : editing ? '13-settings.html' : '19-tutorial.html';
      });
    });
  }

  /* ── 16 증상 기록 ── */
  function page16() {
    var today = new Date();
    /* 시안 날짜(7월 28일)는 app-device.css 가 가려 둔다 — 오늘 날짜를 칠한 뒤에만 드러낸다 */
    var sub = $('.appbar-sub');
    if (sub) { sub.textContent = kdate(today) + ' ' + WDAY[today.getDay()] + '요일'; sub.removeAttribute('data-demo'); }

    /* 주간 위젯 */
    var card = $$('.card')[0];
    var grid = card ? $('div[style*="repeat(7"]', card) : null;
    var rangeEl = card ? $('.center .tiny', card) : null;
    var arrows = card ? $$('a[aria-label]', card) : [];
    var prevA = arrows[0], nextA = arrows[1];
    var tnums = card ? $$('.tile .t-num', card) : [];
    var weekOffset = 0;
    var paintSeq = 0;                    /* 응답 역전 방지 순번 */

    /* 시안 값(7월 날짜·월 '좋음'·화 '보통'·화요일 강조·2일 기록·1회 상담)은 app-device.css 가 가려 둔다.
       가림막만 걷으면 기록한 적 없는 분께 거짓 기록이 드러나고, 가린 채 두면 느린 회선에서 몇 초씩 비어 보인다.
       그래서 배선이 들어오는 즉시 '모름'으로 비우고 칸을 드러낸 뒤, 조회 결과로만 채운다. (2026-09-26) */
    function blankWeek() {
      if (!grid) return;
      for (var bi = 0; bi < 7 && bi < grid.children.length; bi++) {
        var c0 = grid.children[bi];
        c0.style.background = 'transparent';
        c0.style.border = 'none';
        c0.style.borderRadius = '12px';
        var l0 = c0.children[0], b0 = c0.children[1];
        if (l0) { l0.className = 'tiny muted'; l0.style.color = ''; }
        if (b0) {
          b0.textContent = '·';
          b0.style.border = '1.5px dashed var(--outline)';
          b0.style.color = 'transparent';
          b0.style.background = 'transparent';
        }
        c0.removeAttribute('data-demo');
      }
    }
    blankWeek();
    tnums.forEach(function (t0) { t0.textContent = '－'; t0.removeAttribute('data-demo'); });

    function paintWeek() {
      if (!grid) return;
      var my = ++paintSeq;
      var ws = weekStart(addDays(today, weekOffset * 7));
      if (rangeEl) { rangeEl.textContent = kdate(ws) + '(월) ~ ' + kdate(addDays(ws, 6)) + '(일)'; rangeEl.removeAttribute('data-demo'); }
      if (nextA) {
        nextA.style.opacity = weekOffset === 0 ? '.35' : '1';
        nextA.setAttribute('aria-disabled', weekOffset === 0 ? 'true' : 'false');
      }
      sb.from('checkins').select('date,mood')
        .gte('date', ymd(ws)).lte('date', ymd(addDays(ws, 6)))
        .then(function (r) {
          if (my !== paintSeq) return;   /* 더 새 요청이 나갔으면 버린다 */
          var map = {};
          (r.data || []).forEach(function (row) { map[row.date] = row.mood; });
          for (var i = 0; i < 7 && i < grid.children.length; i++) {
            var cell = grid.children[i], d = addDays(ws, i);
            var isToday = ymd(d) === ymd(today);
            cell.style.background = isToday ? 'var(--primary-tint)' : 'transparent';
            cell.style.border = isToday ? '1.5px solid var(--primary)' : 'none';
            cell.style.borderRadius = '12px';
            var lab = cell.children[0], badge = cell.children[1];
            if (lab) {
              lab.className = isToday ? 'tiny strong' : 'tiny muted';
              lab.style.color = isToday ? 'var(--primary-dark)' : '';
            }
            if (!badge) continue;
            var mood = map[ymd(d)];
            if (mood) {
              var s = mood >= 4 ? ['좋음', 'var(--safe)', 'var(--safe-tint)']
                    : mood === 3 ? ['보통', 'var(--warn)', 'var(--warn-tint)']
                    : ['힘듦', 'var(--danger)', 'var(--danger-tint)'];
              badge.textContent = s[0];
              badge.style.border = 'none'; badge.style.color = s[1]; badge.style.background = s[2];
            } else {
              badge.textContent = '·';
              badge.style.border = '1.5px dashed var(--outline)';
              badge.style.color = 'transparent'; badge.style.background = 'transparent';
            }
          }
          if (tnums[0]) tnums[0].textContent = (r && r.error) ? '－' : ((r.data || []).length + '일');
        });
      sb.from('app_events').select('id', { count: 'exact', head: true })
        .eq('event', 'chat_question')
        .gte('created_at', ws.toISOString()).lt('created_at', addDays(ws, 7).toISOString())
        .then(function (r) {
          if (my !== paintSeq) return;
          if (tnums[1]) tnums[1].textContent = (r && r.error) ? '－' : ((r.count || 0) + '회');
        });
    }
    if (prevA) prevA.addEventListener('click', function (e) { e.preventDefault(); weekOffset--; paintWeek(); });
    if (nextA) nextA.addEventListener('click', function (e) { e.preventDefault(); if (weekOffset < 0) { weekOffset++; paintWeek(); } });

    /* 기분 5단계 (왼쪽부터 5,4,3,2,1) */
    var moodLabel = $$('.section-label').filter(function (s) { return s.textContent.indexOf('기분') > -1; })[0];
    var moodRow = moodLabel ? moodLabel.nextElementSibling : null;
    var moodEls = moodRow ? $$('.center', moodRow) : [];
    var curMood = null;
    function setMood(v) {
      curMood = v;
      moodEls.forEach(function (el, i) {
        var on = (5 - i) === v;
        var dim = (v !== null) && !on;
        el.setAttribute('aria-checked', on ? 'true' : 'false');   /* 화면 읽기가 고른 기분을 읽게 */
        /* 선택을 또렷하게: 확대 + 분홍 배경 + 진한 글자, 나머지는 흐리게 */
        el.style.transform = on ? 'scale(1.22)' : '';
        el.style.background = on ? 'var(--primary-tint)' : '';
        el.style.border = on ? '2px solid var(--primary)' : '2px solid transparent';
        el.style.borderRadius = '16px';
        el.style.padding = '6px 4px 4px';
        el.style.opacity = dim ? '.4' : '';
        /* 칸 크기에 닿는 값(여백·테두리 두께)은 움직이지 않는다 — 'all' 이면 처음 여백이 0.15초 동안 늘어나는 사이에
           fitMood 가 작은 폭을 재서, 글자를 키운 폰에서 두 줄로 내려야 할 때를 놓쳤다 */
        el.style.transition = 'transform .15s, background-color .15s, border-color .15s, opacity .15s';
        var lab = el.children[1];
        if (lab) {
          lab.className = on ? 'tiny strong' : 'tiny muted';
          lab.style.color = on ? 'var(--primary-dark)' : '';
          lab.style.fontSize = on ? '13px' : '';   /* 본문 하한 13px (확대는 scale 로) */
        }
      });
      fitMood();                         /* 고른 칸의 이름이 13px 로 커지므로 다시 잰다 */
    }
    /* 한 줄에 다섯 칸이 안 들어가면(시스템 글자를 키운 폰) 3칸·2칸 두 줄로 내린다(app.css .mood-wrap).
       조건을 CSS(rem·컨테이너 쿼리)로 잡으면 웹뷰의 글자 배율이 rem 에 곱해지지 않아 켜지지 않을 수 있어서, 실제로 넘치는지를 잰다.
       재는 동안에는 한 줄 모양으로 되돌려 잰다 — 두 줄일 때 재면 늘 '안 넘침'이 나와 되돌아가 버린다.
       offsetLeft·offsetWidth 는 확대(transform)를 빼고 잰 값이라 고른 칸을 키운 것 때문에 잘못 켜지지 않는다. */
    function fitMood() {
      if (!moodRow || !moodEls.length) return;
      moodRow.classList.remove('mood-wrap');
      var cw = moodRow.clientWidth;
      if (!cw) return;                   /* 아직 그려지지 않음(숨김 등) — 다음 resize·fonts.ready 때 다시 */
      var base = moodRow.offsetLeft + moodRow.clientLeft;
      var over = moodRow.scrollWidth > cw + 1;
      moodEls.forEach(function (el) {
        var x = el.offsetParent === moodRow ? el.offsetLeft : el.offsetLeft - base;
        if (x < -1 || x + el.offsetWidth > cw + 1) over = true;
      });
      if (over) moodRow.classList.add('mood-wrap');
      /* 고른 칸은 1.22배로 커진다 — 줄의 왼쪽·오른쪽 끝에 있는 칸은 안쪽으로 커지게 해서 화면 밖으로 밀리지 않게 */
      moodEls.forEach(function (el) {
        var x = el.offsetParent === moodRow ? el.offsetLeft : el.offsetLeft - base;
        el.style.transformOrigin = x < 8 ? '0 50%' : (x + el.offsetWidth > cw - 8 ? '100% 50%' : '');
      });
    }
    var fitTimer = null;
    window.addEventListener('resize', function () { clearTimeout(fitTimer); fitTimer = setTimeout(fitMood, 80); });
    try { if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitMood, function () {}); } catch (eF) {}
    window.addEventListener('pageshow', function (ev) { if (ev.persisted) fitMood(); });
    /* 앱을 나갔다 오는 사이에 시스템 글자 크기를 바꿨을 수 있다 */
    document.addEventListener('visibilitychange', function () { if (!document.hidden) fitMood(); });
    if (moodRow) { moodRow.setAttribute('role', 'radiogroup'); moodRow.setAttribute('aria-label', '오늘 기분'); }
    moodEls.forEach(function (el, i) {
      el.style.cursor = 'pointer';
      el.setAttribute('role', 'radio'); el.setAttribute('tabindex', '0');
      var h = function (e) {
        if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
        e.preventDefault();
        T.dirty = 1;                     /* 입력 중 — 당겨서 새로고침이 고른 기분을 지우지 않게 (native.js PTR) */
        setMood(5 - i);
      };
      el.addEventListener('click', h); el.addEventListener('keydown', h);
    });
    setMood(null);
    moodEls.forEach(function (e0) { e0.removeAttribute('data-demo'); });   /* 미리 눌린 '보통'을 지운 뒤 드러낸다 */

    /* 증상 칩 + 강도 카드 */
    var symLabel = $$('.section-label').filter(function (s) { return s.textContent.indexOf('증상') > -1; })[0];
    var symChips = symLabel ? symLabel.nextElementSibling : null;
    var intensity = {};   /* {증상: 단계} */
    var tmplCard = $$('.card').filter(function (c) { return c.textContent.indexOf('강도') > -1; })[0];
    var intWrap = null, tmpl = null;
    if (tmplCard) {
      tmpl = tmplCard.cloneNode(true);
      tmpl.removeAttribute('data-demo');   /* 시안 가림막은 본에 따라오지 않게 */
      intWrap = document.createElement('div');
      intWrap.className = 'col gap-10';
      tmplCard.parentNode.replaceChild(intWrap, tmplCard);
    }
    var SEVC = { '없음': 'sev--mild', '약함': 'sev--mild', '보통': 'sev--mod', '심함': 'sev--sev', '매우 심함': 'sev--sev' };
    function renderIntensity() {
      if (!intWrap || !tmpl) return;
      intWrap.innerHTML = '';
      chipValues(symChips, /^＋/).forEach(function (sym) {
        var c = tmpl.cloneNode(true);
        var title = $('.strong', c); if (title) title.textContent = sym + ' 강도';
        var sev = $('.sev', c);
        function paintSev() {
          if (!sev) return;
          var v = intensity[sym];
          sev.textContent = v || '－';
          sev.className = 'sev ' + (SEVC[v] || 'sev--mild');
          sev.style.visibility = v ? '' : 'hidden';
        }
        $$('.chip', c).forEach(function (ch) {
          chipOn(ch, intensity[sym] === chipText(ch));
          ch.style.cursor = 'pointer';
          ch.addEventListener('click', function (e) {
            e.preventDefault();
            T.dirty = 1;                 /* 강도 선택도 입력 중으로 친다 */
            $$('.chip', c).forEach(function (o) { chipOn(o, false); });
            chipOn(ch, true);
            intensity[sym] = chipText(ch);
            paintSev();
          });
        });
        paintSev();
        intWrap.appendChild(c);
      });
    }
    bindChips(symChips, { skip: /^＋/, onChange: renderIntensity });
    if (symChips) $$('.chip', symChips).forEach(function (c1) { c1.removeAttribute('data-demo'); });   /* 미리 눌린 '손발 저림'·'피로'를 지운 뒤 드러낸다 */
    bindAddChip(symChips, '증상을 적어 주세요', { onChange: renderIntensity });
    renderIntensity();

    var memo = $('textarea');
    if (memo) memo.value = '';

    /* 오늘 기록 불러오기 — 실패는 '기록 없음'과 구분하고, 늦게 온 응답이
       사용자가 그 사이 입력한 값을 덮지 않게 한다 */
    var ciReady = false;
    function loadToday() {
      sb.from('checkins').select('*').eq('date', ymd(today)).maybeSingle().then(function (r) {
        if (r.error) return;             /* ciReady 유지 안 함 — 저장 시 재시도 */
        ciReady = true;
        var c = r.data;
        if (!c) return;
        if (curMood === null) setMood(c.mood || null);
        if (c.symptoms && c.symptoms.length) {
          /* 사용자가 먼저 고른 칩은 그대로 두고 저장돼 있던 증상을 합친다 — 늦은 응답이 기존 기록을 지우지 않게 */
          var cur = chipValues(symChips, /^＋/);
          var add = c.symptoms.filter(function (s2) { return cur.indexOf(s2) < 0; });
          if (add.length) setChips(symChips, add, { skip: /^＋/, onChange: renderIntensity });
          var inten0 = c.intensity || {};
          for (var k0 in inten0) if (!intensity[k0]) intensity[k0] = inten0[k0];
          renderIntensity();
        }
        if (memo && c.memo && !memo.value.trim()) memo.value = c.memo;
      }, function () {});
    }
    loadToday();

    var save = T.btnByText('오늘 기록 저장');
    if (save) save.addEventListener('click', function (e) {
      e.preventDefault();
      if (save.__busy) return;
      if (dayChanged()) {
        toast('날짜가 바뀌어 화면을 새로 열어요.');
        setTimeout(function () { location.reload(); }, 900);
        return;
      }
      if (!ciReady) {
        toast('기존 기록을 확인하는 중이에요.\n잠시 후 다시 눌러 주세요.');
        loadToday();
        return;
      }
      if (!curMood) return toast('오늘 기분을 골라 주세요.');
      var syms = chipValues(symChips, /^＋/);
      var inten = {};
      syms.forEach(function (s) { if (intensity[s]) inten[s] = intensity[s]; });
      busy(save, true, '저장 중…');
      uid(function (id) {
        sb.from('checkins').upsert({
          user_id: id, date: ymd(today), mood: curMood,
          symptoms: syms, intensity: inten, memo: (memo && memo.value.trim()) || null
        }, { onConflict: 'user_id,date' }).then(function (r2) {
          if (r2.error) { busy(save, false); return toast(koError(r2.error)); }
          toast('오늘 기록을 저장했어요 🌷');
          /* 사용기록 저장이 끝난 뒤 이동 (이동이 저장을 끊지 않게) · 2초 안전장치 */
          var moved = false;
          var go = function () { if (!moved) { moved = true; location.href = '05-home.html'; } };
          setTimeout(go, 2000);
          logEvent('checkin_save', function () { setTimeout(go, 700); });
        });
      });
    });

    paintWeek();
  }

  /* ── 05 홈 '오늘의 한 가지' 중 오늘의 팁 ──
     최근 사흘에 잦거나 심했던 증상이 없을 때 보여 주는 목록이다.
     화면에 글자를 박아 두면 늘 같은 팁('관절이 뻣뻣한 아침…')만 보인다. 날짜를 세어 하루에 하나씩 돌린다.
     같은 날은 같은 팁, 날이 바뀌면 다음 팁. 14 에서 고른 '신경 쓰는 부작용(concerns)'이 있으면
     해당 팁을 앞에 놓되 나머지도 함께 돌린다. 관심 항목이 하나여도 열 가지를 모두 본 뒤 반복한다.
     글은 모두 앱 안에 이미 있는 안내(06 목록·31·32·33·34·35·36·46·47·66)에서 가져왔다 — 여기서 새 의학 정보를 만들지 않는다.
     c: 14 의 부작용 이름 · t: 제목(할 일을 담은 한 줄) · s: 할 일과 까닭 1~2문장 · g: 카드 아래 '○○ 자세히 보기 ›' · p: 가는 화면
     (2026-09-28 교수님: '왜 이걸 보여 드리는지' 같은 까닭 줄 없이 내용을 바로 — 제목 + 구체적인 1~2문장) */
  var TIPS = [
    { c: '관절통', p: '34-detail-arthralgia.html', g: '관절 뻣뻣함',
      t: '관절이 뻣뻣한 아침엔 가볍게 풀고 일어나요',
      s: '일어나기 전에 스트레칭을 하고, 따뜻한 물로 샤워해 보세요. 호르몬치료 중엔 관절이 아침에 특히 뻣뻣해요.' },
    { c: '피로', p: '33-detail-fatigue.html', g: '피로 관리',
      t: '기운이 없을수록 조금씩이라도 움직여 보세요',
      s: '한 번에 오래 걷기보다 짧게 자주 걸어 보세요. 가벼운 걷기가 오히려 치료 중 피로를 줄여 줘요.' },
    { c: '메스꺼움·구토', p: '31-detail-nausea.html', g: '오심·구토 관리',
      t: '울렁거릴 땐 조금씩 자주 드세요',
      s: '한 번에 반 공기 이하로, 하루 5~6번 나눠 드세요. 배가 빨리 부르면 속이 더 울렁거려요.' },
    { c: '수면 문제', p: '46-detail-sleep.html', g: '수면 관리',
      t: '잠은 눕는 시각보다 일어나는 시각을 먼저 맞춰요',
      s: '눕는 시각은 졸릴 때로 두고, 일어나는 시각은 날마다 같게 지키세요. 낮잠은 30분 안쪽으로, 오후 3시 전에 주무세요.' },
    { c: '손발 저림', p: '15-sideeffect-detail.html', g: '손발 저림 관리',
      t: '손발 감각이 둔할 땐 데거나 넘어지지 않게 조심해요',
      s: '뜨겁고 찬 것을 잘 구분하지 못할 수 있어요. 손발은 따뜻하게 두고, 다니는 길에 걸리는 것은 치워 두세요.' },
    { c: '입안 헐음', p: '36-detail-mucositis.html', g: '구내염 입안 관리',
      t: '입안이 헐 땐 자극을 줄여 주세요',
      s: '식후와 자기 전에 부드러운 칫솔로 닦아 주세요. 맵고 뜨거운 음식은 헌 곳을 건드리니 잠시 미뤄 두세요.' },
    { c: '머리카락 빠짐', p: '32-detail-hairloss.html', g: '탈모·두피 관리',
      t: '머리 감을 땐 순한 샴푸를 쓰세요',
      s: '평소보다 덜 자주, 아주 부드럽게 감으세요. 머리카락은 대개 치료가 끝나고 2~3개월 뒤부터 다시 자라요.' },
    { c: '음식·영양', p: '66-food-immune.html', g: '안전한 식품 위생',
      t: '음식을 만들기 전후엔 손부터 씻어요',
      s: '흐르는 물에 비누로 20초 넘게 씻어 주세요. 항암 주사 뒤 7~14일쯤 백혈구가 가장 낮아져 음식으로 탈이 나기 쉬워요.' },
    { c: '안면홍조·열감', p: '35-detail-hotflash.html', g: '안면홍조·열감',
      t: '열감이 잦을 땐 옷차림부터 바꿔 보세요',
      s: '얇게 여러 겹 입고, 열감이 오르면 한 겹씩 벗으세요. 매운 음식·뜨거운 음료·카페인·술은 열감을 부추기니 줄여 보세요.' },
    { c: '불안·재발 걱정', p: '47-detail-anxiety.html', g: '불안·재발 걱정',
      t: '오늘 마음이 힘든 정도를 0~10으로 매겨 보세요',
      s: '0은 전혀 없음, 10은 극심함이에요. 4점 이상이면 그날 안에 치료받는 병원에 알리세요.' }
  ];
  /* 그 날짜 0시를 기준으로 센 날 수 — 같은 날은 같은 값, 날이 바뀌면 1 늘어난다 (시간대에 흔들리지 않게 UTC 로 센다) */
  function tipDayNo() {
    var d = new Date();
    return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000);
  }
  function tipPick(concerns) {
    /* 저장된 값이 배열이 아니어도 멈추지 않게 */
    if (Object.prototype.toString.call(concerns) !== '[object Array]') concerns = [];
    var list = [];
    concerns.forEach(function (cn) {
      TIPS.forEach(function (tp) { if (tp.c === cn && list.indexOf(tp) < 0) list.push(tp); });
    });
    TIPS.forEach(function (tp) { if (list.indexOf(tp) < 0) list.push(tp); });
    var n = tipDayNo() % list.length;
    var tip = list[(n + list.length) % list.length];
    return { k: 'tip', id: String(tip.p).replace(/\.html$/, ''), t: tip.t, s: tip.s, g: tip.g + ' 자세히 보기', p: tip.p };
  }

  /* ── 05 홈 '오늘의 한 가지' ── 2026-09-28 다시 짬
     교수님 말씀: 날마다 도는 팁이 '나와 상관없는 글'로 읽힌다 — 내가 남긴 것·자주 보는 것에 맞춰 달라.
     고르는 순서(앞에서 걸리면 거기서 끝):
       ① 오늘 증상 기록이 있으면   → 남기신 증상의 관리 화면 + 한 가지 방법 ('오늘 ○○이 있었다고 남기셨어요')
       ② 오늘 약을 챙기셨으면       → 등록하신 유방암 치료약에서 생길 수 있는 불편 하나 (druginfo.js TDRUG 의 링크 있는 항목만)
       ③ 그 밖에는 관심사           → 요즘 잦았던 증상(최근 사흘) · 상담에서 나온 화면(C1 todak_chat_topics)
                                       · 자주 보신 정보 화면(C2 todak_views) · 신경 쓰는 부작용(14 concerns)
       ④ 아무것도 없으면            → 예전처럼 날마다 바뀌는 오늘의 팁(TIPS)
     고르는 까닭은 화면에 적지 않는다 — 2026-09-28 교수님: '음식·영양이 신경 쓰인다고 하셨어요' 같은 까닭 줄 말고 내용을 바로.
     제목(card-title) = 그 화면의 할 일 한 줄(h), 아래(card-sub) = 구체적인 할 일과 까닭 1~2문장(s).
     같은 것이 날마다 되풀이되지 않게 ③ 은 최근 며칠 보여 드린 화면을 건너뛴다(todak_tip_seen · 이 기기에만).
     하루 안에서는 바뀌지 않는다(todak_one_day · paintOne) — 교수님이 보시는 사이 같은 날 글이 바뀌었다.
     딱 한 번만 바뀔 수 있다: 먼저 고른 뒤 오늘 증상 기록을 남기셨을 때(① 로). 응급·위기 화면은 목록에 아예 없다.
     홈이 이미 불러오는 profiles·checkins·medications·med_logs 와 이 기기의 기록만 쓴다 — 새로 서버에 묻거나 보내지 않는다. */

  /* 화면별 한 가지 — id 는 화면 파일 이름(.html 뺀 것). C1·C2 가 이 이름으로 적는다.
     nm: 화면 이름(예전 까닭 줄에 쓰던 것 · 지금은 화면에 쓰지 않는다) · h: 제목 = 할 일 한 줄 · s: 구체적인 할 일과 까닭 1~2문장
     g: 카드 아래 '○○ 자세히 보기 ›' · go: 그 말 대신 쓸 글(있을 때만)
     글은 모두 그 화면(과 06 목록·TIPS)에 이미 있는 안내에서 가져왔다 — 여기서 새 의학 정보를 만들지 않는다.
     넣지 않은 화면: 48 응급·11 위기·08 위험 신호(가볍게 권할 화면이 아니다) · 41 심장 기능(검사·연락 기준이 대부분)
     · 43 성 건강(홈에 그대로 뜨면 곁에 있는 사람도 본다) · 17 가이드 목록·70~75 약 안내(② 가 따로 고른다) */
  function tipS(c) { var t = tipByC(c); return t ? t.s : ''; }
  function tipT(c) { var t = tipByC(c); return t ? t.t : ''; }
  var ONE_CAT = {
    '15-sideeffect-detail': { nm: '손발 저림', g: '손발 저림 관리', h: tipT('손발 저림'), s: tipS('손발 저림') },
    '31-detail-nausea': { nm: '메스꺼움', g: '오심·구토 관리', h: tipT('메스꺼움·구토'), s: tipS('메스꺼움·구토') },
    '32-detail-hairloss': { nm: '탈모', g: '탈모·두피 관리', h: tipT('머리카락 빠짐'), s: tipS('머리카락 빠짐') },
    '33-detail-fatigue': { nm: '피로', g: '피로 관리', h: tipT('피로'), s: tipS('피로') },
    '34-detail-arthralgia': { nm: '관절통', g: '관절통 관리', h: tipT('관절통'), s: tipS('관절통') },
    '35-detail-hotflash': { nm: '안면홍조·열감', g: '안면홍조·열감', h: tipT('안면홍조·열감'), s: tipS('안면홍조·열감') },
    '36-detail-mucositis': { nm: '입안 헐음', g: '구내염 입안 관리', h: tipT('입안 헐음'), s: tipS('입안 헐음') },
    '37-detail-myelo': { nm: '감염 예방', g: '골수억제·감염 위험',
      h: '항암 주사 뒤 7~14일은 감염을 가장 조심해요',
      s: '이때 백혈구가 가장 낮아져요. 하루 한 번 체온을 재서 평소 체온을 알아 두세요.',
      ds: '주사 뒤 7~14일쯤 백혈구가 가장 낮아져요. 이때는 체온을 하루 한 번쯤 재 두세요.' },
    '38-detail-diarrhea': { nm: '설사', g: '설사 관리',
      h: '설사할 땐 빠져나간 물부터 채워요',
      s: '맑은 물을 한꺼번에 많이 드시기보다 조금씩 자주 드세요. 식사는 작게 나눠 하루 5~6번 드시면 장이 편해요.' },
    '39-detail-skinrad': { nm: '방사선 피부', g: '방사선 피부 관리',
      h: '방사선 치료 중에도 날마다 순하게 씻어요',
      s: '미지근한 물과 순한 세정제로 씻으세요. 때수건으로 문지르지 말고, 부드러운 수건으로 눌러서 물기를 걷어 내세요.' },
    '40-detail-lymphedema': { nm: '림프부종', g: '림프부종 관리',
      h: '날마다 1분, 양팔을 나란히 견주어 보세요',
      s: '거울 앞에서 보고 같은 자리를 만져 보면 붓기를 일찍 알 수 있어요. 반지나 소매가 전보다 조이는 느낌도 첫 신호예요.' },
    '42-detail-skintgt': { nm: '피부 발진·건조', g: '표적치료 피부 관리',
      h: '표적치료 중엔 순한 보습제를 자주 발라요',
      s: '샤워는 미지근한 물로 짧게 하세요. 가려울 땐 긁지 말고 차가운 물수건으로 식혀 주세요.' },
    '44-detail-bone': { nm: '뼈 건강', g: '골밀도 관리',
      h: '뼈가 약할 땐 넘어지지 않는 것이 먼저예요',
      s: '넘어지는 일은 대부분 집 안에서 일어나요. 욕실 미끄럼방지 매트, 밤에 화장실 가는 길 조명부터 하나씩 바꿔 보세요.' },
    '45-detail-constipation': { nm: '변비', g: '변비 관리',
      h: '변비엔 물이 먼저, 섬유질은 그다음이에요',
      s: '아침에 따뜻한 보리차나 숭늉 한 잔부터 드세요. 물 없이 섬유질만 늘리면 변이 오히려 더 굳어요.' },
    '46-detail-sleep': { nm: '수면', g: '수면 관리', h: tipT('수면 문제'), s: tipS('수면 문제') },
    '47-detail-anxiety': { nm: '불안·재발 걱정', g: '불안·재발 걱정', h: tipT('불안·재발 걱정'), s: tipS('불안·재발 걱정') },
    '49-detail-cognitive': { nm: '집중·기억 변화', g: '항암 브레인 관리',
      h: '기억은 메모와 알림에 맡겨요',
      s: '약·진료·할 일은 메모와 알림으로 옮겨 두세요. 열쇠·약·지갑은 늘 같은 자리에 두세요.' },
    '50-detail-taste': { nm: '맛 변화', g: '미각·후각 변화',
      h: '쇠 맛이 날 땐 수저부터 바꿔 보세요',
      s: '플라스틱·나무 수저를 써 보세요. 음식은 뜨거운 것보다 실온이나 차게 드시면 쇠 맛이 덜 올라와요.' },
    '51-detail-handfoot': { nm: '손발 피부 변화', g: '수족증후군 관리',
      h: '손발은 시원하게 두는 것이 먼저예요',
      s: '누르고 비비는 것과 뜨거운 물을 피하고, 보습제를 자주 발라 주세요. 설거지·청소할 때는 꼭 고무장갑을 끼세요.' },
    '52-detail-weight': { nm: '체중 변화', g: '체중 변화 관리',
      h: '체중은 같은 시간, 같은 옷차림으로 재요',
      s: '하루하루 숫자보다 일주일 흐름을 보세요. 치료 중에는 빼기보다 늘지 않게 지키는 것이 먼저예요.' },
    '60-food-nausea': { nm: '메스꺼울 때 식사', g: '메스꺼울 때 식사',
      h: '메스꺼울 땐 배고프기 전에 조금씩 드세요',
      s: '하루 세 끼 대신 5~6번으로 나눠 드세요. 물은 식전·식후 30분으로 옮겨 조금씩 드세요.' },
    '61-food-appetite': { nm: '입맛 없을 때 식사', g: '입맛 없을 때 식사',
      h: '입맛이 없어도 단백질은 빼지 마세요',
      s: '적게 드시더라도 계란죽·연두부처럼 부드러운 단백질 음식을 챙겨 드세요. 단백질이 모자라면 지방보다 근육이 먼저 빠져요.' },
    '62-food-mucositis': { nm: '입안이 헐었을 때 식사', g: '입안이 헐었을 때 식사',
      h: '입안이 헐었을 땐 미지근하고 부드러운 음식이 편해요',
      s: '신맛·매운맛·뜨거운 온도·거친 음식이 헌 입안을 건드려요.' },
    '63-food-diarrhea': { nm: '설사할 때 식사', g: '설사할 때 식사',
      h: '설사할 땐 맑은 물을 조금씩 자주 드세요',
      s: '지금은 설사를 멈추는 것보다 빠져나간 물을 채우는 게 먼저예요.' },
    '64-food-constipation': { nm: '변비일 때 식사', g: '변비일 때 식사',
      h: '변비엔 물, 섬유질, 걷기 순서로 챙겨요',
      s: '물 없이 섬유질만 늘리면 변이 오히려 더 굳어요. 따뜻한 물이나 보리차부터 충분히 드세요.' },
    '65-food-taste': { nm: '맛이 이상할 때 식사', g: '맛이 이상할 때 식사',
      h: '맛이 이상해도 단백질은 채워요',
      s: '맛을 되찾으려 애쓰기보다 오늘 넘어가는 음식부터 드세요. 계란찜·연두부는 쇠 맛이 거의 안 나요.' },
    '66-food-immune': { nm: '면역이 약한 시기 식사', g: '면역이 약한 시기 식사', h: tipT('음식·영양'), s: tipS('음식·영양') },
    '67-food-bone': { nm: '뼈 건강 식사', g: '뼈 건강 식사',
      h: '칼슘은 끼니마다 한 가지씩 드세요',
      s: '한 번에 몰아 드시기보다 나눠 드셔야 몸에 더 잘 남아요. 아침 우유 한 컵, 점심 두부, 저녁 멸치처럼요.' },
    '68-food-weight': { nm: '체중 관리 식사', g: '살이 찔 때 식사',
      h: '체중 관리는 근육 지키기가 먼저예요',
      s: '굶으면 근육이 먼저 빠져 회복이 더뎌져요. 단백질과 채소부터 드셔 보세요.' },
    '94-food-soy': { nm: '콩 음식', g: '콩·두부·된장',
      h: '두부·두유·된장은 끊지 않으셔도 돼요',
      s: '콩은 음식으로 드세요. 이소플라본 캡슐·분말 같은 고농축 보충제는 담당 의사와 상의하지 않았다면 드시지 마세요.' },
    '95-food-alcohol': { nm: '술', g: '술, 어떻게 할까요',
      h: '술은 되도록 쉬어 가세요',
      s: '안전하다고 확인된 양은 없어요. 끊기 어려우시면 마시는 횟수부터, 그다음 잔 수를 줄여 보세요.' },
    '09-food-supplement': { nm: '음식·건강기능식품', g: '음식·건강기능식품', go: '음식·건강기능식품 보기',
      h: '불편한 증상에 맞는 식사 카드를 골라 보세요',
      s: '메스꺼울 때, 입맛이 없을 때, 입안이 헐었을 때처럼 증상마다 편한 음식이 달라요.' },
    /* 69 — 토닥은 먹어도 되는지 판정하지 않는다(교수님 원칙). 최종 판단은 늘 담당 의사·약사에게 */
    '69-supplement-check': { nm: '건강기능식품', g: '이거 먹어도 되나요?', go: '이름으로 찾아보기',
      h: '건강기능식품·한약은 드시기 전에 먼저 여쭤보세요',
      s: '지금 받는 치료와 함께 드시면 부담이 될 수 있는 제품도 있어요. 이름으로 찾아보시고, 담당 의사·약사에게 확인해 주세요.' }
  };
  function oneCat(id) { return has(ONE_CAT, id) ? ONE_CAT[id] : null; }
  function oneGo(c) { return c.go || (c.g + ' 자세히 보기'); }

  /* 16 의 증상 이름 → 가는 화면. 두 개면 [상세, 식사 카드] — 심하지 않은 날은 날마다 번갈아 보여 드린다.
     직접 쓴 증상 가운데 앱이 아는 이름만 쓴다. '열'·'붓기'처럼 위험 신호일 수 있는 말은 일부러 넣지 않았다
     (열은 응급 기준이 따로 있고, 다리 붓기는 혈전 신호일 수 있다 — 팁으로 가볍게 다루지 않는다). */
  var SYM_SCR = {
    '메스꺼움': ['31-detail-nausea', '60-food-nausea'], '구토': ['31-detail-nausea', '60-food-nausea'],
    '메스꺼움·구토': ['31-detail-nausea', '60-food-nausea'],
    '손발 저림': ['15-sideeffect-detail'], '피로': ['33-detail-fatigue'], '관절통': ['34-detail-arthralgia'],
    '수면 문제': ['46-detail-sleep'], '불면': ['46-detail-sleep'],
    '입안 헐음': ['36-detail-mucositis', '62-food-mucositis'], '구내염': ['36-detail-mucositis', '62-food-mucositis'],
    '열감': ['35-detail-hotflash'], '안면홍조': ['35-detail-hotflash'], '안면홍조·열감': ['35-detail-hotflash'],
    '탈모': ['32-detail-hairloss'], '머리카락 빠짐': ['32-detail-hairloss'],
    '불안': ['47-detail-anxiety'], '불안·재발 걱정': ['47-detail-anxiety'],
    '설사': ['38-detail-diarrhea', '63-food-diarrhea'], '변비': ['45-detail-constipation', '64-food-constipation'],
    '입맛 없음': ['61-food-appetite'], '식욕부진': ['61-food-appetite'],
    '맛 변화': ['50-detail-taste', '65-food-taste'], '미각 변화': ['50-detail-taste', '65-food-taste'],
    '림프부종': ['40-detail-lymphedema'], '팔 부종': ['40-detail-lymphedema'],
    '수족증후군': ['51-detail-handfoot'], '집중력 저하': ['49-detail-cognitive'], '건망증': ['49-detail-cognitive']
  };
  /* 이름 그대로 넣으면 어색한 증상만 따로 적는다 — '입맛 없음이 있었다고'·'입맛 없음이 잦으셨어요' (2026-09-28 검수)
     has: 오늘 있었다 · sev: 오늘 심했다 · often: 요즘 잦았다 · sevDay: 요즘 심한 날이 있었다 */
  var SYM_SAY = {
    '입맛 없음': { has: '입맛이 없으셨다고', sev: '입맛이 많이 없으셨다고',
      often: '입맛 없는 날이 잦으셨어요', sevDay: '입맛이 많이 없던 날이 있었어요' }
  };
  function symSay(nm, k) {
    var o = has(SYM_SAY, nm) ? SYM_SAY[nm] : null;
    if (o) return o[k];
    return nm + iGa(nm) + (k === 'has' ? ' 있었다고' : k === 'sev' ? ' 심하셨다고' : k === 'often' ? ' 잦으셨어요' : ' 심한 날이 있었어요');
  }
  /* 14 의 '신경 쓰는 부작용' → 가는 화면 (성 건강은 위 까닭으로 뺐다) */
  var CONC_SCR = {
    '손발 저림': '15-sideeffect-detail', '관절통': '34-detail-arthralgia', '머리카락 빠짐': '32-detail-hairloss',
    '메스꺼움·구토': '31-detail-nausea', '입안 헐음': '36-detail-mucositis', '안면홍조·열감': '35-detail-hotflash',
    '피로': '33-detail-fatigue', '수면 문제': '46-detail-sleep', '불안·재발 걱정': '47-detail-anxiety',
    '음식·영양': '66-food-immune', '건강기능식품': '69-supplement-check'
  };
  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function isArr(v) { return Object.prototype.toString.call(v) === '[object Array]'; }
  function tipByC(c) {
    for (var i = 0; i < TIPS.length; i++) if (TIPS[i].c === c) return TIPS[i];
    return null;
  }
  /* 주어 조사 — 받침이 있으면 '이', 없으면 '가'. 숫자·영문으로 끝나면 '이(가)' */
  function iGa(s) {
    var t = String(s || '').replace(/\s+$/, ''), c = t.charCodeAt(t.length - 1);
    if (!(c >= 0xAC00 && c <= 0xD7A3)) return '이(가)';
    return (c - 0xAC00) % 28 ? '이' : '가';
  }
  /* 이 기기에 남긴 값 읽기 — 깨진 값이면 null (C1·C2·보여 드린 기록) */
  function lsJSON(k) {
    var v = null;
    try { v = JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { v = null; }
    return v;
  }
  /* 최근 사흘 기록에서 가장 걸리는 증상 하나 — 사흘 중 이틀 이상이거나(잦음) 한 번이라도 '심함'일 때만 */
  function topSym(rows) {
    if (!isArr(rows) || !rows.length) return null;
    var cnt = {}, sev = {}, order = [];
    rows.forEach(function (c) {
      var syms = (c && c.symptoms) || [], inten = (c && c.intensity) || {};
      if (!isArr(syms)) return;
      var seen = {};
      syms.forEach(function (s) {
        var nm = String(s == null ? '' : s).trim();
        if (!nm || !has(SYM_SCR, nm) || seen[nm]) return;   /* 앱이 아는 증상 이름만 */
        seen[nm] = 1;                                     /* 같은 날 같은 증상은 한 번만 센다 */
        if (!has(cnt, nm)) { cnt[nm] = 0; order.push(nm); }
        cnt[nm]++;
        var iv = inten && has(inten, nm) ? inten[nm] : '';
        if (iv === '심함' || iv === '매우 심함') sev[nm] = 1;
      });
    });
    var best = null;
    order.forEach(function (nm) {
      var sc = cnt[nm] * 2 + (sev[nm] ? 1 : 0);           /* 이틀=4 · 하루+심함=3 · 하루=2 */
      if (sc >= 3 && (!best || sc > best.score)) best = { name: nm, days: cnt[nm], score: sc };
    });
    return best;
  }
  /* ① 오늘 기록에서 가장 힘드셨던 증상 하나 — 강도가 센 것 먼저, 같으면 먼저 고르신 것. '없음'으로 적은 증상은 뺀다 */
  var SEV_RANK = { '매우 심함': 4, '심함': 3, '보통': 2, '약함': 1 };
  /* 같은 강도가 여럿이면(피로 보통·관절통 보통을 날마다 남기시는 분) 어제 보여 드린 화면의 증상은 뒤로 미룬다 —
     날마다 같은 글이 되지 않게 (2026-09-28 검수). 강도가 더 센 증상은 어제 보여 드렸어도 그대로 앞이다 */
  function todaySym(row, yIds) {
    if (!row || !isArr(row.symptoms)) return null;
    var inten = (row.intensity && typeof row.intensity === 'object') ? row.intensity : {}, best = null;
    yIds = yIds || {};
    row.symptoms.forEach(function (s) {
      var nm = String(s == null ? '' : s).trim();
      if (!nm || !has(SYM_SCR, nm)) return;
      var iv = has(inten, nm) ? inten[nm] : '';
      if (iv === '없음') return;
      var r = has(SEV_RANK, iv) ? SEV_RANK[iv] : 1.5;      /* 강도를 안 고르셨으면 '약함'과 '보통' 사이 */
      var y = !!yIds[SYM_SCR[nm][0]];
      if (!best || r > best.r || (r === best.r && best.y && !y)) best = { name: nm, r: r, sev: r >= 3, y: y };
    });
    return best;
  }

  /* ── 보여 드린 기록 (이 기기에만 · 14일치) — [{d:'YYYY-MM-DD', id}] 오래된 것부터 ── */
  var SEEN_K = 'todak_tip_seen';
  function seenGet() {
    var a = lsJSON(SEEN_K);
    return isArr(a) ? a.filter(function (x) { return x && typeof x.id === 'string' && typeof x.d === 'string'; }) : [];
  }
  /* 보여 드린 기록을 날짜별로 — today: 오늘 보여 드린 화면 id · last: 화면 id → 오늘 전 마지막으로 보여 드린 날 */
  function seenMap() {
    var d = ymd(new Date()), hist = seenGet(), out = { today: '', last: {} };
    for (var i = 0; i < hist.length; i++) {
      if (hist[i].d === d) out.today = hist[i].id;
      else out.last[hist[i].id] = hist[i].d;          /* 뒤에 있는 것이 더 최근 — 덮어쓰면 마지막 날이 남는다 */
    }
    return out;
  }
  function seenPut(id) {
    if (!id) return;
    var d = ymd(new Date());
    var a = seenGet().filter(function (x) { return x.d !== d; });   /* 오늘 것은 마지막에 보여 드린 것 하나만 */
    a.push({ d: d, id: id });
    if (a.length > 14) a = a.slice(a.length - 14);
    try { localStorage.setItem(SEEN_K, JSON.stringify(a)); } catch (e) {}
  }

  /* ③ 관심사 후보 — 점수가 높은 것부터. 같은 화면이 여러 까닭으로 걸리면 점수가 높은 까닭 하나만 남긴다 */
  function interestList(st) {
    var now = Date.now(), DAY = 86400000, map = {}, out = [];
    function add(id, sc, why) {
      if (!oneCat(id)) return;                            /* 목록에 없는 화면(응급 등)은 여기서 걸러진다 */
      if (!has(map, id) || map[id].sc < sc) map[id] = { id: id, sc: sc, t: why };
    }
    /* 요즘(최근 사흘) 잦았거나 심했던 증상 — 몸에 대한 것이라 가장 앞 */
    var sy = topSym(st.recent);
    if (sy) {
      (SYM_SCR[sy.name] || []).forEach(function (id, i) {
        add(id, 100 + sy.score - i * 5, '요즘 ' + symSay(sy.name, sy.days >= 2 ? 'often' : 'sevDay'));
      });
    }
    /* 상담에서 나온 화면 (C1 · 2주 안) */
    var tp = lsJSON('todak_chat_topics');
    if (isArr(tp)) {
      tp.forEach(function (x) {
        if (!x || typeof x.id !== 'string') return;
        var id = x.id.replace(/\.html$/, ''), c = oneCat(id), age = now - (+x.t || 0);
        if (!c || !(age >= 0 && age < 14 * DAY)) return;
        add(id, 60 + (age < 3 * DAY ? 20 : age < 7 * DAY ? 10 : 0), '얼마 전 상담에서 ' + c.nm + ' 이야기가 나왔어요');
      });
    }
    /* 자주·최근에 보신 화면 (C2) */
    var vw = lsJSON('todak_views');
    if (vw && typeof vw === 'object' && !isArr(vw)) {
      for (var k in vw) {
        if (!has(vw, k) || !vw[k] || typeof vw[k] !== 'object') continue;
        var c2 = oneCat(k), n = +vw[k].n || 0, age2 = now - (+vw[k].t || 0);
        if (!c2 || !(age2 >= 0)) continue;
        if (n >= 2 && age2 < 30 * DAY) add(k, 50 + Math.min(n, 10) * 2 + (age2 < 3 * DAY ? 10 : 0), '요즘 ' + c2.nm + ' 안내를 자주 살펴보셨어요');
        else if (n >= 1 && age2 < 7 * DAY) add(k, 35, '최근에 ' + c2.nm + ' 안내를 보셨어요');
      }
    }
    /* 신경 쓰는 부작용 (14) — 고른 순서대로 */
    (isArr(st.concerns) ? st.concerns : []).forEach(function (cn, i) {
      if (typeof cn !== 'string' || !has(CONC_SCR, cn)) return;
      add(CONC_SCR[cn], 30 - Math.min(i, 10), cn + iGa(cn) + ' 신경 쓰인다고 하셨어요');
    });
    for (var id in map) if (has(map, id)) out.push(map[id]);
    /* 점수가 같으면 이름순 — 옛 웹뷰의 정렬이 불안정해도 날마다 같은 순서가 되게 */
    out.sort(function (a, b) { return b.sc - a.sc || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0); });
    return out;
  }
  /* 오늘 보여 드릴 관심사 하나 — 하루 안에서는 같은 것, 날이 바뀌면 최근 며칠 보여 드린 것은 건너뛴다.
     후보가 하나뿐인데 어제 보여 드린 것이면 null(→ 오늘의 팁)로 돌려 날마다 같은 글이 되지 않게 한다 */
  function pickInterest(cands) {
    if (!cands.length) return null;
    var now = new Date(), d = ymd(now), hist = seenGet(), last = {}, i, j;
    for (i = 0; i < hist.length; i++) {
      if (hist[i].d === d) { for (j = 0; j < cands.length; j++) if (cands[j].id === hist[i].id) return cands[j]; }
      else last[hist[i].id] = hist[i].d;                 /* 뒤에 있는 것이 더 최근 — 덮어쓰면 마지막 날이 남는다 */
    }
    var yday = ymd(addDays(now, -1));
    if (cands.length === 1) return last[cands[0].id] === yday ? null : cands[0];
    var K = Math.min(3, cands.length - 1), since = ymd(addDays(now, -K));
    for (i = 0; i < cands.length; i++) {
      var ld = last[cands[i].id];
      if (!ld || ld < since) return cands[i];
    }
    /* 모두 최근에 보여 드렸으면 가장 오래전에 보여 드린 것 */
    var pick = cands[0];
    for (i = 1; i < cands.length; i++) if ((last[cands[i].id] || '') < (last[pick.id] || '')) pick = cands[i];
    return pick;
  }
  /* ② 오늘 약을 챙기셨으면 — 등록하신 유방암 치료약(없으면 04 에서 고른 주사 치료)에서 생길 수 있는 불편 하나.
     druginfo.js 가 관리 화면 링크를 달아 둔 항목만 쓴다(링크 없는 항목은 연락 기준 같은 경고라 팁으로 가볍게 쓰지 않는다).
     '생길 수 있어요'까지만 말한다 — 발생을 단정하지 않는다(druginfo.js 원칙). 약·항목은 날마다 돌린다. */
  function drugOne(st) {
    if (!st.medTaken || !window.TDRUG) return null;
    var list = [], seen = {};
    function push(name, logged, inj) {
      var info = window.TDRUG.match(name);
      if (!info || !info.cancer || seen[info.title]) return;
      var effs = (info.effects || []).filter(function (e) {
        return e && typeof e.link === 'string' && oneCat(e.link.replace(/\.html$/, ''));
      });
      if (!effs.length) return;
      seen[info.title] = 1;
      list.push({ info: info, effs: effs, logged: logged, inj: !!inj });
    }
    (st.meds || []).forEach(function (m) { if (m && st.logged && st.logged[m.id]) push(m.name, true); });
    (st.meds || []).forEach(function (m) { if (m) push(m.name, false); });
    if (!list.length) (isArr(st.inj) ? st.inj : []).forEach(function (n) { if (typeof n === 'string') push(n, false, true); });
    if (!list.length) return null;
    /* 날마다 돌리기 — 2026-09-28 검수.
       예전에는 날짜로만 골라, 관리 화면 링크가 하나뿐인 약(타목시펜: 안면홍조·열감)은 약을 챙긴 날마다
       똑같은 글이 떴다. 날마다 약을 챙기시는 분에게는 이 카드가 늘 같은 글이 된다.
       그래서 (약, 불편) 짝을 날짜 순서대로 늘어놓고 최근에 보여 드린 화면은 건너뛴다(③ 과 같은 todak_tip_seen).
       화면이 하나뿐이면 어제 것만, 둘 이상이면 이틀 안에 보여 드린 것을 건너뛴다.
       모두 최근에 보여 드렸으면 null — ③ 관심사·④ 오늘의 팁으로 넘긴다. 하루 안에서는 같은 것을 유지한다. */
    var dn = tipDayNo(), pairs = [], used = {}, ids = {}, nIds = 0, k;
    for (k = 0; k < 60 && pairs.length < 12; k++) {
      var dk = dn + k, dr0 = list[dk % list.length], e0 = dr0.effs[Math.floor(dk / list.length) % dr0.effs.length];
      var key = dr0.info.title + '|' + e0.link;
      if (used[key]) continue;
      used[key] = 1;
      var id0 = e0.link.replace(/\.html$/, '');
      if (!ids[id0]) { ids[id0] = 1; nIds++; }
      pairs.push({ dr: dr0, e: e0, id: id0 });
    }
    var sm = seenMap(), pk = null, since = ymd(addDays(new Date(), -Math.min(2, nIds)));
    for (k = 0; k < pairs.length && !pk; k++) if (pairs[k].id === sm.today) pk = pairs[k];
    for (k = 0; k < pairs.length && !pk; k++) {
      var ld = sm.last[pairs[k].id];
      if (!ld || ld < since) pk = pairs[k];
    }
    if (!pk) return null;
    var dr = pk.dr, e = pk.e;
    var id = pk.id, c = oneCat(id), ttl = dr.info.title || '', cat = dr.info.cat || '';
    /* 조사는 괄호 앞 이름으로 — '캐싸일라(T-DM1)을(를)' 이 아니라 '캐싸일라(T-DM1)를' */
    var base = ttl.replace(/\s*\([^)]*\)\s*$/, '') || ttl;
    /* 주사로 맞는 약(항체·면역항암제 포함)에 '드시는'이라고 하지 않는다 — 엔허투·키트루다·캐싸일라·트로델비 (2026-09-28 검수) */
    var verb = /치료$/.test(base) ? '받으시는' : ((dr.inj || /주사|항체|면역항암/.test(ttl + cat)) ? '맞으시는' : '드시는');
    var how = String(e.d || '').replace(/\s+$/, '');
    if (how && !/[.!?]$/.test(how)) how += '.';
    /* 아래 글은 그 불편의 관리 화면 글(c.s)로 쓴다 — 약 안내의 짧은 조각('잦아지면 알리세요')보다 할 일·까닭이 또렷하다.
       다만 약 안내가 '알리세요'(담당 의료진에게 알리기)를 말하면 그 문장은 빼지 않고 뒤에 붙인다 */
    return { k: 'drug', id: id, t: ttl + eulReul(base) + ' ' + verb + ' 동안\n' + e.n + iGa(e.n) + ' 생길 수 있어요',
      s: (c.ds || c.s) + (how && /알리/.test(how) ? ' ' + how : ''),
      g: oneGo(c), p: id + '.html' };
  }
  /* ① 오늘 남기신 증상 — 없으면 null */
  function symOne(st) {
    var sm = seenMap(), yIds = {}, yd = ymd(addDays(new Date(), -1));
    for (var yk in sm.last) if (has(sm.last, yk) && sm.last[yk] === yd) yIds[yk] = 1;
    var a = todaySym(st.today, yIds);
    if (!a) return null;
    var ids = SYM_SCR[a.name], id = a.sev ? ids[0] : ids[tipDayNo() % ids.length], c = oneCat(id);
    if (!c) return null;
    /* 심하셨으면 늘 상세 화면으로 — 거기에 '이럴 땐 병원에'가 있다.
       상세 화면이 없는 증상(입맛 없음 → 식사 카드)에는 '병원에 연락할 때 보기'를 붙이지 않는다 — 그 칸이 없는 화면이다 */
    var toDoc = a.sev && /detail/.test(id);
    return { k: 'sym', id: id, t: c.h, s: c.s, g: toDoc ? c.g + ' · 병원에 연락할 때 보기' : oneGo(c), p: id + '.html' };
  }
  /* 오늘의 한 가지 고르기 — null 이면 ④ 오늘의 팁 */
  function chooseOne(st) {
    var a = symOne(st);
    if (a) return a;
    var b = drugOne(st);
    if (b) return b;
    var it = pickInterest(interestList(st));
    if (it) {
      var c3 = oneCat(it.id);
      return { k: 'int', id: it.id, t: c3.h, s: c3.s, g: oneGo(c3), p: it.id + '.html' };
    }
    return null;
  }
  /* 오늘 고른 한 가지 (이 기기에만) — {d:'YYYY-MM-DD', k, id, t, s, g, p, ci}
     ci: 오늘 증상 기록을 알고 고른 것인지. false 인데 기록이 생기면 딱 한 번 ① 로 바꿔 볼 수 있다 */
  var ONE_DAY_K = 'todak_one_day';
  function oneDayGet() {
    var v = lsJSON(ONE_DAY_K);
    if (!v || typeof v !== 'object' || v.d !== ymd(new Date())) return null;
    if (typeof v.id !== 'string' || typeof v.t !== 'string' || !v.t || typeof v.s !== 'string' || typeof v.g !== 'string') return null;
    if (typeof v.p !== 'string' || !/^\d{2}-[a-z0-9-]+\.html$/.test(v.p)) return null;   /* 주소로 쓰는 값 — 앱 화면 이름만 */
    return v;
  }
  function oneDayPut(o) {
    try { localStorage.setItem(ONE_DAY_K, JSON.stringify(o)); } catch (e) {}
  }
  function paintOne(card, st) {
    if (!card) return;
    var hasCi = !!(st && st.today), one = oneDayGet();
    /* 하루 한 번 고른 것은 그날 내내 그대로 — 약을 챙기셨거나(②) 안내 화면을 보셨다고(③) 바꾸지 않는다.
       바꾸는 때는 딱 한 번: 먼저 고른 뒤에 오늘 증상 기록을 남기셨을 때 — 남기신 증상(①)이 있으면 그것으로. 그 뒤로는 그대로 */
    if (one && !one.ci && hasCi) {
      var a1 = null;
      try { a1 = symOne(st); } catch (eA) { a1 = null; }
      if (a1) { a1.d = one.d; one = a1; }
      one.ci = true;
      oneDayPut(one);
    }
    if (!one) {
      try { one = chooseOne(st); } catch (eO) { one = null; }   /* 이 기기에 남은 값이 이상해도 홈이 멈추지 않게 — 오늘의 팁으로 */
      if (!one) one = tipPick((st && st.concerns) || []);
      one.d = ymd(new Date());
      one.ci = hasCi;
      oneDayPut(one);
    }
    var ttl = $('.card-title', card), sub = $('.card-sub', card), go = $('.tip-go', card);
    /* '안면홍조·열감이'처럼 가운뎃점으로 이은 말은 점 앞뒤에서 줄이 갈리지 않게 묶는다 — 412px 에서 '·열감이'가 줄 머리에 왔다 */
    function nwDots(el, txt) {
      el.innerHTML = esc(txt).replace(/[^\s·]+(?:·[^\s·]+)+/g, function (w) { return '<span class="nw">' + w + '</span>'; })
        .replace(/\n/g, '<br>');   /* 약 안내 제목은 '○○를 드시는 동안' 뒤에서 끊는다 */
    }
    if (ttl) nwDots(ttl, one.t);
    /* 풀이는 문장마다 한 줄(.tip-l — 05-home.html 이 block 으로 세운다). 할 일과 까닭이 한 덩이로 이어지면
       폭마다 줄 끝에 '보세요.'·'쉬워요.'만 떨어졌다 (2026-09-28 검수). 옛 05-home.html(캐시)에서는 띄어쓰기로 이어 읽힌다.
       '38.0도'처럼 점 뒤에 빈칸이 없으면 나누지 않는다 */
    if (sub) {
      sub.innerHTML = '';
      String(one.s || '').replace(/([.!?])\s+(?=\S)/g, '$1\n').split('\n').forEach(function (sn, i) {
        var ln = document.createElement('span');
        ln.className = 'tip-l';
        nwDots(ln, sn);
        if (i) sub.appendChild(document.createTextNode(' '));
        sub.appendChild(ln);
      });
    }
    if (go) nwDots(go, one.g + ' ›');
    card.setAttribute('href', one.p + '?from=05-home.html');
    $$('[data-demo]', card).forEach(function (el) { el.removeAttribute('data-demo'); });
    seenPut(one.id);
  }

  /* 55 의 시안 예시 줄을 가려내는 자(74·75 로 가는 링크). 웹앱에서는 주소에서 '.html' 이 떨어지므로 이름만 본다 */
  var RX_EFF = /(^|\/)(74-med-effect-detail|75-med-effect-none)(\.html)?($|[?#])/;

  /* ── 05 홈 ── */
  function page05() {
    /* 시안 예시값(data-demo)은 app-device.css 가 가려 두고, 배선이 '실제로 칠한 자리만' 드러낸다.
       예전에는 찾았든 못 찾았든 전부 드러내서, 링크 선택자가 빗나간 웹앱에서 '1/2 완료' 같은
       거짓 숫자가 그대로 드러났다. 이제 못 칠한 자리는 드러내지 않고 아래 마무리에서 비운다. */
    function shown(el) { if (el) el.removeAttribute('data-demo'); }
    function showEl(el, on) { if (el) el.style.display = on ? '' : 'none'; }
    function isEve() { return new Date().getHours() >= 17; }   /* 오후 5시(기기 시각)부터 '하루를 돌아보는' 때 */
    /* 인사 — 오후 5시부터는 묻지 않고 다독인다. 아래 '지금 할 일'이 '오늘 하루 어떠셨어요?'를 묻기 때문에
       위아래에서 같은 질문을 두 번 하지 않게 (2026-09-28) */
    var greetName = null;
    function paintGreet() {
      var h1g = $('.greet h1') || $('h1');
      if (!h1g) return;
      var who = greetName === null ? '안녕하세요,' : esc(greetName) + '님,';
      /* 첫 줄은 .greet-who 로 감싼다 — 오른쪽에 겹쳐 선 알림 단추 자리를 이 줄만 비켜 간다(05-home.html, 2026-10-01) */
      var whoH = '<span class="greet-who">' + who + '</span>';
      /* 저녁 인사는 이름 뒤에서 끊는다 — '○○님, 오늘 하루도 / 고생하셨어요'로 두면 글자를 키운 폰(200%)에서
         '하루도'만 한 줄로 떨어졌다 (2026-09-28 검수) */
      h1g.innerHTML = whoH + (isEve() ? '<br>오늘 하루도 고생하셨어요' : '<br>오늘 컨디션은 어떠세요?');
      shown(h1g);
    }
    paintGreet();   /* 불러오기 전 시안 이름이 보이지 않게 */
    try { sessionStorage.removeItem('todak_onboard'); sessionStorage.removeItem('todak_edit'); } catch (e05) {}
    /* 상단 인사 칸 접기는 없앤다.
       아래로 내릴 때 접고 위로 올릴 때 펴는 배선이 있었는데, 접히는 순간 .content 가 118px 높아져
       (390×664 실측) 맨 아래에 있으면 브라우저가 스크롤 위치를 그만큼 당겼다. 이 당김을 여기서
       '위로 올렸다'로 읽어 다시 펴고, 펴면 또 당겨지고 — 아래로 내려갈수록 화면이 떨렸다.
       지금은 인사 칸을 .content 안 맨 위에 두어(05-home.html) 내용과 함께 위로 흘러가게 한다.
       옆 판 app.css 가 캐시에 남아 is-slim 규칙이 살아 있을 수 있으니, 혹시 붙어 있으면 떼어 둔다. */
    (function () {
      var head0 = $('.brandhead');
      if (head0) head0.classList.remove('is-slim');
    })();
    /* '내가 신경 쓰는 부작용' — 시안의 예시 칩(손발 저림·관절통·탈모·재발 걱정)은 불러오기 전에 먼저 비운다 */
    var cLab = $$('.section-label').filter(function (s) { return s.textContent.indexOf('신경 쓰는') > -1; })[0];
    var cBox = cLab ? $('.chips', cLab.parentNode.parentNode) : null;
    var cBase = cBox ? $('a.chip', cBox) : null;
    var cStyle = (cBase && cBase.getAttribute('style')) || 'text-decoration:none;';
    if (cBox) { cBox.innerHTML = ''; shown(cBox); }
    /* 불러오기 전 시안 숫자(다음 진료까지 16일, 복약 1/2 완료, 반쯤 찬 고리)가 보이지 않게
       알림띠와 두 고리를 먼저 중립 글로 바꾼다 — 실제 값은 아래 getProfile·checkins·medications 응답이 채운다 */
    /* 홈의 73 링크에는 '?from=05-home.html' 이 붙고, 웹앱(Netlify)에서는 '.html' 이 떨어져 나가
       '/73-cycle-setup?from=…' 이 된다. 앞뒤 어느 쪽도 정확하지 않으므로 이름만 들어 있으면 찾는다(*=). */
    var pill0 = $('a[href*="73-cycle-setup"]', $('.greet'));
    if (pill0) {
      if (pill0.children[0]) { pill0.children[0].textContent = '진료 일정'; shown(pill0.children[0]); }
      if (pill0.children[1]) { pill0.children[1].textContent = ' · 불러오는 중…'; shown(pill0.children[1]); }
    }
    /* 두 고리 — 이제 고리 줄에 data-role 을 붙였다. 캐시에 남은 옛 05-home.html 과 섞여도 걸리게 옛 선택자를 뒤에 둔다
       ('지금 할 일'의 버튼도 16·55 로 가지만 a.btn 이라 a.card 선택자에는 걸리지 않는다) */
    var ciCard = $('[data-role="ci-ring"]') || $('a.card[href*="16-checkin"]');
    var medCard = $('[data-role="med-ring"]') || $('a.card[href*="55-med-today"]');
    var ciWrap = $('[data-role="ci-card"]'), ciHint = $('[data-role="ci-hint"]');
    /* 약 목록을 확인하기 전에는 '오늘의 복약'을 먼저 보여 주지 않는다. 등록한 약이 있을 때만 loadMeds 가 연다. */
    showEl(medCard, false);
    [ciCard, medCard].forEach(function (cd) {
      if (!cd) return;
      var rg0 = $('.ring', cd), ri0 = $('.ring-in', cd);
      if (rg0) rg0.style.setProperty('--p', '0%');
      if (ri0) ri0.innerHTML = '확인<br>중';
      shown(rg0);                       /* 칠했으니 이 자리만 드러낸다 */
    });
    /* 지금 할 일 — 시안 예시(약 3개 중 2개)가 비치지 않게 중립 글로 바꾸고 버튼은 숨긴다. paintNow 가 채운다 */
    var nowCard = $('[data-role="now-card"]');
    var nowT = nowCard ? $('.now-t', nowCard) : null, nowS = nowCard ? $('.now-s', nowCard) : null;
    var nowGo = nowCard ? $('.now-go', nowCard) : null, nowMore = null;
    /* 2026-09-28 교수님: '오늘의 복약'을 지금 할 일 묶음 안(버튼 아래)으로 — 카드 안 윗부분(.now-main)이 '지금 할 일',
       아랫부분(.now-rows)이 오늘의 복약·오늘 컨디션 줄이다. 옛 05-home.html(캐시)에는 .now-main 이 없어 카드 전체로 한다 */
    var nowMain = nowCard ? ($('.now-main', nowCard) || nowCard) : null;
    if (nowCard) {
      if (nowT) { nowT.textContent = '오늘 챙길 것을 확인하고 있어요'; shown(nowT); }
      if (nowS) { nowS.textContent = ''; nowS.style.display = 'none'; shown(nowS); }
      if (nowGo) { nowGo.style.display = 'none'; shown(nowGo); }
    }
    /* 오늘의 한 가지 — 시안 글(관절 뻣뻣함)이 잠깐이라도 비치지 않게, 이 카드만은 paintOne 이 칠할 때 드러낸다 */
    var tipCard = $('#tip-card');
    /* 불러오기 전 시안 글이 비치지 않게, 먼저 중립 글로 칠하고 드러낸다 */
    if (tipCard) {
      var t0 = $('.card-title', tipCard), s0 = $('.card-sub', tipCard), g0 = $('.tip-go', tipCard);
      if (t0) t0.textContent = '오늘의 정보를 준비하고 있어요';
      if (s0) s0.textContent = '';
      if (g0) g0.textContent = '';      /* '관절 뻣뻣함 자세히 보기'가 비치지 않게 — paintOne 이 채운다 */
      shown(t0); shown(s0); shown(g0);
      try { tipCard.removeAttribute('data-demo'); } catch (eT) {}
    }
    /* 프로필·오늘 기록·약이 오면 안내를 고른다. 늦으면 4초 뒤 받은 정보로 먼저 보여 준다.
       medTaken: 오늘 챙기신 기록이 하나라도 있는지 · logged: 오늘 챙기신 약 id · inj: 04 에서 고른 주사 치료 */
    var ONE = { concerns: [], recent: null, today: null, meds: [], logged: {}, medTaken: false, inj: [] };
    var oneGot = { prof: false, ci: false, med: false }, oneDone = false;
    function oneShow() {
      if (oneDone) return;
      oneDone = true;
      clearTimeout(tipTimer);
      paintOne(tipCard, ONE);
    }
    function oneReady(k) {
      oneGot[k] = true;
      /* 통신이 느려 4초 지킴이로 먼저 골랐는데 오늘 기록이 뒤늦게 왔으면 — 지금 이 화면에서 바로 한 번 바꿔 본다.
         그냥 두면 다음에 홈을 열 때 바뀌어, 하루 중간에 글이 바뀐 것처럼 보인다. paintOne 은 하루 한 번만 바꾼다.
         기록이 셋 중 마지막으로 와도 여기로 온다 — 예전에는 oneShow 로 가서(이미 끝남) 그냥 지나갔다 (2026-09-29 검수) */
      if (oneDone) { if (k === 'ci') paintOne(tipCard, ONE); return; }
      if (oneGot.prof && oneGot.ci && oneGot.med) oneShow();
    }
    var tipTimer = setTimeout(oneShow, 4000);
    /* 마무리 — 여기까지도 남아 있는 시안 값은 배선이 끝내 칠하지 못한 자리다.
       가림막만 걷으면 거짓이 드러나므로(옛 웹뷰는 가림막 자체를 모를 수도 있다) 내용을 비운다.
       고리는 통째로 비우면 동그라미까지 사라지니 '모름(－)'으로 적는다. */
    $$('[data-demo]').forEach(function (el) {
      el.removeAttribute('data-demo');
      var ri9 = $('.ring-in', el);
      if (ri9) { el.style.setProperty('--p', '0%'); ri9.innerHTML = '－'; return; }
      while (el.firstChild) el.removeChild(el.firstChild);
    });
    /* ── 치료 일정 알림띠도 같은 병을 앓았다 ── 2026-09-28
       통신이 '멈추면'(응답도 거절도 오지 않으면) getProfile 의 어느 자리도 불리지 않아
       ' · 불러오는 중…'이 영원히 남았다. 두 고리와 같은 8초를 두고, 못 불러왔을 때와 같은 말로 바꾼다.
       거짓 숫자는 쓰지 않는다 — 주기·진료일을 지어내지 않고 '눌러서 확인해 보세요'로만 보낸다.
       뒤늦게 응답이 오면 아래 getProfile 이 다시 칠하므로 스스로 낫는다.
       다시 읽기(reread)는 프로필을 다시 읽지 않으므로 이 지킴이는 한 번만 건다. */
    var profSeen = false;
    setTimeout(function () {
      if (profSeen || !pill0) return;
      if (pill0.children[0]) pill0.children[0].textContent = '진료 일정';
      if (pill0.children[1]) pill0.children[1].textContent = ' · 눌러서 확인해 보세요 ›';
    }, 8000);
    getProfile(function (p, pErr) {
      profSeen = true;
      /* 팁에 쓸 관심 항목·주사 치료. 같은 프로필로 아래 치료 일정과 부작용 칩도 채운다. */
      if (!pErr && p && isArr(p.concerns)) ONE.concerns = p.concerns;
      if (!pErr && p && p.treatment && isArr(p.treatment.injections)) {
        ONE.inj = p.treatment.injections.filter(function (n) { return n !== '없어요' && n !== '잘 모르겠어요'; });
      }
      oneReady('prof');
      /* 약이 곧 떨어져요 줄이 진료 일정과 맞춰 말하도록 — 못 불러왔으면 진료 이야기 없이 */
      ONE.treat = (!pErr && p && p.treatment && typeof p.treatment === 'object') ? p.treatment : null;
      paintRx(); paintNow();
      greetName = (p && typeof p.name === 'string' && p.name) || '회원';   /* 예전과 같다 — 못 불러왔으면 '회원님' */
      paintGreet();
      /* 진료 일정 알림띠 — 다음 진료만 알린다 (2026-10-01 교수님: '항암 1주기 3일차'가 떴는데 항암 치료 중인지 모르잖아).
         항암 시작일·주기(chemo_start·cycle_weeks)는 예전 73 화면이 받던 값이다. 지금 73 은 진료 날짜만 받으므로
         예전 값이 남아 있어도 주기를 세지 않는다 — 04 에서 고른 치료가 무엇이든 '항암 ○주기'로 짐작해 말하지 않게.
         다음 진료 = 73 이 저장한 진료 목록(visits)과 next_visit 가운데 오늘이거나 그 뒤인 가장 가까운 날
         (73 의 '다음 진료까지 ○일'과 같은 날짜 셈 — 시각은 보지 않고 날짜끼리 뺀다) */
      var pill = $('a[href*="73-cycle-setup"]', $('.greet'));
      if (pill) {
        var s1 = pill.children[0], s2 = pill.children[1];
        var t = (p && p.treatment && typeof p.treatment === 'object') ? p.treatment : {};
        /* 'YYYY-MM-DD' 이고 달력에 있는 날짜('2026-02-30' 아님)일 때만 */
        var okDay = function (v) {
          var m = typeof v === 'string' && /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
          if (!m) return false;
          var d = new Date(+m[1], +m[2] - 1, +m[3]);
          return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
        };
        var td0 = ymd(new Date()), days0 = [];
        if (Object.prototype.toString.call(t.visits) === '[object Array]') {
          t.visits.forEach(function (v) { if (v && okDay(v.d)) days0.push(v.d); });
        }
        if (okDay(t.next_visit)) days0.push(t.next_visit);
        var nextV = days0.filter(function (d) { return d >= td0; }).sort()[0] || null;
        if (pErr) {
          /* 못 불러왔으면 '등록해 주세요'로 잘못 안내하지 않는다 */
          if (s1) s1.textContent = '진료 일정';
          if (s2) s2.textContent = ' · 눌러서 확인해 보세요 ›';
        } else if (nextV) {
          var dN = new Date(nextV + 'T00:00:00');
          var dv = Math.round((dN - new Date(td0 + 'T00:00:00')) / 86400000);
          if (s1) s1.textContent = dv === 0 ? '오늘 진료가 있어요' : '다음 진료까지 ' + dv + '일';
          if (s2) s2.textContent = dv === 0 ? ' · 일정 보기 ›' : ' · ' + kdate(dN) + '(' + WDAY[dN.getDay()] + ') ›';
        } else if (days0.length) {
          /* 넣어 두신 진료가 모두 지났을 때 */
          if (s1) s1.textContent = '다음 진료 일정';
          if (s2) s2.textContent = ' · 눌러서 넣어 주세요 ›';
        } else {
          if (s1) s1.textContent = '진료 일정 등록';
          if (s2) s2.textContent = ' · 눌러서 입력해 주세요 ›';
        }
      }
      /* 내가 신경 쓰는 부작용 → concerns (14 에서 고를 수 있는 12개 모두 상세 화면으로) */
      var MAPC = {
        '손발 저림': ['🖐️', '15-sideeffect-detail.html'],
        '관절통': ['🦴', '34-detail-arthralgia.html'],
        '머리카락 빠짐': ['💇‍♀️', '32-detail-hairloss.html'],
        '메스꺼움·구토': ['🤢', '60-food-nausea.html'],
        '입안 헐음': ['😷', '62-food-mucositis.html'],
        '안면홍조·열감': ['🔥', '35-detail-hotflash.html'],
        '피로': ['🔋', '33-detail-fatigue.html'],
        '수면 문제': ['😴', '46-detail-sleep.html'],
        '불안·재발 걱정': ['💭', '47-detail-anxiety.html'],
        '성 건강': ['🌸', '43-detail-dryness.html'],
        '음식·영양': ['🥗', '09-food-supplement.html'],
        '건강기능식품': ['💊', '09-food-supplement.html']
      };
      if (!cBox) return;
      if (pErr) return;                  /* 불러오지 못했으면 비워 둔다 — 고른 적 없는 항목을 보여주지 않게 */
      if (p.concerns && p.concerns.length) {
        p.concerns.slice(0, 4).forEach(function (cn) {
          var m = MAPC[cn] || ['🌷', '06-sideeffects.html'];
          var a = document.createElement('a');
          a.className = 'chip chip--soft';
          a.setAttribute('style', cStyle);
          a.href = m[1] + '?from=05-home.html';
          a.textContent = m[0] + ' ' + cn;
          cBox.appendChild(a);
        });
      } else {
        /* 아직 고른 게 없으면 14 에서 고르게 한다 (저장하면 홈으로 돌아온다) */
        var pick = document.createElement('a');
        pick.className = 'chip';
        pick.setAttribute('style', cStyle);
        pick.href = '14-concerns.html?from=05-home.html';
        pick.textContent = '＋ 부작용 고르기';
        cBox.appendChild(pick);
      }
    });

    /* ── 오늘 기록·약의 지금 상태 ── '지금 할 일'과 오늘 컨디션 줄이 함께 본다
       ci : wait(불러오는 중) · rec(오늘 남기심) · none(아직) · fail(못 불러옴)
       med: wait · ok · fail — ok 일 때 count(등록한 약 수)·due(오늘 챙길 칸 수)·left(아직 안 챙긴 칸 [{slot, tm(분·모르면 -1)}]) */
    var CI = { st: 'wait' }, MED = { st: 'wait', count: 0, due: 0, left: [] };
    var nowForce = false;                 /* 8초 지킴이가 돌았으면 불러오는 중이어도 아는 만큼으로 그린다 */

    /* ── 오늘 컨디션 줄·'오늘 뭐가 제일 힘드셨나요?' 보이기 ── 2026-09-28
       하루를 돌아보며 남기는 기록이라 오후 5시(기기 시각)부터 카드 전체를 보여 준다.
       그 전에는 한 줄 안내만 둔다 — 아침에 몸이 안 좋은 분도 거기서 바로 남기실 수 있다.
       오늘 이미 남기셨으면 시각과 상관없이 예전처럼 카드('기록 완료')를 보여 준다.
       '지금 할 일'이 증상 기록을 가리키고 있으면 카드의 고리 줄은 접는다(같은 버튼이 두 번 보이지 않게) — 칩은 남긴다.
       옛 05-home.html(캐시)에는 이 칸들이 없어 예전처럼 늘 보인다. */
    function paintCi() {
      if (!ciWrap) return;
      var on = CI.st === 'rec' || isEve();
      showEl(ciWrap, on);
      showEl(ciHint, !on);
      var fold = on && NOW.kind === 'ci';
      showEl(ciCard, on && !fold);       /* 오후 5시 전(기록 전)에는 한 줄 안내가 이 자리에 선다 */
      ciWrap.classList[fold ? 'add' : 'remove']('no-top');
    }
    /* ── 지금 할 일 ── 2026-09-28
       교수님 말씀: 홈에 들어왔을 때 무엇을 하면 되는지 바로 보이지 않는다(체크리스트·둘러보기는 원치 않으심).
       그래서 인사 바로 아래 한 칸에 '지금 챙길 것 하나'만 적는다. 채운 버튼은 홈 전체에서 여기 하나뿐이다.
       고르는 순서(기기 시각):
         1) 드실 때가 된(지난 것 포함, 앞으로 1시간 안) 약이 아직이면  → 오늘 챙기실 약 N개 중 M개 남았어요 · 오늘의 복약
         2) 오후 5시부터, 오늘 컨디션을 아직 안 남기셨으면         → 오늘 하루 어떠셨어요? · 증상 기록
         3) 오늘 남은 약이 뒤에 있으면                                → N개 중 M개 남았어요 · 다음은 언제 (1시간보다 뒤면 버튼 없이 알리기만)
         4) 등록한 약이 없으면                                        → 먹는 약을 등록하면 시간에 맞춰 알려 드려요 · 약 등록
         5) 다 하셨으면                                               → 조용한 한 줄 + 오늘의 한 가지로
       모르는 것은 아는 척하지 않는다 — 약을 못 불러왔으면 '다 하셨어요'라고 하지 않고 이 칸을 접는다
       (못 불러왔다는 말과 다시 열기는 두 고리 아래 띠가 한다). */
    var NOW = { kind: '', go: false }, VQ = { on: false };
    /* 오늘의 복약 줄 — '지금 할 일' 버튼이 이미 오늘의 복약을 열고 있으면 접는다 (교수님 2026-10-01: 오늘의 복약이 두 번 보인다).
       컨디션 줄(paintCi)과 같은 규칙이다. 버튼이 없을 때(다음 약이 1시간보다 뒤 · 다 하셨을 때 · 컨디션 차례)는
       이 줄이 오늘의 복약으로 가는 길이라 그대로 둔다. 약이 몇 개 남았는지는 버튼 위 글('오늘 챙기실 약 2개 중 1개 남았어요')이 말한다.
       medHas: 등록한 약이 있고 목록을 받아 왔는지 (loadMeds 가 정한다) */
    var medHas = false;
    function paintMedRow() {
      if (!medCard) return;
      showEl(medCard, medHas && !(NOW.kind === 'med' && NOW.go));
    }
    var SLOT_NM = { '아침': '아침', '점심': '점심', '저녁': '저녁', '자기전': '자기 전' };
    function hmMin(v) {
      var mm = typeof v === 'string' && /^(\d{1,2}):(\d{2})$/.exec(v);
      return mm ? (+mm[1]) * 60 + (+mm[2]) : -1;
    }
    /* 약을 등록하지 않으셨는데 '지금 할 일' 윗칸이 다른 일(저녁의 컨디션 남기기)을 가리키면
       아래 줄에 '약 등록하기'를 둔다 — 저녁에도 약 등록 길이 지금 할 일에서 사라지지 않게 (교수님 2026-09-30).
       윗칸이 이미 약 등록을 가리키면 같은 말을 두 번 적지 않는다. */
    var regRow = null;
    function paintRegRow(kind) {
      var rowsBox = nowCard ? $('.now-rows', nowCard) : null;
      var want = !!rowsBox && MED.st === 'ok' && !MED.count && kind !== 'reg' && kind !== 'hide' && kind !== 'wait';
      if (!want) { if (regRow) showEl(regRow, false); return; }
      if (!regRow) {
        regRow = document.createElement('a');
        regRow.className = 'now-row';
        regRow.setAttribute('data-role', 'reg-row');
        regRow.setAttribute('href', '58-med-manual.html?from=05-home.html');
        regRow.innerHTML = '<span class="li-ic" aria-hidden="true" style="width:48px;height:48px;flex:0 0 48px;border-radius:14px;'
          + 'background:var(--primary-tint);display:grid;place-items:center;font-size:24px;">💊</span>'
          + '<div class="grow"><div class="card-title">약 등록하기</div>'
          + '<div class="card-sub">먹는 약을 등록하면 시간에 맞춰 알려 드려요</div></div>'
          + '<span class="li-chev" aria-hidden="true">›</span>';
        rowsBox.insertBefore(regRow, rowsBox.firstChild);
      }
      $('.card-title', regRow).textContent = VQ.on ? '새로운 약을 처방받으셨나요?' : '약 등록하기';
      $('.card-sub', regRow).textContent = VQ.on ? '받으셨다면 약을 추가해 주세요' : '먹는 약을 등록하면 시간에 맞춰 알려 드려요';
      showEl(regRow, true);
    }
    /* 약이 곧 떨어져요 — 며칠분이 1~3일 남은 약이 있으면 오늘의 복약 줄 바로 아래에 한 줄 (교수님 2026-09-30).
       규칙·글은 native.js RX(알림과 같은 규칙) — 떨어지기 전에 진료가 있으면 '그 진료 때 처방을 받아 오세요',
       진료가 그 뒤면 '다음 진료보다 먼저 떨어져요'. 앱 화면이라 약 이름을 쓴다(잠금화면 알림에는 이름을 넣지 않는다).
       약 종류로 말을 바꾸지 않고 늘 '계속 드시는 약이면'을 붙인다(며칠만 드시는 항구토제 같은 약도 있어서).
       누르면 복약 설정(56) — 약마다 '며칠분 · 언제까지'가 적혀 있다. 약이 하나면 그 약 카드로 데려간다. */
    /* ── 진료 뒤 '새로운 약을 처방받으셨나요?' (교수님 2026-09-30) ──
       73 에 적으신 진료 시각(시각을 모르면 낮 12시)이 지나면 그날과 다음 날까지 '지금 할 일'에서 여쭙는다.
       · 약을 등록하신 분: 오늘의 복약 줄 아래 한 줄 — [약 추가하기] [받지 않았어요]
       · 약이 없는 분: 윗칸·아랫줄의 '약 등록' 안내를 이 말로 바꾼다(같은 말을 두 번 적지 않게)
       '받지 않았어요'를 누르시면(이 기기) 또는 진료 뒤에 약을 추가·다시 세셨으면 그 진료에 대해서는 다시 묻지 않는다.
       같은 약을 다시 추가하시면 58·54 가 '새로 받아 왔어요'(며칠분만 다시 세기)를 여쭙는다. */
    var VQ_OFF = 'todak_visit_ask_off';
    var MED_ADDED = 'todak_med_added_at';
    var vqRow = null;
    function vqVisit() {
      var t = ONE.treat, now = new Date(), best = null, list = [];
      if (!t || MED.st !== 'ok') return null;
      if (Object.prototype.toString.call(t.visits) === '[object Array]') t.visits.forEach(function (v) { if (v) list.push({ d: v.d, t: v.t }); });
      if (t.next_visit) list.push({ d: t.next_visit, t: t.next_visit_time });
      list.forEach(function (v) {
        var m = typeof v.d === 'string' && /^(\d{4})-(\d{2})-(\d{2})$/.exec(v.d);
        if (!m) return;
        var hm = typeof v.t === 'string' && /^(\d{1,2}):(\d{2})$/.exec(v.t);
        var at = new Date(+m[1], +m[2] - 1, +m[3], hm ? +hm[1] : 12, hm ? +hm[2] : 0);
        if (at <= now && (!best || at > best.at)) best = { d: v.d, at: at };
      });
      if (!best) return null;
      if (now >= new Date(best.at.getFullYear(), best.at.getMonth(), best.at.getDate() + 2)) return null;   /* 다음 날까지만 */
      var off = '';
      try { off = localStorage.getItem(VQ_OFF) || ''; } catch (eL) {}
      if (off === best.d) return null;
      /* 진료 뒤에 약을 넣으셨거나(새 줄) 며칠분을 다시 세셨으면 이미 하신 것으로 본다.
         58·54 가 약을 넣거나 다시 센 시각을 이 기기에 적어 둔다(MED_ADDED) — 진료 당일에 다시 세면 시작일이 진료일과 같아
         날짜만으로는 가릴 수 없고, 며칠분을 비우고 다시 세면 시작일이 아예 없다 (2026-10-01 검토) */
      var added = null;
      try { added = new Date(localStorage.getItem(MED_ADDED) || ''); } catch (eA) { added = null; }
      if (added && !isNaN(added.getTime()) && added >= best.at) return null;
      var done = (ONE.meds || []).some(function (m) {
        var c = m && m.created_at ? new Date(m.created_at) : null;
        var st = m && m.schedule && m.schedule.startedOn;
        return (c && !isNaN(c.getTime()) && c >= best.at) || (typeof st === 'string' && st > best.d);
      });
      return done ? null : best;
    }
    function paintVq() {
      var v = vqVisit();
      VQ.on = !!v;
      var want = VQ.on && MED.count > 0 && !!medCard && !!medCard.parentNode;
      if (!want) { if (vqRow) showEl(vqRow, false); return; }
      if (!vqRow) {
        vqRow = document.createElement('div');
        vqRow.className = 'now-row';
        vqRow.setAttribute('data-role', 'vq-row');
        vqRow.style.alignItems = 'flex-start';
        vqRow.innerHTML = '<span class="li-ic" aria-hidden="true" style="width:48px;height:48px;flex:0 0 48px;border-radius:14px;'
          + 'background:var(--secondary-tint);display:grid;place-items:center;font-size:24px;">🏥</span>'
          + '<div class="grow"><div class="card-title">새로운 약을 처방받으셨나요?</div>'
          + '<div class="card-sub">받으셨다면 약을 추가해 주세요</div>'
          + '<div class="row" style="gap:8px; margin-top:10px; flex-wrap:wrap;">'
          + '<a class="btn btn-outline btn-sm" href="58-med-manual.html?from=05-home.html">💊 약 추가하기</a>'
          + '<button type="button" class="btn btn-ghost btn-sm" data-role="vq-off">받지 않았어요</button></div></div>';
        $('[data-role="vq-off"]', vqRow).addEventListener('click', function () {
          var v0 = vqVisit();
          if (v0) { try { localStorage.setItem(VQ_OFF, v0.d); } catch (eS) {} }
          paintVq(); paintNow();
        });
      }
      var anchor = (rxRow && rxRow.parentNode === medCard.parentNode && rxRow.style.display !== 'none') ? rxRow : medCard;
      if (vqRow.parentNode !== medCard.parentNode || vqRow.previousSibling !== anchor) medCard.parentNode.insertBefore(vqRow, anchor.nextSibling);
      showEl(vqRow, true);
    }
    var rxRow = null;
    function paintRx() {
      var RXm = window.TDN && window.TDN.rx;
      /* 오늘 진료 시각이 이미 지났으면 '오늘 진료 때 처방을 받아 오세요'는 늦은 말이다 — 지난 오늘 진료는 빼고 다음 진료로 본다
         (알림은 오전 9시라 그대로 둔다 · 2026-10-01 검증: 10:30 진료 뒤 14:00 홈에 '오늘 진료 때'가 남았다) */
      var treatRx = ONE.treat || null;
      if (treatRx) {
        var nowR = new Date(), tdR = ymd(nowR), nmR = nowR.getHours() * 60 + nowR.getMinutes();
        var gone = function (v) {
          if (!v || v.d !== tdR) return false;
          var mm = typeof v.t === 'string' && /^(\d{1,2}):(\d{2})$/.exec(v.t);
          return (mm ? (+mm[1]) * 60 + (+mm[2]) : 12 * 60) <= nmR;
        };
        var vsR = Object.prototype.toString.call(treatRx.visits) === '[object Array]' ? treatRx.visits : [];
        var nvGone = treatRx.next_visit === tdR && gone({ d: tdR, t: treatRx.next_visit_time });
        if (nvGone || vsR.some(gone)) {
          var t2 = {}, kR;
          for (kR in treatRx) if (Object.prototype.hasOwnProperty.call(treatRx, kR)) t2[kR] = treatRx[kR];
          t2.visits = vsR.filter(function (v) { return !gone(v); });
          if (nvGone) t2.next_visit = null;
          treatRx = t2;
        }
      }
      var p = RXm && ONE.meds ? RXm.on(ONE.meds, treatRx, RXm.dayOf(new Date())) : null;
      if (!p || !medCard || !medCard.parentNode) { if (rxRow) showEl(rxRow, false); return; }
      if (!rxRow) {
        rxRow = document.createElement('a');
        rxRow.className = 'now-row';
        rxRow.setAttribute('data-role', 'rx-row');
        rxRow.innerHTML = '<span class="li-ic" aria-hidden="true" style="width:48px;height:48px;flex:0 0 48px;border-radius:14px;'
          + 'background:var(--warn-tint);display:grid;place-items:center;font-size:24px;">📦</span>'
          + '<div class="grow"><div class="card-title rx-t"></div><div class="card-sub rx-who" style="font-weight:700;"></div>'
          + '<div class="card-sub rx-how"></div></div>'
          + '<span class="li-chev" aria-hidden="true">›</span>';
      }
      if (rxRow.parentNode !== medCard.parentNode || rxRow.previousSibling !== medCard) medCard.parentNode.insertBefore(rxRow, medCard.nextSibling);
      var w = RXm.row(p);
      $('.rx-t', rxRow).textContent = w.title;
      $('.rx-who', rxRow).textContent = w.who;
      $('.rx-how', rxRow).textContent = w.how;
      rxRow.setAttribute('href', '56-med-schedule.html?from=05-home.html' + (p.meds.length === 1 && p.meds[0].id != null ? '&m=' + encodeURIComponent(p.meds[0].id) : ''));
      showEl(rxRow, true);
      paintVq();                          /* 새 약 줄은 곧 떨어져요 줄 아래로 */
    }
    function nowSet(kind, t, s, go) {
      NOW.kind = kind;
      NOW.go = !!go;
      paintRegRow(kind);
      paintMedRow();
      if (!nowCard) return;
      showEl(nowMain, kind !== 'hide');
      nowCard.classList[kind === 'hide' && nowMain !== nowCard ? 'add' : 'remove']('now-bare');   /* 안내를 접으면 줄 위 구분선도 뺀다 */
      if (kind === 'hide') return;
      if (nowT) nowT.textContent = t;
      if (nowS) { nowS.textContent = s || ''; showEl(nowS, !!s); }
      if (nowGo) {
        if (go) { nowGo.textContent = go[0]; nowGo.setAttribute('href', go[1]); }
        showEl(nowGo, !!go);
      }
      /* 다 하셨을 때 — 버튼 대신 오늘의 한 가지로 내려 주는 글 링크 하나 */
      var calm = kind === 'done' && !!tipCard;
      if (calm && !nowMore) {
        nowMore = document.createElement('a');
        nowMore.className = 'now-more';
        nowMore.setAttribute('href', 'javascript:void(0)');
        nowMore.textContent = '오늘의 한 가지 보기 ↓';
        nowMore.addEventListener('click', function (e) {
          e.preventDefault();
          try { tipCard.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (eS) { tipCard.scrollIntoView(); }
        });
        nowMain.appendChild(nowMore);
      }
      showEl(nowMore, calm);
    }
    function paintNow() {
      paintVq();                          /* 진료 뒤 여쭙기(VQ.on)를 먼저 정해야 약 등록 안내 글이 맞게 고른다 */
      if (!nowCard) { NOW.kind = ''; return; }
      if (!nowForce && (CI.st === 'wait' || MED.st === 'wait')) {
        nowSet('wait', '오늘 챙길 것을 확인하고 있어요', '', null);
        return;
      }
      var d0 = new Date(), nm = d0.getHours() * 60 + d0.getMinutes(), eve = isEve();
      var GO_MED = ['💊 오늘의 복약 열기', '55-med-today.html?from=05-home.html'];
      /* 하나도 안 챙기셨을 때 '3개 중 3개 남았어요'는 어색해서 '3개 있어요'로 */
      var cnt = MED.st !== 'ok' ? '' : MED.left.length >= MED.due ? '오늘 챙기실 약이 ' + MED.due + '개 있어요'
        : '오늘 챙기실 약 ' + MED.due + '개 중 ' + MED.left.length + '개 남았어요';
      var soon = null, later = null;
      if (MED.st === 'ok') {
        MED.left.forEach(function (x) {
          if (x.tm < 0) return;                           /* 시각을 정하지 않은 약은 '때가 됐다'고 하지 않는다 */
          if (x.tm <= nm + 60) { if (!soon || x.tm < soon.tm) soon = x; }
          else if (!later || x.tm < later.tm) later = x;
        });
      }
      if (soon) {
        /* 때가 지났으면 '챙기셨다면 표시해 주세요', 아직 조금 남았으면 '곧 ○○ 약 챙기실 때예요' */
        var sn = SLOT_NM[soon.slot] || soon.slot;
        nowSet('med', cnt, soon.tm > nm ? '곧 ' + sn + ' 약 챙기실 때예요 (' + mtFmt(soon.hm) + ')'
          : sn + ' 약을 챙기셨다면 눌러서 표시해 주세요', GO_MED);
      } else if (eve && CI.st === 'none') {
        nowSet('ci', '오늘 하루 어떠셨어요?', '컨디션을 남겨 두시면 변화를 한눈에 볼 수 있어요',
          ['📝 오늘 컨디션 남기기', '16-checkin.html?from=05-home.html']);
      } else if (MED.st === 'ok' && MED.left.length) {
        /* '다음은 저녁 오후 7:00이에요'처럼 때가 두 번 겹치지 않게 — 위 '곧 저녁 약 챙기실 때예요 (오후 7:00)'와 같은 꼴 (2026-09-28 검수).
           다음 약이 1시간보다 뒤면 지금 누를 것이 없으니 채운 버튼을 두지 않는다 — 밤 1시에 '지금 할 일'로
           '💊 오늘의 복약 열기'가 떠 있으면 지금 드시라는 말로 읽힌다. 오늘의 복약은 바로 아래 고리 카드로 연다.
           시각을 정하지 않은 약만 남았으면 언제인지 모르니 버튼을 그대로 둔다 */
        nowSet('med', cnt, later ? '다음은 ' + (SLOT_NM[later.slot] || later.slot) + ' 약이에요 (' + mtFmt(later.hm) + ')'
          : '오늘의 복약에서 확인해 보세요', later ? null : GO_MED);
      } else if (MED.st === 'ok' && !MED.count && VQ.on) {
        /* 진료를 다녀오신 뒤 — 같은 약 등록 길을 진료 뒤 말로 (위 '진료 뒤 새로운 약') */
        nowSet('reg', '새로운 약을 처방받으셨나요?', '받으셨다면 약을 추가해 주세요',
          ['💊 약 추가하기', '58-med-manual.html?from=05-home.html']);
      } else if (MED.st === 'ok' && !MED.count) {
        nowSet('reg', '먹는 약을 등록하면 시간에 맞춰 알려 드려요', '사진으로 찍거나 이름으로 넣으실 수 있어요',
          ['💊 약 등록하기', '58-med-manual.html?from=05-home.html']);
      } else if (MED.st === 'ok' && CI.st === 'rec') {
        /* 오늘의 한 가지로 내려 주는 글 링크는 nowSet 이 붙인다 — 설명 글은 짧게 */
        /* '편히 쉬세요'는 저녁에만 — 아침 10시에 기록·약을 마치신 분께는 어색하다 (2026-09-28 검수) */
        nowSet('done', '오늘 챙길 것은 다 하셨어요', eve ? '편히 쉬세요' : '', null);
      } else if (MED.st === 'ok' && !eve) {
        /* '컨디션은 저녁에 남겨 주세요'는 같은 카드 안 한 줄 안내가 이미 한다 — 같은 말을 두 번 적지 않는다 (2026-09-28 검수) */
        nowSet('done', '지금 챙길 것은 다 하셨어요', '', null);
      } else {
        nowSet('hide');
      }
    }

    /* ── 오늘의 두 고리 ──
       컨디션: 오늘 기록이 있는지 (최근 사흘을 한 번에 받아 '오늘의 한 가지'의 증상 안내에도 같이 쓴다)
       복약  : 오늘 챙겨야 하는 (약, 시간대) 가운데 몇을 챙기셨는지
       세 갈래를 반드시 다르게 적는다 — ①없다(등록 전) ②못 받아왔다(－) ③있다(숫자).
       '약이 하나도 없는데 1/2 완료'처럼 읽히는 길은 어느 쪽으로도 없어야 한다. */

    /* ── 두 고리를 못 불러왔을 때 ── 2026-09-28
       고리에 '－' 하나만 남기면 무엇이 잘못됐는지도, 어떻게 다시 볼 수 있는지도 알 수 없어
       끝나지 않는 '확인 중' 화면처럼 보였다. 더구나 통신이 끊기는 것이 아니라 '멈추는' 경우
       (응답이 오지도, 거절되지도 않는 경우)에는 받는 자리·거절 자리 어느 쪽도 불리지 않아
       시안을 지운 '－'가 정말 영원히 남았다. 그래서 두 가지를 함께 둔다:
         (1) 8초까지 아무 소식이 없으면 못 받아온 것으로 적는다(지킴이)
         (2) 55(오늘의 복약)와 같은 결로 — 못 받아왔다고 말하고, 남기신 기록이 사라진 게
             아니라고 알리고, '다시 열기'를 드린다
       거짓 숫자는 어느 쪽으로도 쓰지 않는다(전에 이 자리에 시안 '1/2 완료'가 남았다).
       뒤늦게 응답이 오면 스스로 낫는다 — ringOk 가 띠를 치우고 실제 값을 칠한다. */
    var ringBad = { ci: false, med: false }, ringSeen = { ci: false, med: false };
    var ringBn = null, ringWd = null;
    function ringCard(k) { return k === 'ci' ? ciCard : medCard; }
    function ringFail(k) {
      var card = ringCard(k);
      if (!card) return;
      if (k === 'med') { medHas = false; showEl(card, false); }
      ringSeen[k] = true;
      var rg = $('.ring', card), ri = $('.ring-in', card), sbx = $('.card-sub', card);
      if (rg) rg.style.setProperty('--p', '0%');
      if (ri) ri.innerHTML = '－';
      if (sbx) sbx.textContent = (k === 'ci' ? '오늘 기록을' : '오늘 챙길 약을') + ' 불러오지 못했어요. 아래 ‘다시 열기’를 눌러 주세요';
      ringBad[k] = true;
      /* 아직 한 번도 받지 못했으면 '모름'으로 — 앞서 받아 둔 값이 있으면 그대로 둔다(다시 읽기가 멈춘 경우) */
      if (k === 'ci' && CI.st === 'wait') CI.st = 'fail';
      if (k === 'med' && MED.st === 'wait') MED.st = 'fail';
      paintRingBn();
      paintNow(); paintCi();
    }
    function ringOk(k) {
      ringSeen[k] = true;
      if (!ringBad[k]) return;
      ringBad[k] = false;
      paintRingBn();
    }
    /* 띠를 어디에 둘지 — 두 고리 줄이 지금 할 일 카드 안에 있으면 그 카드 아래(지금 05-home.html).
       옛 화면(캐시)에서는 오늘의 복약 고리 아래가 기본. 오늘 기록만 못 불러왔으면 컨디션 카드(보이면) 아래,
       오후 5시 전이라 카드가 접혀 있으면 한 줄 안내 아래 — 접힌 카드 안에 넣으면 보이지 않는다 */
    function ringAnchor() {
      if (nowCard && medCard && nowCard !== medCard && nowCard.contains(medCard)) return nowCard;
      if (ringBad.med || !ciCard) return medCard;
      if (!ciWrap) return ciCard;
      if (ciWrap.style.display !== 'none') return ciWrap;
      return (ciHint && ciHint.style.display !== 'none') ? ciHint : medCard;
    }
    function paintRingBn() {
      var bad = [];
      if (ringBad.ci) bad.push('오늘 기록');
      if (ringBad.med) bad.push('오늘 챙길 약');
      if (!bad.length) {
        if (ringBn && ringBn.parentNode) ringBn.parentNode.removeChild(ringBn);
        ringBn = null;
        return;
      }
      var anchor = ringAnchor();
      if (!anchor || !anchor.parentNode) return;
      if (!ringBn) {
        ringBn = document.createElement('div');
        ringBn.className = 'banner banner--warn';
        ringBn.setAttribute('role', 'status');
      }
      ringBn.innerHTML = '<span class="b-ic" aria-hidden="true">⚠️</span><div class="small grow"><b>'
        + bad.join('과 ') + '을 불러오지 못했어요.</b> 연결이 원활하지 않은 것 같아요.'
        + '<div style="margin-top:6px;"><b>이 자리가 비어 보여도 남기신 기록과 등록하신 약은 그대로 있어요.</b>'
        + ' 잠시 뒤 아래 ‘다시 열기’를 눌러 주세요.</div>'
        + '<a class="btn btn-outline btn-sm btn-block" href="javascript:void(0)" data-role="ring-retry" style="margin-top:10px;">다시 열기</a></div>';
      if (ringBn.__at !== anchor) {
        anchor.parentNode.insertBefore(ringBn, anchor.nextSibling);
        ringBn.__at = anchor;
      }
      var rbx = $('[data-role="ring-retry"]', ringBn);
      if (rbx) rbx.addEventListener('click', function () { location.reload(); });
    }
    /* 지킴이 — 다시 읽을 때마다 새로 건다. '지금 할 일'도 여기서 기다림을 끝낸다 */
    function ringWatch() {
      if (ringWd) clearTimeout(ringWd);
      ringSeen.ci = false; ringSeen.med = false;
      ringWd = setTimeout(function () {
        if (ciCard && !ringSeen.ci) ringFail('ci');
        if (medCard && !ringSeen.med) ringFail('med');
        nowForce = true;
        paintNow(); paintCi();
      }, 8000);
    }

    /* 다시 읽은 뒤(되살아난 화면)에도 '오늘의 한 가지'를 새 기록으로 다시 고른다 — 두 조회가 모두 끝난 뒤 한 번 */
    var round = 0, roundLeft = {};
    function settled(k, my) {
      if (my === 0) { oneReady(k); return; }
      if (my !== round || !roundLeft[k]) return;
      roundLeft[k] = false;
      if (!roundLeft.ci && !roundLeft.med && oneDone) paintOne(tipCard, ONE);
    }

    function loadCheckin(my) {
      if (!ciCard) { CI.st = 'none'; settled('ci', my); paintNow(); paintCi(); return; }
      var ciTd = ymd(new Date()), ciD0 = new Date();
      ciD0.setDate(ciD0.getDate() - 2);
      sb.from('checkins').select('id,date,symptoms,intensity').gte('date', ymd(ciD0)).lte('date', ciTd).then(function (r) {
        var ring = $('.ring', ciCard), rin = $('.ring-in', ciCard), subEl = $('.card-sub', ciCard);
        if (!r || r.error || !isArr(r.data)) {   /* 못 불러옴 — '기록 전'으로 잘못 보이지 않게 */
          ringFail('ci');
          settled('ci', my);
          return;
        }
        ringOk('ci');
        var mine = null;
        r.data.forEach(function (c) { if (c && c.date === ciTd) mine = c; });
        ONE.recent = r.data;
        ONE.today = mine;
        CI.st = mine ? 'rec' : 'none';
        if (mine) {
          if (ring) ring.style.setProperty('--p', '100%');
          if (rin) rin.innerHTML = '기록<br>완료';
          if (subEl) subEl.textContent = '눌러서 고칠 수 있어요';   /* 고리가 이미 '기록 완료'라고 말한다 — 할 수 있는 것만 */
        } else {
          if (ring) ring.style.setProperty('--p', '0%');
          if (rin) rin.innerHTML = '오늘<br>기록 전';
          if (subEl) subEl.textContent = '증상과 기분을 남겨 주세요';
        }
        paintNow(); paintCi();
        settled('ci', my);
      }, function () {
        ringFail('ci');
        settled('ci', my);
      });
    }

    function loadMeds(my) {
      if (!medCard) { settled('med', my); return; }
      uid(function () {
        /* 이름은 '오늘의 한 가지' ②(등록하신 치료약)에만 쓴다 — 화면에 약 이름을 새로 띄우지 않는다 */
        sb.from('medications').select('id,name,schedule,created_at').eq('active', true).then(function (r) {
          var ring = $('.ring', medCard), rin = $('.ring-in', medCard), subEl = $('.card-sub', medCard);
          function unknown() {             /* 불러오지 못함 — 시안 숫자나 '등록 전'으로 잘못 보이지 않게 */
            ringFail('med');
            settled('med', my);
          }
          if (!r || r.error) return unknown();
          var meds = r.data || [];
          medHas = meds.length > 0;
          paintMedRow();
          ONE.meds = meds;
          paintRx();
          /* 오늘 챙겨야 하는 (약, 시간대) — '필요할 때만'은 넣지 않는다. 기록도 이 목록에 있는 것만 센다
             (필요시 약·그만 쓴 약의 체크가 섞이면 정해진 약을 거르고도 '모두 챙기셨어요'가 떴다) */
          var dueKeys = {}, due = 0, slots = [];
          meds.forEach(function (m) {
            var tms = (m.schedule && m.schedule.times) || {};
            ((m.schedule && m.schedule.slots) || []).forEach(function (sl) {
              var k = m.id + '|' + sl;
              if (sl === '필요시' || dueKeys[k]) return;
              dueKeys[k] = true; due++;
              var hm = (typeof tms[sl] === 'string' && tms[sl]) || MT_TIME[sl] || '';
              slots.push({ k: k, slot: sl, hm: hm, tm: hmMin(hm) });
            });
          });
          if (!meds.length || !due) {
            ringOk('med');
            if (ring) ring.style.setProperty('--p', '0%');
            if (!meds.length) {
              if (rin) rin.innerHTML = '등록<br>전';
              if (subEl) subEl.textContent = '복용할 약을 먼저 등록해 주세요';
            } else {
              if (rin) rin.innerHTML = '필요할<br>때';
              if (subEl) subEl.textContent = '필요할 때만 쓰는 약이 등록돼 있어요';
            }
            MED = { st: 'ok', count: meds.length, due: 0, left: [] };
            paintNow(); paintCi();
            /* 필요할 때만 쓰는 약만 있어도 오늘 쓰신 기록이 있으면 ② 에 쓴다 */
            if (!meds.length) { ONE.medTaken = false; ONE.logged = {}; settled('med', my); return; }
          }
          sb.from('med_logs').select('medication_id,slot').eq('date', ymd(new Date())).eq('taken', true).then(function (r2) {
            if (!r2 || r2.error) {
              if (!due) { settled('med', my); return; }   /* 고리는 이미 칠했다 — ② 만 건너뛴다 */
              return unknown();
            }
            var done = 0, seen = {}, logged = {};
            (r2.data || []).forEach(function (l) {
              if (!l) return;
              logged[l.medication_id] = 1;
              var k = l.medication_id + '|' + l.slot;
              if (dueKeys[k] && !seen[k]) { seen[k] = 1; done++; }
            });
            ONE.logged = logged;
            ONE.medTaken = (r2.data || []).length > 0;
            if (!due) { settled('med', my); return; }
            ringOk('med');
            var all = done >= due;
            if (ring) ring.style.setProperty('--p', Math.round(100 * Math.min(done, due) / due) + '%');
            /* '2/11 남음'은 '2개 남았다'로 읽혀 거의 다 드신 줄 아시게 된다 — 실제로는 2개를 드신 것이다.
               숫자가 뜻하는 대로 '챙김'으로 적는다(다 챙기시면 '완료'). */
            if (rin) rin.innerHTML = Math.min(done, due) + '/' + due + '<br>' + (all ? '완료' : '챙김');
            if (subEl) subEl.textContent = all ? '오늘 약을 모두 챙기셨어요' : '오늘 챙길 약을 확인해 보세요';
            MED = { st: 'ok', count: meds.length, due: due,
              left: slots.filter(function (x) { return !seen[x.k]; }) };
            paintNow(); paintCi();
            settled('med', my);
          }, function () {
            if (!due) { settled('med', my); return; }
            unknown();
          });
        }, function () { ringFail('med'); settled('med', my); });
      });
    }

    paintNow(); paintCi();               /* 오후 5시 전이면 불러오기 전에도 한 줄 안내로 — 카드가 비쳤다가 접히지 않게 */
    loadCheckin(0);
    loadMeds(0);
    ringWatch();

    /* ── 기록하고 홈으로 돌아오면 바로 다시 읽는다 ──
       16(컨디션)·55(복약)은 저장하면 홈을 새로 열기 때문에(location) 그 길은 원래 맞았다.
       맞지 않던 길은 화면이 '되살아나는' 경우다 — 폰 뒤로가기·사파리 스와이프 백은 화면을 다시 만들지 않고
       그대로 꺼내 오므로(bfcache) 아까 그린 숫자가 그대로 남는다. 아이폰 홈화면 웹앱도 마찬가지다.
       그래서 두 자리에서만 다시 읽는다:
         (1) pageshow 의 persisted — 되살아난 경우
         (2) 화면이 다시 보일 때 — 앱 전환·알림에서 돌아온 경우(웹앱 포함)
       다시 읽는 것은 두 고리의 조회뿐이다. 화면 전체를 새로 읽으면(location.reload) 스크립트 1.1MB 를
       다시 읽어 느린 폰이 눈에 띄게 멈춘다. 프로필·치료 일정·부작용 칩은 여기서 다시 읽지 않는다 —
       그 값을 고치는 73·14 는 저장한 뒤 홈을 새로 열기 때문이다.
       두 사건이 함께 터지는 기기가 있어 1.5초 안에 겹쳐 들어오면 건너뛴다. */
    var lastRead = Date.now();
    function reread() {
      if (Date.now() - lastRead < 1500) return;
      lastRead = Date.now();
      round++;
      roundLeft = { ci: true, med: true };
      loadCheckin(round);
      loadMeds(round);
      ringWatch();
    }
    window.addEventListener('pageshow', function (ev) { if (ev && ev.persisted) reread(); });
    document.addEventListener('visibilitychange', function () {
      if (document.visibilityState === 'visible') reread();
    });
    /* ── 시각이 바뀌는 것 따라가기 ── 2026-09-28
       홈을 켜 둔 채 오후 5시를 넘기면 인사·지금 할 일·컨디션 줄이 저녁 모양으로, 약 먹을 때가 되면 '지금 할 일'이 약으로 바뀌어야 한다.
       1분마다 이미 받아 둔 값으로만 다시 그린다(서버에 다시 묻지 않는다).
       자정을 넘기면 어제 날짜로 된 기록·팁이 남으므로 새로 연다 — 화면이 가려져 있을 때는 건너뛰고,
       다시 보일 때 맨 위 visibilitychange 가 새로 연다(features.js 첫머리 dayChanged). */
    setInterval(function () {
      if (document.visibilityState && document.visibilityState !== 'visible') return;
      if (dayChanged()) { location.reload(); return; }
      paintGreet(); paintNow(); paintCi();
    }, 60000);
  }

  /* ── 투여경로 도우미 — 판정표는 native.js(TDN.route) 한 곳에 있다 ── */
  var RT = (window.TDN && window.TDN.route) || null;
  var OCRX = (window.TDN && window.TDN.ocr) || null;
  var RT_ORAL = { label: '먹는 약', chip: '먹는 약', ic: '💊', will: '드실', done: '드셨어요', doneIf: '드셨으면', how: '드시는지', go: '드세요' };
  function routeOfMed(m) { return RT ? RT.ofMed(m) : 'oral'; }
  function routeInfo(r) { return RT ? RT.info(r) : RT_ORAL; }
  /* 약 이름 뒤 조사 — 한글로 끝나면 받침을 보고, 숫자·영문(20mg, 0.1%)으로 끝나면 '을(를)' */
  function eulReul(s) {
    var c = String(s || '').replace(/\s+$/, '').slice(-1).charCodeAt(0);
    if (!(c >= 0xAC00 && c <= 0xD7A3)) return '을(를)';
    return (c - 0xAC00) % 28 ? '을' : '를';
  }
  /* 같은 자리의 조사 '와/과' — 받침이 있으면 '과' */
  function waGwa(s) {
    var c = String(s || '').replace(/\s+$/, '').slice(-1).charCodeAt(0);
    if (!(c >= 0xAC00 && c <= 0xD7A3)) return '와(과)';
    return (c - 0xAC00) % 28 ? '과' : '와';
  }
  /* ── 약을 목록에서 빼기 ── 2026-09-27
     봉투를 사진으로 읽을 때 오타로 같은 약이 두 번 들어가는 일이 있다
     ('레보플레쉬점안액' · '레보플레수쉬점안액'). 새로 등록할 때는 합쳐지지만,
     이미 들어가 있는 것은 환자분이 손수 빼셔야 한다. 그 길이 56 한 곳뿐이라 멀었다.
     그래서 55(오늘의 복약)에서도 뺄 수 있게 하고, 묻는 말은 두 화면이 하나로 쓴다.
     · 되돌릴 수 없는 일이다 — 반드시 한 번 여쭙는다. 여쭙는 창은 '닫기'에 먼저 손이 간다(askPop).
     · 체크해 두신 기록(med_logs)은 지우지 않는다. 약 줄만 목록과 알림에서 빠진다.
     · 약을 끊는 결정은 담당 선생님 몫이라는 말을 함께 둔다. */
  function medStopAsk(m, o) {
    o = o || {};
    askPop({
      icon: '💊',
      title: '「' + m.name + '」' + eulReul(m.name) + ' 그만 쓸까요?',
      body: '다 쓰셨거나 잘못 들어간 약이면 목록과 복약 알림에서 뺄게요. 지금까지 체크한 기록은 그대로 남아요. 처방받은 약을 끊는 건 담당 의사와 먼저 상의해 주세요.',
      yes: '그만 쓰기',
      no: '닫기',
      danger: true,
      onYes: function () {
        if (o.before && o.before() === false) return;
        /* 그만 쓴 날을 함께 적는다 — 55 지난 날 표에 그날 전까지는 이 약이 보이게 (2026-10-26) */
        var stopSch = schedCopy(m.schedule);
        stopSch.stoppedOn = ymd(new Date());
        sb.from('medications').update({ active: false, schedule: stopSch }).eq('id', m.id).then(function (r) {
          if (o.after) o.after();
          if (r && r.error) return toast(koError(r.error));
          if (o.done) o.done();
          toast('「' + m.name + '」' + eulReul(m.name) + ' 목록에서 뺐어요.\n복약 알림도 더 울리지 않아요.');
          if (window.TDN && window.TDN.notifySync) window.TDN.notifySync(function (st) { if (window.TDN.deniedToast) window.TDN.deniedToast(st); });
        }, function () {
          if (o.after) o.after();
          toast('연결이 원활하지 않아요. 다시 시도해 주세요.');
        });
      }
    });
  }

  /* 며칠분의 마지막 날 'YYYY-MM-DD' — 일수(schedule.days)·시작일(schedule.startedOn)을 모르면 '' */
  function medEndDay(m) {
    var s = (m && m.schedule) || {}, n = parseInt(s.days, 10), st = String(s.startedOn || '');
    if (!(n > 0) || !/^\d{4}-\d{2}-\d{2}$/.test(st)) return '';
    var p = st.split('-');
    return ymd(new Date(+p[0], +p[1] - 1, +p[2] + n - 1));
  }

  /* ── 55 오늘의 복약 ──
     예전에는 시간대(아침·점심·저녁·자기전)마다 약이 따로 줄을 차지했다.
     약이 다섯 종이면 줄이 열다섯 개가 되고, 같은 약 이름을 서너 번 보게 되어 헷갈린다.
     이제 표 하나로 모은다 — 왼쪽 한 줄에 약 하나, 오른쪽 네 칸에서 그 시간에 드셨는지 체크한다.

     저장 구조는 그대로다. 예전과 똑같이 med_logs(user_id, medication_id, date, slot, taken)
     한 줄씩 upsert 한다. 이미 남아 있는 기록도 그대로 읽힌다 — 보여 주는 방식만 바꿨다.

     슬롯은 앱이 만들 때부터 다섯 낱말뿐이다(native.js MED_SLOTS·WHEN_ITEMS):
     아침·점심·저녁·자기전·필요시. 시각('08:00')은 schedule.times 에 따로 있고 슬롯 이름이 아니다.
     그래서 표의 네 칸에 아침·점심·저녁·자기전을 두고,
     '필요시'와 (예전 자료에 혹시 있을) 낯선 슬롯은 표 아래 따로 줄을 만들어 빠뜨리지 않는다. */
  var MT_SLOTS = ['아침', '점심', '저녁', '자기전'];
  /* 네 칸 어디에도 못 넣는 약을 위한 이름 — 아래 '정해진 때가 아닌 약' 목록에서만 쓴다.
     med_logs.slot 에 그대로 들어가지만 slot 은 자유 문자열이고(schema), 홈·기록 화면은
     schedule.slots 로 셈을 하므로 이 값이 다른 화면의 숫자를 흔들지 않는다. */
  var MT_UNK = '시간 모름';
  var MT_TIME = { '아침': '08:00', '점심': '13:00', '저녁': '19:00', '자기전': '22:00' };
  function mtFmt(t) {
    if (!t) return '';
    if (window.TDT && TDT.fmt) { var f = TDT.fmt(t); if (f) return f; }
    return t;
  }
  function mtLbl(s) { return s === '자기전' ? '자기 전' : s; }

  /* ── 드시는 시간 이력 · 약 순서 · 그만 쓴 날 ── 2026-10-26 (사용 의견: 지난 날 체크 · 순서 · 아침·점심 약)
     모두 medications.schedule(jsonb) 안에 둔다 — 표를 바꾸지 않는다.
     · slotHist [{ from:'YYYY-MM-DD', slots:[…] }] — 드시는 시간을 바꾼 날부터의 시간.
       지난 날 표는 그날의 시간으로 그린다. 그래서 오늘 아침·저녁을 아침·점심으로 바꿔도 어제 저녁 체크가 사라지거나
       지난 날에 빈 점심 칸이 갑자기 생기지 않는다. 한 번도 안 바꾼 약은 넣은 날부터 지금 slots 그대로다.
     · order — '약 목록 고치기'에서 정한 차례(0부터). 없는 약(새로 넣은 약)은 맨 아래, 넣은 차례대로.
     · stoppedOn — '이 약 그만 쓰기'를 누른 날. 지난 날 표에는 그날 전까지 보인다. */
  function medDay(m) {                         /* 넣은 날(이 기기 날짜) — 모르면 '' */
    var c = m && m.created_at ? new Date(m.created_at) : null;
    return (c && !isNaN(c.getTime())) ? ymd(c) : '';
  }
  function medSlotsOn(m, day) {
    var s = (m && m.schedule) || {}, h = s.slotHist, cur = isArr(s.slots) ? s.slots : [], out = null, i;
    if (!isArr(h) || !h.length) return cur;
    for (i = 0; i < h.length; i++) if (h[i] && isArr(h[i].slots) && String(h[i].from) <= day) out = h[i].slots;
    return out || (h[0] && isArr(h[0].slots) ? h[0].slots : cur);
  }
  function medOrd(m) { var o = m && m.schedule && m.schedule.order; return (typeof o === 'number' && isFinite(o)) ? o : 1e6; }
  function medSort(meds) {
    return (meds || []).slice(0).sort(function (a, b) {
      var oa = medOrd(a), ob = medOrd(b);
      if (oa !== ob) return oa - ob;
      return (+a.id || 0) - (+b.id || 0);
    });
  }
  function schedCopy(src) {
    var sc = {}, k;
    src = (src && typeof src === 'object') ? src : {};
    for (k in src) if (Object.prototype.hasOwnProperty.call(src, k)) sc[k] = src[k];
    return sc;
  }
  /* 드시는 시간을 바꾼 새 schedule — 오늘부터 적용. 알림 시각은 그 시간에 맞춰 두신 것이 있으면 그대로, 없으면 기본 시각 */
  function medNewSched(m, slots) {
    var src = (m && m.schedule) || {}, sc = schedCopy(src), today = ymd(new Date());
    var old = isArr(src.slots) ? src.slots.slice(0) : [];
    var h = isArr(src.slotHist) ? src.slotHist.slice(0) : [];
    if (!h.length) h.push({ from: medDay(m) || today, slots: old });
    if (String(h[h.length - 1].from) >= today) h[h.length - 1] = { from: today, slots: slots.slice(0) };   /* 같은 날 두 번 바꾸면 덮는다 */
    else h.push({ from: today, slots: slots.slice(0) });
    sc.slotHist = h;
    sc.slots = slots.slice(0);
    var fixed = slots.filter(function (s) { return s !== '필요시'; });
    sc.freq = fixed.length ? '하루 ' + fixed.length + '번' : '필요할 때만';
    var tm = schedCopy(src.times);
    fixed.forEach(function (s) { if (!tm[s] && MT_TIME[s]) tm[s] = MT_TIME[s]; });
    sc.times = tm;
    return sc;
  }

  /* ── 약 목록 고치기 ── 2026-10-26 (사용 의견)
     55 오늘의 복약 · 56 복약 설정이 같은 창을 연다. 한 창에서 두 가지를 고친다.
       · 순서 — 카드 왼쪽 손잡이(↕)를 잡고(손가락 0.22초 누르거나 움직이면 · 마우스는 끌면) 위아래로 끌어 옮긴다.
         처음에는 이름 줄을 잡게 했는데 목록을 밀다가 약이 옮겨져 손잡이만 잡게 바꿨다(10-26 둘째 의견).
         처음 안의 ▲▼ 화살표는 누르는 즉시 확 바뀌어 잘못 눌러도 알아채기 어렵다는 의견이 있었다.
         끌기는 손을 떼기 전까지 바뀌지 않고, 다른 약이 비켜 주는 것이 보이고, 놓은 약은 분홍으로 남는다.
         화면 읽기 기능을 쓰시는 분은 끌 수 없으니 그분들께만 '위로·아래로' 단추를 둔다(.ro-sr).
       · 드시는 시간 — 이름 아래 아침·점심·저녁·자기 전 네 칸. 바꾸면 오늘부터(medNewSched).
     저장하면 바뀐 약만 고쳐 쓰고 알림을 다시 맞춘다. 창 틀은 native.js 고르기 창 모양(TDN.pickStyle).
     o = { meds: [...], onSaved: function (slotsChanged) } — meds 는 schedule·created_at 을 가진 약 */
  function medListSheet(o) {
    if (document.querySelector('.pk-dim') || document.querySelector('.tp-dim')) return;
    if (window.TDN && TDN.pickStyle) TDN.pickStyle();
    var tmp = medSort(o.meds).map(function (m) {
      var all = isArr(m.schedule && m.schedule.slots) ? m.schedule.slots : [];
      var fixed = MT_SLOTS.filter(function (s) { return all.indexOf(s) > -1; });
      return { m: m, was: fixed.slice(0), slots: fixed.slice(0), prn: !fixed.length };
    });
    var moved = null, opener = null;
    try { opener = document.activeElement; } catch (eA) {}
    var dim = document.createElement('div');
    dim.className = 'pk-dim';
    dim.setAttribute('role', 'dialog');
    dim.setAttribute('aria-modal', 'true');
    dim.setAttribute('aria-label', '약 목록 고치기');
    dim.innerHTML = '<div class="pk-sheet">'
      + '<div class="pk-title">약 목록 고치기</div>'
      + '<div class="pk-sub">순서는 약 왼쪽 손잡이(▲▼)를 잡고 위아래로 끌어 옮기고,<br>드시는 시간은 아래 칸을 눌러 바꿔요.</div>'
      + '<button type="button" class="btn btn-outline btn-sm btn-block ro-auto">드시는 시간 순서로 한 번에 정리</button>'
      + '<div class="ro-list"></div>'
      + '<p class="tiny muted ro-foot">드시는 시간을 바꾸면 <b>오늘부터</b> 그렇게 보여요.<br>새로 고른 시간의 알림은 복약 설정에서 바꿀 수 있어요.</p>'
      + '<div class="pk-acts"><button type="button" class="pk-cancel">취소</button><button type="button" class="pk-ok">저장</button></div>'
      + '</div>';
    var list = $('.ro-list', dim);
    var noPE = !window.PointerEvent;              /* 아주 옛 웹뷰 — 끌 수 없으니 위로·아래로 단추를 보이게 둔다 */
    function whenWords(l) { return l.length ? l.map(mtLbl).join('·') : '필요할 때만'; }
    function moveTo(i, to) {
      if (to < 0 || to >= tmp.length || to === i) return;
      var it = tmp.splice(i, 1)[0];
      tmp.splice(to, 0, it);
      moved = it.m.id;
    }
    function paint(focusId, focusDir) {
      list.innerHTML = '';
      tmp.forEach(function (x, i) {
        var r = document.createElement('div');
        r.className = 'ro-row' + (x.m.id === moved ? ' is-moved' : '') + (noPE ? ' no-pe' : '');
        /* 왼쪽 손잡이(↕)를 잡을 때만 끌린다 — 이름 줄을 잡게 했더니 목록을 밀다가 약이 옮겨졌다(2026-10-26 둘째 의견) */
        var grip = document.createElement('div');
        grip.className = 'ro-grip';
        grip.setAttribute('aria-hidden', 'true');
        r.appendChild(grip);
        var main = document.createElement('div');
        main.className = 'ro-main';
        var nmB = document.createElement('div');
        nmB.className = 'ro-nm';
        nmB.appendChild(mtName(x.m.name));
        main.appendChild(nmB);
        r.appendChild(main);
        ['위로', '아래로'].forEach(function (w, k) {
          var b = document.createElement('button');
          b.type = 'button';
          b.className = 'ro-sr';
          b.textContent = (noPE ? (k ? '▼ ' : '▲ ') : '') + '「' + x.m.name + '」 ' + w + ' 옮기기';
          b.setAttribute('data-dir', String(k));
          b.addEventListener('click', function () {
            var to = i + (k ? 1 : -1);
            if (to < 0 || to >= tmp.length) return toast(k ? '맨 아래예요' : '맨 위예요');
            moveTo(i, to);
            paint(x.m.id, k);
          });
          main.appendChild(b);
        });
        if (x.prn) {
          var nt = document.createElement('div');
          nt.className = 'ro-note';
          nt.textContent = '필요할 때만 쓰는 약이에요. 정해진 시간이 있으면 눌러 주세요.';
          main.appendChild(nt);
        }
        var g = document.createElement('div');
        g.className = 'when-grid when-grid--sm';
        MT_SLOTS.forEach(function (s) {
          var c = document.createElement('span');
          var on = x.slots.indexOf(s) > -1;
          c.className = 'chip' + (on ? ' chip--on' : '');
          c.setAttribute('role', 'checkbox');
          c.setAttribute('tabindex', '0');
          c.setAttribute('aria-checked', on ? 'true' : 'false');
          c.setAttribute('aria-label', x.m.name + ' ' + mtLbl(s));
          c.textContent = mtLbl(s);
          var h = function (ev) {
            if (ev.type === 'keydown' && ev.key !== ' ' && ev.key !== 'Enter') return;
            ev.preventDefault();
            var at = x.slots.indexOf(s);
            if (at > -1) {
              if (x.slots.length === 1 && !x.prn) return toast('드시는 시간을 하나 이상\n골라 주세요.');
              x.slots.splice(at, 1);
            } else x.slots = MT_SLOTS.filter(function (z) { return z === s || x.slots.indexOf(z) > -1; });
            paint();
          };
          c.addEventListener('click', h);
          c.addEventListener('keydown', h);
          g.appendChild(c);
        });
        main.appendChild(g);
        if (x.slots.join() !== x.was.join()) {
          var cg = document.createElement('div');
          cg.className = 'ro-chg';
          cg.innerHTML = esc(whenWords(x.was)) + ' → <b>' + esc(whenWords(x.slots)) + '</b> · 오늘부터';
          main.appendChild(cg);
        }
        list.appendChild(r);
        if (focusId != null && x.m.id === focusId) {
          try { $('.ro-sr[data-dir="' + focusDir + '"]', r).focus(); } catch (eF) {}
        }
      });
    }

    /* ── 끌어 옮기기 ── 자리는 목록 안 좌표(offsetTop)로 잰다 — 끄는 동안 목록이 굴러가도 어긋나지 않게 */
    var drag = null, roll = null;
    function lift() {
      if (!drag || drag.on) return;
      drag.on = true;
      drag.row.classList.add('is-drag');
      try { if (navigator.vibrate) navigator.vibrate(10); } catch (eV) {}   /* 안드로이드: 잡혔다는 짧은 떨림 */
      roll = setInterval(function () {                                    /* 목록 위·아래 끝에 대면 천천히 굴린다 */
        if (!drag || !drag.on) return;
        var lr = list.getBoundingClientRect(), y = drag.y, st = list.scrollTop;
        if (y < lr.top + 36) list.scrollTop = st - 8;
        else if (y > lr.bottom - 36) list.scrollTop = st + 8;
        if (list.scrollTop !== st) follow();
      }, 16);
    }
    function follow() {
      var d = drag, n = d.tops.length, me = d.idx;
      var dy = d.y - d.y0 + (list.scrollTop - d.sc0);
      dy = Math.max(d.tops[0] - d.tops[me], Math.min(d.tops[n - 1] + d.hs[n - 1] - d.tops[me] - d.hs[me], dy));
      d.row.style.transform = 'translateY(' + dy + 'px) scale(1.02)';
      var c = d.tops[me] + d.hs[me] / 2 + dy, t = me, i;
      for (i = 0; i < n; i++) {
        var mid = d.tops[i] + d.hs[i] / 2;
        /* 같음(<=)까지 넘은 것으로 센다 — 맨 위·맨 아래까지 끌면 끌 수 있는 끝이 그 줄 가운데와 딱 같아져서,
           '<' 로만 세면 맨 끝 자리로는 끝내 못 옮겼다(2026-10-26 시험에서 찾음) */
        if (i < me && c <= mid && i < t) t = i;
        if (i > me && c >= mid && i > t) t = i;
      }
      d.target = t;
      var h = d.hs[me] + 8;
      d.rows.forEach(function (rw, k) {
        if (k === me) return;
        var s = 0;
        if (me < t && k > me && k <= t) s = -h;
        if (me > t && k < me && k >= t) s = h;
        rw.style.transform = s ? 'translateY(' + s + 'px)' : '';
      });
    }
    function drop() {
      if (!drag) return;
      clearTimeout(drag.timer);
      clearInterval(roll); roll = null;
      var d = drag; drag = null;
      if (!d.on) return;
      moveTo(d.idx, d.target);
      paint();
    }
    list.addEventListener('pointerdown', function (ev) {
      var grip = ev.target && ev.target.closest ? ev.target.closest('.ro-grip') : null;
      if (!grip || drag) return;
      if (ev.pointerType === 'mouse' && ev.button !== 0) return;
      var rows = $$('.ro-row', list), row = grip.parentNode, idx = rows.indexOf(row);
      if (idx < 0) return;
      drag = { row: row, rows: rows, idx: idx, target: idx, y0: ev.clientY, y: ev.clientY, on: false, pid: ev.pointerId,
               sc0: list.scrollTop,
               tops: rows.map(function (x) { return x.offsetTop; }),
               hs: rows.map(function (x) { return x.offsetHeight; }) };
      try { grip.setPointerCapture(ev.pointerId); } catch (eP) {}
      if (ev.pointerType !== 'mouse') drag.timer = setTimeout(lift, 220);
      ev.preventDefault();
    });
    list.addEventListener('pointermove', function (ev) {
      if (!drag || ev.pointerId !== drag.pid) return;
      drag.y = ev.clientY;
      if (!drag.on) { if (Math.abs(drag.y - drag.y0) > 4) lift(); else return; }
      follow();
    });
    list.addEventListener('pointerup', drop);
    list.addEventListener('pointercancel', drop);
    list.addEventListener('contextmenu', function (ev) { if (ev.target && ev.target.closest && ev.target.closest('.ro-grip')) ev.preventDefault(); });

    $('.ro-auto', dim).addEventListener('click', function () {
      var first = function (x) { return x.slots.length ? MT_SLOTS.indexOf(x.slots[0]) : 9; };
      tmp = tmp.map(function (x, i) { return [x, i]; })
        .sort(function (a, b) { return (first(a[0]) - first(b[0])) || (a[1] - b[1]); })
        .map(function (p) { return p[0]; });
      moved = null;
      paint();
      toast('아침 약부터 차례로 놓았어요.\n저장을 누르시면 바뀌어요.');
    });
    function close() {
      clearInterval(roll);
      if (dim.parentNode) dim.parentNode.removeChild(dim);
      document.documentElement.style.overflow = '';
      try { if (opener && opener.focus && document.body.contains(opener)) opener.focus(); } catch (eC) {}
    }
    $('.pk-cancel', dim).addEventListener('click', close);
    dim.addEventListener('click', function (ev) { if (ev.target === dim) close(); });
    var okB = $('.pk-ok', dim);
    okB.addEventListener('click', function () {
      if (okB.__busy) return;
      var jobs = [], slotsChanged = false;
      tmp.forEach(function (x, i) {
        var m = x.m, sch = schedCopy(m.schedule), dirty = false;
        if (medOrd(m) !== i) { sch.order = i; dirty = true; }
        if (x.slots.join() !== x.was.join()) {
          var all = isArr(m.schedule && m.schedule.slots) ? m.schedule.slots : [];
          var others = all.filter(function (s) { return MT_SLOTS.indexOf(s) < 0 && s !== '필요시'; });
          var nx = x.slots.length ? x.slots.concat(others) : (others.length ? others : ['필요시']);
          sch = medNewSched({ id: m.id, created_at: m.created_at, schedule: sch }, nx);
          dirty = true; slotsChanged = true;
        }
        if (dirty) jobs.push({ m: m, sch: sch });
      });
      if (!jobs.length) { close(); return; }
      if (dayChanged()) { close(); toast('날짜가 바뀌어 화면을 새로 열어요.'); setTimeout(function () { location.reload(); }, 900); return; }
      okB.__busy = true;
      okB.textContent = '저장 중…';
      var left = jobs.length, failed = false;
      function one() {
        if (--left) return;
        okB.__busy = false;
        okB.textContent = '저장';
        if (failed) return toast('일부는 저장하지 못했어요.\n다시 저장을 눌러 주세요.');
        close();
        toast(slotsChanged ? '저장했어요.\n드시는 시간은 오늘부터 바뀌어요.' : '약 순서를 저장했어요.');
        if (slotsChanged && window.TDN && TDN.notifySync) TDN.notifySync(function (st) { if (TDN.deniedToast) TDN.deniedToast(st); });
        if (o.onSaved) o.onSaved(slotsChanged);
      }
      jobs.forEach(function (j) {
        sb.from('medications').update({ schedule: j.sch }).eq('id', j.m.id).then(function (r) {
          if (r && r.error) failed = true; else j.m.schedule = j.sch;
          one();
        }, function () { failed = true; one(); });
      });
    });
    paint();
    document.documentElement.style.overflow = 'hidden';
    document.body.appendChild(dim);
    try { $('.pk-title', dim).setAttribute('tabindex', '-1'); $('.pk-title', dim).focus(); } catch (eT) {}
  }

  /* ── 약 이름을 칸에 넣기 ──
     말줄임(…)은 쓰지 않는다. 비슷한 이름의 약이 많아 잘리면 어느 약인지 알 수 없다.
     그래서 아주 긴 이름은 그대로 두 줄이 되는데, 끊기는 자리가 문제다.
     칸이 좁아 '아무 데서나 끊기'(overflow-wrap:anywhere)로 두었더니
       · '아이플루플러스점안 / 액'  — 끝 글자 하나만 떨어져 약 이름으로 읽히지 않고
       · '슈가메트서방정2.5/50 / 0밀리그램' — 숫자 한가운데가 갈려 용량을 잘못 보실 수 있다.
     그래서 '여기서는 끊지 마라' 하는 자리를 두 군데만 표시한다(.mt-nb = white-space:nowrap).
       ① 숫자 덩어리(2.5/500 · 150 · 0.1) — 용량이 갈리면 안 된다
       ② 마지막 두 글자 — 한 글자만 떨어지지 않게 ('…점안 / 액' → '…점 / 안액')
     묶는 덩어리는 한글 두 글자나 반각 숫자 열 자까지로 짧게 잡는다.
     시스템 글자를 175%까지 키워도 한 줄 폭(360px 에서 141px)을 넘지 않아 표 밖으로 삐져나가지 않는다.
     글자를 지우거나 줄이지 않는다 — 이름은 그대로 다 보인다. */
  function mtName(name) {
    var s = String(name == null ? '' : name).replace(/\s+$/, '');
    var f = document.createDocumentFragment();
    if (!s) return f;
    /* 숫자·소수점·빗금에 바로 붙은 단위(mg·mL·%)까지 한 덩어리 — '…20 / mg' 로 갈리지 않게.
       열 자가 넘는 덩어리는 묶지 않는다(한 줄 폭을 넘으면 표 밖으로 삐져나간다) */
    var keep = [], re = /\d[\d.,\/]*[A-Za-z%]{0,3}/g, m, i;
    while ((m = re.exec(s))) { if (m[0].length > 1 && m[0].length <= 10) keep.push([m.index, m.index + m[0].length]); }
    /* 끝 두 글자 — 이모지 같은 서러게이트 쌍은 가운데서 가르지 않는다 */
    var n = 2, c = s.length > 2 ? s.charCodeAt(s.length - 2) : 0;
    if (c >= 0xDC00 && c <= 0xDFFF) n = 3;
    var a = s.length - n;
    /* 끝 두 글자 사이에 띄어쓰기가 있으면 거기가 원래 줄 바꿀 자리다 — 묶으면 더 나쁜 데서 끊긴다 */
    if (s.length > n && !/\s/.test(s.slice(a))) {
      var over = -1;
      for (i = 0; i < keep.length; i++) { if (keep[i][1] > a) over = i; }
      if (over < 0) keep.push([a, s.length]);
      /* '0.1%' 처럼 숫자 뒤 한두 글자는 함께 묶는다 — 역시 여섯 자까지만 */
      else if (keep[over][1] < s.length && s.length - keep[over][0] <= 6) keep[over][1] = s.length;
    }
    keep.sort(function (p, q) { return p[0] - q[0]; });
    /* 딱 붙어 있는 덩어리는 하나로 합친다 — '…20' 과 'mg' 를 따로 두면 그 사이에서 끊겨
       '타목시펜정 20 / mg' 가 된다. 다만 여섯 자까지만 합친다(한 줄 폭을 넘지 않게). */
    for (i = keep.length - 1; i > 0; i--) {
      if (keep[i - 1][1] >= keep[i][0] && keep[i][1] - keep[i - 1][0] <= 6) {
        keep[i - 1][1] = Math.max(keep[i - 1][1], keep[i][1]);
        keep.splice(i, 1);
      }
    }
    var pos = 0, k, sp;
    for (i = 0; i < keep.length; i++) {
      k = keep[i];
      if (k[0] < pos) continue;
      if (k[0] > pos) f.appendChild(document.createTextNode(s.slice(pos, k[0])));
      sp = document.createElement('span');
      sp.className = 'mt-nb';
      sp.textContent = s.slice(k[0], k[1]);
      f.appendChild(sp);
      pos = k[1];
    }
    if (pos < s.length) f.appendChild(document.createTextNode(s.slice(pos)));
    return f;
  }

  /* ── 머리줄(아침·점심·저녁·자기전) 글자를 칸에 맞춘다 ── 2026-09-27
     어르신은 시스템 글자 크기를 키워 쓰신다. 150% 부터 '자기전'이 칸(360px 에서 43px)을 넘어
     '자기 / 전'으로 갈리고, 200% 에서는 네 낱말이 모두 '아 / 침'처럼 한 글자씩 세로로 쌓여
     머리줄만 110px 을 차지했다(원래 42px). 붙어 있는 머리줄이라 표가 그만큼 가려졌다.
     고르는 길:
       ① 칸을 넓힌다 → 약 이름 칸이 좁아져 이름이 더 잘게 끊긴다. 이름은 줄이지 않기로 한 자리다.
       ② 머리줄 글자만 줄인다 → 이름 칸·체크 칸(46px·작은 폰 44px)은 그대로다.  ← 이것으로 한다
     지키는 것:
       · 줄이기만 한다. 100% 에서는 손대지 않는다(13px 그대로).
       · 네 칸이 같은 크기다 — 가장 넓은 낱말('자기전')에 맞춰 넷을 함께 줄인다.
       · 체크 칸 크기는 건드리지 않는다.
     px 이 아니라 %로 적는 까닭: 안드로이드 웹뷰의 글자 확대는 '적어 준 px'에 곱해진다.
     그려진 px 을 그대로 다시 적으면 확대가 두 번 걸린다. %(어미 칸에 대한 비율)는
     어미의 '적어 준 크기'로 풀린 뒤 확대가 마지막에 한 번만 걸리므로 어느 배율에서나 맞는다.
     재는 것도 그려진 폭(scrollWidth·clientWidth)뿐이라 배율을 몰라도 된다. */
  function mtLabel(hc) {               /* 글자를 감싸는 칸 — 시안에 없으면 만들어 쓴다 */
    var l = $('.mt-hl', hc);
    if (l) return l;
    l = document.createElement('span');
    l.className = 'mt-hl';
    while (hc.firstChild) l.appendChild(hc.firstChild);
    hc.appendChild(l);
    return l;
  }
  function mtFitHead(table) {
    if (!table) return 0;
    var hcs = $$('.mt-hc', table), labs = [], i, worst = 0, avail, need;
    if (!hcs.length) return 0;
    for (i = 0; i < hcs.length; i++) {
      labs[i] = mtLabel(hcs[i]);
      labs[i].style.fontSize = '';
      labs[i].style.whiteSpace = 'nowrap';       /* 한 줄로 폈을 때 얼마나 필요한지 잰다 */
    }
    for (i = 0; i < hcs.length; i++) {
      avail = labs[i].clientWidth;
      need = labs[i].scrollWidth;
      if (avail > 4 && need > 0 && need / avail > worst) worst = need / avail;
    }
    var pct = 0;
    if (worst > 1.002) {
      pct = Math.max(34, Math.floor(100 / worst));
      for (var pass = 0; pass < 12; pass++) {
        for (i = 0; i < labs.length; i++) labs[i].style.fontSize = pct + '%';
        var over = false;
        for (i = 0; i < hcs.length; i++) { if (labs[i].scrollWidth > labs[i].clientWidth) { over = true; break; } }
        if (!over || pct <= 34) break;
        pct -= 2;
      }
    }
    for (i = 0; i < labs.length; i++) labs[i].style.whiteSpace = '';
    return pct;
  }
  /* 글꼴이 늦게 올라오거나 화면을 돌리시면 폭이 달라진다 — 그때마다 다시 맞춘다 */
  function mtFitLater(table) {
    mtFitHead(table);
    setTimeout(function () { mtFitHead(table); }, 0);
    try { if (document.fonts && document.fonts.ready && document.fonts.ready.then) document.fonts.ready.then(function () { mtFitHead(table); }); } catch (eF) {}
    var tm = null;
    window.addEventListener('resize', function () {
      if (tm) clearTimeout(tm);
      tm = setTimeout(function () { tm = null; mtFitHead(table); }, 150);
    });
  }

  /* ── 이름이 거의 같은 약이 둘 등록돼 있는지 ──
     봉투를 사진으로 읽을 때 오타로 같은 약이 두 번 들어가는 일이 있다
     ('레보플레쉬점안액'과 '레보플레수쉬점안액'). 53(사진 등록)은 심평원 목록과 맞춰
     그 사진 안에서 중복을 합치지만(native.js HIRA.reconcile), 이미 등록돼 있는 약끼리는
     아무도 다시 보지 않는다. 그래서 55 에서 한 번만 여쭤본다.
     · 단정하지 않는다 — 다른 약일 수도 있다. 여기서 지우지도 않는다. 빼는 일은 환자분이 하신다.
     · 짝이 둘 이상일 수도 있다 — 모두 찾되 한 번에 한 짝만 여쭤본다(한꺼번에 여럿을 물으면 겁이 난다).
     · 용량만 다른 약(타이레놀정100 · 타이레놀정500)을 '같은 약'으로 잘못 짚지 않도록
       숫자가 다르면 아예 보지 않는다. 한쪽이 다른 쪽의 앞머리인 경우
       (아모잘탄정 · 아모잘탄플러스정)도 다른 제품이므로 뺀다. */
  /* mg · 밀리그램 · 밀리그람 · ㎎ 을 한 가지로 맞춘다 ── 2026-09-27
     54(사진 등록)는 식약처 정식 이름 그대로(…20밀리그램) 넣고 58(직접 등록)은 환자분이 적으신
     대로(…20mg) 넣는다. 글자만 견주면 같은 약이 다른 약이 되어 쌍둥이 알림이 뜨지 않았다. */
  function mtUnit(s) {
    return String(s == null ? '' : s)
      .replace(/마이크로그람|마이크로그램|마이크로그|㎍|mcg|μg|ug/gi, 'ug')
      .replace(/밀리그람|밀리그램|밀리그|㎎/g, 'mg')
      .replace(/밀리리터|밀리리|㎖|ml/gi, 'ml')
      .replace(/국제단위|단위|iu/gi, 'iu')
      .replace(/그람|그램/g, 'g');
  }
  function mtDupKey(s) {
    return mtUnit(s).replace(/[^0-9A-Za-z가-힣]/g, '').toLowerCase();
  }
  function mtDigits(s) { return String(s == null ? '' : s).replace(/[^0-9]/g, ''); }
  /* 열쇠 뒤에 붙은 용량을 뗀 이름 — '마그밀정500mg' → '마그밀정' */
  function mtNoDose(k) { return String(k == null ? '' : k).replace(/[0-9][0-9]*(?:mg|ug|ml|iu|g|kg|cc)?$/, ''); }
  function mtHan(k) { return String(k == null ? '' : k).replace(/[^가-힣]/g, ''); }
  function mtLev(a, b) {                       /* 글자 하나 차이만 가려내면 되므로 간단한 거리로 충분 */
    var m = a.length, n = b.length, i, j, prev = [], cur = [];
    if (!m) return n;
    if (!n) return m;
    for (j = 0; j <= n; j++) prev[j] = j;
    for (i = 1; i <= m; i++) {
      cur[0] = i;
      for (j = 1; j <= n; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
      }
      for (j = 0; j <= n; j++) prev[j] = cur[j];
    }
    return prev[n];
  }
  /* ── 두 이름이 같은 약인가 ── 2026-09-27 한곳으로 모았다
     전에는 이 판단이 mtTwinOf(58·54) 와 mtLookAlike(55) 두 곳에 따로 적혀 있어
     한쪽만 고치면 화면마다 다른 말을 하게 되어 있었다.
     null = 다른 약 · { same: true } = 글자까지 같음 · { same: false } = 거의 같음
     levMin = '글자 하나 차이' 라는 흐릿한 근거를 쓸 때 요구하는 한글 자릿수 —
     부르는 곳마다 예전 잣대가 달라(58·54 는 세 자 · 55 는 다섯 자) 그대로 지킨다. */
  function mtNear(ka, kb, levMin) {
    if (!ka || !kb) return null;
    if (ka === kb) return { same: true };
    var da = mtDigits(ka), db = mtDigits(kb);
    /* ── 한쪽에만 용량이 붙은 같은 이름 ── 54 는 용량을 떼고 넣고(마그밀정)
       58 은 환자분이 적으신 대로 넣는다(마그밀정500mg). 가장 잦은 꼴인데 길이 차이가 커서
       지금까지 한 번도 걸리지 않았다. 용량이 둘 다 적혀 있고 서로 다르면
       (타이레놀정100 · 타이레놀정500) 다른 약이므로 여기 걸리지 않는다. */
    if (!da || !db) {
      var ba = mtNoDose(ka), bb = mtNoDose(kb);
      if (ba && ba === bb && mtHan(ba).length >= 3) return { same: false };
    }
    if (da !== db) return null;                        /* 용량이 다르면 다른 약으로 본다 */
    /* ── 제조사 이름만 앞에 더 붙은 같은 약 ── '광동타목시펜정20mg' ↔ '타목시펜정20mg'.
       길이 차이가 둘이라 지금까지 못 걸렸다. 어린이·소아용은 어른 약과 갈라야 하므로 뺀다. */
    var lo = ka.length < kb.length ? ka : kb, hi = ka.length < kb.length ? kb : ka;
    if (hi.length - lo.length >= 1 && hi.length - lo.length <= 4
        && hi.slice(hi.length - lo.length) === lo
        && mtHan(lo).length >= 4
        && !/(어린이|소아|유아)/.test(hi.slice(0, hi.length - lo.length))) return { same: false };
    /* 여기서부터는 '글자 하나 차이' 라는 흐릿한 근거다 — 짧은 이름에는 쓰지 않는다 */
    var need = parseInt(levMin, 10) || 3;
    if (mtHan(ka).length < need || mtHan(kb).length < need) return null;
    if (Math.abs(ka.length - kb.length) > 1) return null;
    if (ka.indexOf(kb) === 0 || kb.indexOf(ka) === 0) return null;   /* 앞머리가 같을 뿐인 다른 제품 */
    if (ka.charAt(0) !== kb.charAt(0) || ka.charAt(1) !== kb.charAt(1)) return null;
    return mtLev(ka, kb) <= 1 ? { same: false } : null;
  }
  /* 적으신 이름과 거의 같은 약이 목록에 이미 있는지 — 55 의 쌍둥이 잣대와 같은 눈으로 본다.
     · 용량이 다르면(숫자가 다르면) 다른 약으로 본다 — 타이레놀정100 과 타이레놀정500
     · 한쪽이 다른 쪽의 앞머리인 경우(아모잘탄정 · 아모잘탄플러스정)도 다른 제품이다
     찾으면 { name: 이미 있는 이름, same: 글자까지 똑같은가 }, 없으면 null */
  function mtTwinOf(nm, names) {
    var ka = mtDupKey(nm), i, kb, r, fuzzy = mtHan(ka).length >= 3;
    if (!ka) return null;
    for (i = 0; i < (names || []).length; i++) {
      kb = mtDupKey(names[i]);
      if (!kb) continue;
      /* 글자가 완전히 같으면 한글 자릿수를 세지 않고 무조건 여쭙는다 — 2026-09-28
         전에는 맨 위에서 mtHan(ka).length < 3 이면 바로 null 이라, 'Herceptin'·'MTX'·'Femara'
         처럼 한글이 없는 이름은 똑같이 적어도 검사가 통째로 꺼졌다.
         그래서 같은 약이 55 오늘의 복약에 두 줄로 들어가고(05 홈 고리도 두 배로 센다),
         빈 칸을 채우려고 한 번 더 드시게 됐다. 이름 칸은 자유 입력이라 영문 이름이 막혀 있지 않다. */
      if (ka === kb) return { name: names[i], same: true };
      /* '거의 같음' 은 흐릿한 근거다 — 예전처럼 한글 세 자 이상인 이름에만 쓴다 */
      if (!fuzzy) continue;
      r = mtNear(ka, kb, 3);
      if (r) return { name: names[i], same: r.same };
    }
    return null;
  }
  /* 겹칠 수 있다고 한 번만 여쭙는다 — 단정하지 않는다. 그대로 넣으셔도 괜찮게 둔다. */
  function askTwin(tw, onYes) {
    var more = parseInt(tw.more, 10) || 0;
    askPop({
      icon: '🔎',
      title: '이미 넣으신 약 같아요',
      body: '「' + tw.name + '」 — 이름이 ' + (tw.same ? '똑같은' : '거의 같은') + ' 약이 목록에 이미 있어요.'
        + (more ? ' 이런 약이 ' + more + '개 더 있어요.' : '')
        + ' 같은 약이 두 줄로 들어가면 오늘의 복약에 두 번 보여서 한 번 더 드시게 될 수 있어요. '
        + '용량이 다른 약이거나 정말 두 가지를 쓰시는 것이면 그대로 넣으셔도 괜찮아요.',
      yes: '그래도 넣기',
      no: '닫기',
      onYes: onYes
    });
  }
  /* ── 새로 받아 온 약 (교수님 2026-09-30) ──
     진료 뒤 홈이 '새로운 약을 처방받으셨나요? 받으셨다면 약을 추가해 주세요'라고 여쭙는다. 그때 예전에 넣어 둔 약과
     이름이 똑같은 약을 추가하시면, 새 줄을 만들지 말지 먼저 여쭙는다(두 줄이 되면 오늘의 복약에 두 번 보인다).
       · '새로 받아 왔어요' → 그 약 줄의 며칠분을 오늘부터 다시 센다. 드시는 시간·횟수·어떤 약인지는 그대로 둔다
         (56 에서 고쳐 두신 시간이 사라지지 않게 — 바뀌었으면 56 에서 고치시라고 적는다).
         적으신 며칠분이 없으면 예전 며칠분 셈을 지운다 — 끝나는 날을 모르니 '곧 떨어져요'·'지났어요'를 띄우지 않는다.
       · '따로 넣기' → 예전처럼 새 줄로 넣는다(정말 두 가지를 쓰시는 경우).
     이름이 '거의' 같은 약은 예전처럼 askTwin 으로 여쭙는다 — 용량이 다른 약일 수 있어 같은 약으로 단정하지 않는다. */
  function mtSameOf(nm, meds) {
    var ka = mtDupKey(nm), i;
    if (!ka) return null;
    for (i = 0; i < (meds || []).length; i++) if (meds[i] && mtDupKey(meds[i].name) === ka) return meds[i];
    return null;
  }
  function refillSchedule(old, days) {
    var sc = {}, k, n = parseInt(days, 10);
    old = (old && typeof old === 'object') ? old : {};
    for (k in old) if (Object.prototype.hasOwnProperty.call(old, k)) sc[k] = old[k];
    if (n > 0 && n <= 365) { sc.days = n; sc.startedOn = ymd(new Date()); }
    else { delete sc.days; delete sc.startedOn; }
    return sc;
  }
  function askRefill(o) {
    var n = (o.names || []).length;
    askPop({
      icon: '💊',
      title: '이미 등록된 약이에요',
      body: '「' + o.names[0] + '」' + (n > 1 ? ' 외 ' + (n - 1) + '개' : '') + ' — 같은 이름의 약이 목록에 있어요. '
        + '새로 처방받아 오셨으면 ‘새로 받아 왔어요’를 눌러 주세요. 며칠분을 오늘부터 다시 세고, 드시는 시간은 그대로 둘게요.',
      yes: '새로 받아 왔어요',
      alt: '따로 넣기',
      no: '닫기',
      onYes: o.onRefill,
      onAlt: o.onSeparate
    });
  }
  /* 54(사진에서 찾은 약 등록)도 같은 눈으로 본다 — native.js 가 빌려 쓴다 */
  T.medTwin = { find: mtTwinOf, ask: askTwin, same: mtSameOf, refillAsk: askRefill, refillSchedule: refillSchedule };
  /* 그날의 드시는 시간(schedule.slotHist) — 77 진료 전 요약도 지난 날을 그날 시간으로 센다 (2026-10-26) */
  T.medSlotsOn = medSlotsOn;
  function mtLookAlike(meds) {
    var list = (meds || []).slice(0, 24), i, j, ka, kb, r, out = [], used = {};
    for (i = 0; i < list.length; i++) {
      if (used[i]) continue;
      ka = mtDupKey(list[i].name);
      if (!ka) continue;
      for (j = i + 1; j < list.length; j++) {
        if (used[j]) continue;
        kb = mtDupKey(list[j].name);
        if (!kb) continue;
        /* 글자가 완전히 같으면 자릿수를 세지 않는다 — mtTwinOf 와 같은 구멍이었다 (2026-09-28).
           'Herceptin' 두 줄이 이미 목록에 들어와 있으면 55 에서라도 알려 드려야 한다. */
        if (ka === kb) { out.push({ a: list[i], b: list[j], same: true }); used[i] = used[j] = 1; break; }
        if (mtHan(ka).length < 3 || mtHan(kb).length < 3) continue;   /* '거의 같음' 은 흐릿한 근거 */
        r = mtNear(ka, kb, 5);
        if (r) { out.push({ a: list[i], b: list[j], same: r.same }); used[i] = used[j] = 1; break; }
      }
    }
    return out;
  }

  function page55() {
    /* 아이폰의 뒤로가기로 이전 화면이 복원돼도 약 목록과 시간대를 다시 읽는다. */
    window.addEventListener('pageshow', function (ev) { if (ev.persisted) location.reload(); });
    var today = new Date(), T0 = ymd(today);
    var content = $('.content');
    var table = $('[data-role="medtable"]', content);
    var tbody = table ? $('[data-role="mt-body"]', table) : null;
    var help = $('[data-role="mt-help"]', content);
    if (!table || !tbody) return;
    var sub = $('.appbar-sub');
    var wkCard = $('[data-role="wk-card"]', content);
    var cap = $('[data-role="mt-cap"]', content);
    var ydayBn = $('[data-role="yday"]', content);
    var toTodayB = $('[data-act="to-today"]', content);
    var helpToday = help ? help.innerHTML : '';
    /* 시안 예시값(data-demo)은 app-device.css 가 가려 둔다 — 칠하거나 치운 뒤에만 드러낸다.
       칠하기 전에 드러내면 '5/6일 · 다 챙기셨어요'가 남의 기록처럼 보인다.
       (예시 약 줄과 74·75 예시 링크는 data-demo-off 로 아예 안 그려진다 — 아래에서 지우기도 한다) */
    function revealDemo() { $$('[data-demo]', content).forEach(function (el) { el.removeAttribute('data-demo'); }); }
    tbody.innerHTML = '';                       /* 시안의 예시 두 줄을 치운다 */
    /* '이 약을 쓰시는 동안' 밑의 시안 예시 두 줄도 여기서 먼저 치운다 —
       medications 응답을 기다리는 동안 남의 약이 '등록된 약'처럼 보이면 안 된다 */
    $$('.content a.listitem').forEach(function (a) {
      var h = a.getAttribute('href') || '';
      if (RX_EFF.test(h) && a.parentNode) a.parentNode.removeChild(a);
    });
    /* 오늘만 보이는 것 — 표 아래 안내·약 추가·이 약을 쓰시는 동안. 지난 날을 보실 때는 감춘다(.content.is-past).
       지난 날에 '약 추가하기'가 보이면 그날에 약을 넣는 것처럼 읽힌다. */
    (function () {
      var el = help ? help.nextElementSibling : null;
      while (el) {
        if (el !== toTodayB && !el.classList.contains('disclaimer')) el.setAttribute('data-tonly', '1');
        el = el.nextElementSibling;
      }
    })();

    /* ── 2026-10-26 사용 의견 ──
       ① 자기 전 약을 드시고 바로 주무시면 다음 날 체크할 길이 없었다 → 위 '이번 주' 카드에 한 주 날짜 줄(‹ ›)을 두고
          날짜를 누르면 표가 그날로 바뀐다. 지난 날은 기간 없이 다 고칠 수 있고, 앞으로는 오늘까지만.
          지난 날 체크도 med_logs 에 그날 날짜로 한 줄 쓴다(나중에 고친 것은 DB 가 med_logs.late 로 표시 — 2026-10-26 SQL).
       ② 표 위 '약 목록 고치기'로 순서와 드시는 시간을 바꾼다(medListSheet).
       지난 날 표는 그날 쓰던 약(넣은 날 이후·그만 쓴 날 전)과 그날의 드시는 시간(slotHist)으로 그린다. */
    var hrNow = today.getHours();
    var nowSlot = hrNow < 11 ? '아침' : hrNow < 16 ? '점심' : hrNow < 21 ? '저녁' : '자기전';
    var head = $('.mt-head', table);
    if (head) head.innerHTML = '';
    /* 표 다음에 무엇을 끼워 넣을지 미리 잡아 둔다 — 표나 안내문을 치워도 자리를 잃지 않게 */
    var tailAnchor = (help && help.nextSibling) || table.nextSibling || null;
    var doneBn = null;
    var cells = [];                             /* 오늘 드실 칸 전부 — 다 드셨는지 셀 때 쓴다 */
    var dayEls = [];                            /* 그날 표 아래에 붙인 것(정해진 때가 아닌 약) — 날을 바꾸면 치운다 */
    var allMeds = [], meds = [], FIRST = T0, logs = {}, weekOk = {}, myId = null, fitOn = false;
    var sel = T0, ws = weekStart(today);
    var ydayK = ymd(addDays(today, -1));
    var YDAY_KEY = 'todak_yday_closed';
    function dateOf(k) { var p = String(k).split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
    function dayWord(k) {
      var n = Math.round((dateOf(T0).getTime() - dateOf(k).getTime()) / 864e5);
      return n === 0 ? '오늘' : n === 1 ? '어제' : n + '일 전';
    }
    function dayLabel(k) { var d = dateOf(k); return kdate(d) + '(' + WDAY[d.getDay()] + ')'; }
    function lgOf(k) { return logs[k] || (logs[k] = {}); }
    /* 그날 쓰던 약 — 오늘은 지금 목록 그대로(기기 날짜가 어긋나도 방금 넣은 약이 빠지지 않게) */
    function medsOn(k) {
      if (k === T0) return meds;
      return allMeds.filter(function (m) {
        var d0 = medDay(m);
        if (d0 && d0 > k) return false;
        if (m.active === false) { var so = m.schedule && m.schedule.stoppedOn; return !!so && k < String(so); }
        return true;
      });
    }
    function slotsOf(m, k) {
      var s = k === T0 ? (m.schedule && m.schedule.slots) : medSlotsOn(m, k);
      return isArr(s) ? s : [];
    }
    /* 그날 챙겨야 하는 칸 — '필요할 때만'은 넣지 않는다 (아래 '다 챙김' 셈과 같은 규칙) */
    function dueOf(k) {
      var out = [];
      medsOn(k).forEach(function (m) {
        var all = slotsOf(m, k);
        all.forEach(function (s) { if (s !== '필요시') out.push(m.id + '|' + s); });
        if (!all.length) out.push(m.id + '|' + MT_UNK);
      });
      return out;
    }
    function statusOf(k) {
      if (k > T0) return 'future';
      if (k < FIRST) return 'before';
      if (k === T0) return 'today';
      if (!logs[k]) return 'unknown';
      var due = dueOf(k), lg = logs[k], on = 0;
      if (!due.length) return 'free';
      due.forEach(function (x) { if (lg[x]) on++; });
      return on === due.length ? 'all' : on ? 'part' : 'none';
    }

    /* 오늘 드실 것을 모두 체크하셨으면 알아볼 수 있게 한 줄 띄운다 */
    function paintDone() {
      var all = sel === T0 && cells.length > 0, i;
      if (all) for (i = 0; i < cells.length; i++) if (!cells[i]()) { all = false; break; }
      if (all && !doneBn) {
        doneBn = document.createElement('div');
        doneBn.className = 'banner banner--safe';
        doneBn.setAttribute('data-tonly', '1');
        doneBn.innerHTML = '<span class="b-ic" aria-hidden="true">✅</span><div class="small"><b>오늘 약을 모두 챙기셨어요.</b> 내일도 같은 자리에서 기다릴게요.</div>';
        content.insertBefore(doneBn, tailAnchor);
      } else if (!all && doneBn) {
        if (doneBn.parentNode) doneBn.parentNode.removeChild(doneBn);
        doneBn = null;
      }
    }

    /* 불러오지 못했을 때 — 빈 표('아직 등록된 약이 없어요')나 빈 동그라미('하나도 안 드셨어요')로
       보이면 드신 약을 또 드실 수 있다. 모르는 것은 모른다고 적고 다시 열 길을 드린다. */
    function loadFail(what) {
      [table, help, cap, ydayBn].forEach(function (el) { if (el && el.parentNode) el.parentNode.removeChild(el); });
      var ringE = $('[data-role="ring"]', content), rinE = $('[data-role="ring-in"]', content);
      if (ringE) ringE.style.setProperty('--p', '0%');
      if (rinE) rinE.innerHTML = '－';
      /* 시안 제목 '이번 주 잘 챙기고 계세요'를 그대로 두면 하나도 모르는 채로 잘 챙기고 있다고 말하는 것이다 (2026-09-27) */
      var tE = $('[data-role="wk-title"]', content), sE = $('[data-role="wk-sub"]', content);
      if (tE) tE.textContent = '이번 주 기록을 불러오지 못했어요';
      if (sE) sE.textContent = '이번 주 기록은 아래 ‘다시 열기’를 누르시면 보여요.';
      /* 시안 예시 날짜 줄이 남으면 남의 기록을 내 기록으로 읽으신다 */
      $$('[data-role="wk-nav"], [data-role="wk-days"], .wk-hint', content).forEach(function (el) { if (el.parentNode) el.parentNode.removeChild(el); });
      revealDemo();
      var fb = document.createElement('div');
      fb.className = 'banner banner--warn';
      fb.innerHTML = '<span class="b-ic" aria-hidden="true">⚠️</span><div class="small" style="flex:1 1 auto;"><b>'
        + what + '</b> 연결이 원활하지 않은 것 같아요. 잠시 뒤 <b>다시 열기</b>를 눌러 주세요. '
        + '<b>이 화면이 비어 보여도 등록하신 약과 오늘 체크는 그대로 있어요.</b>'
        + '<a class="btn btn-outline btn-sm btn-block" href="javascript:void(0)" data-role="med-retry" style="margin-top:10px;">다시 열기</a></div>';
      content.insertBefore(fb, wkCard ? wkCard.nextSibling : (content.firstElementChild ? content.firstElementChild.nextSibling : null));
      var rb = $('[data-role="med-retry"]', fb);
      if (rb) rb.addEventListener('click', function () { location.reload(); });
    }

    /* 기록 읽기 — a~b(포함) 날짜. 받은 날은 빈 날도 '읽음'으로 적어 둔다(모름과 '하나도 안 체크함'을 가르려고) */
    function loadRange(a, b, cb) {
      sb.from('med_logs').select('medication_id,date,slot,taken').gte('date', a).lte('date', b).then(function (r) {
        if (!r || r.error) return cb(false);
        var fresh = {}, d, k;
        for (d = dateOf(a); ymd(d) <= b; d = addDays(d, 1)) { k = ymd(d); fresh[k] = {}; }
        (r.data || []).forEach(function (l) {
          if (!l || !l.date) return;
          (fresh[l.date] || (fresh[l.date] = {}))[l.medication_id + '|' + l.slot] = !!l.taken;
        });
        for (k in fresh) if (Object.prototype.hasOwnProperty.call(fresh, k)) logs[k] = fresh[k];
        cb(true);
      }, function () { cb(false); });
    }

    /* 체크 한 번 = med_logs 한 줄. 지난 날이면 그 날짜로 쓴다. */
    function toggle(k, m, slot, el, paint) {
      if (el.__busy) return;                 /* 응답 전 중복 탭 방지 */
      if (dayChanged()) {
        toast('날짜가 바뀌어 화면을 새로 열어요.');
        setTimeout(function () { location.reload(); }, 900);
        return;
      }
      el.__busy = true;
      el.style.opacity = '.6';
      var lg = lgOf(k), key = m.id + '|' + slot, to = !lg[key];
      sb.from('med_logs').upsert({
        user_id: myId, medication_id: m.id, date: k, slot: slot, taken: to
      }, { onConflict: 'user_id,medication_id,date,slot' }).then(function (r3) {
        el.__busy = false;
        el.style.opacity = '';
        if (r3 && r3.error) return toast(koError(r3.error));
        lg[key] = to;
        if (to && k === T0) logEvent('med_check');
        if (k !== T0) {
          var ri = routeInfo(routeOfMed(m));
          toast(kdate(dateOf(k)) + ' ' + (slot === '필요시' ? '필요할 때' : slot === MT_UNK ? '' : mtLbl(slot)) + '\n'
            + (to ? ri.done.replace(/어요$/, '다고') + ' 표시했어요' : '표시를 지웠어요'));
        }
        paint();
        paintDone();
        paintWeek();
        paintYday();
      }, function () {
        el.__busy = false; el.style.opacity = '';
        toast('연결이 원활하지 않아요. 다시 시도해 주세요.');
      });
    }

    /* ── 그날 표 그리기 ── 약 하나가 한 줄 */
    function renderDay() {
      var k = sel, past = k !== T0;
      content.classList.toggle('is-past', past);
      table.classList.toggle('is-past', past);
      dayEls.forEach(function (e) { if (e.parentNode) e.parentNode.removeChild(e); });
      dayEls = [];
      cells = [];
      tbody.innerHTML = '';
      if (head) head.innerHTML = '';
      var ms = medsOn(k), lg = lgOf(k), prnList = [], slotsBy = {};
      ms.forEach(function (m) { slotsBy[m.id] = slotsOf(m, k); });
      var usedSlots = MT_SLOTS.filter(function (slot) {
        return ms.some(function (m) { return slotsBy[m.id].indexOf(slot) > -1; });
      });
      table.setAttribute('data-slots', String(usedSlots.length));
      if (head) {
        var nameHead = document.createElement('div');
        nameHead.className = 'mt-hc mt-hc--name';
        var nameLbl = document.createElement('span');
        nameLbl.className = 'mt-hl'; nameLbl.textContent = '약';
        nameHead.appendChild(nameLbl);
        head.appendChild(nameHead);
        usedSlots.forEach(function (slot) {
          var now = !past && slot === nowSlot;
          var hc = document.createElement('div');
          hc.className = 'mt-hc' + (now ? ' is-now' : '');
          hc.setAttribute('data-slot', slot);
          var hl = document.createElement('span');
          hl.className = 'mt-hl'; hl.textContent = slot;
          hc.appendChild(hl);
          if (now) hc.setAttribute('aria-current', 'time');
          head.appendChild(hc);
        });
      }
      ms.forEach(function (m) {
        var all = slotsBy[m.id];
        var fixed = [], other = [];
        all.forEach(function (s) {
          if (MT_SLOTS.indexOf(s) > -1) { if (fixed.indexOf(s) === -1) fixed.push(s); }
          else if (other.indexOf(s) === -1) other.push(s);
        });
        /* 드시는 때가 하나도 적혀 있지 않은 약 — 앱 등록 길로는 안 생기지만(54·58 이 막는다)
           옛 자료나 직접 고친 자료에는 있을 수 있다. 그냥 두면 표에도 아래 목록에도 없어서
           드셨는지 적을 길이 아예 사라진다. '시간 모름'으로 한 줄 내보내 빠뜨리지 않는다. */
        if (!fixed.length && !other.length) { prnList.push({ m: m, slot: MT_UNK }); return; }
        other.forEach(function (s) { prnList.push({ m: m, slot: s }); });
        if (!fixed.length) return;           /* 필요시뿐인 약은 표 아래 따로 */

        var ri = routeInfo(routeOfMed(m));
        var item = document.createElement('div');
        item.className = 'mt-item';
        var row = document.createElement('div');
        row.className = 'mt-row';
        row.setAttribute('data-med-row', m.id);

        /* 약 이름 — 말줄임을 쓰지 않는다. 비슷한 이름이 많아 잘리면 구별을 못 한다.
           길면 줄이 늘어나고, 누르면 아래로 펼쳐져 종류·시간·안내가 보인다(오늘 표에서만).
           약 그림은 이름 줄에 넣지 않는다 — 띄워 놓으면(float) 첫 줄뿐 아니라 둘째 줄까지
           22px 씩 잡아먹어, 그 폭 때문에 열 글자짜리 이름이 두 줄로 끊겼다. */
        var nb = document.createElement('button');
        nb.type = 'button'; nb.className = 'mt-name';
        var nmEl = document.createElement('span'); nmEl.className = 'mt-nm';
        nmEl.appendChild(mtName(m.name));
        nb.appendChild(nmEl);
        /* 먹는 약이 아닐 때만 아랫줄 — 그림도 여기에 함께 둔다.
           먹는 약의 💊 는 모든 줄에 똑같이 붙어 알려 주는 것이 없었고,
           '삼키는 약이 아니다'라는 표시는 설명 글씨 바로 옆에 있을 때 더 또렷하다. */
        if (routeOfMed(m) !== 'oral' && ri.label) {
          var rl = document.createElement('span'); rl.className = 'mt-sub';
          var ic = document.createElement('span');
          ic.className = 'mt-ic'; ic.setAttribute('aria-hidden', 'true'); ic.textContent = ri.ic;
          rl.appendChild(ic);
          rl.appendChild(document.createTextNode(ri.label));
          nb.appendChild(rl);
        }
        row.appendChild(nb);

        usedSlots.forEach(function (slot) {
          if (fixed.indexOf(slot) === -1) {
            var off = document.createElement('span');
            off.className = 'mt-cell mt-cell--off';
            off.setAttribute('aria-hidden', 'true');
            off.textContent = '·';
            row.appendChild(off);
            return;
          }
          var cell = document.createElement('button');
          cell.type = 'button'; cell.className = 'mt-cell';
          var mark = document.createElement('span');
          mark.className = 'mt-mark'; mark.setAttribute('aria-hidden', 'true'); mark.textContent = '✓';
          cell.appendChild(mark);
          var paint = function () {
            var taken = !!lg[m.id + '|' + slot];
            cell.className = 'mt-cell' + (taken ? ' is-on' : '');
            cell.setAttribute('aria-pressed', taken ? 'true' : 'false');
            cell.setAttribute('aria-label', m.name + ' · ' + (past ? kdate(dateOf(k)) + ' ' : '') + slot + ' · '
              + (taken ? ri.done + ' 누르면 취소돼요' : ri.doneIf + ' 눌러 주세요'));
          };
          paint();
          cell.addEventListener('click', function () { toggle(k, m, slot, cell, paint); });
          if (!past) cells.push(function () { return !!lg[m.id + '|' + slot]; });
          row.appendChild(cell);
        });
        item.appendChild(row);

        /* 펼침 — 전체 이름 · 약 종류 · 몇 시에 드시는지 · 안내로 가는 길 (오늘 표에서만 — 지난 날에는 체크만 고친다) */
        if (!past) {
          nb.setAttribute('aria-expanded', 'false');
          var det = document.createElement('div');
          det.className = 'mt-det'; det.hidden = true;
          var dnm = document.createElement('div'); dnm.className = 'mt-dnm'; dnm.appendChild(mtName(m.name));
          det.appendChild(dnm);
          var tparts = [];
          var tms = (m.schedule && m.schedule.times) || {};
          MT_SLOTS.forEach(function (s) {
            if (fixed.indexOf(s) === -1) return;
            var t = mtFmt(tms[s] || MT_TIME[s] || '');
            tparts.push(s + (t ? ' ' + t : ''));
          });
          other.forEach(function (s) { tparts.push(s === '필요시' ? '필요할 때' : s); });
          var d1 = document.createElement('div'); d1.className = 'mt-dline';
          d1.textContent = (ri.label ? ri.label + ' · ' : '') + tparts.join(' · ');
          det.appendChild(d1);
          var endD0 = medEndDay(m);
          if (endD0) {
            var ep0 = endD0.split('-');
            var d2 = document.createElement('div'); d2.className = 'mt-dline';
            d2.textContent = m.schedule.days + '일분 · '
              + (endD0 < T0 ? '적어 두신 날짜가 지났어요' : (+ep0[1]) + '월 ' + (+ep0[2]) + '일까지');
            det.appendChild(d2);
          }
          var acts = document.createElement('div'); acts.className = 'mt-dacts';
          if (window.TDRUG) {
            var info0 = window.TDRUG.match(m.name);
            var ga = document.createElement('a');
            ga.className = 'btn btn-outline btn-sm grow';
            ga.href = (info0.cancer ? '74-med-effect-detail.html' : '75-med-effect-none.html') + '?m=' + m.id;
            ga.textContent = info0.cancer ? '부작용 안내 보기' : '이 약 확인 결과';
            acts.appendChild(ga);
          }
          var ta = document.createElement('a');
          ta.className = 'btn btn-outline btn-sm grow';
          ta.href = '56-med-schedule.html?m=' + encodeURIComponent(m.id);
          ta.textContent = '시간 바꾸기';
          acts.appendChild(ta);
          /* 이 약 그만 쓰기 — 잘못 들어간 약·두 번 들어간 약을 여기서 바로 뺀다.
             예전에는 56 까지 가서 그 약 카드를 찾아야 했다. 줄이 아래로 길어지지 않게
             한 줄을 통째로 쓰고(flex 100%), 되돌릴 수 없는 일이라 한 번 여쭙는다. */
          var sa = document.createElement('button');
          sa.type = 'button';
          sa.className = 'btn btn-outline btn-sm';
          sa.style.flex = '1 1 100%';
          sa.textContent = '이 약 그만 쓰기';
          sa.addEventListener('click', function () {
            medStopAsk(m, {
              before: function () { if (sa.__busy) return false; busy(sa, true, '빼는 중…'); },
              after: function () { busy(sa, false); },
              done: function () {
                if (item.parentNode) item.parentNode.removeChild(item);
                /* 줄 하나가 빠지면 쓰는 시간대와 주간 셈이 달라진다 — 화면을 새로 그린다 */
                setTimeout(function () { location.reload(); }, 1200);
              }
            });
          });
          acts.appendChild(sa);
          det.appendChild(acts);
          nb.addEventListener('click', function () {
            var open = det.hidden;
            det.hidden = !open;
            nb.setAttribute('aria-expanded', open ? 'true' : 'false');
          });
          item.appendChild(det);
        } else {
          nb.setAttribute('aria-disabled', 'true');
          nb.style.cursor = 'default';
        }
        tbody.appendChild(item);
      });

      /* 표에 한 줄도 없으면(전부 필요시 약) 표를 감춘다 */
      var noRows = !tbody.children.length;
      table.style.display = noRows ? 'none' : '';
      if (help) {
        help.style.display = noRows ? 'none' : '';
        help.innerHTML = past
          ? '드셨는데 못 누르신 칸만 눌러 주세요.<br>잘못 누르셨으면 한 번 더 누르면 지워져요.'
          : helpToday;
      }
      if (!noRows) {
        if (!fitOn) { fitOn = true; mtFitLater(table); }      /* 글자를 키워 쓰시는 분께도 머리줄이 한 줄로 남게 */
        else mtFitHead(table);
      }

      /* ── 네 칸에 안 들어가는 시간대 ── 빠뜨리지 않고 아래에 따로 둔다.
         '필요시'는 정해진 시각이 없어 알림도 없다(native.js). 그래도 드시면 기록은 남긴다. */
      if (prnList.length) {
        var lab = document.createElement('div');
        lab.className = 'section-label';
        lab.textContent = '정해진 때가 아닌 약';
        content.insertBefore(lab, tailAnchor);
        dayEls.push(lab);
        prnList.forEach(function (p) {
          var m = p.m, slot = p.slot;
          var riP = routeInfo(routeOfMed(m));
          var li = document.createElement('div');
          li.className = 'listitem mt-prn';
          var icP = document.createElement('span');
          icP.className = 'li-ic'; icP.setAttribute('aria-hidden', 'true'); icP.textContent = riP.ic;
          var body = document.createElement('div'); body.className = 'li-body';
          var t1 = document.createElement('div'); t1.className = 'li-title'; t1.appendChild(mtName(m.name));
          var s1 = document.createElement('div'); s1.className = 'li-sub';
          /* 말은 약 종류에 맞춘다 — 점안액·연고에 '드셨으면'이라고 적지 않게 (riP 는 바로 위에서 정해 둔 것) */
          s1.textContent = (slot === '필요시' ? '필요할 때만'
            : slot === MT_UNK ? '쓰시는 때가 저장되지 않았어요'
            : slot) + ' · ' + riP.doneIf + ' 오른쪽을 눌러 주세요';
          body.appendChild(t1); body.appendChild(s1);
          var btn = document.createElement('button');
          btn.type = 'button'; btn.className = 'li-mark';
          var mk = document.createElement('span');
          mk.className = 'mt-mark'; mk.setAttribute('aria-hidden', 'true'); mk.textContent = '✓';
          btn.appendChild(mk);
          var paintP = function () {
            var taken = !!lg[m.id + '|' + slot];
            btn.className = 'li-mark' + (taken ? ' is-on' : '');
            mk.style.background = taken ? 'var(--safe)' : 'var(--white)';
            mk.style.borderColor = taken ? 'var(--safe)' : 'var(--outline-strong)';
            mk.style.color = taken ? '#fff' : 'transparent';
            li.style.borderColor = taken ? 'var(--safe)' : 'var(--outline)';
            li.style.background = taken ? 'var(--safe-tint)' : 'var(--white)';
            btn.setAttribute('aria-pressed', taken ? 'true' : 'false');
            btn.setAttribute('aria-label', m.name + ' · ' + (past ? kdate(dateOf(k)) + ' ' : '') + slot + ' · '
              + (taken ? riP.done + ' 누르면 취소돼요' : riP.doneIf + ' 눌러 주세요'));
          };
          paintP();
          btn.addEventListener('click', function () { toggle(k, m, slot, btn, paintP); });
          /* '필요시'는 드셔야 하는 것이 아니라 필요할 때만이다 — '오늘 다 드셨어요' 셈에 넣지 않는다.
             (예전 자료에 들어 있을지 모르는 낯선 시간대는 정해진 때이므로 센다) */
          if (!past && slot !== '필요시') cells.push(function () { return !!lg[m.id + '|' + slot]; });
          li.appendChild(icP); li.appendChild(body); li.appendChild(btn);
          content.insertBefore(li, tailAnchor);
          dayEls.push(li);
        });
      }
      if (!ms.length && past) {
        var nb0 = document.createElement('div');
        nb0.className = 'banner banner--info';
        nb0.innerHTML = '<span class="b-ic" aria-hidden="true">💊</span><div class="small">이날은 등록된 약이 없었어요.</div>';
        content.insertBefore(nb0, tailAnchor);
        dayEls.push(nb0);
      }

      /* 머리띠·앱바 날짜·돌아가기 */
      if (cap) {
        var dd = dateOf(k);
        cap.className = 'mt-cap' + (past ? ' is-past' : '');
        if (past) {
          cap.innerHTML = '<span class="cap-ic" aria-hidden="true">📅</span><div class="cap-t"></div>'
            + '<button type="button" class="btn btn-outline btn-sm" data-act="to-today">오늘로 ›</button>';
          $('.cap-t', cap).innerHTML = esc(dayLabel(k) + ' · ' + dayWord(k)) + '<small>지난 날 기록을 고치고 있어요</small>';
        } else {
          cap.innerHTML = '<div class="cap-t"></div>'
            + (meds.length ? '<button type="button" class="btn btn-outline btn-sm" data-act="med-list-edit">약 목록 고치기</button>' : '');
          $('.cap-t', cap).innerHTML = (meds.length ? '오늘 드실 약' : '오늘') + '<small>' + esc(kdate(dd) + '(' + WDAY[dd.getDay()] + ')') + '</small>';
        }
      }
      if (sub) { sub.textContent = kdate(dateOf(k)) + ' · ' + dayWord(k) + (past ? ' 기록' : ''); sub.removeAttribute('data-demo'); }
      if (toTodayB) toTodayB.style.display = past ? '' : 'none';
      paintDone();
    }

    /* ── 한 주 날짜 줄 + 그 주 요약 고리 ── */
    function paintWeek() {
      if (!wkCard) return;
      var rangeE = $('[data-role="wk-range"]', wkCard), daysE = $('[data-role="wk-days"]', wkCard);
      var prevB = $('[data-act="wk-prev"]', wkCard), nextB = $('[data-act="wk-next"]', wkCard);
      var nav = $('[data-role="wk-nav"]', wkCard), hint = $('.wk-hint', wkCard);
      var none = !allMeds.length;
      [nav, daysE, hint].forEach(function (el) { if (el) el.style.display = none ? 'none' : ''; });
      var we = addDays(ws, 6);
      var weeksAgo = Math.round((weekStart(today).getTime() - ws.getTime()) / (7 * 864e5));
      var cur = weeksAgo === 0;
      if (rangeE) rangeE.innerHTML = esc(kdate(ws) + ' ~ ' + (we.getMonth() === ws.getMonth() ? we.getDate() + '일' : kdate(we)))
        + '<small>' + (cur ? '이번 주' : weeksAgo === 1 ? '지난주' : weeksAgo + '주 전') + '</small>';
      if (prevB) prevB.disabled = ymd(addDays(ws, -1)) < FIRST;          /* 처음 약을 넣은 주까지 */
      if (nextB) nextB.disabled = ymd(addDays(ws, 7)) > T0;              /* 오늘이 든 주까지 */
      var full = 0, pastN = 0, anyOn = false;
      var WORD = { today: '오늘', all: '다 챙기셨어요', part: '빈 칸이 있어요', none: '체크한 기록이 없어요',
                   free: '정해진 때 드실 약이 없던 날', unknown: '', future: '아직 오지 않은 날', before: '약을 넣기 전' };
      if (daysE) daysE.innerHTML = '';
      for (var i = 0; i < 7; i++) (function (d) {
        var k = ymd(d), st = statusOf(k), off = st === 'future' || st === 'before';
        if (st === 'all' || st === 'part' || st === 'none') { pastN++; if (st === 'all') full++; if (st !== 'none') anyOn = true; }
        if (!daysE) return;
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'wk-d' + (k === sel ? ' is-sel' : '');
        b.disabled = off;
        b.setAttribute('aria-label', kdate(d) + ' ' + WDAY[d.getDay()] + '요일' + (WORD[st] ? ' · ' + WORD[st] : ''));
        if (k === sel) b.setAttribute('aria-current', 'date');
        var mk = (off || st === 'unknown' || st === 'free') ? 'off' : st;
        b.innerHTML = '<span class="wk-w">' + (k === T0 ? '오늘' : WDAY[d.getDay()]) + '</span><span class="wk-n">' + d.getDate()
          + '</span><span class="wk-st wk-st--' + mk + '" aria-hidden="true"></span>';
        if (!off) b.addEventListener('click', function () { goDay(k); });
        daysE.appendChild(b);
      })(addDays(ws, i));

      /* 그 주 요약 — 지난 날 가운데 다 챙긴 날(오늘은 하루가 남아 세지 않는다).
         제목은 실제 날수에 맞춘다 — 하루도 못 챙기셨는데 '잘 챙기고 계세요'라고 하지 않는다. 탓하는 말도 쓰지 않는다 (2026-09-26·28) */
      var ringE = $('[data-role="ring"]', wkCard), rinE = $('[data-role="ring-in"]', wkCard);
      var tE = $('[data-role="wk-title"]', wkCard), sE = $('[data-role="wk-sub"]', wkCard);
      if (ringE) ringE.style.setProperty('--p', pastN ? Math.round(100 * full / pastN) + '%' : '0%');
      if (rinE) rinE.textContent = pastN ? full + '/' + pastN + '일' : '－';
      var tt, st2;
      if (none) { tt = '약을 등록하면 여기서 챙겨 드려요'; st2 = '아래에서 챙기실 약을 등록해 주세요.'; }
      else if (!pastN) { tt = cur ? '이번 주가 막 시작됐어요' : '이 주는 기록할 날이 없어요'; st2 = cur ? '오늘 드실 약을 아래 표에서 챙겨 주세요.' : ''; }
      else {
        if (full === pastN) tt = cur ? '이번 주 다 챙기고 계세요' : '이 주는 다 챙기셨어요';
        else if (full * 10 >= pastN * 7) tt = cur ? '이번 주 잘 챙기고 계세요' : '이 주도 잘 챙기셨어요';
        else if (anyOn) tt = cur ? '이번 주 챙기신 기록이에요' : '이 주 챙기신 기록이에요';
        else tt = cur ? '이번 주 기록이 아직 없어요' : '이 주는 기록이 없어요';
        st2 = (cur ? '지난 ' : '') + pastN + '일 중 <b>' + full + '일</b> 다 챙기셨어요. 빠뜨린 날이 있어도 괜찮아요.';
      }
      if (tE) tE.textContent = tt;
      if (sE) sE.innerHTML = st2;
    }

    /* ── 어제 빈 칸 ── 자기 전 약을 드시고 바로 주무시면 다음 날 체크할 길이 없었다(사용 의견).
       오늘 표를 볼 때 한 번 알린다. '닫기'를 누르시면 오늘은 다시 띄우지 않는다. */
    function paintYday() {
      if (!ydayBn) return;
      var em = [];
      if (sel === T0 && ydayK >= FIRST && logs[ydayK]) {
        var closed = null;
        try { closed = localStorage.getItem(YDAY_KEY); } catch (eY) {}
        if (closed !== T0) em = dueOf(ydayK).filter(function (x) { return !logs[ydayK][x]; });
      }
      if (!em.length) { ydayBn.style.display = 'none'; return; }
      ydayBn.removeAttribute('data-demo-off');
      ydayBn.style.display = '';
      var t = $('[data-role="yday-t"]', ydayBn);
      var s0 = em[0].split('|')[1];
      if (t) t.textContent = (em.length === 1 && MT_SLOTS.indexOf(s0) > -1)
        ? '어제 ' + mtLbl(s0) + ' 칸이 비어 있어요.'
        : '어제 빈 칸이 ' + em.length + '개 있어요.';
    }

    /* ── 날 바꾸기 ── 그 주 기록을 아직 안 읽었으면 읽고 나서 바꾼다. 못 읽으면 보던 날에 머문다
       (모르는 날을 빈 칸으로 보여 주면 이미 드신 약을 안 드신 것처럼 읽으신다) */
    var busyWk = false;
    function goDay(k) {
      if (busyWk) return;
      if (k > T0) k = T0;
      if (k < FIRST) k = FIRST;
      var nws = weekStart(dateOf(k)), wk = ymd(nws);
      function show() { sel = k; ws = nws; renderDay(); paintWeek(); paintYday(); }
      if (weekOk[wk]) return show();
      busyWk = true;
      var rs = wkCard ? $('[data-role="wk-range"] small', wkCard) : null;
      if (rs) rs.textContent = '불러오는 중…';
      var end = ymd(addDays(nws, 6));
      loadRange(wk < FIRST ? FIRST : wk, end > T0 ? T0 : end, function (ok) {
        busyWk = false;
        if (!ok) { paintWeek(); return toast('그 주 기록을 불러오지 못했어요.\n잠시 뒤 다시 눌러 주세요.'); }
        weekOk[wk] = true;
        show();
      });
    }

    content.addEventListener('click', function (ev) {
      var a = ev.target && ev.target.closest ? ev.target.closest('[data-act]') : null;
      if (!a || a.disabled) return;
      var act = a.getAttribute('data-act');
      if (act === 'to-today') { goDay(T0); try { content.scrollTop = 0; } catch (eS) {} }
      else if (act === 'wk-prev') goDay(ymd(addDays(dateOf(sel), -7)));
      else if (act === 'wk-next') goDay(ymd(addDays(dateOf(sel), 7)));
      else if (act === 'yday-open') goDay(ydayK);
      else if (act === 'yday-close') { try { localStorage.setItem(YDAY_KEY, T0); } catch (eC) {} paintYday(); }
      else if (act === 'med-list-edit') {
        medListSheet({ meds: meds, onSaved: function () {
          /* 고친 schedule 은 같은 약 객체에 이미 들어 있다 — 순서만 다시 세우고 다시 그린다 */
          meds = medSort(meds);
          allMeds = medSort(allMeds);
          renderDay(); paintWeek(); paintYday();
        } });
      }
    });

    /* 며칠분(54·58 에서 받은 일수)이 끝난 약 · 이름이 거의 같은 약 · 이 약을 쓰시는 동안 — 오늘 표를 볼 때만 */
    function todayExtras() {
      /* 며칠분이 끝난 약 — 알림이 끝없이 울리지 않게 다 쓰셨는지 여쭤본다.
         스스로 끊으시라는 뜻이 아니라, 받아 온 만큼 다 쓰셨으면 목록을 정리하시라는 안내다 (그만 쓰기는 56) */
      var ended = meds.filter(function (m) { var e = medEndDay(m); return e && e < T0; });
      if (ended.length) {
        var eb = document.createElement('div');
        eb.className = 'banner banner--warn';
        eb.setAttribute('data-tonly', '1');
        /* 새로 처방받아 오셨으면 같은 약을 추가하시면 된다 — 58·54 가 '새로 받아 왔어요'(며칠분만 다시 세기)를 여쭙는다 (2026-09-30) */
        eb.innerHTML = '<span class="b-ic">📦</span><div class="small" style="flex:1 1 auto;"><b class="eb-names"></b> 적어 두신 며칠분이 지났어요. '
          + '새로 처방받아 오셨으면 약을 추가해 주세요(같은 약이면 며칠분을 다시 셀게요). '
          + '다 쓰셨으면 <b>복약 설정</b>에서 ‘이 약 그만 쓰기’를 눌러 주세요.'
          + '<div class="row" style="gap:8px; margin-top:10px;">'
          + '<a class="btn btn-outline btn-sm grow" href="58-med-manual.html?from=55-med-today.html">약 추가하기</a>'
          + '<a class="btn btn-outline btn-sm grow" href="56-med-schedule.html">복약 설정</a></div></div>';
        $('.eb-names', eb).textContent = ended.slice(0, 3).map(function (m) { return '「' + m.name + '」'; }).join(' ') + (ended.length > 3 ? ' 외 ' + (ended.length - 3) + '개' : '') + ' —';
        if (wkCard && wkCard.parentNode) wkCard.parentNode.insertBefore(eb, wkCard.nextSibling);
      }

      /* 이름이 거의 같은 약 둘 — 봉투를 읽을 때 오타로 두 번 들어갔을 수 있다.
         여기서는 여쭤보기만 한다(지우지 않는다). 지우는 길은 56 한 곳뿐이라 길을 함께 드린다. */
      var twins = mtLookAlike(meds);
      if (twins.length) {
        var tw = twins[0], more = twins.length - 1;
        var db = document.createElement('div');
        db.className = 'banner banner--info';
        db.setAttribute('data-tonly', '1');
        db.innerHTML = '<span class="b-ic" aria-hidden="true">🔎</span><div class="small" style="flex:1 1 auto;">'
          + '<b class="db-names"></b> — <span class="db-how"></span> <b>약 봉투를 한 번만 다시 봐 주세요.</b> '
          + '같은 약이 두 번 들어간 것이면 하나만 빼시면 돼요. 서로 다른 약이면 그대로 두셔도 괜찮아요.'
          + '<span class="db-more"></span>'
          + '<button type="button" class="btn btn-outline btn-sm btn-block" data-role="twin-go" style="margin-top:10px;"></button></div>';
        $('.db-names', db).textContent = '「' + tw.a.name + '」' + waGwa(tw.a.name) + ' 「' + tw.b.name + '」';
        $('.db-how', db).textContent = tw.same ? '이름이 똑같아요.' : '이름이 거의 같아요.';
        if (more > 0) $('.db-more', db).textContent = ' 이런 짝이 ' + more + '개 더 있어요 — 하나씩 차례로 알려 드릴게요.';
        /* 표에 그 약 줄이 있으면 그리로 데려가 펼친다. 표에 없는 약(필요할 때만 드시는 약)은
           복약 설정의 그 카드로 보낸다. 어느 쪽이든 빼는 단추가 눈앞에 오게. */
        var tgo = $('[data-role="twin-go"]', db);
        var trow = null;
        try { trow = $('[data-med-row="' + tw.b.id + '"]', content); } catch (eQ) { trow = null; }
        if (trow) {
          tgo.textContent = '「' + tw.b.name + '」 줄 열기';
          tgo.addEventListener('click', function () {
            var rowT = null;
            try { rowT = $('[data-med-row="' + tw.b.id + '"]', content); } catch (eR) { rowT = null; }   /* 표를 다시 그렸으면 새 줄 */
            if (!rowT) return;
            var nbT = $('.mt-name', rowT);
            var detT = rowT.parentNode ? $('.mt-det', rowT.parentNode) : null;
            if (nbT && detT && detT.hidden) nbT.click();
            var box = rowT.getBoundingClientRect(), cb = content.getBoundingClientRect();
            content.scrollTop = content.scrollTop + (box.top - cb.top) - 12;
            try { if (nbT) nbT.focus(); } catch (eT) {}
          });
        } else {
          tgo.textContent = '복약 설정에서 빼기';
          tgo.addEventListener('click', function () { location.href = '56-med-schedule.html?m=' + encodeURIComponent(tw.b.id); });
        }
        if (wkCard && wkCard.parentNode) wkCard.parentNode.insertBefore(db, wkCard.nextSibling);
      }

      /* '이 약을 쓰시는 동안' — 등록한 약별 안내 링크 (druginfo.js 매핑) · 예전 문구('드시는 동안')도 찾는다 */
      var durLabel = $$('.section-label', content).filter(function (l) { return /(드시는|쓰시는) 동안/.test(l.textContent); })[0];
      if (durLabel && meds.length && window.TDRUG) {
        var anchor2 = durLabel.nextElementSibling;   /* '등록한 약 전체 보기' 링크 앞에 끼움 */
        /* 시안에 들어 있는 예시 두 줄(타목시펜·암로디핀)을 치운다 */
        var demo2 = [];
        var el2 = durLabel.nextElementSibling;
        while (el2 && el2.tagName === 'A') {
          if (RX_EFF.test(el2.getAttribute('href') || '')) demo2.push(el2);
          el2 = el2.nextElementSibling;
        }
        demo2.forEach(function (d) { if (d.parentNode) d.parentNode.removeChild(d); });
        anchor2 = durLabel.nextElementSibling;
        /* 유방암 치료약이 아닌 약 — 예전에는 토닥 목록에 없으면 '목록에서 확인하지 못한 약이에요'로만 적고,
           눌러야 식약처 자료를 찾았다(5초). 돌아오면 또 '확인하지 못한 약'이었다(2026-10-26 사용 의견).
           이제 식약처에서 찾아 둔 것(druginfo.js 가 이 기기에 30일 둔다)이 있으면 효능 한 줄을 바로 보여 주고,
           아직 없는 약은 이 화면이 뒤에서 하나씩 찾아(허가정보 → 효능효과·용법용량) 그 줄을 채운다.
           한 번 찾아 두면 약 정보(75)도 기다리지 않고 바로 열린다. */
        var PRM = window.TDPRM || null, need = [];
        function paintDrug(m, info, a) {
          var lt = $('.li-title', a), sub = $('.li-sub', a);
          lt.innerHTML = '';
          lt.appendChild(mtName(m.name));
          lt.appendChild(document.createTextNode(info.cancer ? ' · 부작용 안내' : ' · 약 정보'));
          if (info.cancer) { sub.textContent = info.cat + ' — 생길 수 있는 불편과 병원에 연락할 때'; return true; }
          var c = PRM ? PRM.cached(m.name) : null;
          var dc = (c && c.ok && c.seq && PRM.docCached) ? PRM.docCached(c.seq) : null;
          var ee = (dc && dc.ee && PRM.eeShort) ? PRM.eeShort(dc.ee) : '';
          if (c && c.ok) {
            sub.textContent = ee ? '효능 · ' + ee
              : (info.cat ? '유방암 치료약이 아니라서 부작용 안내는 없어요'
                 : ((c.ingr && c.ingr.length) ? '성분 · ' + c.ingr.slice(0, 2).join(', ') : '식약처 자료에서 찾았어요') + ' — 눌러서 자세히');
            return (!!dc || !c.seq) && !!c.full;      /* 효능효과·주의까지 받아 뒀으면 끝(아니면 뒤에서 마저 받는다) */
          }
          if (c && !c.ok && c.reason === 'none') {
            sub.textContent = info.cat ? '유방암 치료약이 아니라서 부작용 안내는 없어요'
              : '식약처 자료에서 찾지 못한 약이에요 — 담당 의사나 약사에게 여쭤보세요';
            return true;
          }
          sub.textContent = info.cat ? '유방암 치료약이 아니라서 부작용 안내는 없어요'
            : PRM ? '약 정보를 확인하는 중이에요…' : '목록에서 확인하지 못한 약이에요 — 눌러서 안내 보기';
          return false;
        }
        meds.forEach(function (m) {
          var info = window.TDRUG.match(m.name);
          var a = document.createElement('a');
          a.className = 'listitem';
          a.setAttribute('data-tonly', '1');
          a.setAttribute('data-drug-row', m.id);
          a.href = (info.cancer ? '74-med-effect-detail.html' : '75-med-effect-none.html') + '?m=' + m.id;
          a.innerHTML = '<span class="li-ic" style="background:var(--primary-tint);">' + (info.cancer ? '💊' : '🩺') + '</span>'
            + '<div class="li-body"><div class="li-title"></div><div class="li-sub"></div></div><span class="li-chev">›</span>';
          if (!paintDrug(m, info, a) && PRM) need.push({ m: m, info: info, a: a });
          durLabel.parentNode.insertBefore(a, anchor2);
        });
        /* 세 약씩 함께 찾는다 — 한 약에 세 번(허가정보 → 주의·상세 → 효능효과) 오가서, 하나씩이면 약 여덟 개에 수십 초가 걸린다.
           중계 함수에 한꺼번에 몰리지도 않게 셋까지만. 연결이 안 되면 그 줄만 '다시' 안내로 둔다.
           칸이나 그림에서 예외가 나도 다음 약은 이어서 찾는다(그 줄만 '확인하는 중'에 머물지 않게) */
        var nextI = 0;
        function worker() {
          if (nextI >= need.length) return;
          var x = need[nextI++];
          var done = function (d) {
            try {
              if (!paintDrug(x.m, x.info, x.a) && !(d && (d.ok || d.reason === 'none')) && !x.info.cat) {
                $('.li-sub', x.a).textContent = '약 정보를 지금 확인하지 못했어요 — 눌러서 다시 보기';
              }
            } catch (eP) {}
            worker();
          };
          PRM.lookup(x.m.name, 'full').then(function (d) {
            if (d && d.ok && d.seq && PRM.doc) return PRM.doc(d.seq).then(function () { return d; }, function () { return d; });
            return d;
          }).then(done, function () { done(null); });
        }
        for (var wk = 0; wk < 3; wk++) worker();
      } else if (durLabel && !meds.length) {
        durLabel.style.display = 'none';
        var el3 = durLabel.nextElementSibling;
        while (el3 && el3.tagName === 'A') {
          var nx3 = el3.nextElementSibling;
          if (RX_EFF.test(el3.getAttribute('href') || '')) el3.parentNode.removeChild(el3);
          el3 = nx3;
        }
      }
    }

    /* 통신이 끊기면 이 약속들은 '오류가 담긴 응답'이 아니라 아예 거절된다.
       받는 자리(then)만 있으면 loadFail 이 한 번도 불리지 않아, 시안 제목만 남은 반쪽 화면이 됐다.
       거절도 같은 loadFail 로 보낸다. (2026-09-27) */
    uid(function (id) {
      myId = id;
      /* 그만 쓴 약도 함께 읽는다 — 지난 날 표에는 그만 쓰기 전 날까지 보여야 한다(stoppedOn 이 적힌 약만) */
      sb.from('medications').select('id,name,schedule,active,created_at').then(function (r) {
        if (!r || r.error) { loadFail('약 목록을 불러오지 못했어요.'); return; }
        allMeds = medSort((r.data || []).filter(function (m) {
          return m && (m.active !== false || !!(m.schedule && m.schedule.stoppedOn));
        }));
        meds = allMeds.filter(function (m) { return m.active !== false; });
        allMeds.forEach(function (m) { var d0 = medDay(m); if (d0 && d0 < FIRST) FIRST = d0; });
        /* 이번 주와 어제(월요일이면 어제는 지난주) 기록을 한 번에 읽는다 */
        var a = ymd(ws) < ydayK ? ymd(ws) : ydayK;
        if (a < FIRST) a = FIRST;
        loadRange(a, T0, function (ok) {
          if (!ok) { loadFail('오늘 체크하신 기록을 불러오지 못했어요.'); return; }
          weekOk[ymd(ws)] = true;
          /* ── 약이 하나도 없을 때 ── 표 대신 등록으로 가는 길을 보여 준다 */
          if (!meds.length) {
            var eb0 = document.createElement('div');
            eb0.className = 'banner banner--info';
            eb0.setAttribute('data-tonly', '1');
            eb0.innerHTML = '<span class="b-ic" aria-hidden="true">💊</span><div class="small"><b>아직 등록된 약이 없어요.</b> 약을 등록하시면 여기에 표로 모아 보여 드리고, 챙기실 시간에 알려 드려요.</div>';
            if (wkCard && wkCard.parentNode) wkCard.parentNode.insertBefore(eb0, wkCard.nextSibling);
          }
          renderDay();
          paintWeek();
          paintYday();
          todayExtras();
          revealDemo();
        });
      }, function () { loadFail('약 목록을 불러오지 못했어요.'); });
    });
  }

  /* ── 심평원(건강보험심사평가원) 약 목록 응답 읽기 ──
     지금까지는 <itmNm> 만 정규식으로 긁고 나머지를 버렸다. 그런데 같은 <item> 안에
     투여경로(injcPthNm: 내복·외용·주사)·단위(unit: 정·mL/병·g/개)·약효분류번호(meftDivNo)가
     이미 함께 온다. <item> 블록 단위로 잘라 품목명과 이 값들을 짝지어 들고 있는다.
     중계 함수(hosp-proxy)는 XML 을 그대로 흘려보내므로 서버는 손대지 않는다.
     54·58 이 이 값으로 약 종류(먹는 약·눈에 넣는 약·바르는 약…)를 1순위로 정해 schedule.route 에 저장한다. */
  /* ── 식약처가 글자 대신 보내는 문자참조 ── 2026-09-27 실제 응답에서 확인
     '삼성록소프로펜나트륨정(록소프로펜나트륨수화물)&#13;' 처럼 ITEM_NAME 에 '&#13;' 가
     글자 그대로 들어온다. 그대로 두면 환자분 화면의 약 이름에 '&#13;' 이 보인다.
     글을 고치는 것이 아니라 원래 글자로 되돌려 놓는 것이다. */
  function tagEnt(t) {
    var s = String(t == null ? '' : t).replace(/&#(x[0-9a-fA-F]+|[0-9]+);/g, function (all, code) {
      var hex = (code.charAt(0) === 'x' || code.charAt(0) === 'X');
      var n = hex ? parseInt(code.slice(1), 16) : parseInt(code, 10);
      if (!(n > 0 && n <= 0xffff)) return all;
      return String.fromCharCode(n);
    });
    return s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&#?apos;/g, "'").replace(/&amp;/g, '&');
  }
  function drugTag(block, tag) {
    var m = new RegExp('<' + tag + '\\b[^>]*>([\\s\\S]*?)<\\/' + tag + '>').exec(block);
    if (!m) return '';
    return tagEnt(String(m[1]).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')).replace(/\s+/g, ' ').trim();
  }
  /* 이름 뒤 괄호를 뗀다 — 괄호 안에 괄호가 또 있는 이름도 있다
     ('넥스티올정(애엽95%에탄올연조엑스(20→1))'). 한 겹만 보면 ')' 한 짝이 이름에 남는다. */
  function cleanDrugName(s) {
    var t = String(s == null ? '' : s);
    for (var i = 0; i < 4; i++) {
      var u = t.replace(/_?\((?:[^()]|\([^()]*\))*\)\s*$/, '');
      if (u === t) break;
      t = u;
    }
    return t.replace(/\s+/g, ' ').trim();
  }
  /* 투여경로를 짧은 키로 정리한다 — 외용(topical)은 눈·피부·붙이는 약 구분을 TDN.route.fromHira 가 이어서 한다 */
  function drugRouteKey(route) {
    var r = String(route || '');
    if (r.indexOf('주사') > -1) return 'injection';
    if (r.indexOf('외용') > -1) return 'topical';
    if (r.indexOf('내복') > -1 || r.indexOf('내服') > -1) return 'oral';
    return '';
  }
  function parseDrugItems(xml) {
    var s = String(xml || ''), out = [], m, re = /<item>([\s\S]*?)<\/item>/g;
    while ((m = re.exec(s)) && out.length < 30) {
      var b = m[1];
      var raw = drugTag(b, 'itmNm');
      if (!raw) continue;
      var route = drugTag(b, 'injcPthNm');
      out.push({
        name: cleanDrugName(raw),
        rawName: raw,
        route: route,                       /* 내복 | 외용 | 주사 (심평원 공식 분류) */
        routeKey: drugRouteKey(route),
        unit: drugTag(b, 'unit'),           /* 정 | mL/병 | g/개 … */
        meftDivNo: drugTag(b, 'meftDivNo')  /* 약효분류번호 — 131 안과용제, 26x 외피용약 등 */
      });
    }
    /* <item> 으로 감싸지 않은 응답(형식이 다르거나 오류 XML)에서도 이름만은 건진다 */
    if (!out.length) {
      var re2 = /<itmNm\b[^>]*>([^<]+)<\/itmNm>/g, m2;
      while ((m2 = re2.exec(s)) && out.length < 30) {
        var nm = cleanDrugName(m2[1]);
        if (nm) out.push({ name: nm, rawName: m2[1], route: '', routeKey: '', unit: '', meftDivNo: '' });
      }
    }
    return out;
  }
  /* ── 식약처 의약품 허가정보(drugprm) 응답 읽기 ── 2026-09-20 교수님 피드백
     지금까지 약 이름 대조·자동완성은 심평원 약가 목록(/drug · itmNm)을 썼다. 그런데 그 목록은
     '급여 등재 약가'라 교수님 봉투의 점안액·안연고처럼 빠져 있는 약이 있었고, 그래서 54 가
     '약 목록과 맞춰 보지 못했어요'를 띄우고 중복(레보플레쉬/레보플레수쉬)도 합치지 못했다.
     이제 식약처 허가정보(/drugprm · item_name)를 쓴다 — 허가받은 모든 품목이 들어 있다.
     칸 이름이 대문자다: ITEM_NAME(정식 이름)·ITEM_SEQ(품목기준코드)·ENTP_NAME(업체)·MATERIAL_NAME(성분). */
  /* 국내 약국에서 사람에게 조제되지 않는 품목 */
  var NOT_HUMAN = /수출용|수출명|동물용|수의용/;
  function prmClassNo(block) {
    /* CLASS_NO 는 '[13100]안과용제' 꼴 — 숫자만 뽑으면 심평원 약효분류번호와 앞자리가 같다 */
    var s = drugTag(block, 'CLASS_NO') || drugTag(block, 'CLASS_NO_NAME');
    var m = /\d{3,5}/.exec(s);
    return m ? m[0] : '';
  }
  function parseDrugPrmItems(xml) {
    var s = String(xml || ''), out = [], m, re = /<item>([\s\S]*?)<\/item>/g;
    while ((m = re.exec(s)) && out.length < 30) {
      var b = m[1];
      var raw = drugTag(b, 'ITEM_NAME');
      if (!raw) continue;
      /* 수출용·동물용 품목은 국내 약국에서 사람에게 조제되지 않는다 — 이름이 같아 헷갈리기만 하므로 뺀다
         (2026-09-26: '동물용'이 빠져 있어 사람 약과 같은 이름의 동물약이 후보에 섞여 나왔다) */
      if (NOT_HUMAN.test(raw)) continue;
      var cls = prmClassNo(b);
      /* 식약처 허가정보에는 투여경로 칸이 없다 — 분류번호가 안과용제(131)·외피용약(26x)일 때만
         '외용'인 것을 알 수 있고, 눈·피부·붙이는 약 구분은 TDN.route.fromHira 가 이름의 제형 꼬리로 잇는다.
         그 밖의 약은 비워 두고 이름의 제형 꼬리(정·캡슐·시럽…)로 판정한다. */
      var rk = (/^131/.test(cls) || /^26/.test(cls)) ? 'topical' : '';
      out.push({
        name: cleanDrugName(raw),
        rawName: raw,
        seq: drugTag(b, 'ITEM_SEQ'),
        entp: drugTag(b, 'ENTP_NAME'),
        material: drugTag(b, 'MATERIAL_NAME'),
        route: '',
        routeKey: rk,
        unit: '',
        meftDivNo: cls
      });
    }
    /* <item> 으로 감싸지 않은 응답에서도 이름만은 건진다 */
    if (!out.length) {
      var re2 = /<ITEM_NAME\b[^>]*>([\s\S]*?)<\/ITEM_NAME>/g, m2;
      while ((m2 = re2.exec(s)) && out.length < 30) {
        /* 위와 같은 잣대를 쓴다 — 수출용은 국내 약국에서 조제되지 않으므로 여기서도 뺀다
           (2026-09-21: 이 되살리기 길에만 걸러내기가 빠져 있어 '아진탈포르테정(수출용)'이 살아 돌아왔다) */
        var raw2 = String(m2[1]).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/\s+/g, ' ').trim();
        if (NOT_HUMAN.test(raw2)) continue;
        var nm = cleanDrugName(raw2);
        if (nm) out.push({ name: nm, rawName: raw2, seq: '', entp: '', material: '', route: '', routeKey: '', unit: '', meftDivNo: '' });
      }
    }
    return out;
  }
  /* ── 찾은 약을 보여 줄 순서 ── 2026-09-20 교수님 피드백
     '타이레놀'을 치면 어린이용만 나왔다. 식약처 목록이 돌려주는 차례가 '어린이타이레놀산 → 어린이타이레놀현탁액
     → 우먼스타이레놀정 → …' 이고 앱은 앞 몇 개만 보여 주기 때문이었다.
     ① 적은 글자로 시작하는 이름 먼저 ② 어린이·소아·유아용은 뒤로 ③ 용량을 뗀 이름이 짧은 것 먼저 */
  var KID_WORD = /(어린이|소아|유아|키즈|베이비|시럽용|드라이시럽)/;
  function searchKey(s) {
    return String(s == null ? '' : s).replace(/\([^)]*\)/g, '').replace(/[\s·,\-_/]/g, '').toLowerCase();
  }
  function shortKey(s) {
    /* window. 을 붙여 끝까지 같은 곳을 본다 — 앞만 window.TDN 이고 뒤는 맨 TDN 이면
       전역이 아직 안 붙은 순간에 오류가 나고, 그러면 이름 차례가 통째로 무너진다 */
    var b = (window.TDN && window.TDN.ocr && window.TDN.ocr.stripDose) ? window.TDN.ocr.stripDose(searchKey(s)) : searchKey(s);
    return b || searchKey(s);
  }
  function rankDrugs(items, q) {
    var qk = searchKey(q);
    /* 2026-09-26: 적으신 글자에 '어린이·소아'가 들어 있으면 정말 그 약을 찾으시는 것이다 — 뒤로 보내지 않는다.
       봉투 대조 쪽(native.js HIRA.bestOf)이 쓰는 잣대와 같게 맞췄다. */
    var wantKid = KID_WORD.test(String(q == null ? '' : q));
    var rows = (items || []).map(function (d, i) {
      var k = searchKey(d.name);
      return {
        d: d, i: i,
        pre: (qk && k.indexOf(qk) === 0) ? 0 : 1,       /* 그 글자로 시작하면 먼저 */
        kid: (!wantKid && KID_WORD.test(d.name)) ? 1 : 0,   /* 어린이용은 뒤로 (성인용 앱이다) */
        len: shortKey(d.name).length                    /* 용량을 뗀 이름이 짧은 것 먼저 */
      };
    });
    rows.sort(function (a, b) {
      return (a.pre - b.pre) || (a.kid - b.kid) || (a.len - b.len)
        || (searchKey(a.d.name).length - searchKey(b.d.name).length) || (a.i - b.i);
    });
    return rows.map(function (r) { return r.d; });
  }

  /* 이번 화면에서 찾아본 약의 부가정보 — 메모리에만 두고 서버·저장소에 남기지 않는다 */
  var drugInfoByName = {};
  function rememberDrugInfo(list) {
    (list || []).forEach(function (d) { if (d.name && !drugInfoByName[d.name]) drugInfoByName[d.name] = d; });
  }
  /* 약 이름 찾기 — 58 입력칸과 54 이름 고치기가 함께 쓴다. 보내는 것은 적힌 약 이름 글자뿐이다.
     식약처 허가정보에서 25줄까지 받아 보고(중계 함수 상한 30) 위 차례대로 골라 보여 준다.
     → Promise<{ items: [...], note: '' }> (실패해도 reject 하지 않고 안내 문구를 돌려준다) */
  var SEARCH_ROWS = 25;
  function searchDrugs(q) {
    return new Promise(function (resolve) {
      if (!CFG.fnBase) return resolve({ items: [], note: '' });
      sb.auth.getSession().then(function (rs) {
        var tok = rs.data.session ? rs.data.session.access_token : null;
        if (!tok) return resolve({ items: [], note: '로그인하시면 약 이름을 찾아 드려요' });
        fetch(CFG.fnBase + '/hosp-proxy/drugprm?numOfRows=' + SEARCH_ROWS + '&item_name=' + encodeURIComponent(q),
          { headers: { 'Authorization': 'Bearer ' + tok, 'apikey': CFG.anonKey } })
          .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
          .then(function (res) {
            /* 이름만 긁지 않고 <item> 통째로 읽어 품목기준코드·업체·성분·분류번호를 함께 보관한다 */
            var items = rankDrugs(parseDrugPrmItems(res), q);
            rememberDrugInfo(items);
            resolve({ items: items, note: '비슷한 약을 찾지 못했어요. 봉투에 적힌 대로 적어 주세요' });
          }, function (err) {
            resolve({ items: [], note: '약 이름 목록을 불러오지 못했어요. 봉투에 적힌 대로 적어 주세요' });
          });
      }, function () { resolve({ items: [], note: '연결이 원활하지 않아요. 다시 시도해 주세요' }); });
    });
  }
  T.drug = {
    parse: parseDrugItems,            /* 심평원 약가 목록(/drug) — 지금은 쓰지 않지만 남겨 둔다 */
    parsePrm: parseDrugPrmItems,      /* 식약처 허가정보(/drugprm) — 54 대조·58 자동완성이 쓴다 */
    rank: rankDrugs,
    routeKey: drugRouteKey,
    search: searchDrugs,
    info: function (nm) { return drugInfoByName[cleanDrugName(nm)] || null; }
  };

  /* ── 58 약 직접 입력 (시간 직접 설정 + 이름 자동완성) ── */
  function page58() {
    /* 가입 중(todak_onboard)이거나 내 정보 고치기(todak_edit) 흐름이면 04 로, 평소에는 시안대로 56 으로 */
    var IN_WIZ = !!(ss('todak_onboard') || ss('todak_edit'));
    /* 사진 흐름 중(54 '＋ 빠진 약 넣기'로 들어옴) — 바로 등록하지 않고 54 의 목록에 넣고 돌아간다.
       주소: 58-med-manual.html?add=1&from=54-med-confirm.html (‹ 는 app.js 가 from 으로 맞춘다) */
    var ADD58 = /[?&]add=1(&|$)/.test(location.search || '');
    var b58 = $('.appbar .back'); if (b58 && IN_WIZ && !ADD58) b58.setAttribute('href', '04-treatment.html');
    if (ADD58) {
      /* 여기서 또 사진을 찍으면 읽어 둔 목록을 덮어쓰게 된다 — 사진 진입은 감춘다 */
      var pe58 = $('[data-role="photo-entry"]'), po58 = $('[data-role="photo-entry-or"]');
      if (pe58 && pe58.parentNode) pe58.parentNode.removeChild(pe58);
      if (po58 && po58.parentNode) po58.parentNode.removeChild(po58);
      var c58 = $('.content');
      if (c58) {
        var bn58 = document.createElement('div');
        bn58.className = 'banner banner--info';
        bn58.innerHTML = '<span class="b-ic">➕</span><div class="grow">'
          + '<div class="small">넣으시면 <b>사진에서 찾은 약 목록</b>으로 돌아가요. 등록은 그 화면에서 한 번에 해요.</div>'
          + '<div class="small" style="margin-top:4px;">사진을 다시 찍으시려면 <b>뒤로</b> 가 주세요.</div></div>';
        c58.insertBefore(bn58, c58.firstChild);
      }
    }
    var name = $('input[aria-label="약 이름"]');
    if (name) name.value = '';
    var CFGX = window.TODAK_CONFIG || {};
    /* 예시 자동완성 카드 → 실제 추천 상자로 재사용 */
    var sugCard = $$('.card').filter(function (c) {
      return c.textContent.indexOf('아나스트로졸') > -1 && c.textContent.indexOf('약 이름') < 0;
    })[0];
    if (sugCard) {
      sugCard.innerHTML = '';
      sugCard.style.display = 'none';
    }
    var hint = name ? name.parentNode.querySelector('p') : null;

    /* 이름 자동완성 — 식약처 의약품 허가정보.
       공공데이터 인증키는 앱에 심지 않고 토닥 중계 함수(hosp-proxy/drugprm)를 거친다. */
    var canSearch = !!CFGX.fnBase;
    /* 입력칸 아래 긴 안내(약 목록 조회·성함 미전송·미보관)는 뺀다 — 0.9.1 사용 의견.
       한 줄만 남긴다. 적은 글자로 약 목록을 찾는다는 고지는 02 동의문·25 처리방침에 그대로 있다.
       찾기를 쓸 수 없는 상태면(중계 주소 없음) 찾아드린다고 적지 않는다 — 없는 기능을 약속하지 않게. */
    if (hint) hint.textContent = canSearch
      ? '두 글자만 입력해도 찾아 드려요.'
      : '지금은 비슷한 약 찾기를 쓸 수 없어요. 적어 주신 그대로 등록해 드려요.';

    /* ── 약 종류(투여경로) ── 1순위 식약처 분류번호(자동완성에서 고른 경우) · 2순위 이름의 제형 꼬리 · 근거 없으면 미정 */
    var fRoute = fieldByLabel('어떤 약');
    /* '언제 드시나요'(2026-10-26) — 옛 시안('사용 횟수')이 남아 있어도 칸을 찾아 둔다(경로 칸을 그 앞에 붙일 자리) */
    var fWhen = fieldByLabel('언제');
    var fFreq = fWhen || fieldByLabel('사용 횟수') || fieldByLabel('복용 횟수');
    var fTime = fieldByLabel('알림 시간') || fieldByLabel('복용 시간');
    if (!fRoute && fFreq && RT) {             /* 시안이 옛 모양이면 칸을 만들어 붙인다 */
      fRoute = document.createElement('div');
      fRoute.className = 'field';
      fRoute.innerHTML = '<label>어떤 약인가요</label><div class="chips" data-role="route"></div>';
      RT.CHIPS.forEach(function (lb) {
        var sp = document.createElement('span'); sp.className = 'chip'; sp.textContent = lb; $('.chips', fRoute).appendChild(sp);
      });
      fFreq.parentNode.insertBefore(fRoute, fFreq);
    }
    var routeChips = fRoute ? $('.chips', fRoute) : null;
    var routeNote = fRoute ? $('p', fRoute) : null;
    if (fRoute && !routeNote) {
      routeNote = document.createElement('p');
      routeNote.className = 'tiny muted';
      fRoute.appendChild(routeNote);
    }
    var routeState = { route: 'unknown', by: '' }, routeWarn = false;
    var onRouteChange = null;              /* 약 종류가 바뀌면 '언제 드시나요/넣으시나요' 말을 맞춘다(아래 언제 칸) */
    function paintRoute() {
      if (!routeChips) return;
      var lb = (RT && RT.known(routeState.route)) ? RT.info(routeState.route).chip : '';
      $$('.chip', routeChips).forEach(function (c) { chipOn(c, !!lb && chipText(c) === lb); });
      if (!routeNote) return;
      routeNote.style.color = '';
      if (!lb) {
        /* '먹는 약인지 바르거나 눈에 넣는 약인지 골라주세요' 안내문은 뺀다 — 0.9.1 사용 의견.
           고르는 칩이 바로 아래 있어 문장이 없어도 뜻이 통한다.
           추가를 눌렀는데 비어 있을 때만 짧게 빨간 글씨로 알린다(무엇을 해야 하는지 화면에 남게). */
        routeNote.textContent = routeWarn ? '골라 주세요.' : '';
        if (routeWarn) routeNote.style.color = 'var(--danger)';
      }
      else if (routeState.by === 'hira') routeNote.textContent = '식약처 허가정보를 보고 골라 두었어요. 다르면 바꿔 주세요.';
      else if (routeState.by === 'form') routeNote.textContent = '약 이름을 보고 골라 두었어요. 다르면 바꿔 주세요.';
      else routeNote.textContent = '';
      if (onRouteChange) onRouteChange();
    }
    function setRoute(r, by) {
      routeState.route = (RT && RT.known(r)) ? r : 'unknown';
      routeState.by = routeState.route === 'unknown' ? '' : by;
      paintRoute();
    }
    function routeFromName(nm) {
      if (!RT || !OCRX) return;
      var k = OCRX.formKind(OCRX.stripDose(nm));
      setRoute(RT.fromKind(k), 'form');
    }
    if (routeChips) {
      bindChips(routeChips, { single: true });
      $$('.chip', routeChips).forEach(function (c) {
        var pick = function (ev) {
          if (ev.type === 'keydown' && ev.key !== ' ' && ev.key !== 'Enter') return;
          if (!RT) return;
          var lb = chipText(c), r = RT.BY_CHIP[lb] || 'other';
          if (RT.known(routeState.route) && RT.info(routeState.route).chip === lb) r = routeState.route;   /* '기타'로 보이던 흡입제는 그대로 */
          setRoute(r, 'user');
        };
        c.addEventListener('click', pick);
        c.addEventListener('keydown', pick);
      });
      paintRoute();
    }

    var sugTimer = null, sugSeq = 0, lastQ = '';
    function showSug(list, note) {
      if (!sugCard) return;
      sugCard.innerHTML = '';
      if (!list.length) {
        if (!note) { sugCard.style.display = 'none'; return; }
        /* 빈 상자만 덩그러니 보이지 않게, 무슨 일인지 한 줄로 알려준다 */
        var msg = document.createElement('div');
        msg.className = 'listitem';
        msg.setAttribute('style', 'border:none; border-radius:0;');
        msg.innerHTML = '<div class="li-body"><div class="li-sub"></div></div>';
        $('.li-sub', msg).textContent = note;
        sugCard.appendChild(msg);
        sugCard.style.display = '';
        return;
      }
      list.forEach(function (nm2, i) {
        var li = document.createElement('div');
        li.className = 'listitem';
        li.setAttribute('style', 'border:none; border-radius:0;' + (i ? ' border-top:1px solid var(--outline);' : ''));
        /* 시안 틀을 복제하지 않고 직접 만든다 — 틀을 못 찾으면 빈 줄만 그려지던 문제 */
        li.innerHTML = '<span class="li-ic">💊</span><div class="li-body">'
          + '<div class="li-title"></div><div class="li-sub">눌러서 채우기</div></div>';
        var t = $('.li-title', li);
        if (t) t.textContent = nm2;
        li.style.cursor = 'pointer';
        li.addEventListener('click', function () {
          if (name) name.value = nm2;
          lastQ = nm2;
          sugCard.style.display = 'none';
          /* 식약처 분류번호로 짐작한 약 종류를 기본 선택 — 환자가 직접 고른 값은 덮지 않는다 */
          if (routeState.by !== 'user' && RT) {
            var h = RT.fromHira(T.drug.info(nm2));
            if (h && RT.known(h.route)) setRoute(h.route, 'hira');
            else routeFromName(nm2);
            if (h && h.injection) toast('병원에서 맞는 주사약 같아요.\n집에서 직접 쓰시는 약일 때만 추가해 주세요.');
          }
        });
        sugCard.appendChild(li);
      });
      sugCard.style.display = '';
    }
    function runSearch(q) {
      if (!canSearch) return;
      q = String(q || '').trim();
      if (q.length < 2) { showSug([]); return; }
      lastQ = q;
      var my = ++sugSeq;
      searchDrugs(q).then(function (res) {
        if (my !== sugSeq) return;
        var names = [];
        (res.items || []).forEach(function (d) {
          if (d.name && names.indexOf(d.name) < 0 && names.length < 12) names.push(d.name);
        });
        /* 3개만 보이던 것을 5개로 — '타이레놀'처럼 같은 이름이 여러 개인 약은
           앞 세 줄이 어린이용·복합제로 다 차서 정작 찾으시는 약이 가려졌다 */
        showSug(names.slice(0, 5), res.note);
      });
    }
    if (name) name.addEventListener('input', function () {
      if (routeState.by !== 'user') routeFromName(name.value);   /* 이름이 바뀌면 심평원 선택은 더 이상 맞지 않는다 */
      if (!canSearch) return;
      clearTimeout(sugTimer);
      if (name.value.trim().length < 2) { showSug([]); return; }
      sugTimer = setTimeout(function () { runSearch(name.value); }, 350);
    });
    /* 이름칸을 누르면(사진에서 잘려 읽힌 이름 등) 목록을 다시 찾아 보여준다 */
    if (name && canSearch) name.addEventListener('click', function () {
      var q = name.value.trim();
      if (q.length >= 2 && sugCard && sugCard.style.display === 'none' && q !== lastQ) runSearch(q);
      else if (q.length >= 2 && sugCard && sugCard.style.display === 'none' && sugCard.children.length) sugCard.style.display = '';
    });

    /* ── 언제 드시나요 ── 2026-10-26 (사용 의견)
       예전에는 '하루 몇 번'을 고르면 아침·저녁처럼 정해지고, 바꾸려면 알림 줄의 '아침 ▾'를 눌러야 했다.
       그 줄이 누르는 곳으로 보이지 않아 아침·점심에 드시는 약이 아침·저녁으로 들어갔다.
       이제 약 봉투의 복용 시간표처럼 드시는 시간을 바로 누른다. 횟수는 고른 개수로 정해진다
       (저장 모양은 예전 그대로 freq '하루 N번' · slots — 55·56·알림·서버가 같은 값을 읽는다). */
    var whenBox = fWhen ? $('[data-role="when"]', fWhen) : null;
    var prnChip = fWhen ? $('[data-role="when-prn"]', fWhen) : null;
    var sumEl = fWhen ? $('[data-role="when-sum"]', fWhen) : null;
    var whenLbl = fWhen ? $('label', fWhen) : null;
    var SLOT_IC = { '아침': '🌅', '점심': '☀️', '저녁': '🌆', '자기전': '🌙', '필요시': '💊' };
    var picked = ['아침'], prn = false, keepTimes = {};
    var ocrNote = null;
    function slotOfChip(c) { var t = chipText(c); return t === '자기 전' ? '자기전' : t; }
    function paintWhen() {
      var ri = routeInfo(routeState.route);
      if (whenBox) $$('.chip', whenBox).forEach(function (c) { chipOn(c, !prn && picked.indexOf(slotOfChip(c)) > -1); });
      if (prnChip) chipOn(prnChip, prn);
      /* 말은 약 종류에 맞춘다 — 안약이면 '언제 넣으시나요' */
      if (whenLbl && whenLbl.firstChild && whenLbl.firstChild.nodeType === 3) whenLbl.firstChild.nodeValue = '언제 ' + ri.go.replace('세요', '시나요') + ' ';
      if (sumEl) {
        sumEl.className = 'when-sum' + (!prn && !picked.length ? ' is-empty' : '');
        sumEl.textContent = prn ? '필요할 때만 · 알림 없음'
          : picked.length ? '하루 ' + picked.length + '번 · ' + picked.map(mtLbl).join('·')
          : ri.how.replace('는지', '는 시간') + '을 골라 주세요';
      }
      renderSlots();
    }
    onRouteChange = function () { if (fWhen) paintWhen(); };
    function bindWhenChip(c, onTap) {
      c.style.cursor = 'pointer';
      c.setAttribute('role', 'checkbox');
      c.setAttribute('tabindex', '0');
      var h = function (e) {
        if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
        e.preventDefault();
        T.dirty = 1;
        if (ocrNote) ocrNote.hidden = true;             /* 고치셨으면 '봉투에서 골라 두었어요'는 거둔다 */
        onTap();
        paintWhen();
      };
      c.addEventListener('click', h);
      c.addEventListener('keydown', h);
    }
    if (whenBox) $$('.chip', whenBox).forEach(function (c) {
      bindWhenChip(c, function () {
        var s = slotOfChip(c), at = picked.indexOf(s);
        prn = false;
        if (at > -1) picked.splice(at, 1);
        else picked = MT_SLOTS.filter(function (z) { return z === s || picked.indexOf(z) > -1; });
      });
    });
    if (prnChip) bindWhenChip(prnChip, function () { prn = !prn; if (prn) picked = []; });

    var timeTmpl = fTime ? $('.listitem', fTime) : null;
    function renderSlots() {
      if (!fTime || !timeTmpl) return;
      $$('.listitem', fTime).forEach(function (li) { if (li !== timeTmpl) li.parentNode.removeChild(li); });
      timeTmpl.style.display = 'none';
      var plan = prn ? [['💊', '필요시', '']]
        : picked.map(function (s) { return [SLOT_IC[s] || '💊', s, keepTimes[s] || MT_TIME[s] || '']; });
      /* 아직 고르지 않았으면(사진에서 횟수를 못 읽음) 알림 시간도 미리 만들지 않는다 */
      fTime.style.display = plan.length ? '' : 'none';
      plan.forEach(function (p) {
        var li = timeTmpl.cloneNode(true);
        li.style.display = '';
        li.setAttribute('data-slot', p[1]);
        var ic = $('.li-ic', li), t = $('.li-title', li), s = $('.li-sub', li), tm = $('.strong', li);
        if (ic) ic.textContent = p[0];
        if (t) t.textContent = mtLbl(p[1]);
        if (p[1] === '필요시') {
          if (t) t.textContent = '필요할 때만';
          if (s) s.textContent = '증상이 있을 때 · 알림 없음';
          if (tm) tm.textContent = '—';
        } else {
          if (s) { s.textContent = ''; s.style.display = 'none'; }
          if (tm) {
            /* 고정 글자 → 시간 입력으로 교체 */
            var inp = document.createElement('input');
            inp.type = 'time'; inp.value = p[2];
            inp.className = 'input';
            inp.setAttribute('data-time', p[1]);
            /* 누르는 칸이라 44px 아래로 내려가지 않게 (손 저림 배려 — 예전에는 39px 였다) */
            inp.setAttribute('style', 'width:140px; min-height:44px; padding:10px 6px; font-weight:700; color:var(--primary-dark); flex:0 0 auto;');
            if (window.TDT) TDT.attach(inp);
            var keep = function () { if (inp.value) keepTimes[p[1]] = inp.value; };
            inp.addEventListener('change', keep);
            inp.addEventListener('input', keep);
            tm.parentNode.replaceChild(inp, tm);
          }
        }
        fTime.appendChild(li);
      });
    }
    paintWhen();
    var daysIn = $('input[aria-label="며칠분"]');

    /* ── 사진에서 약이 한 종만 읽혔을 때 — 53 이 넘긴 이름·횟수·일수·제형을 채운다 ── */
    var ocr = null;
    try {
      var raw1 = sessionStorage.getItem('todak_ocr_one');
      if (raw1) ocr = JSON.parse(raw1);
      else if (sessionStorage.getItem('todak_ocr_name')) ocr = { name: sessionStorage.getItem('todak_ocr_name') };   /* 예전 형식 */
      sessionStorage.removeItem('todak_ocr_one'); sessionStorage.removeItem('todak_ocr_name');
    } catch (eo) { ocr = null; }
    var ocrStart = !!(ocr && ocr.name && name);
    if (ocrStart) {
      name.value = String(ocr.name);
      if (RT) setRoute(RT.fromKind(ocr.kind || ''), 'form');
      var tn = parseInt(ocr.times, 10);
      prn = false;
      if (tn >= 1 && tn <= 4) {
        /* 봉투에는 '하루 2번'처럼 횟수만 적힌 일이 많다 — 아침·저녁 같은 기본 시간을 미리 골라 두고, 다르면 바꾸시라고 적는다 */
        picked = (window.TDN && TDN.whenDefault) ? TDN.whenDefault(tn).slice(0) : MT_SLOTS.slice(0, tn);
        if (sumEl && sumEl.parentNode) {
          ocrNote = document.createElement('p');
          ocrNote.className = 'tiny muted';
          ocrNote.style.marginTop = '2px';
          ocrNote.innerHTML = '약 봉투에 <b>‘하루 ' + tn + '번’</b>으로 적혀 있어 ' + esc(picked.map(mtLbl).join('·')) + '(으)로 골라 두었어요. 드시는 시간이 다르면 눌러서 바꿔 주세요.';
          sumEl.parentNode.insertBefore(ocrNote, sumEl.nextSibling);
        }
      } else {
        /* 사진에서 횟수를 못 읽었으면 미리 고르지 않는다 — 직접 고르기 전엔 저장하지 않는다(54와 같은 방식) */
        picked = [];
      }
      paintWhen();
      if (daysIn && parseInt(ocr.days, 10) > 0) daysIn.value = String(parseInt(ocr.days, 10));
      if (ocr.kind === 'injection') toast('병원에서 맞는 주사약 같아요.\n집에서 직접 쓰시는 약일 때만 추가해 주세요.');
      else toast('사진에서 읽은 내용이에요.\n맞는지 확인하고 추가해 주세요.');
      /* 봉투에는 이름이 잘려 찍히기도 한다 — 읽은 이름으로 바로 목록을 찾아 고를 수 있게 한다 */
      runSearch(name.value);
    }

    var cta = $('.footer-actions .btn');
    if (cta && ADD58) cta.textContent = '목록에 넣기';
    if (cta) cta.addEventListener('click', function (e) {
      e.preventDefault();
      if (cta.__busy) return;
      var nm = (name && name.value.trim()) || '';
      if (!nm) return toast('약 이름을 입력해 주세요.');
      /* 약 종류를 모르면 저장하지 않는다 — 연고·안약에 '드실 시간' 알림이 걸리지 않게 */
      if (RT && routeChips && !RT.known(routeState.route)) {
        routeWarn = true;
        paintRoute();
        try { fRoute.scrollIntoView({ block: 'center' }); } catch (e0) {}
        return toast('어떤 약인지(먹는 약·바르는 약 등) 골라 주세요.');
      }
      if (fWhen && !prn && !picked.length) {
        try { fWhen.scrollIntoView({ block: 'center' }); } catch (e1) {}
        return toast('언제 ' + routeInfo(routeState.route).go.replace('세요', '시나요') + '?\n' + routeInfo(routeState.route).how.replace('는지', '는 시간') + '을 골라 주세요.');
      }
      /* 고르신 그대로 저장한다 — 횟수는 고른 개수(예전 저장 모양 freq '하루 N번' · slots 그대로) */
      var slots = prn ? ['필요시'] : (picked.length ? picked.slice(0) : ['아침']);
      var freq = prn ? '필요할 때만' : '하루 ' + slots.length + '번';
      var times = {};
      $$('input[data-time]', fTime).forEach(function (inp) {
        if (inp.value) times[inp.getAttribute('data-time')] = inp.value;
      });
      var sch = { freq: freq, slots: slots, times: times };
      if (RT && RT.known(routeState.route)) { sch.route = routeState.route; sch.route_by = routeState.by || 'user'; }
      var dn = daysIn ? parseInt(daysIn.value, 10) : 0;
      if (dn > 0 && dn <= 365) {
        var td = new Date();
        sch.days = dn;
        sch.startedOn = td.getFullYear() + '-' + ('0' + (td.getMonth() + 1)).slice(-2) + '-' + ('0' + td.getDate()).slice(-2);
      }
      /* 사진 흐름 중이면 여기서 등록하지 않는다 — 54 의 목록에 넣고 돌아가 사진으로 읽은 약들과 함께 등록한다 */
      if (ADD58) {
        /* 임시 저장은 native.js 가 맡는다(localStorage·저장 시각·6시간) — 읽고 쓰는 곳을 한 군데로 모은다 */
        var PEND58 = (window.TDN && window.TDN.ocrPend) || null;
        var list58 = [];
        if (PEND58) list58 = PEND58.get();
        else { try { list58 = JSON.parse(sessionStorage.getItem('todak_ocr_meds') || '[]'); } catch (eA) { list58 = []; } }
        if (!(list58 instanceof Array)) list58 = [];
        var tw58 = mtTwinOf(nm, list58.filter(function (x) { return !x.__drop; }).map(function (x) { return x.name; }));
        if (tw58 && !cta.__twinOk) { return askTwin(tw58, function () { cta.__twinOk = 1; cta.click(); }); }
        cta.__twinOk = 0;
        var fq58 = freq === '필요할 때만' ? 'prn' : (parseInt(freq.replace(/[^0-9]/g, ''), 10) || 1);
        list58.push({
          name: nm, kind: '', times: 0, days: dn > 0 ? dn : 0,
          __init: 1, __manual: 1, __off: 0,
          __route: routeState.route, __routeBy: routeState.by || 'user',
          __freq: fq58, __days: dn > 0 ? dn : 0,
          __when: fq58 === 'prn' ? [] : slots.slice(0)
        });
        if (PEND58) PEND58.set(list58);
        else { try { sessionStorage.setItem('todak_ocr_meds', JSON.stringify(list58)); } catch (eB) {} }
        busy(cta, true, '넣는 중…');
        toast('목록에 넣었어요');
        setTimeout(function () { location.href = '54-med-confirm.html'; }, 500);
        return;
      }
      busy(cta, true, '추가 중…');
      uid(function (id) {
        /* 넣기 전에 같은 약이 이미 있는지 한 번 본다 — 못 불러와도 등록은 막지 않는다 */
        function addNow() { doInsert(id); }
        if (cta.__twinOk) { cta.__twinOk = 0; return addNow(); }
        sb.from('medications').select('id,name,schedule').eq('active', true).then(function (rd) {
          var have = (rd && !rd.error) ? (rd.data || []) : [];
          /* 이름이 똑같은 약 — 새로 처방받아 오신 것인지 먼저 여쭙는다(위 '새로 받아 온 약') */
          var same = mtSameOf(nm, have);
          if (same) {
            busy(cta, false);
            return askRefill({ names: [same.name],
              onRefill: function () { busy(cta, true, '다시 세는 중…'); doRefill(same); },
              onSeparate: function () { cta.__twinOk = 1; cta.click(); } });
          }
          var tw = mtTwinOf(nm, have.map(function (x) { return x.name; }));
          if (!tw) return addNow();
          busy(cta, false);
          askTwin(tw, function () { cta.__twinOk = 1; cta.click(); });
        }, addNow);
      });
      /* 새로 받아 오셨다 — 그 약 줄의 며칠분만 오늘부터 다시 센다 */
      function doRefill(m) {
        sb.from('medications').update({ schedule: refillSchedule(m.schedule, dn) }).eq('id', m.id).then(function (r) {
          if (r.error) { busy(cta, false); return toast(koError(r.error)); }
          toast(dn > 0 ? '「' + m.name + '」 ' + dn + '일분을 오늘부터 다시 셀게요' : '「' + m.name + '」' + eulReul(m.name) + ' 새로 받아 오신 것으로 적어 두었어요');
          after58();
        }, function () {
          busy(cta, false);
          toast('연결이 원활하지 않아요. 다시 시도해 주세요.');
        });
      }
      function doInsert(id) {
        /* 사진 인식(53)이 채워 준 것으로 시작했으면 'ocr' — 사진 등록 대 직접 입력 비율이 한 종짜리 사진 등록에서 빠지지 않게 */
        sb.from('medications').insert({ user_id: id, name: nm, schedule: sch, source: ocrStart ? 'ocr' : 'manual' })
          .then(function (r) {
            if (r.error) { busy(cta, false); return toast(koError(r.error)); }
            toast('「' + nm + '」' + eulReul(nm) + ' 추가했어요');
            after58();
          }, function () {
            /* 연결이 끊겨 요청 자체가 실패하면 '추가 중…'에서 멈추지 않게 버튼을 풀고 알린다 */
            busy(cta, false);
            toast('연결이 원활하지 않아요. 다시 시도해 주세요.');
          });
      }
      function after58() {
            try { localStorage.setItem('todak_med_added_at', new Date().toISOString()); } catch (eM) {}   /* 홈 '진료 뒤 새 약' 여쭙기가 멈추게 */
            /* 이전 화면 주소(referrer)로 정하지 않는다 — 04 에 다른 길로 들른 평소 사용자가 가입 화면으로 떨어지던 문제 */
            var back = IN_WIZ ? '04-treatment.html' : '55-med-today.html';
            /* 알림 예약을 다 맞춘 뒤(notifySync 콜백)에 옮긴다 — 600ms 고정으로 옮기면 예약 도중에 화면이 바뀌어 새 약 알림이 빠질 수 있었다.
               콜백이 2초 안에 안 오면(권한 창을 띄운 경우 등) 그래도 옮긴다 — 55·홈이 열릴 때 예약을 다시 맞춘다.
               추가됐다는 안내가 읽히도록 최소 600ms 는 둔다. 알림 상태 안내(권한 꺼짐·동의 안 함·브라우저 미지원 등)가 뜨는 경우에는
               곧바로 덮지 않고 '추가했어요'를 먼저 0.8초 보여 준 뒤 안내로 바꾸고, 안내를 1.5초 보여 준 뒤 옮긴다.
               (설치판에서 'unsupported' 는 안내가 없으므로 기다리지 않는다 — native.js deniedToast 와 같은 기준) */
            var t58 = new Date().getTime(), gone58 = false;
            var go58 = function () {
              if (gone58) return;
              gone58 = true;
              clearTimeout(safe58);
              location.href = back;
            };
            var safe58 = setTimeout(go58, 2000);
            if (window.TDN && window.TDN.notifySync) {
              window.TDN.notifySync(function (st) {
                if (gone58) return;
                clearTimeout(safe58);
                var spent58 = new Date().getTime() - t58;
                var note58 = st && st !== 'ok' && !(st === 'unsupported' && window.TDN.isNative) && window.TDN.deniedToast;
                if (!note58) return setTimeout(go58, Math.max(0, 600 - spent58));
                setTimeout(function () {
                  if (gone58) return;
                  window.TDN.deniedToast(st);
                  setTimeout(go58, 1500);
                }, Math.max(0, 800 - spent58));
              });
            } else setTimeout(go58, 600);
      }
    });
  }

  /* ── 56 복약 설정 (2026-10-26 이름 바꿈 — 예전 '복약 시간 설정') ──
     약마다 드시는 시간(아침·점심·저녁·자기 전) · 알림 시각 · 어떤 약인지를 고치고 저장하면 알림도 그대로 맞춘다.
     드시는 시간은 예전에는 58·54 에서 넣을 때만 정할 수 있었다. '하루 2번'으로 넣으면 아침·저녁으로 들어가
     아침·점심에 드시는 약을 고칠 길이 없었다(사용 의견) — 이제 여기와 55 '약 목록 고치기'에서 고친다(오늘부터). */
  function page56() {
    var content = $('.content');
    /* 55 에서 '시간 바꾸기'·'빼기'로 건너올 때 어느 약인지 들고 온다 —
       약이 여럿이면 카드가 길게 이어져 찾기 어렵다. 그 카드로 데려가 도드라지게 한다. */
    var WANT = (/[?&]m=([^&#]*)/.exec(location.search || '') || [])[1];
    if (WANT) { try { WANT = decodeURIComponent(WANT); } catch (eW) {} }
    var wantCard = null, cardEls = [];
    /* 시안 예시 카드(감싸개째)를 치운다 — 실제 약 카드는 아래에서 만든다 */
    $$('[data-demo-box]', content).forEach(function (b) { if (b.parentNode) b.parentNode.removeChild(b); });
    $$('.card', content).forEach(function (c) { if (c.parentNode) c.parentNode.removeChild(c); });
    /* 알림 방식 스위치 묶음은 23 알림 설정으로 통합 안내 */
    var secAlarm = $$('.section-label', content).filter(function (l) { return l.textContent.indexOf('알림') > -1; })[0];
    if (secAlarm) {
      var el = secAlarm.nextElementSibling;
      while (el && !el.classList.contains('section-label') && el.tagName !== 'A') {
        var nx = el.nextElementSibling; el.parentNode.removeChild(el); el = nx;
      }
      var note = document.createElement('a');
      note.className = 'listitem'; note.href = '23-notif-settings.html';
      note.innerHTML = '<span class="li-ic">🔔</span><div class="li-body"><div class="li-title">알림 켜고 끄기</div><div class="li-sub">알림 설정에서 한 번에 관리해요</div></div><span class="li-chev">›</span>';
      secAlarm.parentNode.insertBefore(note, secAlarm.nextSibling);
    }
    var listA = $('[data-act="med-list-edit"]', content);
    if (listA) listA.style.display = 'none';           /* 약을 읽은 뒤 두 개 이상일 때만 */
    var DEF_TIME = MT_TIME;
    var ICONS = { '아침': '🌅', '점심': '☀️', '저녁': '🌙', '자기전': '🌙', '필요시': '💊' };
    var medList = [];
    var anchor = content.firstElementChild ? content.firstElementChild.nextSibling : null;

    /* 화면에서 고치는 값은 약 객체에 들고 있는다(__slots·__times·__route) — '약 목록 고치기' 창을 다녀와 카드를 다시 그려도
       저장 전에 고쳐 두신 시각·종류가 사라지지 않게 */
    function initUi(m) {
      var all = isArr(m.schedule && m.schedule.slots) ? m.schedule.slots : [];
      m.__was = MT_SLOTS.filter(function (s) { return all.indexOf(s) > -1; });
      m.__slots = m.__was.slice(0);
      m.__prn = !m.__was.length;
      m.__others = all.filter(function (s) { return MT_SLOTS.indexOf(s) < 0 && s !== '필요시'; });
      if (!m.__times) m.__times = schedCopy((m.schedule && m.schedule.times) || {});
      if (m.__route === undefined) { m.__route = routeOfMed(m); m.__routeTouched = false; }
    }
    function freqWord(m) {
      var n = m.__slots.length + m.__others.length;
      return n ? '하루 ' + n + '번' : '필요할 때만';
    }

    function buildCard(m) {
      var c = document.createElement('div');
      c.className = 'card';
      c.setAttribute('data-med', m.id);
      c.innerHTML = '<div class="row" style="justify-content:space-between; align-items:center; gap:10px;">'
        + '<div><div class="strong" style="font-size:16px;"></div><div class="tiny muted" data-role="type"></div></div>'
        + '<span class="tiny muted" data-role="days" style="text-align:right;"></span></div>';
      $('.strong', c).textContent = m.name;
      var ty = $('[data-role="type"]', c), fr = $('[data-role="days"]', c);
      function paintType() {
        var ri0 = routeInfo(m.__route);
        ty.textContent = ri0.ic + ' ' + ri0.label + ' · ' + freqWord(m);
      }
      paintType();
      /* 약 종류 — 자동 판정이 틀렸을 때 여기서 고친다. route 가 없는 예전 약은 먹는 약으로 보여준다 */
      if (RT) {
        var rc = document.createElement('div');
        rc.className = 'chips'; rc.setAttribute('data-role', 'route');
        rc.style.marginTop = '10px';
        RT.CHIPS.forEach(function (lb) { var sp = document.createElement('span'); sp.className = 'chip'; sp.textContent = lb; rc.appendChild(sp); });
        c.appendChild(rc);
        bindChips(rc, { single: true });
        var paintChips = function () {
          var lb = routeInfo(m.__route).chip;
          $$('.chip', rc).forEach(function (ch) { chipOn(ch, chipText(ch) === lb); });
        };
        paintChips();
        $$('.chip', rc).forEach(function (ch) {
          var pick = function (ev) {
            if (ev.type === 'keydown' && ev.key !== ' ' && ev.key !== 'Enter') return;
            var lb = chipText(ch), r = RT.BY_CHIP[lb] || 'other';
            if (routeInfo(m.__route).chip === lb) r = m.__route;          /* '기타'로 보이던 흡입제는 그대로 */
            m.__route = r; m.__routeTouched = true;
            paintChips(); paintType();
            var wt0 = $('[data-role="when-t"]', c);
            if (wt0) wt0.textContent = routeInfo(m.__route).how.replace('는지', '는 시간');
          };
          ch.addEventListener('click', pick);
          ch.addEventListener('keydown', pick);
        });
      }

      /* 드시는 시간 — 아침·점심·저녁·자기 전 네 칸 (55 '약 목록 고치기'와 같은 규칙: 하나는 꼭 남는다. 필요할 때만 쓰던 약은 비워 둘 수 있다) */
      var wt = document.createElement('div');
      wt.className = 'when-t';
      wt.setAttribute('data-role', 'when-t');
      wt.textContent = routeInfo(m.__route).how.replace('는지', '는 시간');
      c.appendChild(wt);
      if (m.__prn) {
        var pn = document.createElement('div');
        pn.className = 'ro-note';
        pn.textContent = '필요할 때만 쓰는 약이에요. 정해진 시간이 있으면 눌러 주세요.';
        c.appendChild(pn);
      }
      var g = document.createElement('div');
      g.className = 'when-grid';
      MT_SLOTS.forEach(function (s) {
        var ch = document.createElement('span');
        var on = m.__slots.indexOf(s) > -1;
        ch.className = 'chip' + (on ? ' chip--on' : '');
        ch.setAttribute('role', 'checkbox');
        ch.setAttribute('tabindex', '0');
        ch.setAttribute('aria-checked', on ? 'true' : 'false');
        ch.setAttribute('aria-label', m.name + ' ' + mtLbl(s));
        ch.textContent = mtLbl(s);
        var h = function (ev) {
          if (ev.type === 'keydown' && ev.key !== ' ' && ev.key !== 'Enter') return;
          ev.preventDefault();
          T.dirty = 1;
          var at = m.__slots.indexOf(s);
          if (at > -1) {
            if (m.__slots.length === 1 && !m.__prn && !m.__others.length) return toast('드시는 시간을 하나 이상\n골라 주세요.');
            m.__slots.splice(at, 1);
          } else m.__slots = MT_SLOTS.filter(function (z) { return z === s || m.__slots.indexOf(z) > -1; });
          renderCards(m.id);
        };
        ch.addEventListener('click', h);
        ch.addEventListener('keydown', h);
        g.appendChild(ch);
      });
      c.appendChild(g);
      if (m.__slots.join() !== m.__was.join()) {
        var cg = document.createElement('div');
        cg.className = 'when-chg';
        var w0 = m.__was.length ? m.__was.map(mtLbl).join('·') : '필요할 때만';
        var w1 = m.__slots.length ? m.__slots.map(mtLbl).join('·') : '필요할 때만';
        cg.innerHTML = esc(w0) + ' → <b>' + esc(w1) + '</b> · 오늘부터 바뀌어요. 저장을 누르시면 알림도 바뀌어요.';
        c.appendChild(cg);
      }

      /* 알림 시간 — 고른 때마다 한 줄 */
      var show = m.__slots.concat(m.__others);
      var at2 = document.createElement('div');
      at2.className = 'when-t';
      at2.textContent = '알림 시간';
      c.appendChild(at2);
      if (!show.length) {
        var li0 = document.createElement('div');
        li0.className = 'listitem';
        li0.innerHTML = '<span class="li-ic">💊</span><div class="li-body"><div class="li-title">필요할 때만</div><div class="li-sub">알림 없음</div></div>';
        c.appendChild(li0);
      }
      show.forEach(function (slot, i) {
        var li = document.createElement('div');
        li.className = 'listitem';
        if (i) li.style.marginTop = '10px';
        li.innerHTML = '<span class="li-ic">' + (ICONS[slot] || '💊') + '</span><div class="li-body"><div class="li-title"></div><div class="li-sub">눌러서 시간 바꾸기</div></div>';
        $('.li-title', li).textContent = mtLbl(slot);
        var inp = document.createElement('input');
        inp.type = 'time';
        inp.value = m.__times[slot] || DEF_TIME[slot] || '08:00';
        m.__times[slot] = inp.value;
        inp.className = 'input';
        inp.setAttribute('data-med', m.id);
        inp.setAttribute('data-slot', slot);
        /* 누르는 칸이라 44px 아래로 내려가지 않게 (손 저림 배려 — 예전에는 39px 였다) */
        inp.setAttribute('style', 'width:140px; min-height:44px; padding:10px 6px; font-weight:700; color:var(--primary-dark); flex:0 0 auto;');
        if (window.TDT) TDT.attach(inp);
        var keep = function () { if (inp.value) m.__times[slot] = inp.value; };
        inp.addEventListener('change', keep);
        inp.addEventListener('input', keep);
        li.appendChild(inp);
        c.appendChild(li);
      });
      /* 며칠분으로 받아 온 약 — 언제까지인지 머리에 보여준다 */
      var endD = medEndDay(m);
      if (fr && endD) {
        var ep = endD.split('-'), over = endD < ymd(new Date());
        fr.textContent = m.schedule.days + '일분 · ' + (over ? '적어 두신 날짜가 지났어요' : (+ep[1]) + '월 ' + (+ep[2]) + '일까지');
        if (over) { fr.style.color = 'var(--warn)'; fr.style.fontWeight = '700'; }
      }
      /* 이 약 그만 쓰기 — 다 쓴 약·잘못 넣은 약·두 번 들어간 약을 목록과 알림에서 뺀다 (기록은 남긴다) */
      var stop = document.createElement('button');
      stop.type = 'button';
      stop.className = 'btn btn-outline btn-sm btn-block';
      stop.style.marginTop = '12px';
      stop.textContent = '이 약 그만 쓰기';
      stop.addEventListener('click', function (ev) { ev.preventDefault(); askStop(m, c); });
      c.appendChild(stop);
      if (WANT && String(m.id) === String(WANT)) {
        wantCard = c;
        c.style.boxShadow = '0 0 0 2px var(--primary)';
        var hint = document.createElement('div');
        hint.className = 'tiny strong';
        hint.style.cssText = 'color:var(--primary-dark); margin-top:10px; word-break:keep-all;';
        hint.textContent = '찾으시는 약이에요. 드시는 시간은 위 네 칸을, 알림 시각은 아래 시각을 누르시고, 목록에서 빼시려면 ‘이 약 그만 쓰기’를 눌러 주세요.';
        c.insertBefore(hint, stop);
      }
      return c;
    }
    /* 카드를 다시 그린다 — 칸을 누른 카드는 그 자리를 지킨다(화면이 튀지 않게) */
    function renderCards(keepId) {
      var keepEl = null, keepTop = 0;
      if (keepId != null) {
        keepEl = $('[data-med="' + keepId + '"]', content);
        if (keepEl) keepTop = keepEl.getBoundingClientRect().top;
      }
      cardEls.forEach(function (c) { if (c.parentNode) c.parentNode.removeChild(c); });
      cardEls = [];
      wantCard = null;
      medList.forEach(function (m) {
        var c = buildCard(m);
        content.insertBefore(c, anchor);
        cardEls.push(c);
      });
      if (keepEl) {
        var now = $('[data-med="' + keepId + '"]', content);
        if (now) content.scrollTop = content.scrollTop + (now.getBoundingClientRect().top - keepTop);
      }
      if (listA) listA.style.display = medList.length ? '' : 'none';
    }

    /* 통신이 끊기면 이 약속은 '오류가 담긴 응답'이 아니라 아예 거절된다.
       받는 자리(then)만 있으면 약 카드만 사라지고 아무 말도 없어 지워진 것처럼 보였다. (2026-09-28) */
    function schedFail() {
      if ($('[data-sched-fail]', content)) return;
      var bn0 = $('[data-empty-meds]', content);
      if (bn0 && bn0.parentNode) bn0.parentNode.removeChild(bn0);
      var fb = document.createElement('div');
      fb.className = 'banner banner--warn';
      fb.setAttribute('data-sched-fail', '1');
      fb.innerHTML = '<span class="b-ic" aria-hidden="true">⚠️</span><div class="small" style="flex:1 1 auto;">'
        + '<b>약 목록을 불러오지 못했어요.</b> 연결이 원활하지 않은 것 같아요. 잠시 뒤 <b>다시 열기</b>를 눌러 주세요. '
        + '<b>이 화면이 비어 보여도 등록하신 약과 알림 시간은 그대로 있어요.</b>'
        + '<a class="btn btn-outline btn-sm btn-block" href="javascript:void(0)" data-role="sched-retry" style="margin-top:10px;">다시 열기</a></div>';
      var first0 = content.firstElementChild;
      content.insertBefore(fb, first0 ? first0.nextSibling : null);
      var rb0 = $('[data-role="sched-retry"]', fb);
      if (rb0) rb0.addEventListener('click', function () { location.reload(); });
      /* 불러오지도 못한 화면에 '저장'이 남아 있으면 안 바뀐 것을 저장한 줄 아신다 */
      var cta0 = $('.footer-actions .btn');
      if (cta0) cta0.textContent = '돌아가기';
    }
    function showEmpty() {
      if ($('[data-empty-meds]', content)) return;
      if ($('[data-sched-fail]', content)) return;
      var bn = document.createElement('div');
      bn.className = 'banner banner--info';
      bn.setAttribute('data-empty-meds', '1');
      bn.innerHTML = '<span class="b-ic">💊</span><div class="small"><b>아직 등록된 약이 없어요.</b> 아래 약 추가하기로 등록해 주세요.</div>';
      var first = content.firstElementChild;
      content.insertBefore(bn, first ? first.nextSibling : null);
      if (listA) listA.style.display = 'none';
    }
    /* 묻는 말과 빼는 일은 medStopAsk() 하나로 — 55 에서도 같은 말로 여쭙는다 */
    function askStop(m, card) {
      medStopAsk(m, {
        before: function () { if (card.__busy) return false; card.__busy = true; card.style.opacity = '.6'; },
        after: function () { card.__busy = false; card.style.opacity = ''; },
        done: function () {
          medList = medList.filter(function (x) { return x !== m; });
          if (card.parentNode) card.parentNode.removeChild(card);
          cardEls = cardEls.filter(function (x) { return x !== card; });
          if (!medList.length) showEmpty();
        }
      });
    }

    uid(function (id) {
      sb.from('medications').select('id,name,schedule,created_at').eq('active', true).then(function (r) {
        /* 못 불러왔는데 빈 표('아직 등록된 약이 없어요')가 뜨면 등록해 둔 약이 지워진 줄 아신다.
           55 와 같은 말로 모른다고 적고 다시 열 길을 드린다. (2026-09-28) */
        if (!r || r.error) { schedFail(); return; }
        medList = medSort(r.data || []);
        medList.forEach(initUi);
        if (medList.length) {
          var bnr = $('.banner .small', content);
          if (bnr) bnr.innerHTML = '약마다 <b>드시는 시간</b>과 알림을 고치실 수 있어요. 알림은 <b>평소 약을 챙기시는 시각</b>으로 맞춰 두세요.';
        }
        renderCards();
        if (wantCard) {
          setTimeout(function () {
            var box = wantCard.getBoundingClientRect(), cb = content.getBoundingClientRect();
            content.scrollTop = content.scrollTop + (box.top - cb.top) - 12;
          }, 60);
        }
        if (!medList.length) showEmpty();
      }, function () { schedFail(); });
      /* 약 목록 고치기 — 55 와 같은 창. 창의 '저장'은 그 자리에서 바로 저장한다(저장을 두 번 누르게 하지 않는다).
         카드에서 아직 저장하지 않은 시각·종류는 그대로 들고 있다 */
      if (listA) listA.addEventListener('click', function (ev) {
        ev.preventDefault();
        if (!medList.length) return;
        var before = {};
        medList.forEach(function (m) { before[m.id] = JSON.stringify((m.schedule && m.schedule.slots) || []); });
        medListSheet({ meds: medList, onSaved: function () {
          medList = medSort(medList);
          medList.forEach(function (m) {
            if (JSON.stringify((m.schedule && m.schedule.slots) || []) === before[m.id]) return;
            var keepT = m.__times;
            m.__was = null;
            initUi(m);
            var tms = (m.schedule && m.schedule.times) || {};
            for (var k in tms) if (Object.prototype.hasOwnProperty.call(tms, k) && !keepT[k]) keepT[k] = tms[k];
            m.__times = keepT;
          });
          renderCards();
        } });
      });

      var cta = $('.footer-actions .btn');
      if (cta) {
        cta.textContent = '저장';
        cta.addEventListener('click', function (e) {
          e.preventDefault();
          if (cta.__busy) return;
          if (!medList.length) { location.href = '55-med-today.html'; return; }
          if (dayChanged()) { toast('날짜가 바뀌어 화면을 새로 열어요.'); setTimeout(function () { location.reload(); }, 900); return; }
          busy(cta, true, '저장 중…');
          var left = medList.length, failed = false;
          medList.forEach(function (m) {
            var sch = schedCopy(m.schedule);
            if (m.__slots.join() !== m.__was.join()) {
              var nx = m.__slots.length ? m.__slots.concat(m.__others) : (m.__others.length ? m.__others : ['필요시']);
              sch = medNewSched({ id: m.id, created_at: m.created_at, schedule: sch }, nx);
            }
            /* 알림 시각 — 지금 드시는 때의 것만 적는다(예전처럼 화면에 보이는 칸 그대로) */
            var times = {};
            (isArr(sch.slots) ? sch.slots : []).forEach(function (s) {
              if (s === '필요시') return;
              times[s] = m.__times[s] || (sch.times && sch.times[s]) || DEF_TIME[s] || '08:00';
            });
            sch.times = times;
            if (m.__routeTouched) { sch.route = m.__route; sch.route_by = 'user'; }   /* 손대지 않은 약은 경로를 새로 쓰지 않는다 */
            sb.from('medications').update({ schedule: sch }).eq('id', m.id).then(function (r2) {
              if (r2.error) failed = true;
              else { m.schedule = sch; m.__was = null; initUi(m); }
              if (--left === 0) {
                busy(cta, false);
                if (failed) return toast('일부는 저장하지 못했어요. 다시 시도해 주세요.');
                toast('복약 설정을 저장했어요 ⏰');
                if (window.TDN && window.TDN.notifySync) window.TDN.notifySync(function (st) { if (window.TDN.deniedToast) window.TDN.deniedToast(st); });
                setTimeout(function () { location.href = '55-med-today.html'; }, 700);
              }
            }, function () {
              failed = true;
              if (--left === 0) { busy(cta, false); toast('연결이 원활하지 않아요. 다시 시도해 주세요.'); }
            });
          });
        });
      }
    });
  }

  /* 07 AI 상담은 chat.js 가 담당한다 */

  /* ── 13 내 정보: 이름 표시 ── */
  function page13() {
    var ver = $$('.proto-tag').filter(function (s) { return s.textContent.indexOf('토닥') > -1; })[0];
    /* textContent 를 통째로 갈면 안의 로고 <img> 까지 지워진다 — 글자 노드만 바꾼다 */
    if (ver && CFG.appVersion) {
      var txt = null;
      for (var vi = 0; vi < ver.childNodes.length; vi++) {
        if (ver.childNodes[vi].nodeType === 3) { txt = ver.childNodes[vi]; break; }
      }
      if (txt) txt.nodeValue = ' 토닥 v' + CFG.appVersion;
      else ver.appendChild(document.createTextNode(' 토닥 v' + CFG.appVersion));
    }
    getProfile(function (p) {
      var el = $$('.strong').filter(function (s) { return s.textContent.trim() === '김지영'; })[0];
      if (el) el.textContent = p.name || '회원';
      var sub = $('[data-prof-sub]');
      if (sub) sub.textContent = [p.stage, p.subtype].filter(Boolean).join(' · ') || '내 치료 정보';
      /* 시안의 '항암 중·호르몬치료' 더미 칩 → 실제 등록한 치료 */
      var card = sub; while (card && !(card.classList && card.classList.contains('card'))) card = card.parentNode;
      var old = card ? $$('.chip', card) : [];
      var wrap = old.length ? old[0].parentNode : null;
      old.forEach(function (c) { c.parentNode.removeChild(c); });
      var tr = (p.treatment && p.treatment.treatments) || [];
      if (wrap) tr.forEach(function (t) { var c = document.createElement('span'); c.className = 'chip chip--soft'; c.style.padding = '4px 10px'; c.textContent = t; wrap.appendChild(c); });
    });
  }

  /* ── 57 약 챙기기 힘든 점 — 고른 이유에 맞는 안내 묶음만 보여준다 ──
     고른 내용은 이 화면 안에서만 쓰고 서버·기기에 남기지 않는다.
     묶음은 화면(HTML)의 data-reason 으로 찾는다. 목록에 없는 이유(직접 입력)는 '기타' 묶음을 보여준다.
     .col·.banner 는 display 를 직접 정해 hidden 속성이 듣지 않으므로 style.display 로 켜고 끈다. */
  function page57() {
    var content = $('.content');
    var chips = $('.chips[data-role="reasons"]', content) || $('.chips', content);
    if (!chips) return;
    var blocks = $$('[data-reason]', content);
    var empty = $('[data-reason-empty]', content);
    var qBox = $('[data-q-box]', content);
    var known = {};
    blocks.forEach(function (b) { known[b.getAttribute('data-reason')] = 1; });
    function show(el, on) { if (el) el.style.display = on ? '' : 'none'; }
    function paint() {
      var sel = chipValues(chips, /^＋/);
      var custom = sel.filter(function (v) { return !known[v]; });
      var qs = [];
      blocks.forEach(function (b) {
        var k = b.getAttribute('data-reason');
        var on = sel.indexOf(k) > -1 || (k === '기타' && custom.length > 0);
        show(b, on);
        if (!on) return;
        var q = b.getAttribute('data-q') || '';
        if (k === '기타' && custom.length) q = '약 챙기기가 힘든 점이 있어요 — ' + custom.join(', ') + '. 도움이 될 방법이 있을까요?';
        if (q) qs.push(q);
      });
      show(empty, !sel.length);
      if (qBox) {
        if (!qs.length) qs.push(qBox.getAttribute('data-q-default') || '약 챙기기가 힘든 점이 있어요. 도움이 될 방법이 있을까요?');
        qBox.innerHTML = '';
        qs.forEach(function (q) {
          var p = document.createElement('p');
          p.className = 'small';
          p.textContent = '“' + q + '”';
          qBox.appendChild(p);
        });
      }
    }
    bindChips(chips, { skip: /^＋/, onChange: paint });
    bindAddChip(chips, '힘든 점을 짧게 적어 주세요', { onChange: paint });
    paint();
  }

  /* ── 48 응급 안내 · '담당 병원' 버튼 ──
     예전에는 84(내 병원 연락처) 화면으로 보내기만 했다. 급할 때 화면을 한 번 더 거치지 않도록,
     등록해 두신 번호가 있으면 119 버튼처럼 바로 전화가 걸리는 버튼으로 바꾼다.
       ① 응급실 번호가 있으면 그 번호  ② 없으면 외래(대표) 번호  ③ 둘 다 없으면 84 로 보내고 글자를 '내 병원 번호 등록하기'로
     번호는 profiles.treatment 의 care 에 있다(84 가 care.tel_er·care.tel_out·care.name·care.dept 로 저장한다).
     48 화면의 전화 확인창이 '어디로 거는지' 물을 수 있게 병원 이름을 data-callname 으로 함께 붙인다. */
  /* 버튼 하나를 '바로 걸리는 번호' 로 바꾼다 (48 · 31 … 공용).
     erFirst=true 면 응급실 번호 먼저(🔴 지금 바로), false 면 외래(대표) 번호 먼저(🟠 오늘 안에).
     번호가 하나도 없으면 아무것도 건드리지 않고 false 를 돌려준다 — 뒷일은 부른 쪽이 정한다. */
  function careCallBtn(btn, care, erFirst) {
    /* 병원 이름이 두 줄이 되어도 이름·진료과·번호 모두 버튼 한가운데에 둔다. */
    btn.style.textAlign = 'center';
    btn.style.justifyContent = 'center';
    /* 번호 칸에 '모름'처럼 글자만 적혀 있으면 전화가 걸리지 않는다 — 숫자가 3자 이상일 때만 번호로 본다 */
    var okTel = function (v) { return String(v || '').replace(/[^0-9]/g, '').length >= 3; };
    var erRaw = String(care.tel_er || '').trim(), outRaw = String(care.tel_out || '').trim();
    var er = okTel(erRaw) ? erRaw : '', out = okTel(outRaw) ? outRaw : '';
    var num = erFirst ? (er || out) : (out || er);
    if (!num) return false;              /* 등록된 번호 없음 */
    var useEr = erFirst ? !!er : !out;   /* 어느 쪽 번호를 골랐는지 — 글자에 그대로 적는다 */
    var nm = String(care.name || '').trim() || '담당 병원';
    var where = useEr ? '응급실' : (String(care.dept || '').trim() || '외래');
    btn.setAttribute('href', 'tel:' + num.replace(/[^0-9+]/g, ''));
    btn.setAttribute('data-callname', nm + ' ' + where);
    /* 두 줄로 나누면 읽어 주는 기능에서는 붙어 들려 — 읽을 글을 따로 준다 */
    btn.setAttribute('aria-label', nm + ' ' + where + ' ' + num + '번으로 전화 걸기');
    /* 어디로 거는지 글자로 보이게 — 병원 이름과 번호를 두 줄로 (좁은 폰에서 한 줄이면 넘친다) */
    btn.innerHTML = '';
    var l1 = document.createElement('span');
    l1.textContent = '📞 ' + nm + ' ' + where;
    var l2 = document.createElement('span');
    /* 번호도 버튼 글자 크기 그대로 — 40~70대가 눌러도 되는 번호인지 바로 읽을 수 있게 (.tiny 는 13px 아래로 내려간다) */
    l2.setAttribute('style', 'font-weight:600;');
    l2.textContent = num;
    var box = document.createElement('span');
    box.setAttribute('style', 'display:flex; flex-direction:column; align-items:center; gap:2px; width:100%; min-width:0; text-align:center;');
    l1.setAttribute('style', 'display:block; width:100%; max-width:100%; text-align:center; overflow-wrap:anywhere;');
    box.appendChild(l1); box.appendChild(l2);
    btn.appendChild(box);
    return true;
  }
  function page48() {
    var btn = $('#care-call');
    if (!btn) return;
    getProfile(function (p, pErr) {
      if (pErr) return;                  /* 못 불러왔으면 화면 그대로(84 등록하기) 둔다 — 없는 번호로 걸게 하지 않는다 */
      careCallBtn(btn, ((p && p.treatment) || {}).care || {}, true);   /* ③ 둘 다 없으면 화면 그대로 */
    });
  }

  /* ── 📞 '내 병원으로 연락하기' (data-role="call-mine") ──
     31 처럼 🟠(오늘 안에 연락) 단계에 이 버튼을 단 정보 화면 전부. 화면 이름을 가리지 않고 data-role 로만 찾으므로
     앞으로 다른 정보 화면에 같은 버튼을 붙여도 그대로 걸린다.
     48(🔴 지금 바로)과 달리 외래(대표) 번호가 먼저다 — 오늘 안에 연락이면 진료받는 과로 거는 것이 맞다.
       ① 외래(대표) 번호가 있으면 그 번호  ② 없으면 응급실 번호  ③ 둘 다 없으면 시안의 href(84 등록 화면) 그대로 두고
          글자를 '🏥 내 병원 번호 등록하기'로 바꾼다 — 걸리지 않는데 '연락하기'라고 두지 않는다.
     프로필을 못 불러왔을 때도 ③ 과 같이 둔다(번호가 있는지 모르는 채로 전화를 약속하지 않는다). */
  function wireCallMine() {
    var btns = $$('[data-role="call-mine"]');
    if (!btns.length) return;
    getProfile(function (p, pErr) {
      var care = (!pErr && ((p && p.treatment) || {}).care) || {};
      btns.forEach(function (btn) {
        btn.style.textAlign = 'center';
        btn.style.justifyContent = 'center';
        if (careCallBtn(btn, care, false)) return;
        btn.removeAttribute('data-callname');
        btn.removeAttribute('aria-label');
        btn.textContent = '🏥 내 병원 번호 등록하기';
      });
    });
  }

  /* ── 정보 화면 열람 기록 (연구용 집계 · 화면 이름은 저장하지 않는다) ──
     목록 + 파일명 패턴: 부작용 상세(NN-detail-*)·음식 카드(NN-food-*) 전부 */
  var CONTENT_PAGES = {
    '06-sideeffects.html': 1, '15-sideeffect-detail.html': 1, '17-selfcare-library.html': 1,
    '09-food-supplement.html': 1, '48-emergency.html': 1, '69-supplement-check.html': 1
  };
  function isContentPage(p) { return !!CONTENT_PAGES[p] || /^\d+-(detail|food)-[0-9a-z-]+\.html$/.test(p); }

  /* ── 정보 화면 열람 기억 (C2 · 이 기기에만) ── 2026-09-28
     홈 '오늘의 한 가지'가 요즘 자주 보신 화면을 고를 수 있게, 화면 이름·본 횟수·마지막으로 본 시각만
     이 기기(localStorage 'todak_views' = {"31-detail-nausea": {n, t}})에 남긴다.
     서버로는 보내지 않는다 — 위 content_view 는 화면 이름 없이 '봤다'만 남기는 그대로다.
     로그아웃하면 app.js 가 'todak_' 로 시작하는 값을 모두 지운다(기기를 함께 쓰는 경우).
     대상: 09·15·17·31~52·60~69·70~75·94·95 (부작용 상세·가이드·식사 카드·건강기능식품·약 안내).
     48 응급도 세기는 하지만 홈이 팁으로 쓰지는 않는다(features.js ONE_CAT 에 없음).
     뒤로가기로 되살아난 화면(bfcache)은 스크립트가 다시 돌지 않아 두 번 세지 않는다. 오래된 것부터 지워 40개까지만 둔다. */
  var VIEW_RX = /^(09|15|17|3[1-9]|4[0-9]|5[0-2]|6[0-9]|7[0-5]|94|95)-[0-9a-z-]+$/;
  function trackView() {
    var id = String(PAGE || '').replace(/\.html$/, '');
    if (!VIEW_RX.test(id)) return;
    var K = 'todak_views', o = null;
    try { o = JSON.parse(localStorage.getItem(K) || '{}'); } catch (e) { o = null; }
    if (!o || typeof o !== 'object' || isArr(o)) o = {};
    var cur = (has(o, id) && o[id] && typeof o[id] === 'object') ? o[id] : {};
    o[id] = { n: (+cur.n || 0) + 1, t: Date.now() };
    var ks = [];
    for (var k in o) if (has(o, k)) ks.push(k);
    if (ks.length > 40) {
      ks.sort(function (a, b) { return ((o[a] && +o[a].t) || 0) - ((o[b] && +o[b].t) || 0); });
      for (var i = 0; i < ks.length - 40; i++) delete o[ks[i]];
    }
    try { localStorage.setItem(K, JSON.stringify(o)); } catch (e2) { /* 못 담아도 화면은 그대로 */ }
  }

  /* ── 분기 ── */
  applyStubs();
  wireCallMine();                         /* 화면을 가리지 않는다 — 버튼이 있는 화면에서만 움직인다 */
  if (isContentPage(PAGE)) withConsent(function () { logEvent('content_view'); });
  trackView();
  if (PAGE === '03-profile-type.html') page03();
  else if (PAGE === '04-treatment.html') page04();
  else if (PAGE === '14-concerns.html') page14();
  else if (PAGE === '16-checkin.html') page16();
  else if (PAGE === '05-home.html') page05();
  else if (PAGE === '55-med-today.html') page55();
  else if (PAGE === '58-med-manual.html') page58();
  else if (PAGE === '56-med-schedule.html') page56();
  else if (PAGE === '57-med-missed.html') page57();
  else if (PAGE === '13-settings.html') page13();
  else if (PAGE === '48-emergency.html') page48();
})();
