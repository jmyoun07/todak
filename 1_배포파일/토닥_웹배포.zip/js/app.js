/* ═══ 토닥 화면 배선 v1 — 이메일 가입·로그인 ═══
   시안 화면(HTML)은 그대로 두고, 빌드가 이 파일을 모든 화면 끝에 끼워 넣는다.
   화면 파일명으로 분기해 그 화면에 필요한 동작만 붙인다. */
(function () {
  'use strict';

  var CFG = window.TODAK_CONFIG || {};
  var sb = null;
  /* 기록 읽기·저장(데이터베이스 REST 요청)에만 시간 제한을 둔다 — 통신이 '멈추면'(응답도 거절도 없으면)
     저장 단추가 '저장 중…'에 묶인 채 아무 말이 없었다(40초 넘게 · 2026-10-01 새벽 검증).
     30초가 지나면 요청을 거두어 오류로 돌려준다 → 화면마다 이미 있는 '저장하지 못했어요' 안내와 단추 되살리기가 돈다.
     응답 머리가 오면 시계를 멈춘다(느린 통신에서 긴 목록을 받는 중에는 끊지 않는다).
     사진 올리기(storage)·서버 함수(사진 인식·상담)·로그인(auth)은 오래 걸릴 수 있어 건드리지 않는다. */
  var REST_WAIT = 30000;
  function restFetch(input, init) {
    var url = typeof input === 'string' ? input : ((input && input.url) || '');
    if (url.indexOf('/rest/v1/') < 0 || !window.AbortController || (init && init.signal)) return fetch(input, init);
    var ac = new AbortController(), o = {}, k;
    for (k in (init || {})) o[k] = init[k];
    o.signal = ac.signal;
    var t = setTimeout(function () { ac.abort(); }, REST_WAIT);
    return fetch(input, o).then(function (r) { clearTimeout(t); return r; }, function (e) { clearTimeout(t); throw e; });
  }
  try {
    sb = window.supabase.createClient(CFG.url, CFG.anonKey, { global: { fetch: restFetch } });
  } catch (e) { /* 연결 부품 로드 실패 — 화면 자체는 그대로 보인다 */ }

  /* Netlify 는 주소에서 '.html' 을 떼어낸다(/97-email-login). 떼어진 이름을 그대로 쓰면 OPEN 목록과
     화면 분기가 전부 어긋나 로그인·가입 화면이 시작화면으로 되튕긴다. 확장자를 붙여 맞춘다. */
  var PAGE = location.pathname.split('/').pop() || 'index.html';
  if (PAGE.indexOf('.') === -1) PAGE += '.html';

  /* 같은 까닭으로 <a href> 도 어긋난다. Netlify 는 링크까지 '/16-checkin?from=05-home.html' 로 고쳐 쓴다.
     화면 배선은 링크를 파일 이름으로 찾는다(a.card[href^="16-checkin.html"]) — 고쳐 쓴 주소에는 하나도 걸리지 않아,
     웹앱에서는 홈의 두 고리가 시안 예시값('오늘 기록 전' · '1/2 완료')에 그대로 멈춰 있었다.
     배선이 읽기 전에 원래 모습으로 되돌려 둔다. 안드로이드 빌드는 이미 그 모습이라 아무것도 바뀌지 않는다.
     (되돌린 상대 주소로 눌러도 /16-checkin.html 이 그대로 열린다 — 확인함) */
  function normHref(v) {
    var raw = String(v == null ? '' : v), s0 = raw;
    if (!s0 || s0.charAt(0) === '#') return raw;
    if (/^[A-Za-z][A-Za-z0-9+.\-]*:/.test(s0)) return raw;        /* http: · tel: · mailto: · javascript: */
    if (s0.charAt(0) === '/') s0 = s0.slice(1);
    if (!s0 || s0.charAt(0) === '/') return raw;                  /* '/' · '//바깥주소' */
    var i = s0.search(/[?#]/), path = i < 0 ? s0 : s0.slice(0, i), rest = i < 0 ? '' : s0.slice(i);
    if (path.indexOf('.') > -1 || !/^[0-9A-Za-z._-]+$/.test(path)) return raw;   /* 이미 확장자가 있거나 우리 화면 이름이 아니면 그대로 */
    return path + '.html' + rest;
  }
  (function () {
    var as = document.getElementsByTagName('a');
    for (var i = 0; i < as.length; i++) {
      var v = as[i].getAttribute('href');
      if (v == null) continue;
      var nv = normHref(v);
      if (nv !== v) as[i].setAttribute('href', nv);
    }
  })();
  var DOC_VERSION = 'v6 2026-09';          /* 동의문 버전 — 바꾸면 재동의를 받는다. 25-terms 시행일 표기와 맞춘다 */
  /* 02 동의 화면의 임시 체크(pageConsent 참고) — 02 와 '전문 보기'(25) 사이를 오갈 때만 살려 둔다 */
  var CONSENT_DRAFT = 'todak_consent_draft';
  if (PAGE !== '02-consent.html' && PAGE !== '25-terms.html') {
    try { sessionStorage.removeItem(CONSENT_DRAFT); sessionStorage.removeItem('todak_review_from'); } catch (eD) {}
  }
  /* 사진으로 읽어 두고 아직 등록하지 않은 약(53 → 54 임시 저장 · native.js ocrPend).
     sessionStorage 에서 localStorage 로 옮겨(안드로이드가 WebView 를 정리해도 남게) 저장 시각을 함께 적는다.
     그래서 여기서 치우는 길을 둔다 — 약 등록 화면(53·54·58·59) 밖으로 나가면 지운다.
     (등록에 성공하면 54 가, 6시간이 지나면 native.js 가, 로그아웃 때는 아래 logout 이 지운다) */
  if (!/^(53|54|58|59)-/.test(PAGE)) {
    try { localStorage.removeItem('todak_ocr_meds'); localStorage.removeItem('todak_ocr_meds_at'); } catch (eM) {}
    try { sessionStorage.removeItem('todak_ocr_meds'); } catch (eM2) {}
  }
  /* 96 가입 화면에 적어 두신 이메일(약관 보기에 다녀오시는 동안만 — pageSignup 참고). 96·25 밖에서는 지운다 */
  var SIGNUP_EMAIL = 'todak_signup_email';
  if (PAGE !== '96-email-signup.html' && PAGE !== '25-terms.html') {
    try { sessionStorage.removeItem(SIGNUP_EMAIL); } catch (eE) {}
  }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

  /* 로그인 없이 볼 수 있는 화면 — 나머지는 전부 로그인 필요.
     순서를 바꿔 계정부터 만들므로 02(동의)는 로그인 후 화면이 되었다. */
  var OPEN = {
    'index.html': 1, '01-splash.html': 1,
    '96-email-signup.html': 1, '97-email-login.html': 1,
    '81-account-recovery.html': 1, '26-help.html': 1, '25-terms.html': 1
  };

  /* ── 공용 도우미 ── */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  var toastEl = null, toastTimer = null;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.setAttribute('role', 'status');
      toastEl.style.cssText =
        'position:fixed;left:50%;transform:translateX(-50%);' +
        'bottom:calc(100px + env(safe-area-inset-bottom));z-index:9999;' +
        'max-width:86%;padding:13px 18px;border-radius:14px;' +
        'background:rgba(33,29,30,.93);color:#fff;font-size:14px;line-height:1.55;' +
        'text-align:center;white-space:pre-line;box-shadow:0 6px 22px rgba(0,0,0,.25);' +
        /* body 바로 아래라 .screen 의 어절 단위 줄바꿈이 닿지 않는다 — 여기서 따로 건다 */
        'word-break:keep-all;overflow-wrap:break-word;overflow-wrap:anywhere;' +
        'opacity:0;transition:opacity .18s;pointer-events:none;';
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.style.opacity = '1';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.style.opacity = '0'; }, Math.min(7000, 2600 + String(msg).length * 45));
  }

  function busy(btn, on, label) {
    if (!btn) return;
    if (on) {
      if (btn.__busy) return;            /* 중복 호출이 원래 문구를 지우지 않게 */
      btn.__busy = true;
      btn.dataset.label = btn.textContent;
      btn.textContent = label || '잠시만요…';
      btn.style.opacity = '.65';
      btn.style.pointerEvents = 'none';
    } else {
      if (!btn.__busy) return;
      btn.__busy = false;
      if (btn.dataset.label) btn.textContent = btn.dataset.label;
      btn.style.opacity = '';
      btn.style.pointerEvents = '';
    }
  }

  function koError(err) {
    var m = String((err && (err.message || err.error_description)) || '');
    if (!navigator.onLine) return '인터넷 연결을 확인해 주세요.';
    if (/invalid login credentials/i.test(m)) return '이메일 또는 비밀번호가 맞지 않아요.';
    if (/already registered|already exists/i.test(m)) return '이미 가입된 이메일이에요. 로그인 화면에서 들어와 주세요.';
    if (/password.*(at least|characters)/i.test(m)) return '비밀번호는 8자 이상으로 정해 주세요.';
    if (/unable to validate email|invalid format/i.test(m)) return '이메일 주소를 다시 확인해 주세요.';
    if (/rate limit|too many/i.test(m)) return '요청이 잠시 몰렸어요. 1분 뒤 다시 시도해 주세요.';
    if (/fetch|network|load failed|timeout|abort/i.test(m)) return '연결이 원활하지 않아요. 잠시 후 다시 시도해 주세요.';   /* abort — 위 restFetch 가 30초 뒤 거둔 요청 */
    /* 영문 원본 오류는 화면에 보이지 않게 한다 — 환자분이 읽으실 글이다. 확인은 콘솔로. */
    if (m && window.console && console.warn) console.warn('todak error:', m);
    return '문제가 생겼어요. 잠시 후 다시 시도해 주세요.';
  }

  function btnByText(text) {
    return $$('a.btn').filter(function (a) { return a.textContent.indexOf(text) !== -1; })[0] || null;
  }

  /* ── 세션 확인 ── 2026-09-28
     getSession() 은 access token 이 이미 만료됐고 갱신이 연결 문제로 실패하면
     { data: { session: null }, error: AuthRetryableFetchError } 를 돌려준다 (실측 25.5초).
     error 를 보지 않고 '세션 없음 = 로그아웃' 으로 단정하면 로그인된 환자분을 01-splash 로
     내보내게 된다 — 그러면 이 파일 첫머리가 todak_ocr_meds 를 지우므로 사진으로 읽은 약이
     전부 사라지고, 16 증상 기록·10 진료 질문·58 약 이름처럼 적던 것도 함께 날아간다.
     native.js:336 · native.js:497 은 처음부터 이렇게 갈라 놓았다 — 나머지를 여기 한 곳으로 모은다.
     cb(session, err): session 있으면 정상 · 없고 err 있으면 연결 문제(로그아웃 아님) ·
     둘 다 없으면 진짜 로그아웃이다. */
  function withSession(cb) {
    if (!sb) { cb(null, new Error('no client')); return; }
    var done = false;
    var fin = function (ses, err) { if (done) return; done = true; cb(ses || null, err || null); };
    try {
      sb.auth.getSession().then(function (r) {
        fin((r && r.data && r.data.session) || null, (r && r.error) || null);
      }, function (e) { fin(null, e || new Error('getSession rejected')); });
    } catch (e1) { fin(null, e1); }
  }
  /* 연결 문제로 세션을 확인하지 못했다 — 화면에 머물게 하고 다시 해 보실 수 있게 풀어 드린다.
     누르신 단추가 '저장 중…' 으로 잠긴 채면 아무것도 못 하시므로 같이 풀어 준다.
     같은 말을 연달아 띄우지 않는다(화면마다 uid() 가 여러 번 부를 수 있다). */
  var sessOffAt = 0;
  function sessOffline(btn, msg) {
    if (btn) busy(btn, false);
    /* uid() 를 거쳐 들어온 길은 어느 단추가 잠겼는지 모른다 — 화면에서 잠긴 단추를 모두 풀어 준다.
       그대로 두면 '추가 중…'·'저장 중…' 에서 영영 멈춘 것처럼 보여 아무것도 못 하신다.
       busy() 는 자기가 잠근 것(__busy)만 되돌리므로 다른 단추를 건드리지 않는다. */
    try {
      var all = document.querySelectorAll('.btn, button'), i;
      for (i = 0; i < all.length; i++) if (all[i].__busy) busy(all[i], false);
    } catch (e0) {}
    var t = (new Date()).getTime();
    if (t - sessOffAt < 4000) return;
    sessOffAt = t;
    toast(msg || '연결이 원활하지 않아요. 잠시 후 다시 시도해 주세요.');
  }

  /* 지금의 동의 = consent_records 의 가장 최근 행 (consented_at → id 내림차순).
     02 열람·native.js·nearby.js 와 같은 규칙이다. 로그인 게이트도 이 한 행만 보고,
     그 행이 현재 동의문 버전이고 철회 표시(withdrawn_at)가 없을 때만 통과시킨다.
     (예전처럼 '철회 안 된 현재 버전 행이 하나라도 있으면' 통과시키면, 연구팀이 가장 최근 행에
      withdrawn_at 을 찍어도 앞선 행 때문에 홈으로 들어가 열람 화면의 '철회 처리됐어요'와 어긋난다) */
  function latestConsentQ(uid, cols) {
    return sb.from('consent_records').select(cols || 'doc_version,withdrawn_at').eq('user_id', uid)
      .order('consented_at', { ascending: false }).order('id', { ascending: false }).limit(1);
  }
  function consentValid(row) { return !!(row && row.doc_version === DOC_VERSION && !row.withdrawn_at); }

  /* ── 환자 확인 서류(99) 상태 ── 2026-09-28
     토닥은 유방암 치료를 받고 계신 분만 쓰는 앱이라, 가입 도중 02 동의 다음에 진단서·소견서 사진을 받는다.
     글자를 읽지 않고(OCR 없음) 토닥 담당자가 대시보드에서 나중에 본다. 표·보관함은
     supabase/sql/2026-09-28_patient_verify.sql 이 만든다 — 교수님이 그 파일을 실행하기 전에는 표가 없다.
     cb(state, row) — state 는 아래 중 하나:
       'none'     올린 적 없음            'pending'  확인 중
       'approved' 확인 완료               'rejected' 다시 올려 주세요 (row.note 에 담당자 한 줄)
       'missing'  표가 아직 없다(기능 준비 전) — 막지 않고 건너뛴다
       'error'    연결 문제 등 — 이 경우만 '모른다'. 부르는 쪽이 다시 확인할지 정한다
     가장 최근 행 하나가 지금 상태다 (동의 기록의 '가장 최근 행' 규칙과 같다). */
  function verifyMissing(r) {
    var e = r && r.error;
    if (!e) return false;
    /* PostgREST: 표가 없으면 404 + PGRST205('schema cache 에 없음') — 옛 판은 42P01('relation does not exist') */
    return r.status === 404 || e.code === 'PGRST205' || e.code === '42P01' ||
      /does not exist|schema cache|could not find the table/i.test(String(e.message || ''));
  }
  function verifyState(uid, cb) {
    var done = false;
    var fin = function (st, row, err) { if (done) return; done = true; cb(st, row || null, err || null); };
    if (!sb || !uid) { fin('error', null, new Error('no client')); return; }
    try {
      sb.from('patient_verifications').select('id,status,note,created_at,reviewed_at').eq('user_id', uid)
        .order('created_at', { ascending: false }).order('id', { ascending: false }).limit(1)
        .then(function (r) {
          if (r && r.error) { fin(verifyMissing(r) ? 'missing' : 'error', null, r.error); return; }
          var row = r && r.data && r.data[0];
          if (!row) { fin('none'); return; }
          fin(row.status === 'approved' || row.status === 'rejected' ? row.status : 'pending', row);
        }, function (e) { fin('error', null, e); });
    } catch (e1) { fin('error', null, e1); }
  }

  /* 다시 로그인하실 때 '지난번에 이걸로 하셨어요'를 보여 드리려고, 방법 한 낱말만 이 기기에 적어 둔다 */
  /* '최근 로그인'에 적을 방법은 버튼을 누른 그 순간에 적어 두었다가(noteLoginTry) 로그인이 끝나면 옮겨 적는다 (2026-09-28).
     예전에는 계정 정보(app_metadata.provider)만 봤는데, 카카오·네이버는 서버 함수(oauth-login)가 이메일 계정을 만들어
     매직링크로 들여보내는 방식이라 provider 가 늘 'email' 이다 → 카카오로 들어와도 '최근 로그인'이 이메일 버튼에 붙었다.
     · 버튼을 누른 기록(20분 안)이 있으면 그 방법 — 진짜 로그인이다
     · 없으면 앱을 다시 연 것(세션 이어 쓰기)이다 — 이미 적힌 값을 덮어쓰지 않는다. 다만 처음이거나,
       예전 방식으로 잘못 적힌 'email' 인데 카카오·네이버로 만든 계정이면 그 방법으로 바로잡는다 */
  var WAY_OK = { email: 1, kakao: 1, naver: 1, google: 1 };
  function noteLoginTry(w) {
    if (!WAY_OK[w]) return;
    try { localStorage.setItem('todak_login_try', JSON.stringify({ w: w, t: Date.now() })); } catch (e) {}
  }
  function noteLoginWay(user) {
    try {
      var tr = null, w = '', had = localStorage.getItem('todak_last_login') || '';
      try { tr = JSON.parse(localStorage.getItem('todak_login_try') || 'null'); } catch (eJ) { tr = null; }
      localStorage.removeItem('todak_login_try');
      var am = (user && user.app_metadata) || {}, um = (user && user.user_metadata) || {};
      var viaFn = um.oauth_provider === 'kakao' || um.oauth_provider === 'naver' ? um.oauth_provider : '';
      if (tr && WAY_OK[tr.w] && Date.now() - (+tr.t || 0) < 20 * 60000) w = tr.w;
      else if (!WAY_OK[had]) w = viaFn || am.provider || 'email';
      else if (had === 'email' && viaFn) w = viaFn;
      if (WAY_OK[w]) localStorage.setItem('todak_last_login', w);
    } catch (e) {}
  }

  function goAfterLogin(user, attempt, onFail) {
    if (!attempt) noteLoginWay(user);
    /* 가입은 단계로 나뉜다: 계정 생성 → 02 동의 → 99 환자 확인 서류 → 03~14 프로필.
       어느 단계에서 끊겼든 로그인하면 빠진 단계부터 이어서 진행시킨다.
       · 유효한 동의(가장 최근 행이 현재 버전·철회 안 됨) 없으면 → 02
       · 동의는 했는데 치료 단계(stage) 없고, 환자 확인 서류를 올린 적도 없으면 → 99 (2026-09-28)
         - 치료 단계가 이미 있는 분 = 이 단계가 생기기 전에 가입을 마치신 분이다. 99 로 막지 않는다
           ('내 정보 › 환자 확인 서류'에서 올리시면 된다).
         - 서류 표가 아직 없으면(교수님이 SQL 을 실행하기 전 · 404) 확인 단계를 건너뛴다 — 가입이 막히지 않게.
         - 확인 자체가 연결 문제로 실패하면 아래 retry 로 다시 확인한다(홈으로 열지 않는다 — 다른 단계와 같다).
         - 이미 올리셨으면(확인 중·완료·다시 올려 주세요 모두) 가입을 이어 간다. '다시 올려 주세요'는 13 에서 알린다.
       · 동의는 했는데 치료 단계(stage) 없으면 → 03
       · 둘 다 있으면 → 05 홈
       확인 자체가 실패하면 홈으로 열지 않고(fail-closed) 잠시 후 다시 확인한다.
       onFail — 세 번 다 실패했을 때 부른다. 버튼을 눌러 들어온 화면(97·96·02)이 버튼을 되살려
       다시 누를 수 있게 한다 (goAfterLogin(user, onFail) 처럼 두 번째 자리에 넘겨도 된다). */
    if (typeof attempt === 'function') { onFail = attempt; attempt = 0; }
    attempt = attempt || 0;
    function decide(hasConsent, stage, needVerify) {
      if (!hasConsent) location.replace('02-consent.html');
      else if (needVerify) location.replace('99-patient-verify.html');
      else if (!stage) location.replace('03-profile-type.html');
      else location.replace('05-home.html');
    }
    function retry() {
      if (attempt >= 2) {
        toast(onFail ? '연결이 원활하지 않아요.\n잠시 후 다시 시도해 주세요.' : '연결이 원활하지 않아요.\n잠시 후 앱을 다시 열어 주세요.');
        if (onFail) { try { onFail(); } catch (eF) {} }
        return;
      }
      toast('정보를 확인하는 중이에요…');
      setTimeout(function () { goAfterLogin(user, attempt + 1, onFail); }, 2500);
    }
    sb.from('profiles').select('stage,name').eq('id', user.id).maybeSingle()
      .then(function (r) {
        if (r.error) return retry();
        var d = r.data || {};
        /* (예전에는 가입 때 받은 이름을 여기서 profiles 에 옮겨 적었다. 지금은 이름·생년월일을
           약관 동의 뒤 03 기본 정보에서만 받으므로, 동의 전에 이름을 저장하지 않도록 뺐다 — 2026-09-17) */
        latestConsentQ(user.id)
          .then(function (r2) {
            if (r2.error) return retry();
            var ok = consentValid(r2.data && r2.data[0]);
            if (!ok || d.stage) return decide(ok, d.stage, false);
            verifyState(user.id, function (st) {
              if (st === 'error') return retry();
              decide(ok, d.stage, st === 'none');
            });
          }, retry);
      }, retry);
  }

  /* ── 문지기: 로그인 필요한 화면에서 세션 없으면 첫 화면으로 ── */
  function guard() {
    if (OPEN[PAGE] || !sb) return;
    withSession(function (ses, err) {
      if (ses || err) return;        /* err = 연결 문제 — 로그인된 분을 내보내지 않는다 */
      location.replace('01-splash.html');
    });
  }

  /* ── 01 시작 화면: 이미 로그인돼 있으면 바로 안으로 ── */
  var WAY_KO = { kakao: '카카오 로그인', naver: '네이버 로그인', google: 'Google 계정으로 로그인', email: '이메일로 로그인·가입' };
  function pageSplash() {
    markLastWay();
    /* 이미 로그인하신 분은 홈으로 바로 간다. 예전에는 확인하는 동안 로그인 단추 묶음만 감췄는데,
       '최근 로그인' 표시(markLastWay)가 그 단추를 따로 감싸면서 감추는 칸이 그 단추 하나로 줄어
       나머지 단추·로고가 0.1초 비쳤다가 홈으로 넘어갔다(2026-10-26 사용 의견 — '카카오만 안 보였다').
       이제 로그인 표시가 남은 폰은 head 의 작은 스크립트가 화면 전체를 처음부터 감춰 두고(.boot-sess),
       확인해 보니 로그인이 필요할 때만 여기서 보인다. 확인이 아주 늦거나 넘어가지 못하면 2.5초 뒤에 그래도 보인다
       — 로그인 못 하는 일이 없게. 로그인 표시가 없는 폰(처음 오신 분)은 감추지 않으므로 기다림 없이 바로 보인다. */
    var root = document.documentElement, shown = false;
    var show = function () {
      if (shown) return;
      shown = true;
      root.className = String(root.className || '').replace(/(^|\s)boot-sess(?=\s|$)/g, ' ');
    };
    if (!sb) { show(); return; }
    var t = setTimeout(show, 2500);
    sb.auth.getSession().then(function (r) {
      if (r && r.data && r.data.session) { goAfterLogin(r.data.session.user); return; }   /* 홈으로 — 화면은 그리지 않은 채 */
      clearTimeout(t); show();
    }, function () { clearTimeout(t); show(); });
  }
  /* 마지막으로 쓰신 로그인 방법을 그 버튼 왼쪽 위에 '최근 로그인' 으로 표시한다.
     기기에 남는 건 방법 한 낱말(kakao·naver·google·email)뿐 — 계정·이메일은 저장하지도 보여 주지도 않는다.
     .oauth-btn 은 overflow:hidden 이라 버튼 밖으로 나온 표시가 잘린다 → 버튼을 감싸는 칸을 하나 만들어 그 위에 얹는다. */
  function markLastWay() {
    var w = '';
    try { w = localStorage.getItem('todak_last_login') || ''; } catch (e) {}
    if (!WAY_KO[w]) return;
    var btn = w === 'email' ? $('#emailLoginLink') : $('.oauth-btn[data-oauth="' + w + '"]');
    if (!btn || !btn.parentNode) return;
    var wrap = document.createElement('div');
    wrap.setAttribute('style', 'position:relative; margin-top:8px;');
    btn.parentNode.insertBefore(wrap, btn);
    wrap.appendChild(btn);
    var tag = document.createElement('span');
    tag.setAttribute('style', 'position:absolute; top:-9px; left:12px; z-index:2; background:var(--primary-dark); color:#fff;'
      + ' font-size:13px; font-weight:700; line-height:1.4; padding:2px 10px; border-radius:999px; white-space:nowrap;');
    tag.textContent = '최근 로그인';
    wrap.appendChild(tag);
    /* 화면 읽기 프로그램이 읽을 이름 — 단추에 보이는 글자를 그대로 쓴다(01 화면과 늘 같게) */
    var say = '';
    try { var sp = btn.querySelector('span'); say = String((sp ? sp.textContent : btn.textContent) || '').replace(/\s+/g, ' ').replace(/^ | $/g, ''); } catch (eA) { say = ''; }
    btn.setAttribute('aria-label', (say || WAY_KO[w]) + ' · 최근에 쓰신 방법');
  }

  /* 비밀번호 표시 눈 토글 (96 이메일 가입·97 이메일 로그인) */
  function bindPwEye() {
    $$('.pw-eye').forEach(function (btn) {
      var inp = btn.parentNode ? btn.parentNode.querySelector('input') : null;
      if (!inp) return;
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var show = inp.type === 'password';
        inp.type = show ? 'text' : 'password';
        btn.classList[show ? 'add' : 'remove']('on');
        btn.textContent = show ? '🙈' : '👁';
        btn.setAttribute('aria-label', show ? '비밀번호 숨기기' : '비밀번호 표시');
      });
    });
  }

  /* ═══ 동의 열람·저장 도우미 ═══
     대전대학교 IRB 승인 연구 동의서 8항 — 전자적 동의를 마치신 뒤에도 동의 내용과
     연구설명문을 확인하거나 저장하실 수 있어야 한다. 아래 도구를 02 열람 모드가 쓴다. */

  /* 화면의 동의 항목 순서와 consent_records 컬럼을 짝지어 둔다 (순서가 곧 화면 순서) */
  var CONSENT_ITEMS = [
    { key: 'terms',         label: '서비스 이용약관 동의',         req: 1 },
    { key: 'privacy',       label: '개인정보 수집·이용 동의',      req: 1 },
    { key: 'health_info',   label: '민감정보(건강정보) 처리 동의', req: 1 },
    { key: 'location',      label: '위치정보 이용 동의',           req: 0 },
    { key: 'notifications', label: '맞춤 정보·알림 수신 동의',     req: 0 }
  ];

  function pad2(n) { return ('0' + n).slice(-2); }
  function fmtWhen(ts) {
    if (!ts) return '기록 없음';
    var d = new Date(ts);
    if (isNaN(d.getTime())) return String(ts);
    return d.getFullYear() + '년 ' + (d.getMonth() + 1) + '월 ' + d.getDate() + '일 ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  }

  /* ── 02 약관 동의 (로그인 후 화면) + 열람 모드(?review=1) ── */
  function pageConsent() {
    var Q = location.search || '';
    var REVIEW = /[?&]review=1/.test(Q);          /* 13 내 정보 / 03 뒤로가기에서 오는 '내가 동의한 내용 보기' */
    /* 돌아갈 화면 — 바깥 주소로 튀지 않게 화면 파일명만 받는다 */
    var FROM = (function () {
      var m = /[?&]from=([^&]*)/.exec(Q), v = '';
      try { v = m ? decodeURIComponent(m[1]) : ''; } catch (e) { v = ''; }
      v = /^[0-9A-Za-z._-]+\.html$/.test(v) ? v : '';
      /* 열람 중 '보기'(25)에 다녀오면 from 이 빠진 주소로 돌아온다 — 처음 받은 돌아갈 곳을 기억해 둔다 */
      if (REVIEW) {
        try {
          if (v) sessionStorage.setItem('todak_review_from', v);
          else v = sessionStorage.getItem('todak_review_from') || '';
        } catch (eF) {}
        v = /^[0-9A-Za-z._-]+\.html$/.test(v) ? v : '';
      }
      return v;
    })();
    var BACK = FROM || '03-profile-type.html';     /* from 이 없으면 예전대로 03 (가입 도중 뒤로가기) */
    var already = false;

    /* 열람 모드 뼈대 전환은 DB 응답을 기다리지 않는다 (느린 망에서도 화면이 먼저 제자리를 잡게) */
    var elFoot = $('#consentFooter'), elRFoot = $('#reviewFooter');
    if (REVIEW) {
      var elSteps = $('#consentSteps'), elNote = $('#consentNote'),
          elRev = $('#consentReview'), elRBack = $('#reviewBack'),
          elTitle = $('#consentTitle'), elSub = $('#consentSub');
      if (elSteps) elSteps.hidden = true;
      if (elFoot) elFoot.hidden = true;
      if (elNote) elNote.hidden = true;
      if (elRev) elRev.hidden = false;
      if (elRFoot) elRFoot.hidden = false;
      if (elRBack) elRBack.setAttribute('href', BACK);
      /* 가입 화면의 제목('동의가 필요해요')을 그대로 두면 이미 동의하신 분께 다시 동의를 구하는 꼴이 된다 */
      if (elTitle) elTitle.textContent = '내가 동의한 내용';
      if (elSub) { elSub.textContent = '동의하신 때와 항목이에요. 각 항목의 ‘보기’에서 내용을 다시 보실 수 있어요.'; elSub.hidden = false; }
      /* '보기'에 다녀오면 열람 화면으로 돌아오게 */
      $$('a.agree-view, a.agree-info').forEach(function (a) {
        var hr = a.getAttribute('href') || '';
        if (hr.indexOf('from=02-consent.html') > -1 && hr.indexOf('review=1') === -1) {
          a.setAttribute('href', hr.replace('from=02-consent.html', 'from=02-consent.html&review=1'));
        }
      });
    }

    /* 세션 없이 들어오면 계정부터 */
    if (sb) withSession(function (rs0, err0) {
      /* 연결 문제면 체크를 지우지도, 내보내지도 않는다 — 저장할 때 다시 확인한다 */
      if (!rs0) { if (!err0) { draftClear(); location.replace('01-splash.html'); } return; }
      var rs = { data: { session: rs0 } };
      var u = rs.data.session.user;
      if (REVIEW) { loadReview(u.id, u.email); return; }
      draftOwner(u.id);
      /* 이미 유효한 동의가 있으면(가장 최근 행 기준 — goAfterLogin 과 같은 규칙) 다음 단계로 */
      latestConsentQ(u.id)
        .then(function (r) {
          if (r && !r.error && consentValid(r.data && r.data[0])) { already = true; draftClear(); goAfterLogin(u); }
        });
    });

    /* ── 체크 임시 보관 — '전문 보기'(25)에 다녀오셔도 누르신 체크가 풀리지 않게 ──
       · sessionStorage 라 앱(탭)을 닫으면 사라진다. 02·25 밖의 화면에 가면 app.js 첫머리에서 지운다.
       · 동의 기록(consent_records)은 여전히 '저장 버튼을 누르는 순간 화면에 보이는 체크'로만 만든다.
         여기 값은 화면의 체크를 되살리는 데만 쓰고, 저장에 직접 쓰지 않는다.
       · 다른 계정이 남긴 값이면 되살리지 않는다(같은 기기를 함께 쓰는 경우).
       · 열람 모드(?review=1)에서는 읽지도 쓰지도 않는다. */
    function draftRead() {
      try {
        var d = JSON.parse(sessionStorage.getItem(CONSENT_DRAFT) || 'null');
        return (d && d.v === DOC_VERSION && d.c && d.c.length === 5) ? d : null;
      } catch (e) { return null; }
    }
    function draftClear() { try { sessionStorage.removeItem(CONSENT_DRAFT); } catch (e) {} }
    function draftSave() {
      /* 계정을 확인하기 전(draftUid 없음)에는 보관함을 건드리지 않는다 —
         첫 refresh() 가 빈 체크로 앞서 남긴 값을 지워 버리지 않게 */
      if (REVIEW || !items || !draftUid) return;
      var c = items.map(isOn), a = !!(age && isOn(age));
      if (c.indexOf(true) === -1 && !a) { draftClear(); return; }  /* 아무것도 안 눌렀으면 남길 것이 없다 */
      try { sessionStorage.setItem(CONSENT_DRAFT, JSON.stringify({ v: DOC_VERSION, uid: draftUid, c: c, a: a })); } catch (e) {}
    }
    /* 되살리기는 로그인 계정을 확인한 뒤에만 한다 — 다른 계정의 체크가 잠깐이라도 보이지 않게.
       되살린 체크도 화면에 그대로 보이고 누르면 바뀌므로, 저장은 늘 화면 상태를 따른다. */
    function draftOwner(uid) {
      if (!items || !uid) return;
      draftUid = uid;
      var d = draftRead();
      if (d && d.uid !== uid) { draftClear(); d = null; }         /* 다른 계정이 남긴 체크 — 버린다 */
      /* 확인을 기다리는 사이 이미 누르셨으면 지금 화면이 우선이다 */
      if (d && !items.some(isOn) && !(age && isOn(age))) {
        items.forEach(function (el, i) { setBox(el, d.c[i] === true); });
        if (age) setBox(age, d.a === true);
      }
      refresh();                                                   /* 전체 동의·버튼 갱신 + 지금 화면 상태 보관 */
    }
    var draftUid = '';

    /* 뒤로가기: 열람이면 온 곳으로, 아니면 이 계정을 벗어나 처음으로 (다른 계정으로 시작할 수 있게)
       · 가입 도중의 열람(03 기본 정보의 ‹ 로 온 경우 — from 없음)에서 한 번 더 뒤로 가면 처음 화면이다.
         묻고 나서 로그아웃한다 (예전에는 03 ↔ 02 열람만 오가 로그아웃·앱 닫기로 나갈 길이 없었다).
         '돌아가기' 버튼은 그대로 03 으로 간다.
       · 로그아웃은 82 와 같은 공용 정리(logout)를 탄다 — 예약 알림·기기에 남은 값까지 지운다. */
    var back02 = $('.appbar .back');
    if (back02) back02.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      if (REVIEW) {
        if (FROM) location.replace(BACK);
        else leaveSignup();
        return;
      }
      draftClear();
      logout(function () { location.replace('01-splash.html'); });
    });

    /* (예전 화면 대비) 항목 안에 details 본문이 있으면 '자세히' 버튼으로 바꾼다.
       2026-09-17 단순화 뒤로는 본문이 25 탭에 있고 항목 오른쪽 '보기' 링크로 가므로 여기서 할 일이 없다. */
    $$('.consent-item').forEach(function (item) {
      var sel = $('.selectable', item);
      var det = item.querySelector('details');
      if (!sel || !det) return;
      var body = $('.consent-body', det);
      if (!body) return;
      var btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'consent-toggle'; btn.textContent = '자세히';
      sel.appendChild(btn);
      item.appendChild(body); body.hidden = true;
      det.parentNode.removeChild(det);
      btn.addEventListener('click', function (e) {
        e.stopPropagation(); e.preventDefault();
        body.hidden = !body.hidden;
        btn.textContent = body.hidden ? '자세히' : '접기';
      });
      btn.addEventListener('keydown', function (e) { e.stopPropagation(); });
    });

    /* 전체 동의(.agree-all)와 만 19세 확인(data-gate="age")은 이름으로 따로 집고,
       나머지 체크 5개만 화면 순서대로 consent_records 컬럼과 짝짓는다 */
    var all = $('.selectable.agree-all');
    var age = $('.selectable[data-gate="age"]');
    var items = $$('.selectable[role="checkbox"]').filter(function (b) { return b !== all && b !== age; });
    if (!all || items.length < 5) return;
    items = items.slice(0, 5);       /* [약관, 개인정보, 민감정보, 위치(선택), 알림(선택)] */
    var REQ = 3;
    /* .footer-actions 가 둘(가입용·열람용)이라 id 로 정확히 집는다 */
    var cta = $('#consentFooter .btn');
    var hint = $('#consentFooter p');

    function isOn(el) { return el.getAttribute('aria-checked') === 'true'; }
    function setBox(el, on, isAll) {
      el.setAttribute('aria-checked', on ? 'true' : 'false');
      var box = $('.s-box', el);
      if (!box) return;
      box.textContent = on ? '✓' : '';
      box.style.background = on ? 'var(--primary)' : '';
      box.style.borderColor = on ? 'var(--primary)' : '';
      box.style.color = on ? '#fff' : '';
      if (isAll) el.classList[on ? 'add' : 'remove']('is-on');
    }

    /* 열람 모드는 여기서 갈라진다 — 아래 가입 게이트(필수 체크 → 저장)는 타지 않는다 */
    if (REVIEW) { reviewMode(); return; }

    function ageOn() { return !age || isOn(age); }
    function refresh() {
      setBox(all, items.every(isOn) && ageOn(), true);
      var ok = ageOn() && items.slice(0, REQ).every(isOn);
      if (!cta.__busy) cta.setAttribute('aria-disabled', ok ? 'false' : 'true');
      if (hint) hint.style.display = ok ? 'none' : '';
      draftSave();
    }
    function toggleHandler(el) {
      return function (e) {
        if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
        e.preventDefault();
        setBox(el, !isOn(el));
        refresh();
      };
    }
    items.concat(age ? [age] : []).forEach(function (el) {
      el.addEventListener('click', toggleHandler(el));
      el.addEventListener('keydown', toggleHandler(el));
    });
    function allHandler(e) {
      if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
      e.preventDefault();
      var to = !(items.every(isOn) && ageOn());
      items.forEach(function (el) { setBox(el, to); });
      if (age) setBox(age, to);
      refresh();
    }
    all.addEventListener('click', allHandler);
    all.addEventListener('keydown', allHandler);

    cta.addEventListener('click', function (e) {
      e.preventDefault();
      if (cta.getAttribute('aria-disabled') === 'true') {
        /* 무엇이 빠졌는지 토스트로만 말하지 않고, 빠진 첫 필수 줄로 데려가 잠깐 표시한다 */
        var miss = (age && !isOn(age)) ? age : items.slice(0, REQ).filter(function (el) { return !isOn(el); })[0];
        toast(miss === age ? '만 19세 이상인지 확인해 주세요.' : '필수 항목에 모두 동의하셔야 시작할 수 있어요.');
        if (miss) {
          var row = miss.parentNode || miss;
          try { row.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e1) {}
          row.classList.add('is-missing');
          setTimeout(function () { row.classList.remove('is-missing'); }, 2600);
        }
        return;
      }
      if (cta.__busy) return;
      /* 다음 화면을 정하는 확인이 끝내 실패하면 버튼을 되살려 다시 누르실 수 있게 한다 */
      var reopen = function () { busy(cta, false); };
      if (already) {                   /* 이미 동의함: 중복 저장 안 함 */
        busy(cta, true, '확인 중…');
        withSession(function (ses0, err0) {
          if (ses0) { goAfterLogin(ses0.user, reopen); return; }
          if (err0) { sessOffline(cta); reopen(); return; }   /* 연결 문제 — 내보내지 않는다 */
          reopen(); location.replace('01-splash.html');
        });
        return;
      }
      if (!sb) return toast('연결이 준비되지 않았어요. 인터넷을 연결한 뒤 다시 열어 주세요.');
      busy(cta, true, '저장 중…');
      /* 기록은 화면의 실제 체크 상태 그대로 남긴다.
         필수 3개를 다 체크해야 버튼이 열리는 것은 위 게이트가 이미 막고 있다. */
      var picked = {
        terms: isOn(items[0]), privacy: isOn(items[1]), health_info: isOn(items[2]),
        location: isOn(items[3]), notifications: isOn(items[4])
      };
      withSession(function (ses1, err1) {
        if (!ses1) {
          /* 연결 문제면 체크한 것을 그대로 두고 화면에 머문다 — 다시 누르시면 된다 */
          if (err1) { sessOffline(cta); return; }
          busy(cta, false); location.replace('01-splash.html'); return;
        }
        var rs = { data: { session: ses1 } };
        sb.from('consent_records').insert({
          user_id: rs.data.session.user.id, doc_version: DOC_VERSION,
          terms: picked.terms, privacy: picked.privacy, health_info: picked.health_info,
          location: picked.location, notifications: picked.notifications
        }).then(function (r) {
          if (r.error) { busy(cta, false); return toast(koError(r.error)); }
          draftClear();                  /* 기록이 남았으니 임시 체크는 더 필요 없다 */
          already = true;                /* 다음 화면 확인이 실패해 다시 누르셔도 동의 행을 또 만들지 않게 */
          /* 동의 직후 휴대폰 접근권한을 차례로 묻는다 (앱일 때만·거절해도 진행) */
          /* 기본 정보가 이미 있으면(새 동의문에 다시 동의하신 경우) 홈으로, 없으면 99 환자 확인 서류(아직 안 올리셨으면)를 거쳐 03 으로.
             '동의하고 시작하기' 다음 화면은 goAfterLogin 한 곳이 정한다 — 여기서 03 으로 곧장 보내지 않는다 (2026-09-28) */
          var go = function () { goAfterLogin(rs.data.session.user, reopen); };
          if (window.TDN && TDN.askPermissions) {
            busy(cta, true, '권한 확인 중…');
            TDN.askPermissions({ location: picked.location, notifications: picked.notifications }, go);
          } else go();
        }, function (err) { busy(cta, false); toast(koError(err)); });
      });
    });
    refresh();          /* '전문 보기'에서 돌아오신 경우의 체크 되살리기는 계정 확인 뒤 draftOwner 가 한다 */

    /* ══ 열람 모드(?review=1) ══ 아래 둘은 함수 선언이라 위에서 먼저 불러도 된다 ══ */
    var reviewApply;                     /* reviewMode() 가 채우고 loadReview() 가 부른다 */

    function loadReview(uid, email) {
      var elWhen = $('#crWhen');
      if (!sb) { if (elWhen) elWhen.textContent = '연결이 준비되지 않았어요. 인터넷을 연결한 뒤 다시 열어 주세요.'; return; }
      sb.from('consent_records')
        .select('id,doc_version,terms,privacy,health_info,location,notifications,consented_at,withdrawn_at')
        .eq('user_id', uid)
        .order('consented_at', { ascending: false })
        .order('id', { ascending: false })
        .limit(30)
        .then(function (r) {
          if (r.error) { if (elWhen) elWhen.textContent = koError(r.error); return; }
          var rows = r.data || [];
          if (!rows.length) {
            if (elWhen) elWhen.textContent = '남아 있는 동의 기록을 찾지 못했어요. 앱을 다시 열어 로그인해 주세요.';
            return;
          }
          /* 지금의 동의 = 가장 최근 행. 앱의 다른 곳(native.js consentNotif · nearby.js)도
             똑같이 '가장 최근 행'을 현재 동의로 읽는다. 여기서만 '철회 안 된 가장 최근 행'을
             고르면, 연구팀이 최근 행에 withdrawn_at 을 찍은 경우 화면에는 옛 동의가 보이고
             앱은 새 행대로 움직여 서로 어긋난다. 규칙을 하나로 맞춘다. */
          if (reviewApply) reviewApply(rows[0], rows, email);
        }, function (err) { if (elWhen) elWhen.textContent = koError(err); });
    }

    function reviewMode() {
      var elWhen = $('#crWhen'), elVer = $('#crVersion'), elItems = $('#crItems'), elHist = $('#crHistory'),
          btnSave = $('#reviewSave'), noteChange = $('#reviewChangeNote'), elEditNote = $('#crEditNote');
      var rec = null, rowsAll = [], email = '', withdrawn = false;

      if (all) all.hidden = true;                      /* 열람에서는 '전체 동의하기'가 필요 없어요 */
      /* 만 19세 확인은 기록 칸이 없는 가입 때의 확인이라, 열람에서는 줄째 감춘다 */
      if (age && age.parentNode) age.parentNode.hidden = true;

      /* 필수 3항목은 열람 전용 — 눌러도 바뀌지 않아요 (거두시려면 보호책임자 이메일로) */
      /* 항목 줄에 설명 줄(.s-sub)이 없으면 만들어 붙인다 (2026-09-17 한 줄 목록으로 바뀜) */
      function subLine(el, html) {
        var sub = $('.s-sub', el);
        if (!sub) {
          var t = $('.s-title', el);
          sub = document.createElement('div');
          sub.className = 's-sub';
          if (t && t.parentNode) t.parentNode.appendChild(sub); else return;
          sub.innerHTML = html;
        } else sub.innerHTML = sub.innerHTML + ' · ' + html;
      }
      items.slice(0, REQ).forEach(function (el) {
        el.setAttribute('aria-disabled', 'true');
        subLine(el, '여기서는 바꿀 수 없어요');
        var hr = function (e) {
          if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
          e.preventDefault();
          toast('필수 항목은 여기서 바꾸실 수 없어요.');
        };
        el.addEventListener('click', hr);
        el.addEventListener('keydown', hr);
      });
      /* 선택 2항목(위치·알림)은 여기서 바로 철회하거나 다시 동의하실 수 있어요 */
      items.slice(REQ).forEach(function (el) {
        subLine(el, '<b>여기서 켜고 끄실 수 있어요</b>');
        var h = function (e) {
          if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
          e.preventDefault();
          if (!rec) return;                            /* 기록을 아직 못 불러왔으면 손대지 않아요 */
          if (withdrawn) { toast('이 동의는 철회 처리돼 있어요.\n앱에서는 다시 켜실 수 없어요.'); return; }
          setBox(el, !isOn(el));
          syncChanged();
        };
        el.addEventListener('click', h);
        el.addEventListener('keydown', h);
      });

      /* 위치·알림을 바꾸고 저장하지 않은 채 '보기'로 나가면 바꾼 내용이 사라진다 — 나가기 전에 묻는다 */
      $$('a.agree-view').forEach(function (a) {
        a.addEventListener('click', function (e) {
          if (!btnSave || btnSave.hidden) return;
          if (!window.confirm('바꾸신 내용을 아직 저장하지 않았어요.\n저장하지 않고 내용을 보러 갈까요?')) e.preventDefault();
        });
      });
      function syncChanged() {
        if (!rec) return;
        if (withdrawn) {                               /* 철회된 기록은 여기서 되살리지 않아요 */
          if (btnSave) btnSave.hidden = true;
          if (noteChange) noteChange.hidden = true;
          return;
        }
        var msgs = [];
        if (isOn(items[3]) !== !!rec.location) msgs.push('위치정보 ' + (isOn(items[3]) ? '동의' : '동의 철회'));
        if (isOn(items[4]) !== !!rec.notifications) msgs.push('알림 수신 ' + (isOn(items[4]) ? '동의' : '동의 철회'));
        if (btnSave) btnSave.hidden = !msgs.length;
        if (noteChange) {
          noteChange.hidden = !msgs.length;
          if (msgs.length) noteChange.innerHTML = '바꾸신 내용 — <b>' + esc(msgs.join(' · ')) + '</b><br>아래 <b>‘바꾼 내용 저장’</b>을 누르셔야 바뀌어요.';
        }
      }

      function paint() {
        if (elWhen) elWhen.innerHTML = '<b>' + esc(fmtWhen(rec.consented_at)) + '</b>에 동의하셨어요.' +
          (withdrawn
            ? '<br><b style="color:var(--danger);">이 동의는 ' + esc(fmtWhen(rec.withdrawn_at)) + '에 철회 처리됐어요.</b>' +
              ' 앱에서는 다시 켜실 수 없어요. 궁금하신 점은 개인정보 보호책임자 이메일(jamesyoun@dju.kr)로 알려 주세요.'
            : '');
        if (elEditNote) elEditNote.hidden = withdrawn;   /* '선택 2가지는 켜고 끄실 수 있어요' 안내 */
        if (elVer) elVer.textContent = '동의문 버전 ' + (rec.doc_version || '') + ' · 서버에 남아 있는 기록 그대로예요.';
        if (elItems) {
          var h = '';
          for (var i = 0; i < CONSENT_ITEMS.length; i++) {
            var c = CONSENT_ITEMS[i], on = !!rec[c.key];
            /* 항목 목록은 본문이라 .small(13px 이상) — .tiny 는 작은 폰에서 11.5px 까지 줄어든다 */
            h += '<div class="row" style="align-items:flex-start;">' +
                 '<span class="small grow">' + esc(c.label) +
                 ' <span class="pill ' + (c.req ? 'pill--danger' : 'pill--brand') + '">' + (c.req ? '필수' : '선택') + '</span></span>' +
                 '<span class="small strong" style="flex:0 0 auto; color:' + (on ? 'var(--safe)' : 'var(--on-surface-variant)') + ';">' +
                 (on ? '동의함' : '동의 안 함') + '</span></div>';
          }
          elItems.innerHTML = h;
        }
        if (elHist) {
          if (rowsAll.length > 1) {
            var hh = '<b>동의 변경 이력</b><br>';
            for (var k = 0; k < rowsAll.length; k++) {
              var x = rowsAll[k];
              hh += '· ' + esc(fmtWhen(x.consented_at)) +
                    ' — 위치 ' + (x.location ? '동의' : '동의 안 함') +
                    ' · 알림 ' + (x.notifications ? '동의' : '동의 안 함') +
                    (x.withdrawn_at ? ' <b>(' + esc(fmtWhen(x.withdrawn_at)) + ' 철회 처리)</b>' : '') + '<br>';
            }
            elHist.innerHTML = hh;
            elHist.hidden = false;
          } else elHist.hidden = true;
        }
      }

      reviewApply = function (r, rows, mail) {
        rec = r; rowsAll = rows || []; email = mail || ''; withdrawn = !!(rec && rec.withdrawn_at);
        for (var i = 0; i < CONSENT_ITEMS.length; i++) setBox(items[i], !!rec[CONSENT_ITEMS[i].key]);
        paint();
        syncChanged();
      };

      /* ── 선택 동의 철회·재동의 저장 ── */
      if (btnSave) btnSave.addEventListener('click', function (e) {
        e.preventDefault();
        if (!rec || withdrawn || btnSave.__busy) return;
        if (!sb) return toast('연결이 준비되지 않았어요. 인터넷을 연결한 뒤 다시 열어 주세요.');
        var loc = isOn(items[3]), noti = isOn(items[4]);
        var notifChanged = noti !== !!rec.notifications;
        var offNotif = !!rec.notifications && !noti;
        busy(btnSave, true, '저장 중…');
        withSession(function (ses2, err2) {
          if (!ses2) {
            if (err2) { sessOffline(btnSave); return; }
            busy(btnSave, false); location.replace('01-splash.html'); return;
          }
          var u = ses2.user;
          /* consent_records 는 넣기·읽기만 열려 있고 고치기가 막혀 있다
             (supabase_schema.sql — "사용기록·동의는 남기기만 하고 고치거나 지울 수 없다").
             그래서 철회는 기존 행을 고치지 않고 '지금의 동의 상태'를 담은 새 행을 하나 더 남긴다.
             native.js(consentNotif)·nearby.js 도 이미 consented_at 이 가장 최근인 행을 현재 동의로 읽는다. */
          sb.from('consent_records').insert({
            user_id: u.id,
            doc_version: rec.doc_version || DOC_VERSION,
            terms: !!rec.terms, privacy: !!rec.privacy, health_info: !!rec.health_info,
            location: loc, notifications: noti
          }).then(function (r2) {
            if (r2.error) { busy(btnSave, false); return toast(koError(r2.error)); }
            var fin = function () {
              busy(btnSave, false);
              toast(offNotif ? '바꾸신 내용을 저장했어요.\n예약돼 있던 알림도 모두 껐어요.' : '바꾸신 내용을 저장했어요.');
              loadReview(u.id, u.email);
            };
            /* 알림 동의를 끄셨으면 동의를 다시 읽지 않고 예약을 바로 모두 지운다 (오프라인이어도 지워지게) */
            if (offNotif && window.TDN && window.TDN.cancelAll) window.TDN.cancelAll(function () { fin(); });
            /* 알림 동의를 켜셨으면 실제 예약까지 맞춘다 (notifySync 가 방금 남긴 행을 다시 읽는다) */
            else if (notifChanged && window.TDN && window.TDN.notifySync) window.TDN.notifySync(function (st) {
              fin();
              /* 휴대폰 권한이 꺼져 있으면 저장 안내 뒤에 설정 방법을 알린다 (native.js 는 이미 거부된 상태에선 따로 안내하지 않음) */
              if (st && st !== 'ok' && window.TDN.deniedToast) setTimeout(function () { window.TDN.deniedToast(st); }, 1500);
            });
            else fin();
          }, function (err) { busy(btnSave, false); toast(koError(err)); });
        });
      });
    }
  }

  /* ═══ 입력 도우미 — 이메일 뒷주소 추천 · 생년월일 년/월/일 ═══ */

  function fire(el, type) {
    try { var ev = document.createEvent('Event'); ev.initEvent(type, true, true); el.dispatchEvent(ev); } catch (e) {}
  }

  /* 이메일 칸 아래에 '@naver.com' 같은 뒷주소를 골라 넣을 수 있게 펼친다 (참고 캡처 07).
     칸에 적힌 앞부분만 쓰고, 기기에 저장된 다른 주소는 읽지 않는다. */
  var MAIL_DOMAINS = ['naver.com', 'gmail.com', 'daum.net', 'hanmail.net', 'kakao.com', 'nate.com', 'icloud.com'];
  function bindEmailSuggest(inp, next) {
    if (!inp || inp.__sug) return;
    inp.__sug = 1;
    var box = document.createElement('div');
    box.className = 'email-suggest';
    box.setAttribute('role', 'listbox');
    box.hidden = true;
    inp.parentNode.appendChild(box);
    var hideT = null;
    function hide() { box.hidden = true; box.innerHTML = ''; }
    function render() {
      /* 81 비밀번호 재설정은 같은 칸을 '새 비밀번호'(type=password)로 바꿔 쓴다 — 그때는 절대 펼치지 않는다
         (비밀번호가 목록에 글자로 보이고, 잘못 누르면 비밀번호 끝에 '@naver.com' 이 붙는다) */
      if (inp.type !== 'email') return hide();
      var v = String(inp.value || '').replace(/\s/g, '');
      var at = v.indexOf('@');
      var local = at === -1 ? v : v.slice(0, at);
      var dom = at === -1 ? '' : v.slice(at + 1).toLowerCase();
      if (!local || !/^[A-Za-z0-9._%+-]+$/.test(local) || dom.indexOf('@') > -1) return hide();
      var list = MAIL_DOMAINS.filter(function (d) { return d.indexOf(dom) === 0 && d !== dom; });
      if (!list.length) return hide();
      box.innerHTML = '';
      list.slice(0, 5).forEach(function (d) {
        var b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('role', 'option');
        b.innerHTML = esc(local) + '<b>@' + esc(d) + '</b>';
        /* 누르는 순간 칸에서 초점이 빠지면 자판이 내려갔다 다시 올라온다 — 초점을 붙잡아 둔다 */
        b.addEventListener('mousedown', function (e) { e.preventDefault(); });
        b.addEventListener('click', function (e) {
          e.preventDefault();
          clearTimeout(hideT);
          inp.value = local + '@' + d;
          hide();
          fire(inp, 'input');
          if (next) { try { next.focus(); } catch (e2) {} }
        });
        box.appendChild(b);
      });
      box.hidden = false;
    }
    inp.addEventListener('input', render);
    inp.addEventListener('focus', render);
    inp.addEventListener('blur', function () { clearTimeout(hideT); hideT = setTimeout(hide, 250); });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Escape') hide(); });
  }

  /* 생년월일 — 년·월·일 세 목록(.birth-sel)을 눌러 고르고, 값은 숨은 칸(aria-label="생년월일")에
     'YYYY-MM-DD' 로 모은다. 그래서 가입(96)·기본 정보(03) 코드는 예전처럼 그 칸의 value 만 읽고 쓴다.
     코드가 value 를 넣으면(03 에서 저장된 생일 불러오기) 세 목록도 따라 바뀐다. */
  function bindBirthSelect(wrap, hid) {
    if (!wrap || !hid || wrap.__bound) return;
    var sels = $$('select', wrap);
    if (sels.length < 3) return;
    wrap.__bound = 1;
    var sy = sels[0], sm = sels[1], sd = sels[2];
    var maxY = new Date().getFullYear() - 19, minY = 1920;
    function fill(sel, from, to, suffix) {
      var ph = sel.options[0] ? sel.options[0].textContent : '';
      var keep = sel.value;
      sel.innerHTML = '';
      var o0 = document.createElement('option'); o0.value = ''; o0.textContent = ph; sel.appendChild(o0);
      var step = from <= to ? 1 : -1;
      for (var n = from; step > 0 ? n <= to : n >= to; n += step) {
        var o = document.createElement('option'); o.value = String(n); o.textContent = n + suffix; sel.appendChild(o);
      }
      sel.value = keep;
      if (sel.value !== keep) sel.value = '';
    }
    fill(sy, maxY, minY, '년');          /* 최근 해부터 — 40~60대가 덜 내려도 되게 */
    fill(sm, 1, 12, '월');
    function fixDays() {
      var y = +sy.value || 2000, m = +sm.value || 1;
      fill(sd, 1, new Date(y, m, 0).getDate(), '일');
    }
    fixDays();
    var desc = null;
    try { desc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value'); } catch (e0) { desc = null; }
    function rawSet(v) { if (desc && desc.set) desc.set.call(hid, v); else hid.setAttribute('value', v); }
    function rawGet() { return (desc && desc.get) ? desc.get.call(hid) : (hid.getAttribute('value') || ''); }
    function paint() { sels.forEach(function (s) { s.classList[s.value ? 'remove' : 'add']('is-empty'); }); }
    function toValue() {
      rawSet((sy.value && sm.value && sd.value) ? sy.value + '-' + pad2(sm.value) + '-' + pad2(sd.value) : '');
      paint();
      fire(hid, 'change');
    }
    function fromValue() {
      var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(rawGet() || '');
      sy.value = m ? String(+m[1]) : '';
      sm.value = m ? String(+m[2]) : '';
      fixDays();
      sd.value = m ? String(+m[3]) : '';
      paint();
    }
    sy.addEventListener('change', function () { fixDays(); toValue(); });
    sm.addEventListener('change', function () { fixDays(); toValue(); });
    sd.addEventListener('change', toValue);
    if (desc && desc.set) {
      try {
        Object.defineProperty(hid, 'value', {
          configurable: true,
          get: function () { return rawGet(); },
          set: function (v) { rawSet(v); fromValue(); fire(hid, 'change'); }
        });
      } catch (e1) {}
    }
    /* 틀렸을 때 '그 칸으로 데려가기'가 숨은 칸 대신 비어 있는 목록으로 가게 */
    hid.__birthWrap = wrap;
    hid.focus = function () {
      var t = !sy.value ? sy : (!sm.value ? sm : (!sd.value ? sd : sy));
      try { t.focus(); } catch (e2) {}
    };
    hid.scrollIntoView = function (o) {
      try { wrap.scrollIntoView(o); } catch (e3) { try { wrap.scrollIntoView(true); } catch (e4) {} }
    };
    fromValue();
  }

  /* 화면에 있는 입력 도우미를 한 번에 붙인다 (가입 96 · 로그인 97 · 기본 정보 03 · 비밀번호 재설정 81) */
  $$('.birth-sel').forEach(function (w) {
    var f = w.parentNode;
    bindBirthSelect(w, f ? f.querySelector('input[aria-label="생년월일"]') : null);
  });
  $$('.field--suggest input[type="email"]').forEach(function (inp) {
    bindEmailSuggest(inp, $('input[type="password"]'));
  });

  /* 틀린 칸으로 데려가서 보여준다 (토스트만으로는 어느 칸인지 모른다) */
  function markBad(inp, msg) {
    toast(msg);
    if (!inp) return;
    try { inp.focus(); inp.scrollIntoView({ block: 'center' }); } catch (e) {}
    var mark = inp.__birthWrap || inp;
    mark.classList.add('is-bad');
    setTimeout(function () { mark.classList.remove('is-bad'); }, 2500);
  }

  /* ── 96 이메일로 가입하기 (계정만 만들고 → 02 동의로) ──
     이메일·비밀번호만 받는다. 이름·생년월일은 동의 뒤 03 기본 정보에서 간편 로그인과 똑같이 받는다. */
  function pageSignup() {
    bindPwEye();
    if (sb) sb.auth.getSession().then(function (rs) { if (rs.data.session) goAfterLogin(rs.data.session.user); }, function () {});

    var email = $('input[aria-label="이메일"]');
    var pw    = $('input[aria-label="비밀번호"]');
    var pw2   = $('input[aria-label="비밀번호 확인"]');
    var cta = $('#signupNext');
    if (!cta || !email || !pw || !pw2) return;
    [email, pw, pw2].forEach(function (i) { i.value = ''; });
    /* 화면 안내대로 이용약관·처리방침(25)을 읽고 돌아오시면 적어 두신 이메일만 되살린다.
       · 25 로 가는 링크를 누르는 순간에만 sessionStorage 에 잠깐 두고, 돌아오면 바로 지운다
         (96·25 밖의 화면에 가도 app.js 첫머리에서 지운다).
       · 비밀번호는 기기에 남기지 않는다 — 다시 적어 주셔야 한다. */
    var restored = '';
    try { restored = sessionStorage.getItem(SIGNUP_EMAIL) || ''; sessionStorage.removeItem(SIGNUP_EMAIL); } catch (eR) { restored = ''; }
    if (restored) email.value = restored;
    $$('a[href*="25-terms"]').forEach(function (a) {
      a.addEventListener('click', function () {
        try {
          var keep = (email.value || '').trim();
          if (keep) sessionStorage.setItem(SIGNUP_EMAIL, keep); else sessionStorage.removeItem(SIGNUP_EMAIL);
        } catch (eS) {}
      });
    });
    if (restored) toast('적어 두신 이메일은 그대로예요.\n비밀번호만 다시 적어 주세요.');
    var hintPw = $('#hintPw'), hintPw2 = $('#hintPw2');

    function emailOk(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
    function setHint(el, cls, text) {
      if (!el) return;
      el.hidden = !text;
      el.className = 'field-hint' + (cls ? ' ' + cls : '');
      el.textContent = text || '';
    }

    /* 규칙은 칸 안 안내 글자('8자 이상')로 먼저 보이고, 칸 아래 한 줄은 입력을 시작한 뒤에만 나온다 */
    function live() {
      var p = pw.value || '', p2 = pw2.value || '';
      if (!p) setHint(hintPw, '', '');
      else if (p.length >= 8) setHint(hintPw, 'ok', '✓ 쓸 수 있는 비밀번호예요');
      else setHint(hintPw, '', '지금 ' + p.length + '자예요 · 8자 이상으로 정해 주세요');
      if (!p2) setHint(hintPw2, '', '');
      else if (p2 === p) setHint(hintPw2, 'ok', '✓ 비밀번호가 같아요');
      else if (p2.length >= p.length) setHint(hintPw2, 'bad', '비밀번호가 서로 달라요');
      else setHint(hintPw2, '', '');
      var ready = emailOk((email.value || '').trim()) && p.length >= 8 && p === p2;
      if (!cta.__busy) cta.setAttribute('aria-disabled', ready ? 'false' : 'true');
    }
    [email, pw, pw2].forEach(function (i) { i.addEventListener('input', live); });
    live();

    cta.addEventListener('click', function (e) {
      e.preventDefault();
      if (!sb) return toast('연결이 준비되지 않았어요. 인터넷을 연결한 뒤 다시 열어 주세요.');
      if (cta.__busy) return;
      var em = (email.value || '').trim();
      var p  = pw.value || '';
      var p2 = pw2.value || '';
      if (!emailOk(em)) return markBad(email, '이메일 주소를 확인해 주세요.');
      if (p.length < 8) return markBad(pw, '비밀번호는 8자 이상으로 정해 주세요.');
      if (p !== p2) return markBad(pw2, '비밀번호가 서로 달라요. 다시 확인해 주세요.');

      busy(cta, true, '계정을 만드는 중…');
      noteLoginTry('email');
      sb.auth.signUp({ email: em, password: p })
        .then(function (r) {
          if (r.error) throw r.error;
          if (!r.data.session) {
            busy(cta, false);
            toast('확인 메일을 보냈어요.\n메일함에서 확인을 마친 뒤 로그인해 주세요.');
            return;
          }
          location.href = '02-consent.html';
        })
        .catch(function (err) {
          var m = String((err && err.message) || '');
          if (/already registered|already exists|user.*exists/i.test(m)) {
            /* 앞서 가입하다 끊긴 계정 — 같은 비번으로 로그인해 빠진 단계부터 이어간다 */
            sb.auth.signInWithPassword({ email: em, password: p }).then(function (r2) {
              if (r2.error) {
                busy(cta, false);
                toast('이미 가입된 이메일이에요.\n로그인 화면에서 들어오시고, 비밀번호가 기억나지 않으면 ‘비밀번호 찾기’를 눌러 주세요.');
                return;
              }
              /* 다음 화면 확인이 끝내 실패하면 버튼을 되살린다 (다시 누르면 같은 길로 이어진다) */
              goAfterLogin(r2.data.user, function () { busy(cta, false); });
            }, function () { busy(cta, false); toast(koError(err)); });
            return;
          }
          busy(cta, false);
          toast(koError(err));
        });
    });
  }

  /* ── 97 이메일로 로그인 ── */
  function pageLogin() {
    var email = $('input[aria-label="이메일"]');
    var pw    = $('input[aria-label="비밀번호"]');
    if (email) email.value = '';
    if (pw) pw.value = '';
    var btn = $('#loginBtn') || btnByText('이메일로 로그인');
    if (!btn || !email || !pw) return;
    var errLine = $('#loginError');
    bindPwEye();

    function showErr(msg) {
      if (!errLine) return;
      errLine.textContent = msg || '';
      errLine.hidden = !msg;
    }
    function live() {
      showErr('');                       /* 다시 고치기 시작하면 지난 실패 안내는 거둔다 */
      if (btn.__busy) return;
      btn.setAttribute('aria-disabled', ((email.value || '').trim() && pw.value) ? 'false' : 'true');
    }
    function submit() {
      if (!sb) return toast('연결이 준비되지 않았어요. 인터넷을 연결한 뒤 다시 열어 주세요.');
      if (btn.__busy) return;            /* Enter 연타로 인한 중복 요청 방지 */
      var em = (email.value || '').trim();
      var p  = pw.value || '';
      if (!em) return markBad(email, '이메일을 입력해 주세요.');
      if (!p) return markBad(pw, '비밀번호를 입력해 주세요.');
      busy(btn, true, '로그인 중…');
      noteLoginTry('email');
      sb.auth.signInWithPassword({ email: em, password: p })
        .then(function (r) {
          if (r.error) throw r.error;
          /* 로그인은 됐는데 다음 화면 확인이 끝내 실패하면 '로그인 중…'에 멈추지 않게 버튼을 되살린다 */
          goAfterLogin(r.data.user, function () { busy(btn, false); live(); });
        })
        .catch(function (err) {
          busy(btn, false);
          btn.setAttribute('aria-disabled', 'false');
          /* 토스트는 사라지므로, 무엇이 틀렸는지 칸 아래에 남겨 둔다 */
          var msg = koError(err);
          var firstTime = /invalid login credentials/i.test(String((err && err.message) || ''));
          showErr(msg + (firstTime ? '\n처음이시면 아래 ‘처음이면 이메일로 가입하기’를 눌러 주세요.' : ''));
          toast(msg);
          var join = $('a[href*="96-email-signup"]');
          if (firstTime && join) {
            join.classList.add('is-hint');
            setTimeout(function () { join.classList.remove('is-hint'); }, 2800);
          }
        });
    }
    btn.addEventListener('click', function (e) { e.preventDefault(); submit(); });
    [email, pw].forEach(function (i) {
      i.addEventListener('input', live);
      i.addEventListener('keydown', function (e) { if (e.key === 'Enter') submit(); });
    });
    live();
  }

  /* ── 로그인한 계정 표시 (82 계정 관리) ──
     로그인 방법과 계정 이메일을 보여 준다. 네이버·구글에서 받은 이메일은 개인정보 요청 때 본인 확인에 쓴다.
     카카오처럼 이메일을 주지 않는 곳은 서버 함수가 'kakao-번호@login.todak.app' 같은 자리 이메일로 계정을 만든다 —
     실제로 없는 주소라 그대로 보여 주지 않는다. */
  var PROVIDER_KO = { kakao: '카카오', naver: '네이버', google: '구글', email: '이메일' };
  function isStandInEmail(em) { return /@login\.todak\.app$/i.test(String(em || '')); }
  function fillAccount() {
    var boxes = $$('[data-account]');
    if (!boxes.length || !sb) return;
    /* 시안의 예시 값이 잠깐이라도 보이지 않게 먼저 비운다 */
    boxes.forEach(function (b) {
      var h = $('[data-ac-how]', b), m = $('[data-ac-mail]', b);
      if (h) h.textContent = '계정을 확인하는 중이에요…';
      if (m) m.textContent = '';
    });
    sb.auth.getSession().then(function (rs) {
      var u = rs && rs.data && rs.data.session && rs.data.session.user;
      if (!u) return;
      sb.from('profiles').select('login_provider,email').eq('id', u.id).maybeSingle().then(function (r) {
        var p = (r && r.data) || {};
        var md = u.user_metadata || {}, am = u.app_metadata || {};
        var prov = p.login_provider || md.oauth_provider || am.provider || 'email';
        var em = u.email || p.email || '';
        var noMail = !em || isStandInEmail(em);
        var how = (PROVIDER_KO[prov] || '이메일') + '로 로그인했어요';
        boxes.forEach(function (b) {
          var h = $('[data-ac-how]', b), m = $('[data-ac-mail]', b);
          if (h) h.textContent = how;
          if (m) {
            m.textContent = noMail ? '이메일 주소는 받지 않았어요' : em;
            m.classList[noMail ? 'add' : 'remove']('is-none');
          }
          $$('[data-ac-if]', b).forEach(function (n) {
            n.hidden = (n.getAttribute('data-ac-if') === 'mail') ? noMail : !noMail;
          });
        });
      }, function () {});
    }, function () {});
  }
  fillAccount();

  /* ══ 공용 로그아웃 — TD.logout(done) ══
     82 '로그아웃' · 02 동의 화면 뒤로가기 · 가입 도중 03 '로그아웃하고 처음으로'·‹(features.js) 가 모두 이것을 쓴다.
     기기를 함께 쓰는 경우를 대비해, 이 계정이 기기에 남긴 값과 예약 알림을 지운 뒤 로그아웃한다.
     · localStorage — 'todak_' 로 시작하는 값(진료 질문·검색 지역·마지막 접속 등)을 지운다.
       기기 설정인 todak_push_banner_off(알림 안내 띠 닫음)만 남긴다.
     · sessionStorage — 모두 비우되 todak_launch_done 은 남긴다. 앱을 연 딥링크(todak://auth·reset)는
       프로세스가 살아 있는 동안 계속 같은 값이 돌아와서, 이 표시를 지우면 native.js 가 옛 토큰으로
       setSession 을 다시 불러 방금 로그아웃한 계정으로 되돌아가거나 오류 안내가 뜬다.
     · 예약 알림 — TDN.cancelAll: 앱은 휴대폰 안 예약을 모두 취소하고, 웹은 푸시 구독 해제와 서버 행 삭제까지 한다.
       서버 행을 지우려면 아직 로그인돼 있어야 하므로 signOut 보다 먼저 한다.
       (응답이 끝내 오지 않아도 4초 뒤에는 로그아웃으로 넘어간다)
     · signOut — 실패해도 이 기기의 세션은 지워진다(supabase-js). done 은 성공·실패 모두 한 번 부른다.
     · done 을 넘기지 않으면(TD.logout()) 끝난 뒤 처음 화면(01)으로 간다 — 로그아웃된 채 로그인 화면에 남지 않게. */
  /* 로그아웃해도 남기는 값 — 기기 설정(알림 안내 띠)과, 다시 로그인하실 때 보여 드릴
     '마지막 로그인 방법'(kakao·naver·google·email 중 한 낱말. 계정·이메일은 저장하지 않는다) */
  var LOGOUT_KEEP_LOCAL = { 'todak_push_banner_off': 1, 'todak_last_login': 1 };
  var logoutBusy = false;
  function logout(done) {
    if (logoutBusy) return;                   /* 두 번 눌러도 한 번만 */
    logoutBusy = true;
    if (typeof done !== 'function') done = function () { location.replace('01-splash.html'); };
    var finished = false;
    var fin = function () { if (finished) return; finished = true; if (done) done(); };
    try {
      var ks = [];
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf('todak_') === 0 && !LOGOUT_KEEP_LOCAL[k]) ks.push(k);
      }
      ks.forEach(function (k2) { localStorage.removeItem(k2); });
      /* 사진으로 읽어 둔 약(등록 전 임시 저장) — 위 'todak_' 쓸기에 들어가지만, 기기를 함께 쓰는 경우라
         빠뜨리면 남의 약 이름이 남는 값이라 이름으로도 한 번 더 지운다 */
      localStorage.removeItem('todak_ocr_meds'); localStorage.removeItem('todak_ocr_meds_at');
    } catch (e1) {}
    try {
      var launch = sessionStorage.getItem('todak_launch_done');
      sessionStorage.clear();
      if (launch) sessionStorage.setItem('todak_launch_done', launch);
    } catch (e2) {}
    var went = false;
    var out = function () {
      if (went) return;
      went = true;
      if (!sb) return fin();
      try { sb.auth.signOut().then(fin, fin); } catch (e3) { fin(); }
    };
    setTimeout(out, 4000);
    if (window.TDN && window.TDN.cancelAll) {
      try { window.TDN.cancelAll(out); } catch (e4) { out(); }
    } else out();
  }

  /* 가입 도중(기본 정보를 넣기 전) 이 계정에서 나가 처음 화면으로 — 묻고 나서 공용 로그아웃.
     가족 계정으로 잘못 들어왔거나, 만 19세 미만으로 기본 정보에서 막힌 경우에도 나갈 길이 있게 한다. */
  function leaveSignup() {
    if (!window.confirm('처음 화면으로 돌아갈까요?\n지금 계정에서 로그아웃돼요.\n\n적고 계시던 기본 정보는 저장되지 않아요. 같은 계정으로 다시 들어오시면 기본 정보부터 이어서 하실 수 있어요.')) return;
    logout(function () { location.replace('01-splash.html'); });
  }

  /* ── 03 기본 정보(가입 도중): '로그아웃하고 처음으로' ──
     설정에서 고치러 온 경우(todak_edit — features.js page03 가 정한다)에는 감춘 채로 둔다.
     features.js 는 이 파일보다 뒤에 실리므로, 모든 스크립트가 끝난 뒤(DOMContentLoaded) 판단한다.
     누르면 03 의 ‹ 가 띄우는 것과 같은 확인 창을 쓴다 — 한 화면에 모양이 다른 확인 창이 섞이지 않게.
       ‹ 에 '떠보기' 클릭(이동하지 않는 가짜 클릭, BACK_PROBE)을 보내, 화면 코드가 받아서 막으면(확인 창을 띄움) 그것으로 끝.
       받는 코드가 없으면 아래 leaveSignup(기본 확인 창)으로 묻는다. */
  var BACK_PROBE = '__tdProbe';
  function page03Switch() {
    var box = $('#signupSwitch'), btn = $('#signupSwitchBtn');
    if (!box || !btn) return;
    function editing() {
      try { return !!sessionStorage.getItem('todak_edit'); } catch (e) { return false; }
    }
    var apply = function () { box.hidden = editing(); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply);
    else apply();
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      if (editing()) return;
      var back = $('.appbar .back');
      if (back) {
        var probe = document.createEvent('Event');       /* MouseEvent 가 아니라 링크 이동(기본 동작)이 일어나지 않는다 */
        probe.initEvent('click', true, true);
        probe[BACK_PROBE] = 1;
        back.dispatchEvent(probe);
        if (probe.defaultPrevented) return;              /* 화면 코드가 확인 창을 띄웠다 */
      }
      leaveSignup();
    });
  }

  /* ── 13 내 정보: '환자 확인 서류' 줄 — 지금 상태를 보여 주고 99 로 보낸다 (2026-09-28) ──
     이 단계가 생기기 전에 가입을 마치신 분은 02·99 를 다시 지나지 않으므로 여기서 올리신다(막지 않는다).
     · 상태 낱말은 99 화면과 같게: 올리지 않음 · 확인 중 · 확인 완료 · 다시 올려 주세요
     · 서류 표가 아직 없으면(SQL 실행 전) 줄째 감춘다 — 눌러도 올릴 곳이 없다.
     · 시안 예시값('확인 완료')은 data-demo 로 가려 두었다가 실제 상태를 칠한 뒤에만 드러낸다. */
  var VERIFY_KO = { none: '올리지 않음', pending: '확인 중', approved: '확인 완료', rejected: '다시 올려 주세요' };
  function page13Verify() {
    var row = $('[data-verify-row]');
    if (!row || !sb) return;
    var st = $('[data-verify-state]', row);
    function paint(s) {
      if (!st) return;
      st.textContent = VERIFY_KO[s] || '상태를 불러오지 못했어요';
      st.style.color = s === 'rejected' ? 'var(--danger)' : (s === 'approved' ? 'var(--safe)' : '');
      st.style.fontWeight = (s === 'rejected' || s === 'none') ? '700' : '';
      st.removeAttribute('data-demo');
    }
    withSession(function (ses, err) {
      if (!ses) { if (err) paint('error'); return; }      /* 로그아웃이면 guard 가 01 로 보낸다 */
      verifyState(ses.user.id, function (s) {
        if (s === 'missing') { row.style.display = 'none'; return; }
        paint(s);
      });
    });
  }

  /* ── 82 계정 관리: 로그아웃 ── */
  function pageAccountExit() {
    var item = $$('a.listitem').filter(function (a) { return a.textContent.indexOf('로그아웃') !== -1; })[0];
    if (!item || !sb) return;
    item.addEventListener('click', function (e) {
      e.preventDefault();
      logout(function () { location.replace('01-splash.html'); });
    });
  }

  /* 주소에 '?from=<화면파일.html>' 이 붙어 오면(예: AI 상담 카드가 붙이는 ?from=07-chat.html)
     앱바 ‹ (와 휴대폰 뒤로가기)는 그 화면으로 돌아간다. 화면마다 정해 둔 상위 화면보다 앞선다.
     · 02(열람의 돌아갈 곳 기억)·25(가입 중 동의 목록 처리)는 화면 코드가 따로 처리하므로 여기서 건드리지 않는다.
     · 바깥 주소로 튀지 않게 같은 폴더의 화면 파일명(영문·숫자·._-, .html)만 받는다.
     · 자동 저장 뒤 이동하는 화면(84·73 등)은 ‹ 의 href 를 읽어 가므로, 스크립트가 다 돈 뒤 href 도 바꿔 둔다. */
  var FROM_BACK = (function () {
    if (PAGE === '02-consent.html' || PAGE === '25-terms.html') return '';
    var m = /[?&]from=([^&#]*)/.exec(location.search || ''), v = '';
    try { v = m ? decodeURIComponent(m[1]) : ''; } catch (e) { v = ''; }
    return (/^[0-9A-Za-z._-]+\.html$/.test(v) && v !== PAGE) ? v : '';
  })();
  function inAppbar(el) {
    for (var p = el.parentNode; p && p !== document; p = p.parentNode) {
      if (p.className && (' ' + p.className + ' ').indexOf(' appbar ') > -1) return true;
    }
    return false;
  }
  if (FROM_BACK) {
    var setFromBack = function () {
      $$('.appbar a.back').forEach(function (b) { b.setAttribute('href', FROM_BACK); });
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setFromBack);
    else setFromBack();
  }

  /* 뒤로가기(앱바 화살표 ‹)는 방문 스택을 쌓지 않고 정해진 상위 화면으로 이동한다.
     화면을 이리저리 눌러도 뒤로가기 한 번이면 논리적 상위로 바로 간다. */
  document.addEventListener('click', function (e) {
    if (e.defaultPrevented) return;          /* 84·73처럼 화면이 자동 저장 뒤 이동시키는 경우 */
    if (e[BACK_PROBE]) return;               /* 03 '로그아웃하고 처음으로'의 떠보기 클릭 — 이동하지 않는다 */
    var a = null, t = e.target;
    while (t && t !== document) {
      if (t.tagName === 'A' && t.className && (' ' + t.className + ' ').indexOf(' back ') > -1) { a = t; break; }
      t = t.parentNode;
    }
    if (!a) return;
    var h = (FROM_BACK && inAppbar(a)) ? FROM_BACK : (a.getAttribute('href') || '');
    if (!h || h.charAt(0) === '#' || h.indexOf('javascript:') === 0) return;
    e.preventDefault();
    location.replace(h);
  }, false);

  /* ── 분기 ── */
  guard();
  if (PAGE === 'index.html' || PAGE === '01-splash.html') pageSplash();
  else if (PAGE === '02-consent.html') pageConsent();
  else if (PAGE === '96-email-signup.html') pageSignup();
  else if (PAGE === '97-email-login.html') pageLogin();
  else if (PAGE === '82-account-exit.html') pageAccountExit();
  else if (PAGE === '03-profile-type.html') page03Switch();
  else if (PAGE === '13-settings.html') page13Verify();

  /* features.js(로그인 후 화면 배선)가 같은 도구를 쓴다 · verify.js(99 환자 확인 서류)는 verifyState 를 쓴다 */
  window.TD = { sb: sb, PAGE: PAGE, normHref: normHref, $: $, $$: $$, toast: toast, busy: busy, koError: koError, btnByText: btnByText, goAfterLogin: goAfterLogin, noteLoginTry: noteLoginTry, esc: esc, DOC_VERSION: DOC_VERSION, dirty: 0,
                logout: logout, consentValid: consentValid,
                withSession: withSession, sessOffline: sessOffline,
                verifyState: verifyState, VERIFY_KO: VERIFY_KO };
})();
