/* ═══ 토닥 99 환자 확인 서류 — 진단서·소견서·진료확인서 사진 올리기 (2026-09-28) ═══
   토닥은 유방암 치료를 받고 계신 분만 쓰는 앱이다. 가입 도중 02 약관 동의 다음에 이 화면에서
   서류 사진 한 장을 받고, 토닥 담당자가 수파베이스 대시보드에서 나중에 확인한다.
   · 글자를 읽지 않는다(OCR 없음) — 사진은 사람이 본다. 앱은 '올렸다'만 안다.
   · 주민등록번호(고유식별정보)는 받지 않는다 — 찍기 전에 뒷자리를 가리시라고 크게 알리고, 미리보기에서 한 번 더 확인하시게 한다.
   · 사진은 휴대폰에서 긴 변 1600px · JPEG 0.85 로 다시 그려 올린다. 다시 그리면 사진 속 촬영 위치(GPS)·기기 정보(EXIF)도
     함께 빠진다 — 원본 파일을 그대로 올리는 길은 두지 않는다(그릴 수 없는 사진이면 다시 찍어 달라고 한다).
   · 올리는 곳: 비공개 보관함 verify-docs/<uid>/<올린 시각 ms>.jpg → 그다음 patient_verifications 에 한 행.
     표·보관함·규칙은 supabase/sql/2026-09-28_patient_verify.sql 이 만든다.
   · 받는 그 자리에서 따로 동의(필수 체크)를 받는다. 동의문 버전(CONSENT_VER)을 행에 함께 남긴다.
   · 이 파일은 화면 HTML 에 직접 실려(<script src="js/verify.js">) 빌드가 붙이는 app.js 보다 먼저 읽힌다.
     그래서 TD(app.js)가 필요한 일은 모든 스크립트가 끝난 뒤(DOMContentLoaded) 시작한다.
   두 가지 쓰임
     가입 도중(주소에 from 없음) — 올리면 app.js goAfterLogin 이 다음 단계(03 기본 정보)로 보낸다.
                                  이미 올리신 분이 들어오면(확인 중·완료) 이 화면을 건너뛴다.
     내 정보에서(?from=13-settings.html) — 지금 상태를 보여 드리고, 필요하면 올리거나 다시 올리신다. 올리면 여기 머문다. */
(function () {
  'use strict';
  var isThis = /(^|\/)99-patient-verify(\.html)?$/.test(location.pathname || '');
  if (!isThis) return;

  /* 상태를 불러오기 전에는 올리기 칸을 감춰 둔다(깜빡임 방지) — 불러오면 start() 가 푼다 */
  var screenEl = document.querySelector('.screen');
  if (screenEl) screenEl.classList.add('pv-wait');

  var BUCKET = 'verify-docs';
  var CONSENT_VER = 'pv1 2026-09-28';      /* 99 화면 '사진 수집·이용' 안내문 버전 — 안내문을 바꾸면 올린다 */
  var MAX_SIDE = 1600, JPEG_Q = 0.85;
  var UP_TIMEOUT = 60000, DB_TIMEOUT = 20000;

  function start() {
    var T = window.TD || {};
    var sb = T.sb, $ = T.$, toast = T.toast || function (m) { try { window.alert(m); } catch (e) {} };
    var busy = T.busy || function () {};
    var wait = function (on) { if (screenEl) screenEl.classList[on ? 'add' : 'remove']('pv-wait'); };
    if (!$ || !sb) {
      wait(false);
      var e0 = document.getElementById('pvErr');
      if (e0) { e0.textContent = '연결이 준비되지 않았어요.\n인터넷을 연결한 뒤 앱을 다시 열어 주세요.'; e0.hidden = false; }
      return;
    }

    /* 돌아갈 화면 — 바깥 주소로 튀지 않게 화면 파일명만 받는다 (app.js FROM_BACK 과 같은 규칙) */
    var FROM = (function () {
      var m = /[?&]from=([^&#]*)/.exec(location.search || ''), v = '';
      try { v = m ? decodeURIComponent(m[1]) : ''; } catch (e) { v = ''; }
      return (/^[0-9A-Za-z._-]+\.html$/.test(v) && v !== '99-patient-verify.html') ? v : '';
    })();
    var EDIT = !!FROM;                     /* 내 정보 등에서 온 경우 — 가입 단계가 아니다 */

    var elSteps = $('#pvSteps'), elTitle = $('#pvTitle'), elSub = $('#pvSub'), elLoading = $('#pvLoading');
    var elState = $('#pvState'), elStIc = $('#pvStIc'), elStT = $('#pvStT'), elStB = $('#pvStB'),
        elStNote = $('#pvStNote'), elStMore = $('#pvStMore');
    var elForm = $('#pvForm'), btnCam = $('#pvCam'), btnAlb = $('#pvAlb'), elPickNote = $('#pvPickNote');
    var elPrev = $('#pvPrev'), elImg = $('#pvImg'), elSmall = $('#pvSmall'), btnRedo = $('#pvRedo'), elPick = $('#pvPick');
    var elAgree = $('#pvAgree'), elAgreeRow = $('#pvAgreeRow'), elView = $('#pvView'), elTerms = $('#pvTerms'), elLater = $('#pvLater');
    var cta = $('#pvSend'), elErr = $('#pvErr'), elHint = $('#pvHint'), btnSkip = $('#pvSkip'), elContent = $('.content');
    if (!cta || !elForm || !elAgree) { wait(false); return; }

    var photo = null;          /* 줄여 둔 사진 { blob, w, h } — 기기 저장소에는 남기지 않고 이 화면 메모리에만 */
    var prevUrl = '';          /* 미리보기 주소(blob:) — 바꾸거나 떠날 때 거둔다 */
    var upPath = '';           /* 이 사진을 올릴 자리 — 다시 올리기에도 같은 자리를 써서 두 번 올라가지 않게 */
    var upDone = false;        /* 보관함에는 올라갔다(표에 적기만 남았다) */
    var sent = false;          /* 표에도 적었다 — 다음 단계로 넘어가는 확인만 남았다 */
    var sending = false;       /* 두 번 눌러도 한 번만 */
    var working = false;       /* 사진을 줄이는 중 */
    var user = null;
    var state = '';            /* verifyState 결과 */

    if (EDIT) {
      if (elSteps) elSteps.hidden = true;
      if (elLater) elLater.hidden = true;
      if (elTitle) elTitle.textContent = '환자 확인 서류';
      if (elSub) elSub.innerHTML = '토닥은 유방암 치료를 받고 계신 분만 쓰시는 앱이에요. 올려 주신 서류는 <b>토닥 담당자</b>가 확인해요.';
      cta.textContent = '사진 올리기';
      /* 받는 자리 동의의 '거부 시 불이익'도 이 쓰임에 맞게 바꾼다. 내 정보에서 오신 분은 가입을 이미 마치셨고
         올리지 않으셔도 앱을 그대로 쓰시므로 '가입을 이어서 하실 수 없어요'는 사실이 아니다 (2026-09-28 검토) */
      var elRefuse = elTerms ? elTerms.querySelector('.doc-refuse') : null;
      if (elRefuse) elRefuse.innerHTML = '동의하지 않으실 수 있어요. 다만 동의하지 않으시면 <b>서류 사진을 올리실 수 없어요.</b> 그 밖에 불이익은 없어요.';
    }

    /* ── 동의 체크 (app.js 02 와 같은 모양) ── */
    function isOn() { return elAgree.getAttribute('aria-checked') === 'true'; }
    function setOn(on) {
      elAgree.setAttribute('aria-checked', on ? 'true' : 'false');
      var box = elAgree.querySelector('.s-box');
      if (!box) return;
      box.textContent = on ? '✓' : '';
      box.style.background = on ? 'var(--primary)' : '';
      box.style.borderColor = on ? 'var(--primary)' : '';
      box.style.color = on ? '#fff' : '';
    }
    function agreeHandler(e) {
      if (e.type === 'keydown' && e.key !== ' ' && e.key !== 'Enter') return;
      e.preventDefault();
      setOn(!isOn());
      refresh();
    }
    elAgree.addEventListener('click', agreeHandler);
    elAgree.addEventListener('keydown', agreeHandler);
    if (elView && elTerms) elView.addEventListener('click', function (e) {
      e.preventDefault();
      var open = elTerms.hidden;
      elTerms.hidden = !open;
      elView.textContent = open ? '접기' : '보기';
      elView.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    /* ── 하단 띠 높이 맞추기 (2026-09-28 검토) ──
       본문 끝 여백을 190px(실패 때 280px)로 박아 두었더니, 휴대폰 글자 크기를 키우신 분은 하단 띠(안내 줄·버튼 두 개)가
       그보다 길어져 동의 줄·'지금 서류가 없으시면…' 줄이 띠 밑에 깔려 읽거나 누를 수 없었다(412px·130% 에서도 재현).
       · 띠 높이를 재서 본문 끝 여백을 그만큼 띄운다 — 띠 안이 바뀔 때(안내 줄·건너뛰기 단추·버튼 글자)와 화면 크기가 바뀔 때.
       · 띠가 화면 높이의 45% 를 넘으면(글자 200% 등) 띠를 본문 맨 끝으로 옮겨 함께 내려 보게 한다(.pv-foot-inline).
         바닥에 고정한 채로는 본문이 두세 줄 창으로만 보여 읽을 수가 없다. 30% 밑으로 줄면 다시 바닥에 고정한다. */
    var elFoot = $('#pvFooter'), footHome = elFoot ? elFoot.parentNode : null, footNext = elFoot ? elFoot.nextSibling : null;
    var footInline = false;
    function fitFoot() {
      if (!elFoot || !elContent || !footHome) return;
      var H = window.innerHeight || document.documentElement.clientHeight || 0;
      var h = elFoot.offsetHeight || 0;
      if (!footInline && H && h > H * 0.45) {
        footInline = true;
        elFoot.classList.add('pv-foot-inline');
        elContent.appendChild(elFoot);
      } else if (footInline && H && h < H * 0.3) {
        footInline = false;
        elFoot.classList.remove('pv-foot-inline');
        footHome.insertBefore(elFoot, (footNext && footNext.parentNode === footHome) ? footNext : null);
      }
      elContent.style.paddingBottom = footInline ? '24px' : (Math.max(190, (elFoot.offsetHeight || 0) + 24) + 'px');
    }
    var fitT = 0;
    function fitSoon() { clearTimeout(fitT); fitT = setTimeout(fitFoot, 30); }
    window.addEventListener('resize', fitSoon);
    /* 버튼 글자('사진을 올리는 중…')·안내 줄이 바뀌어 띠 높이가 변하는 것도 따라간다. 콜백 안에서 바로 옮기면
       'ResizeObserver loop' 경고가 나므로 한 박자 뒤에 잰다. 없는 기기(아주 오래된 WebView)는 아래 호출들로만 맞춘다 */
    try { if (window.ResizeObserver && elFoot) new window.ResizeObserver(fitSoon).observe(elFoot); } catch (eR) {}

    function showErr(msg) {
      if (!elErr) return;
      elErr.textContent = msg || '';
      elErr.hidden = !msg;
      fitFoot();
    }
    /* 하단 버튼은 사진과 동의가 다 있을 때만 '눌러져요' 모양 — 눌러도 막지는 않고 무엇이 빠졌는지 알려 준다(02 와 같다).
       올리기 칸이 닫혀 있으면(확인 완료 등) ctaBack 이 '돌아가기'로 바꿔 둔 것을 건드리지 않는다. */
    function refresh() {
      if (sent || elForm.hidden) return;
      var ok = !!photo && isOn();
      if (!cta.__busy) cta.setAttribute('aria-disabled', ok ? 'false' : 'true');
      if (elHint) elHint.hidden = ok;
      fitFoot();
    }

    /* ── 사진 고르기 ── native.js 53 과 같은 방식: 숨은 <input type=file> 을 눌러 준다.
       · 안드로이드 앱(Capacitor): WebView 파일 선택 — capture 가 있으면 카메라, 없으면 사진 고르기 화면.
       · 아이폰 사파리: capture 가 있으면 카메라, 없으면 '사진 보관함 · 사진 찍기 · 파일' 목록. HEIC 도 사파리가 열어 준다.
       · 안드로이드 앨범의 HEIC('고효율 사진')는 WebView 가 그리지 못한다 — 그때는 '사진 찍기로 다시'를 안내한다(shrink 실패). */
    function mkInput(capture) {
      var inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/*';
      if (capture) inp.setAttribute('capture', 'environment');
      inp.style.display = 'none';
      inp.setAttribute('aria-hidden', 'true');
      document.body.appendChild(inp);
      inp.addEventListener('change', function () {
        var f = inp.files && inp.files[0];
        if (f) takeFile(f, capture);        /* takeFile 이 파일을 곧바로 읽기 시작한 뒤에 칸을 비운다 (native.js 53 과 같은 순서) */
        inp.value = '';                     /* 같은 사진을 다시 골라도 change 가 오게 */
      });
      return inp;
    }
    var inCam = mkInput(true), inAlb = mkInput(false);
    function pick(inp) {
      return function (e) {
        e.preventDefault();
        if (working || sending) return;
        try { inp.click(); } catch (e1) { toast('사진을 고를 수 없어요.\n앱을 다시 열어 주세요.'); }
      };
    }
    if (btnCam) btnCam.addEventListener('click', pick(inCam));
    if (btnAlb) btnAlb.addEventListener('click', pick(inAlb));
    if (btnRedo) btnRedo.addEventListener('click', function (e) {
      e.preventDefault();
      if (sending) return;
      clearPhoto();
      try { if (elPick) elPick.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e1) {}
    });

    function clearPhoto() {
      photo = null; upPath = ''; upDone = false;
      if (prevUrl) { try { URL.revokeObjectURL(prevUrl); } catch (e) {} prevUrl = ''; }
      if (elImg) elImg.removeAttribute('src');
      if (elPrev) elPrev.hidden = true;
      if (elPick) elPick.hidden = false;
      if (elPickNote) elPickNote.hidden = false;
      showErr('');
      refresh();
    }
    window.addEventListener('pagehide', function () {
      if (prevUrl) { try { URL.revokeObjectURL(prevUrl); } catch (e) {} }
    });

    /* 안드로이드 앱의 카메라 찍기는 Capacitor 가 앱 전용 폴더(Android/data/…/files/Pictures/JPEG_날짜_시각_번호.jpg)에
       원본을 한 장 남긴다. 갤러리에는 안 보이지만 기기에 서류 원본이 남지 않게, 줄인 사진을 만든 뒤 지운다.
       이 이름 꼴이고 앱이 방금 찍은 경우에만 — 앨범에서 고르신 사진은 절대 건드리지 않는다. 실패해도 조용히 넘어간다. */
    function dropCameraTemp(file, fromCam) {
      try {
        var cap = window.Capacitor, P = (cap && cap.Plugins) || {};
        if (!fromCam || !(cap && cap.isNativePlatform && cap.isNativePlatform())) return;
        var nm = String((file && file.name) || '');
        if (!/^JPEG_\d{8}_\d{6}_\d+\.jpg$/.test(nm) || !P.Filesystem || !P.Filesystem.deleteFile) return;
        P.Filesystem.deleteFile({ path: 'Pictures/' + nm, directory: 'EXTERNAL' }).then(function () {}, function () {});
      } catch (e) {}
    }

    function toJpeg(cv, cb) {
      try {
        if (cv.toBlob) { cv.toBlob(function (b) { cb(b || null); }, 'image/jpeg', JPEG_Q); return; }
      } catch (e) {}
      try {
        var d = cv.toDataURL('image/jpeg', JPEG_Q), bin = atob(d.split(',')[1] || ''), arr = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        cb(arr.length ? new Blob([arr], { type: 'image/jpeg' }) : null);
      } catch (e2) { cb(null); }
    }
    /* 긴 변 MAX_SIDE 로 줄여 JPEG 로 다시 그린다 (사진 방향은 요즘 브라우저가 EXIF 대로 바로 세워 그린다) */
    function shrink(file, ok, bad) {
      var url = '';
      try { url = URL.createObjectURL(file); } catch (e) { bad(); return; }
      var img = new Image();
      img.onload = function () {
        var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
        if (!w || !h) { try { URL.revokeObjectURL(url); } catch (e1) {} bad(); return; }
        var k = Math.min(1, MAX_SIDE / Math.max(w, h));
        var cw = Math.max(1, Math.round(w * k)), ch = Math.max(1, Math.round(h * k));
        var cv = document.createElement('canvas');
        cv.width = cw; cv.height = ch;
        var cx = null;
        try { cx = cv.getContext('2d'); } catch (e2) { cx = null; }
        if (!cx) { try { URL.revokeObjectURL(url); } catch (e3) {} bad(); return; }
        cx.fillStyle = '#ffffff';            /* 투명 PNG 가 검게 나오지 않게 흰 바탕 */
        cx.fillRect(0, 0, cw, ch);
        try { cx.drawImage(img, 0, 0, cw, ch); } catch (e4) { try { URL.revokeObjectURL(url); } catch (e5) {} bad(); return; }
        try { URL.revokeObjectURL(url); } catch (e6) {}
        toJpeg(cv, function (b) {
          cv.width = 1; cv.height = 1;       /* 큰 그림판 메모리를 바로 돌려준다(오래된 폰) */
          if (!b || !b.size) return bad();
          ok(b, cw, ch, Math.max(w, h));
        });
      };
      img.onerror = function () { try { URL.revokeObjectURL(url); } catch (e7) {} bad(); };
      img.src = url;
    }

    function takeFile(file, fromCam) {
      if (file.type && !/^image\//i.test(file.type)) {
        toast('사진만 올릴 수 있어요.\n서류를 사진으로 찍어 주세요.');
        return;
      }
      working = true;
      if (elPickNote) elPickNote.textContent = '사진을 준비하는 중이에요…';
      [btnCam, btnAlb].forEach(function (b) { if (b) b.setAttribute('aria-disabled', 'true'); });
      var finish = function () {
        working = false;
        [btnCam, btnAlb].forEach(function (b) { if (b) b.removeAttribute('aria-disabled'); });
        if (elPickNote) elPickNote.textContent = '사진은 올리기 전에 휴대폰에서 알맞은 크기로 줄여요.';
      };
      shrink(file, function (blob, w, h, orig) {
        finish();
        dropCameraTemp(file, fromCam);
        clearPhoto();
        photo = { blob: blob, w: w, h: h };
        try { prevUrl = URL.createObjectURL(blob); } catch (e) { prevUrl = ''; }
        if (elImg && prevUrl) elImg.src = prevUrl;
        if (elSmall) elSmall.hidden = orig >= 900;
        if (elPrev) elPrev.hidden = false;
        if (elPick) elPick.hidden = true;
        if (elPickNote) elPickNote.hidden = true;
        refresh();
        try { elPrev.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (e1) {}
      }, function () {
        finish();
        dropCameraTemp(file, fromCam);
        toast(fromCam ? '사진을 열지 못했어요.\n한 번 더 찍어 주세요.'
                      : '이 사진은 열 수 없어요.\n📷 사진 찍기로 서류를 직접 찍어 주세요.');
      });
    }

    /* ── 상태 보여 주기 ── */
    function fmtDay(ts) {
      var d = new Date(ts);
      if (!ts || isNaN(d.getTime())) return '';
      return d.getFullYear() + '년 ' + (d.getMonth() + 1) + '월 ' + d.getDate() + '일';
    }
    function paintState(ic, title, bodyHtml, note, more) {
      if (!elState) return;
      elState.hidden = false;
      if (elStIc) elStIc.textContent = ic;
      if (elStT) elStT.textContent = title;
      if (elStB) elStB.innerHTML = bodyHtml;
      if (elStNote) {
        elStNote.hidden = !note;
        elStNote.textContent = note ? ('토닥 담당자: ' + note) : '';
      }
      if (elStMore) elStMore.hidden = !more;
    }
    function showForm(on) {
      elForm.hidden = !on;
      refresh();
    }
    function backToFrom() { location.replace(FROM || '13-settings.html'); }
    function ctaBack() {
      /* 올릴 것이 없는 상태(확인 완료 등) — 하단 버튼은 '돌아가기' */
      cta.textContent = '돌아가기';
      cta.setAttribute('aria-disabled', 'false');
      if (elHint) elHint.hidden = true;
      fitFoot();
    }
    var esc = T.esc || function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };

    function applyState(st, row) {
      state = st;
      wait(false);
      if (elLoading) elLoading.hidden = true;
      var when = row ? fmtDay(row.created_at) : '';
      var note = row && row.note ? String(row.note).slice(0, 300) : '';
      if (st === 'rejected') {
        paintState('📷', '서류를 다시 올려 주세요',
          '보내 주신 사진으로는 확인이 어려웠어요.' + (when ? '<br>지난번에 올리신 날: <b>' + esc(when) + '</b>' : ''),
          note, false);
        showForm(true);
        return;
      }
      if (!EDIT) {
        /* 가입 도중 — 이미 올리셨으면 이 화면을 건너뛴다. 표가 아직 없어도(기능 준비 전) 건너뛴다.
           goAfterLogin 도 같은 규칙이라('missing'·올린 행 있음 → 99 를 요구하지 않음) 서로 되튕기지 않는다. */
        if ((st === 'pending' || st === 'approved' || st === 'missing') && user && T.goAfterLogin) {
          wait(true);
          if (elLoading) { elLoading.textContent = '다음 단계로 가는 중이에요…'; elLoading.hidden = false; }
          T.goAfterLogin(user, function () {           /* 끝내 확인하지 못하면 여기 머물고 버튼으로 다시 */
            wait(false);
            if (elLoading) elLoading.hidden = true;
            sent = true;
            showForm(false);
            if (st !== 'missing') paintState('⏳', '서류는 이미 올리셨어요', '다음 단계로 넘어가는 데 시간이 걸리고 있어요. 아래 <b>‘다음으로’</b>를 눌러 주세요.', '', false);
            cta.textContent = '다음으로';
            cta.setAttribute('aria-disabled', 'false');
            if (elHint) elHint.hidden = true;
          });
          return;
        }
        showForm(true);                               /* none · error — 올리기 */
        return;
      }
      /* 내 정보에서 온 경우 */
      if (st === 'approved') {
        paintState('✅', '확인을 마쳤어요', '유방암 치료 중이신 것을 확인했어요. 더 올리실 것은 없어요.' + (row && row.reviewed_at ? '<br>확인한 날: <b>' + esc(fmtDay(row.reviewed_at)) + '</b>' : ''), note, false);
        showForm(false); ctaBack();
      } else if (st === 'pending') {
        paintState('⏳', '확인 중이에요', '올려 주신 서류를 토닥 담당자가 확인하고 있어요. 확인이 끝나면 ‘내 정보’에 <b>확인 완료</b>라고 보여요.' + (when ? '<br>올리신 날: <b>' + esc(when) + '</b>' : ''), '', true);
        showForm(false); ctaBack();
      } else if (st === 'missing') {
        paintState('ℹ️', '아직 준비 중이에요', '서류를 올리는 기능을 준비하고 있어요. 지금은 올리지 않으셔도 토닥을 그대로 쓰실 수 있어요.', '', false);
        showForm(false); ctaBack();
      } else if (st === 'error') {
        paintState('📶', '올린 기록을 불러오지 못했어요', '연결이 원활하지 않아요. 사진은 그대로 올리실 수 있어요.', '', false);
        showForm(true);
      } else {                                        /* none */
        if (elState) elState.hidden = true;
        showForm(true);
      }
    }
    if (elStMore) elStMore.addEventListener('click', function (e) {
      e.preventDefault();
      elStMore.hidden = true;
      cta.textContent = '사진 올리기';
      showForm(true);
      try { elForm.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (e1) {}
    });

    /* verifyState 는 app.js 에 있다. 웹앱에서 예전 app.js 가 캐시에 남아 있으면 없을 수 있어 같은 규칙으로 대신 읽는다 */
    function readState(uid, cb) {
      if (T.verifyState) { T.verifyState(uid, cb); return; }
      sb.from('patient_verifications').select('id,status,note,created_at,reviewed_at').eq('user_id', uid)
        .order('created_at', { ascending: false }).order('id', { ascending: false }).limit(1)
        .then(function (r) {
          if (r && r.error) {
            var miss = r.status === 404 || /PGRST205|42P01/.test(String(r.error.code || '')) || /does not exist|schema cache/i.test(String(r.error.message || ''));
            return cb(miss ? 'missing' : 'error', null);
          }
          var row = r && r.data && r.data[0];
          cb(!row ? 'none' : (row.status === 'approved' || row.status === 'rejected' ? row.status : 'pending'), row || null);
        }, function () { cb('error', null); });
    }

    /* 세션 확인 → 상태 읽기. 오래 걸려도 5초 뒤에는 올리기 칸을 보여 드린다(올리실 때 다시 확인한다) */
    var shownByTimer = false;
    var slowT = setTimeout(function () { if (!state) { shownByTimer = true; applyState('error', null); } }, 5000);
    var withSession = T.withSession || function (cb) {
      sb.auth.getSession().then(function (r) { cb((r && r.data && r.data.session) || null, (r && r.error) || null); },
        function (e) { cb(null, e || true); });
    };
    withSession(function (ses, err) {
      if (!ses) {
        if (!err) { location.replace('01-splash.html'); return; }
        clearTimeout(slowT);
        if (!state) applyState('error', null);       /* 연결 문제 — 내보내지 않는다. 올리실 때 다시 확인한다 */
        return;
      }
      user = ses.user;
      readState(user.id, function (st, row) {
        clearTimeout(slowT);
        /* 느려서 올리기 칸을 먼저 보여 드렸고 그사이 사진을 고르셨으면(또는 올리는 중이면) 화면을 바꾸지 않는다 */
        if (shownByTimer && (photo || working || sending || sent)) return;
        applyState(st, row);
      });
    });

    /* ── 올리기 ── */
    function withTimeout(p, ms) {
      return new Promise(function (res, rej) {
        var t = setTimeout(function () { rej(new Error('timeout')); }, ms);
        p.then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
      });
    }
    function errText(err) {
      var m = String((err && (err.message || err.error || err.error_description)) || '');
      var code = String((err && (err.statusCode || err.status || err.code)) || '');
      return { m: m, both: m + ' ' + code };
    }
    /* 받는 쪽 준비가 덜 된 실패 — 보관함이 없거나(Bucket not found) 규칙이 없어(row-level security) 막힌 경우.
       SQL 이 반쯤만 실행되면(표는 생기고 보관함 규칙은 못 만든 경우) 새로 가입하시는 분이 여기서 영영 막힌다.
       환자분 잘못이 아니므로, 가입 도중이면 '가입 먼저 이어 하기'를 함께 보여 드린다(나중에 내 정보에서 올리신다). */
    function isSetupErr(err) {
      var t = errText(err);
      if (/jwt|token|401/i.test(t.both)) return false;
      return /bucket not found|row-level security|violates|policy|403|404|PGRST205|42P01|42501/i.test(t.both);
    }
    function upMsg(err) {
      var t = errText(err), m = t.m, both = t.both;
      if (typeof navigator !== 'undefined' && navigator.onLine === false) return '인터넷이 끊겨 있어요.\n와이파이나 데이터를 켠 뒤 ‘다시 올리기’를 눌러 주세요.';
      if (/timeout/i.test(m)) return '연결이 느려 사진을 다 보내지 못했어요.\n‘다시 올리기’를 눌러 주세요.';
      if (/payload too large|too large|exceeded the maximum|413/i.test(both)) return '사진이 너무 커요.\n‘다시 고르기’로 다른 사진을 골라 주세요.';
      if (/mime|invalid.*type|415/i.test(both)) return '이런 사진은 올릴 수 없어요.\n📷 사진 찍기로 다시 찍어 주세요.';
      if (/jwt|token|401/i.test(both)) return '로그인이 풀렸어요.\n앱을 닫았다가 다시 열어 로그인한 뒤 올려 주세요.';
      if (isSetupErr(err)) return EDIT ? '지금은 사진을 받을 준비가 덜 됐어요.\n조금 뒤에 ‘다시 올리기’를 눌러 주세요.'
        : '지금은 사진을 받을 준비가 덜 됐어요.\n조금 뒤에 다시 올리시거나, 가입을 먼저 이어 가신 뒤\n‘내 정보 › 환자 확인 서류’에서 올려 주세요.';
      if (/fetch|network|load failed|connection/i.test(m)) return '연결이 원활하지 않아요.\n잠시 후 ‘다시 올리기’를 눌러 주세요.';
      return '사진을 올리지 못했어요.\n잠시 후 ‘다시 올리기’를 눌러 주세요.' + (m ? '\n(' + m.slice(0, 60) + ')' : '');
    }
    function fail(err) {
      sending = false;
      busy(cta, false);
      cta.textContent = '다시 올리기';
      cta.setAttribute('aria-disabled', 'false');
      /* 토스트는 곧 사라지고 같은 자리(하단)를 가려서, 버튼 바로 위에 남는 한 줄로만 알린다 */
      showErr(upMsg(err));
      if (btnSkip && !EDIT && isSetupErr(err)) btnSkip.hidden = false;
      fitFoot();                                     /* 안내 줄·건너뛰기 단추로 띠가 길어진 만큼 본문 끝을 띄운다 */
      try { elErr.scrollIntoView({ block: 'nearest' }); } catch (e) {}
    }
    if (btnSkip) btnSkip.addEventListener('click', function (e) {
      e.preventDefault();
      if (sending) return;
      /* goAfterLogin 은 서류 줄이 없으면 다시 99 로 보내므로 03 으로 곧장 간다.
         03~14 를 마치면 치료 단계가 생겨 다음 로그인부터는 99 로 오지 않는다 — 올리기는 내 정보에서 */
      location.replace('03-profile-type.html');
    });
    function markMissing(el) {
      if (!el) return;
      try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) {}
      el.classList.add('is-missing');
      setTimeout(function () { el.classList.remove('is-missing'); }, 2600);
    }
    function goNext() {
      /* 올린 뒤 0.9초 기다리는 사이 '잘 받았어요 ✓'를 한 번 더 누르시면 goAfterLogin 이 두 줄로 돌아
         느린 망에서 '확인하는 중이에요' 안내가 겹쳐 뜬다 — 이미 가는 중이면 하나로 (2026-09-28 검토) */
      if (EDIT || cta.__busy) return;
      busy(cta, true, '다음 단계로 가는 중…');
      withSession(function (ses) {
        var u = (ses && ses.user) || user;
        if (!u || !T.goAfterLogin) { busy(cta, false); location.replace('03-profile-type.html'); return; }
        T.goAfterLogin(u, function () {             /* 세 번 다 확인하지 못하면 버튼을 되살린다 — 다시 눌러도 또 올리지 않는다 */
          busy(cta, false);
          cta.textContent = '다음으로';
          cta.setAttribute('aria-disabled', 'false');
        });
      });
    }
    function done() {
      sending = false;
      sent = true;
      busy(cta, false);
      showErr('');
      if (prevUrl) { try { URL.revokeObjectURL(prevUrl); } catch (e) {} prevUrl = ''; }
      if (elImg) elImg.removeAttribute('src');
      photo = null;                                  /* 올린 사진은 이 화면 메모리에서도 치운다 */
      if (EDIT) {
        paintState('✅', '사진을 잘 받았어요', '토닥 담당자가 확인해 드릴게요. 확인이 끝나면 ‘내 정보’에 <b>확인 완료</b>라고 보여요.', '', false);
        showForm(false);
        ctaBack();
        try { elState.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (e1) {}
        toast('사진을 잘 받았어요.\n토닥 담당자가 확인해 드릴게요.');
        return;
      }
      cta.textContent = '잘 받았어요 ✓';
      toast('사진을 잘 받았어요.\n토닥 담당자가 확인해 드릴게요.');
      setTimeout(goNext, 900);
    }

    function send() {
      if (sending || cta.__busy) return;
      sending = true;
      showErr('');
      busy(cta, true, upDone ? '마무리하는 중…' : '사진을 올리는 중…');
      withSession(function (ses, err) {
        if (!ses) {
          sending = false;
          if (err) { if (T.sessOffline) T.sessOffline(cta); else busy(cta, false); showErr(upMsg(err)); cta.textContent = '다시 올리기'; return; }
          busy(cta, false); location.replace('01-splash.html'); return;
        }
        var u = ses.user;
        user = u;
        /* 자리는 사진마다 한 번만 정한다. 느린 망에서 시간이 넘어 실패로 보였는데 사실은 올라간 경우,
           같은 자리로 다시 올리면 '이미 있어요' 가 돌아온다 → 올라간 것으로 보고 표에 적기로 넘어간다. */
        if (!upPath || upPath.split('/')[0] !== u.id) { upPath = u.id + '/' + (new Date()).getTime() + '.jpg'; upDone = false; }
        var path = upPath;
        var step1 = upDone ? Promise.resolve({ data: { path: path }, error: null })
          : withTimeout(sb.storage.from(BUCKET).upload(path, photo.blob, { contentType: 'image/jpeg', upsert: false, cacheControl: '3600' }), UP_TIMEOUT);
        step1.then(function (r1) {
          var e1 = r1 && r1.error;
          if (e1 && !/already exists|duplicate|409/i.test(String(e1.message || '') + ' ' + String(e1.statusCode || e1.status || ''))) throw e1;
          upDone = true;
          if (cta.__busy) cta.textContent = '마무리하는 중…';
          return withTimeout(sb.from('patient_verifications').insert({
            user_id: u.id, file_path: path, consent_version: CONSENT_VER
          }), DB_TIMEOUT);
        }).then(function (r2) {
          if (r2 && r2.error) throw r2.error;
          done();
        }).catch(function (e2) { fail(e2); });
      });
    }

    cta.addEventListener('click', function (e) {
      e.preventDefault();
      if (cta.__busy || sending) return;
      if (sent) { if (EDIT) backToFrom(); else goNext(); return; }
      if (elForm.hidden) { backToFrom(); return; }  /* 올릴 것이 없는 상태 — 돌아가기 */
      if (!photo) {
        toast('서류 사진을 먼저 골라 주세요.');
        markMissing(elPick && !elPick.hidden ? elPick : elPrev);
        return;
      }
      if (!isOn()) {
        toast('사진 수집·이용에 동의해 주셔야 올릴 수 있어요.');
        markMissing(elAgreeRow);
        return;
      }
      send();
    });

    /* ── 뒤로가기 ── 가입 도중이면 03 처럼 '이 계정에서 나가기'를 묻는다.
       내 정보에서 왔으면 app.js(FROM_BACK)가 그 화면으로 돌려보낸다(여기서 건드리지 않는다).
       휴대폰 뒤로가기도 native.js 가 이 버튼을 눌러 같은 길을 탄다. */
    var back = document.querySelector('.appbar .back');
    if (back && !EDIT) back.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      if (sending) { toast('사진을 올리는 중이에요.\n잠시만 기다려 주세요.'); return; }
      askLeave();
    });
    function askLeave() {
      var old = document.getElementById('pvAsk');
      if (old && old.parentNode) old.parentNode.removeChild(old);
      var pop = document.createElement('div');
      pop.className = 'callpop'; pop.id = 'pvAsk';
      pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-modal', 'true'); pop.setAttribute('aria-labelledby', 'pvAskT');
      pop.innerHTML = '<div class="callpop-card"><div style="font-size:32px;" aria-hidden="true">🚪</div>'
        + '<div class="strong" style="font-size:17px; word-break:keep-all;" id="pvAskT">처음 화면으로 나갈까요?</div>'
        + '<p class="small muted" style="margin:-2px 2px 4px; line-height:1.6; word-break:keep-all;">지금 계정에서 로그아웃돼요. 약관 동의는 저장돼 있어서, 같은 계정으로 다시 로그인하시면 이 화면부터 이어서 하실 수 있어요.</p>'
        + '<button type="button" class="btn btn-primary btn-block btn-lg">로그아웃하고 나가기</button>'
        + '<button type="button" class="btn btn-outline btn-block">계속하기</button></div>';
      var btns = pop.getElementsByTagName('button'), yes = btns[0], no = btns[1];
      function close() { pop.hidden = true; if (pop.parentNode) pop.parentNode.removeChild(pop); }
      no.addEventListener('click', close);
      pop.addEventListener('click', function (e) { if (e.target === pop) close(); });
      pop.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
      yes.addEventListener('click', function () {
        close();
        if (T.logout) T.logout(function () { location.replace('01-splash.html'); });
        else location.replace('01-splash.html');
      });
      (screenEl || document.body).appendChild(pop);
      try { no.focus(); } catch (e3) {}
    }

    refresh();
    fitFoot();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
