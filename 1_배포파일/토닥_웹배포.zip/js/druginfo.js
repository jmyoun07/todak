/* ═══ 토닥 약 정보 지도 — 주요 유방암 치료제의 분류·흔한 불편·연락 신호 ═══
   근거: 식약처 허가사항·NCI Side Effects·CTCAE (12-sources 참조 체계와 동일)
   원칙: 발생 확률을 단정하지 않고 "생길 수 있어요" 수준으로만.
   약을 바꾸거나 끊으라는 안내는 하지 않는다. */
(function () {
  'use strict';

  /* 링크: 15 손발저림 · 32 탈모 · 34 관절통 · 38 설사 · 49 집중력 · 51 수족증후군
           60 메스꺼움 음식 · 62 입안 헐음 음식 · 65 맛 변화 · 17 자가관리 */
  var DRUGS = [
    {
      pat: /타목시펜|놀바덱스|타모플렉스|타목스타/,
      cat: '호르몬치료제', name: '타목시펜',
      effects: [
        { n: '안면홍조·열감', d: '얇게 겹쳐 입고 시원한 물을 자주 드세요', link: '35-detail-hotflash.html' },
        { n: '질 분비물·불규칙 출혈', d: '새로 생긴 질 출혈은 미루지 말고 바로 진료를 받아 주세요' },
        { n: '기분 변화', d: '마음이 가라앉는 날이 이어지면 적어 두었다가 담당 의사와 상의하세요' }
      ],
      warn: '한쪽 종아리가 붓고 아프거나 갑자기 숨이 차면 혈전 신호일 수 있어요 — 바로 치료받는 병원에 연락하세요. 새로 생긴 질 출혈도 미루지 말고 진료받으세요 — 자궁 안쪽을 확인해야 할 수 있어요. 말이 어눌해지거나 한쪽 팔다리에 힘이 빠지면 바로 119에 연락하세요.'
    },
    {
      pat: /레트로졸|페마라|아나스트로졸|아리미덱스|엑세메스탄|아로마신/,
      cat: '호르몬치료제(아로마타제 억제제)', name: '아로마타제 억제제',
      effects: [
        { n: '관절통·뻣뻣함', d: '아침에 특히 흔해요. 가벼운 스트레칭이 도움이 돼요', link: '34-detail-arthralgia.html' },
        { n: '안면홍조·열감', d: '얇게 겹쳐 입고 카페인을 줄여 보세요', link: '35-detail-hotflash.html' },
        { n: '골밀도 감소', d: '골밀도 검사를 정기적으로 받아요. 칼슘·비타민D는 담당 의사와 상의하세요' },
        { n: '피로', d: '짧은 산책이 오히려 피로를 줄여 줘요' }
      ],
      warn: '넘어진 뒤 통증이 가라앉지 않거나, 다치지 않았는데 등·허리가 갑자기 아프면 골절일 수 있어요 — 미루지 말고 치료받는 병원에서 진료받으세요.'
    },
    {
      pat: /아베마시클립|버제니오|팔보시클립|입랜스|리보시클립|키스칼리/,
      cat: '표적치료제(CDK4/6 억제제)', name: 'CDK4/6 억제제',
      effects: [
        { n: '설사', d: '변이 무르기 시작하면 물을 충분히 드시고, 잦아지면 미루지 말고 알리세요', link: '38-detail-diarrhea.html' },
        { n: '백혈구 감소', d: '정기 혈액검사로 확인해요. 손 씻기처럼 감염을 막는 습관이 중요해요' },
        { n: '피로', d: '무리하지 말고 쉬어 가며 활동하세요' },
        { n: '입맛 변화', d: '부드럽고 담백한 음식이 편할 수 있어요', link: '65-food-taste.html' }
      ],
      warn: '38.0도(겨드랑이는 37.5도) 이상 열이 나면 밤이든 주말이든 바로 치료받는 병원에 연락하세요 — 항암치료 중에 나는 열은 그 자체가 응급이에요. 설사가 평소보다 하루 4번 이상 늘면 그날 안에 연락하세요. 실신할 것 같거나 가슴이 심하게 두근거릴 때(리보시클립·키스칼리), 한쪽 다리가 붓거나 갑자기 숨이 찰 때(혈전 신호)도 바로 연락하세요. 마른기침이나 숨참이 새로 생기면 폐 염증(간질성 폐질환) 신호일 수 있어 그날 안에 알리세요.'
    },
    {
      pat: /카페시타빈|젤로다/,
      cat: '먹는 항암제', name: '카페시타빈',
      effects: [
        { n: '수족증후군', d: '손발이 붉어지고 벗겨질 수 있어요. 보습제를 자주 바르고 마찰을 줄여 주세요', link: '51-detail-handfoot.html' },
        { n: '설사', d: '잦아지면 미루지 말고 그날 안에 알리세요', link: '38-detail-diarrhea.html' },
        { n: '입안 헐음', d: '부드러운 칫솔과 자극 없는 음식이 도움이 돼요', link: '62-food-mucositis.html' }
      ],
      warn: '이 약은 스스로 양을 줄이거나 끊으면 위험할 수 있어요. 힘드시면 반드시 담당 의사와 먼저 상의하세요. 심한 설사·입안 헐음·손발 통증이 오면 그날 안에 연락하고, 가슴이 조이듯 아프면 바로 치료받는 병원에 연락하세요 — 다음 약을 드실지는 병원에서 알려 드려요.'
    },
    {
      pat: /독소루비신|아드리아마이신|에피루비신|사이클로포스파미드|^AC\b|AC \(/,
      cat: '주사 항암제(AC 계열)', name: 'AC 항암치료',
      effects: [
        { n: '메스꺼움·구토', d: '처방받은 항구토제를 시간 맞춰 드시는 것이 가장 도움이 돼요', link: '60-food-nausea.html' },
        { n: '탈모', d: '보통 2~3주째부터 시작돼요. 준비 방법을 미리 봐 두세요', link: '32-detail-hairloss.html' },
        { n: '백혈구 감소', d: '주사 뒤 7~14일쯤 면역력이 가장 낮아요. 사람 많은 곳을 피하고 손을 자주 씻으세요', link: '37-detail-myelo.html' },
        { n: '피로', d: '주사 뒤 며칠은 쉬는 일정으로 잡아 두세요' },
        { n: '심장 기능 변화', d: '이 약을 쓰는 동안에는 심장 검사를 정기적으로 받아요' }
      ],
      warn: '38.0도(겨드랑이는 37.5도) 이상 열이 나면 밤이든 주말이든 바로 치료받는 병원에 연락하세요 — 항암치료 중에 나는 열은 그 자체가 응급이에요. 숨이 차거나 발목이 붓거나 가슴이 두근거려도 미루지 말고 알리세요.'
    },
    {
      pat: /파클리탁셀|탁솔|도세탁셀|탁소텔/,
      cat: '주사 항암제(탁산 계열)', name: '탁산 항암치료',
      effects: [
        { n: '손발 저림·찌릿함', d: '새로 생기거나 심해지면 다음 주사 전에 꼭 알리세요', link: '15-sideeffect-detail.html' },
        { n: '탈모', d: '준비 방법을 미리 봐 두면 덜 당황스러워요', link: '32-detail-hairloss.html' },
        { n: '근육·관절통', d: '주사 뒤 2~4일쯤 흔하고 대개 지나가요', link: '34-detail-arthralgia.html' },
        { n: '손발톱 변화', d: '손발톱을 짧게 깎고 보습제를 발라 주세요' }
      ],
      warn: '38.0도(겨드랑이는 37.5도) 이상 열이 나거나, 단추를 못 잠글 정도로 손이 저리면 바로 치료받는 병원에 알려 주세요.'
    },
    {
      pat: /트라스투주맙(?!.*(데룩스테칸|엠탄신))|허셉틴|허쥬마|삼페넷|온트루잔트|퍼투주맙|퍼제타|페스고/,
      cat: 'HER2 표적치료제', name: 'HER2 표적치료',
      effects: [
        { n: '심장 기능 변화', d: '정기 심장 검사로 확인해요. 계단 오르기가 갑자기 힘들어지면 알리세요' },
        { n: '오한·열(첫 주사 때)', d: '첫 주사 때 흔하고 대개 가벼워요' },
        { n: '설사', d: '잦아지면 알리세요', link: '38-detail-diarrhea.html' }
      ],
      warn: '숨이 차거나 발목이 붓거나 가슴이 두근거릴 때, 38.0도(겨드랑이는 37.5도) 이상 열이 날 때는 미루지 말고 치료받는 병원에 연락하세요.'
    },
    {
      pat: /펨브롤리주맙|키트루다/,
      cat: '면역항암제', name: '펨브롤리주맙',
      effects: [
        { n: '피부 발진·가려움', d: '넓게 번지면 알리세요' },
        { n: '설사', d: '잦아지면 미루지 말고 알리세요', link: '38-detail-diarrhea.html' },
        { n: '피로·기운 없음', d: '갑자기 심해지면 갑상선 같은 호르몬 검사가 필요할 수 있어요' }
      ],
      warn: '면역항암제는 몸 어디에나 염증을 일으킬 수 있어요. 숨이 차거나, 설사가 심하거나, 기운이 갑자기 빠지거나, 눈·피부가 노래지면 바로 치료받는 병원에 알리세요.'
    },
    {
      pat: /사시투주맙|트로델비/,
      cat: '표적치료제(항체에 항암제를 붙인 약)', name: '사시투주맙 고비테칸',
      effects: [
        { n: '설사', d: '시작되면 바로 알리세요 — 설사를 멎게 하는 약이 있어요', link: '38-detail-diarrhea.html' },
        { n: '백혈구 감소', d: '정기 혈액검사로 확인해요. 사람 많은 곳을 피하고 손을 자주 씻으세요' },
        { n: '메스꺼움', d: '', link: '60-food-nausea.html' },
        { n: '탈모', d: '', link: '32-detail-hairloss.html' }
      ],
      warn: '38.0도(겨드랑이는 37.5도) 이상 열이 나거나 설사가 심해지면 밤이든 주말이든 바로 치료받는 병원에 연락하세요 — 항암치료 중에 나는 열은 그 자체가 응급이에요.'
    },
    {
      pat: /에리불린|할라벤|비노렐빈|나벨빈|젬시타빈|카보플라틴|시스플라틴|메토트렉세이트|플루오로우라실|5-?FU/,
      cat: '주사 항암제', name: '주사 항암치료',
      effects: [
        { n: '백혈구 감소', d: '주사 뒤 7~14일쯤 면역력이 가장 낮아요. 사람 많은 곳을 피하고 손을 자주 씻으세요', link: '37-detail-myelo.html' },
        { n: '메스꺼움', d: '', link: '60-food-nausea.html' },
        { n: '피로', d: '무리하지 말고 쉬어 가며 활동하세요' },
        { n: '손발 저림', d: '새로 생기면 다음 주사 전에 알리세요', link: '15-sideeffect-detail.html' }
      ],
      warn: '38.0도(겨드랑이는 37.5도) 이상 열이 나면 밤이든 주말이든 바로 치료받는 병원에 연락하세요 — 항암치료 중에 나는 열은 그 자체가 응급이에요.'
    },
    {
      pat: /에베로리무스|아피니토|라파티닙|타이커브|투카티닙/,
      cat: '먹는 표적치료제', name: '먹는 표적치료제',
      effects: [
        { n: '입안 헐음', d: '자극 없는 음식과 부드러운 칫솔이 도움이 돼요', link: '62-food-mucositis.html' },
        { n: '설사', d: '잦아지면 알리세요', link: '38-detail-diarrhea.html' },
        { n: '피부 발진', d: '보습제를 꾸준히 바르고, 넓게 번지면 알리세요' }
      ],
      warn: '이 약을 스스로 끊거나 줄이지 마세요. 숨이 차거나 설사가 심하거나 눈·피부가 노래지면 바로 치료받는 병원에 알리세요.'
    },
    {
      pat: /캐싸일라|엠탄신|T-?DM1/i,
      cat: '표적치료제(항체에 항암제를 붙인 약)', name: '캐싸일라(T-DM1)',
      effects: [
        { n: '피로·메스꺼움', d: '주사 뒤 며칠은 쉬는 일정으로 잡아 두세요', link: '60-food-nausea.html' },
        { n: '혈소판 감소', d: '멍이 쉽게 들거나, 잇몸에서 피가 나거나, 코피가 잦아지면 알리세요' },
        { n: '간 수치 상승', d: '정기 혈액검사로 확인해요' },
        { n: '손발 저림', d: '새로 생기면 다음 주사 전에 알리세요', link: '15-sideeffect-detail.html' }
      ],
      warn: '눈·피부가 노래지거나 소변 색이 진해지면(간 신호), 피가 잘 멎지 않으면, 기침이나 숨참이 새로 생기면 바로 치료받는 병원에 연락하세요. 38.0도(겨드랑이는 37.5도) 이상 열이 나도 바로 연락하세요.'
    },
    {
      pat: /엔허투|데룩스테칸/,
      cat: '표적치료제(항체에 항암제를 붙인 약)', name: '엔허투',
      effects: [
        { n: '마른기침·숨참', d: '가볍더라도 새로 생기면 그날 바로 알리세요' },
        { n: '메스꺼움', d: '처방받은 항구토제를 시간 맞춰 드시는 것이 가장 도움이 돼요', link: '60-food-nausea.html' },
        { n: '탈모', d: '준비 방법을 미리 봐 두세요', link: '32-detail-hairloss.html' },
        { n: '피로·백혈구 감소', d: '정기 혈액검사로 확인해요' }
      ],
      warn: '기침이나 숨참이 새로 생기면 가볍더라도 그날 바로 치료받는 병원에 알리세요 — 폐에 염증이 생길 수 있는 약이라 빨리 확인해야 해요. 38.0도(겨드랑이는 37.5도) 이상 열이 나도 바로 연락하세요.'
    },
    {
      pat: /졸라덱스|고세렐린|루프린|류프로렐린|루프롤린/,
      cat: '난소 기능 억제 주사', name: '난소 기능 억제 주사',
      effects: [
        { n: '안면홍조·열감', d: '폐경기 증상과 비슷해요. 얇게 겹쳐 입으세요', link: '35-detail-hotflash.html' },
        { n: '기분 변화', d: '그날그날 마음을 적어 두면 진료 때 도움이 돼요' },
        { n: '골밀도 감소', d: '골밀도 검사로 정기적으로 확인해요' },
        { n: '주사 부위 통증', d: '주사 맞은 자리가 며칠 뻐근할 수 있어요' }
      ],
      warn: '머리가 몹시 아프거나 눈앞이 흐릿해지면 치료받는 병원에 연락하세요.'
    },
    {
      pat: /풀베스트란트|파슬로덱스/,
      cat: '호르몬치료제(주사)', name: '풀베스트란트',
      effects: [
        { n: '주사 부위 통증', d: '엉덩이 주사 자리가 며칠 뻐근할 수 있어요' },
        { n: '안면홍조·열감', d: '', link: '35-detail-hotflash.html' },
        { n: '관절통', d: '', link: '34-detail-arthralgia.html' }
      ],
      warn: '한쪽 다리가 붓고 아프거나 갑자기 숨이 차면 바로 치료받는 병원에 연락하세요.'
    },
    {
      pat: /올라파립|린파자|탈라조파립/,
      cat: '표적치료제(PARP 억제제)', name: 'PARP 억제제',
      effects: [
        { n: '빈혈·피로', d: '정기 혈액검사로 확인해요. 어지러우면 무리하지 마세요' },
        { n: '메스꺼움', d: '조금씩 자주 드시는 것이 도움이 돼요', link: '60-food-nausea.html' }
      ],
      warn: '숨이 차고 얼굴이 유난히 창백해지면 치료받는 병원에 연락해 진료를 앞당겨 주세요.'
    }
  ];

  /* 유방암 치료약이 아닌 흔한 약 분류 (부작용 카드 없음 · 겹침 확인용) */
  var OTHERS = [
    [/암로디핀|로자탄|텔미|발사르탄|아모잘탄|올메사르탄|비소프롤롤|카르베딜롤|히드로클로로/, '혈압약'],
    [/메트포르민|다이아벡스|글리메피리드|아마릴|시타글립틴|자누비아|다파글리플로진/, '당뇨약'],
    [/아토르바|리피토|로수바|크레스토|심바스타틴/, '고지혈증약'],
    [/오메프라졸|에스오메|넥시움|판토프라졸|라베프라졸|알비스|개비스콘/, '위장약'],
    [/레보티록신|씬지로이드|씬지록신/, '갑상선약'],
    [/아세트아미노펜|타이레놀|이부프로펜|낙센|나프록센/, '진통·해열제'],
    [/파록세틴|팍실|세로자트|플루옥세틴|프로작|부프로피온|웰부트린/, '마음 건강 약'],
    [/와파린|쿠마딘|리바록사반|자렐토|아픽사반|엘리퀴스/, '혈전 예방약'],
    [/졸피뎀|스틸녹스|알프라졸람|자낙스|로라제팜|에스시탈로프람|렉사프로|설트랄린|졸로푸트|트라조돈/, '수면·마음 건강 약'],
    [/아스피린|클로피도그렐|플라빅스/, '혈전 예방약'],
    [/알렌드로네이트|포사맥스|리세드로네이트|이반드론산/, '골다공증약'],
    /* 실제 약 봉투(2026-09-20 교수님 자료)에서 나온 눈약·붓기약 — 지금까지는 모두
       '목록에서 확인하지 못한 약'으로만 보였다. 부작용 카드는 없고 분류 이름만 보여 준다.
       좁은 것부터 본다 — '히아레인점안액'이 아래 점안액 줄에 먼저 걸리지 않게. */
    [/히알루론산나트륨점안|히아레인|히아린|카복시메틸셀룰로오스점안/, '인공눈물'],
    [/안연고/, '눈에 바르는 약(안연고)'],
    [/점안액|점안제|점안겔|점안현탁액|점안용액|안약$/, '눈에 넣는 약(점안액)'],
    [/엔테론|디오스민|베노론|치오크로만올/, '붓기 완화제'],
    [/세라티오펩티다제|스트렙토키나제|브로멜라인/, '붓기·염증 가라앉히는 약']
  ];

  function norm(s) { return String(s || '').replace(/\s+/g, ''); }

  window.TDRUG = {
    match: function (name) {
      var n = norm(name);
      for (var i = 0; i < DRUGS.length; i++) {
        if (DRUGS[i].pat.test(n)) {
          return { cancer: true, cat: DRUGS[i].cat, title: DRUGS[i].name, effects: DRUGS[i].effects, warn: DRUGS[i].warn };
        }
      }
      for (var j = 0; j < OTHERS.length; j++) {
        if (OTHERS[j][0].test(n)) return { cancer: false, cat: OTHERS[j][1] };
      }
      return { cancer: false, cat: null, unknown: true };   /* 목록에서 확인 못 한 약 */
    }
  };
})();

/* ═══ 토닥 약 정보(공공데이터) — 식약처 허가정보·DUR 품목정보를 hosp-proxy 로 받아 온다 ═══
   원칙: 받아온 글을 그대로 보여주기만 한다. 토닥이 해석하거나 '먹지 마세요'라고 판단하지 않는다.
   ── 2026-10-26 사용 의견 ──
   예전에는 조회 결과를 그날치만 sessionStorage 에 두었다. 그래서 약 정보(75)를 열 때마다 5초쯤 기다리고,
   55 오늘의 복약으로 돌아오면 다시 '확인하지 못한 약'으로 보였다(55 는 이 결과를 쓰지도 않았다).
   이제 찾은 결과(허가정보·DUR·효능효과·용법용량)는 이 기기에 오래 둔다(localStorage · 찾은 약 30일 · 못 찾은 약 7일).
   공공데이터 글이고 개인 기록이 아니다. 연결이 끊겨 못 받은 것은 오래 두지 않고 그날 창에만 둔다(다음에 다시 묻게).
   등록 약끼리 병용금기 짝(pair)은 약 목록이 바뀌면 키가 바뀌므로 예전처럼 그날치만 둔다. */
(function () {
  'use strict';
  var CFG = window.TODAK_CONFIG || {};
  var STORE = 'todak_druginfo';
  var CALL_MS = 7000;
  var MAX_MEDS = 6;          /* 겹침 확인은 등록 약 여섯 개까지만 (조회 수를 아끼려고) */

  var NOTICE = '식품의약품안전처 공공데이터를 그대로 보여 드려요. 진단이나 처방이 아니에요. 드시는 방법은 담당 의사나 약사가 알려 주신 대로 해 주세요.';

  /* 병용금기가 첫 줄인 이유: 등록 약끼리 겹침 확인에 이것만 쓴다(목록 화면은 이 한 가지만 묻는다) */
  var DUR_SPECS = [
    { op: 'getUsjntTabooInfoList03', key: 'usjnt', label: '병용금기' },
    { op: 'getSpcifyAgrdeTabooInfoList03', key: 'agrde', label: '연령금기' },
    { op: 'getPwnmTabooInfoList03', key: 'pwnm', label: '임부금기' },
    { op: 'getOdsnAtentInfoList03', key: 'odsn', label: '노인주의' },
    { op: 'getCpctyAtentInfoList03', key: 'cpcty', label: '용량주의' }
  ];

  function today() {
    var d = new Date();
    return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  }
  function box() {
    var raw = null, o = null;
    try { raw = sessionStorage.getItem(STORE); } catch (e) { raw = null; }
    try { o = raw ? JSON.parse(raw) : null; } catch (e2) { o = null; }
    if (!o || o.d !== today()) o = { d: today(), byName: {}, pair: {}, doc: {} };
    if (!o.byName) o.byName = {};
    if (!o.pair) o.pair = {};
    if (!o.doc) o.doc = {};
    return o;
  }
  function save(o) {
    try { sessionStorage.setItem(STORE, JSON.stringify(o)); } catch (e) { /* 못 담아도 화면은 그대로 */ }
  }
  /* ── 오래 두는 칸(localStorage) ── 찾은 약은 30일, 못 찾은 약('none')은 7일. 많아지면 오래된 것부터 지운다 */
  var KEEP = 'todak_druginfo_keep';
  var DAY_MS = 864e5, OK_DAYS = 30, NONE_DAYS = 7, KEEP_MAX = 80;
  function kbox() {
    var o = null;
    try { o = JSON.parse(localStorage.getItem(KEEP) || 'null'); } catch (e) { o = null; }
    if (!o || typeof o !== 'object') o = {};
    if (!o.byName || typeof o.byName !== 'object') o.byName = {};
    if (!o.doc || typeof o.doc !== 'object') o.doc = {};
    return o;
  }
  function fresh(v) {
    if (!v || !v.t) return false;
    var age = Date.now() - v.t;
    return age >= 0 && age < (v.ok === false ? NONE_DAYS : OK_DAYS) * DAY_MS;
  }
  function trim(map) {
    var ks = Object.keys(map);
    if (ks.length <= KEEP_MAX) return;
    ks.sort(function (a, b) { return (map[a].t || 0) - (map[b].t || 0); });
    for (var i = 0; i < ks.length - KEEP_MAX; i++) delete map[ks[i]];
  }
  function ksave(o) {
    trim(o.byName); trim(o.doc);
    try { localStorage.setItem(KEEP, JSON.stringify(o)); } catch (e) {
      /* 자리가 모자라면 절반을 비우고 한 번 더 */
      try { o.byName = {}; o.doc = {}; localStorage.setItem(KEEP, JSON.stringify(o)); } catch (e2) {}
    }
  }
  function kept(ck) {
    var v = kbox().byName[ck];
    return fresh(v) ? v : null;
  }
  function remember(ck, v) {
    /* 연결 실패는 그날 창에만 — 오래 두면 약 정보를 영영 못 본다 */
    if (v && (v.ok || v.reason === 'none')) {
      var k = kbox(), x = {}, key;
      for (key in v) if (Object.prototype.hasOwnProperty.call(v, key)) x[key] = v[key];
      x.t = Date.now();
      k.byName[ck] = x;
      ksave(k);
    }
    var o = box(); o.byName[ck] = v; save(o);
    return v;
  }

  /* 이름 맞추기용 글자 — 띄어쓰기·괄호·용량을 뺀다
     ('엔테론정50밀리그램(포도씨건조엑스)' → '엔테론정', '프레미나정(결합형에스트로겐)' → '프레미나정') */
  function keyName(s) {
    return String(s == null ? '' : s)
      .replace(/\([^)]*\)/g, '')
      .replace(/\d+(\.\d+)?\s*(밀리그램|밀리그람|마이크로그램|마이크로그람|밀리리터|그램|그람|리터|mg|mcg|ug|ml|iu|%)/gi, '')
      .replace(/\d+(\.\d+)?/g, '')
      .replace(/[\s·,\-_/]/g, '')
      .toLowerCase();
  }

  function tagOf(block, tag) {
    var m = new RegExp('<' + tag + '\\b[^>]*>([\\s\\S]*?)<\\/' + tag + '>').exec(String(block || ''));
    if (!m) return '';
    return String(m[1]).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/\s+/g, ' ').trim();
  }
  function itemsOf(xml, max) {
    var s = String(xml || ''), out = [], m, re = /<item>([\s\S]*?)<\/item>/g;
    while ((m = re.exec(s)) && out.length < (max || 30)) out.push(m[1]);
    return out;
  }

  /* 성분 — MATERIAL_NAME('총량 : …|성분명 : 아세트아미노펜|분량 : 500…')에서 성분명만 뽑는다 */
  function ingredients(material) {
    var s = String(material || ''), out = [], seen = {}, m, v, re = /성분명\s*:\s*([^|;]+)/g;
    while ((m = re.exec(s))) {
      v = m[1].replace(/\s+/g, ' ').trim();
      if (!v || seen[v]) continue;
      seen[v] = 1; out.push(v);
      if (out.length >= 8) break;
    }
    /* '성분명 :' 꼴이 아니라 성분 이름만 들어 있는 줄도 있다 */
    if (!out.length) {
      v = s.replace(/\s+/g, ' ').trim();
      if (v && v.indexOf('|') === -1 && v.length <= 60) out.push(v);
    }
    return out;
  }

  /* 중계 함수 한 번 — 실패해도 거절하지 않고 null 을 돌려준다(조회 실패와 '해당 없음'을 가른다) */
  function call(path, qs, waitMs) {
    return new Promise(function (resolve) {
      var TD = window.TD || {}, sb = TD.sb;
      if (!CFG.fnBase || !sb || typeof fetch !== 'function') return resolve(null);
      sb.auth.getSession().then(function (rs) {
        var tok = (rs && rs.data && rs.data.session) ? rs.data.session.access_token : null;
        if (!tok) return resolve(null);
        var done = false;
        var tm = setTimeout(function () { if (!done) { done = true; resolve(null); } }, waitMs || CALL_MS);
        function end(v) { if (done) return; done = true; clearTimeout(tm); resolve(v); }
        try {
          fetch(CFG.fnBase + '/hosp-proxy/' + path + '?' + qs,
                { headers: { 'Authorization': 'Bearer ' + tok, 'apikey': CFG.anonKey } })
            .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
            .then(function (x) { end(x); }, function () { end(null); });
        } catch (e) { end(null); }
      }, function () { resolve(null); });
    });
  }

  /* 제형 꼬리 — 등록한 이름이 식약처 정식 이름과 조금 다를 때 한 번 더 찾아보는 데 쓴다
     ('아이플루플러스점안액'으로는 못 찾아도 '아이플루플러스'로는 '아이플루플러스점안현탁액'이 나온다) */
  var FORM_TAIL = /(점안현탁액|점안액|점안제|점안겔|점안용액|안연고|나잘스프레이|주사액|현탁액|시럽|캡슐|연고|크림|로션|과립|패취|패치|정|액|겔|산|주)$/;
  function stemOf(want) {
    var s = String(want == null ? '' : want).replace(/\([^)]*\)/g, '')
      .replace(/\d+(\.\d+)?\s*(밀리그램|밀리그람|마이크로그램|마이크로그람|밀리리터|그램|그람|리터|mg|mcg|ug|ml|iu|%)/gi, '')
      .replace(/\d+(\.\d+)?/g, '').replace(/\s+/g, '');
    var t = s.replace(FORM_TAIL, '');
    return (t.length >= 3 && t !== s) ? t : '';
  }
  /* 이름이 서로 겹치지 않는 줄은 쓰지 않는다 — 엉뚱한 약을 보여주지 않게.
     prefixOnly 는 제형 꼬리를 뗀 두 번째 조회에서만 쓴다(정식 이름이 그 글자로 시작할 때만 받는다).

     ── 어느 줄을 고를까 ── 2026-09-21 교수님 피드백
     "일반적으로 타이레놀이 있을 텐데 어린이용이 잡히더라고. 애초에 성인인데."
     식약처 목록이 돌려주는 차례가 '어린이타이레놀산 → 타이레놀정500 → 타이레놀콜드-에스정'이고,
     예전에는 이름이 겹치기만 하면 먼저 걸린 줄을 그대로 집어서 어린이용이 잡혔다.
     이제는 모두 보고 나서 고른다 — ① 이름이 똑같은 줄 ② 그 글자로 시작하는 줄
     ③ 어린이·소아용이 아닌 줄(등록한 이름에 '어린이'가 있으면 그대로 맞춘다) ④ 짧은 이름.
     수출용 품목은 국내 약국에서 조제되지 않으므로 아예 후보에서 뺀다. */
  var KID_WORD = /(어린이|소아|유아|키즈|베이비|시럽용|드라이시럽)/;
  var EXPORT_WORD = /수출용|수출명/;
  function rankLess(a, b) {
    for (var i = 0; i < a.length; i++) { if (a[i] !== b[i]) return a[i] < b[i]; }
    return false;
  }
  function pickItem(xml, ck, prefixOnly) {
    var blocks = itemsOf(xml, 30), best = null, bestRank = null, i, nm, k2, r, hit;
    if (!ck) return null;
    var wantKid = KID_WORD.test(ck);
    for (i = 0; i < blocks.length; i++) {
      nm = tagOf(blocks[i], 'ITEM_NAME');
      if (!nm || EXPORT_WORD.test(nm)) continue;
      k2 = keyName(nm);
      if (!k2) continue;
      hit = prefixOnly ? (k2.indexOf(ck) === 0) : (k2 === ck || k2.indexOf(ck) > -1 || ck.indexOf(k2) > -1);
      if (!hit) continue;
      r = [(k2 === ck) ? 0 : 1,
           (k2.indexOf(ck) === 0) ? 0 : 1,
           (!wantKid && KID_WORD.test(nm)) ? 1 : 0,
           k2.length, i];
      if (!best || rankLess(r, bestRank)) { best = blocks[i]; bestRank = r; }
    }
    return best;
  }
  function shapeItem(pick) {
    return {
      ok: true, full: false, detailed: false,
      name: tagOf(pick, 'ITEM_NAME'),
      seq: tagOf(pick, 'ITEM_SEQ'),
      entp: tagOf(pick, 'ENTP_NAME'),
      ingr: ingredients(tagOf(pick, 'MATERIAL_NAME')),
      storage: '',
      dur: {}
    };
  }
  /* ── 셋째 시도 ── 2026-09-27 확인한 것
     식약처 목록 찾기는 글자를 그대로 맞춘다. 그래서 정식 이름 가운데 붙임표가 있는 약은
     붙임표 없이 적으면 0건이 된다 — '타이레놀콜드에스정' 0건, '타이레놀'로 찾으면
     '타이레놀콜드-에스정'이 나온다. 앞 네 글자로 한 번 더 찾되, 띄어쓰기·붙임표를 뗀 이름이
     '똑같은' 줄만 받는다. 비슷한 줄은 받지 않는다 — 타이레놀콜드-에스정을 찾다가
     타이레놀정500 을 보여 주면 안 된다. 실패한 길에서만 한 번 더 묻고, 기다리는 시간도 짧게 둔다. */
  var HEAD_LEN = 4;
  var HEAD_MS = 4500;
  function headOf(want) {
    var s = String(want == null ? '' : want).replace(/\([^)]*\)/g, '').replace(/[\s·,\-_/]/g, '');
    var t = s.slice(0, HEAD_LEN);
    return (s.length > HEAD_LEN + 1 && /^[가-힣A-Za-z]+$/.test(t)) ? t : '';
  }
  /* 글자를 맞춘 이름이 똑같은 줄만 — 겹치기만 하는 줄은 고르지 않는다 */
  function pickSame(xml, ck) {
    var blocks = itemsOf(xml, 30), i, nm;
    if (!ck) return null;
    for (i = 0; i < blocks.length; i++) {
      nm = tagOf(blocks[i], 'ITEM_NAME');
      if (!nm || EXPORT_WORD.test(nm)) continue;
      if (keyName(nm) === ck) return blocks[i];
    }
    return null;
  }
  /* 허가정보 목록에서 이 약 한 줄 고르기 — 못 찾으면 제형 꼬리를 떼고, 그래도 못 찾으면 앞 네 글자로 */
  var PRM_ROWS = 20;                 /* 5줄이면 흔한 이름('타이레놀')의 성인용이 뒤에 밀려 안 보인다 */
  function thirdStep(want, ck) {
    var head = headOf(want);
    if (!head) return Promise.resolve({ ok: false, reason: 'none' });
    return call('drugprm', 'item_name=' + encodeURIComponent(head) + '&numOfRows=' + PRM_ROWS, HEAD_MS)
      .then(function (x3) {
        if (x3 == null) return { ok: false, reason: 'fail' };
        var p3 = pickSame(x3, ck);
        return p3 ? shapeItem(p3) : { ok: false, reason: 'none' };
      });
  }
  function firstStep(want) {
    var ck = keyName(want);
    return call('drugprm', 'item_name=' + encodeURIComponent(want) + '&numOfRows=' + PRM_ROWS).then(function (xml) {
      if (xml == null) return { ok: false, reason: 'fail' };
      var pick = pickItem(xml, ck, false);
      if (pick) return shapeItem(pick);
      var stem = stemOf(want);
      if (!stem) return thirdStep(want, ck);
      return call('drugprm', 'item_name=' + encodeURIComponent(stem) + '&numOfRows=' + PRM_ROWS).then(function (x2) {
        if (x2 == null) return { ok: false, reason: 'fail' };
        var p2 = pickItem(x2, keyName(stem), true);
        if (p2) return shapeItem(p2);
        return thirdStep(want, ck);
      });
    });
  }

  /* DUR 한 가지 — null 이면 조회 실패, [] 면 해당 없음 */
  function durOne(seq, spec) {
    return call('dur', 'op=' + spec.op + '&itemSeq=' + encodeURIComponent(seq) + '&numOfRows=30').then(function (xml) {
      if (xml == null) return null;
      var blocks = itemsOf(xml, 30), out = [], i, why, mate;
      for (i = 0; i < blocks.length && out.length < 30; i++) {
        why = tagOf(blocks[i], 'PROHBT_CONTENT') || tagOf(blocks[i], 'TYPE_NAME');
        mate = tagOf(blocks[i], 'MIXTURE_ITEM_NAME');
        if (!why && !mate) continue;
        out.push({ mate: mate.slice(0, 60), why: why.slice(0, 200) });
      }
      return out;
    });
  }

  /* 약 이름 하나 → { ok, name, seq, entp, ingr, storage, dur } (실패해도 거절하지 않는다)
     mode 'pair' 면 병용금기만, 'full' 이면 상세와 DUR 다섯 가지를 모두 받는다. */
  function lookup(want, mode) {
    var nm = String(want == null ? '' : want).trim();
    var ck = keyName(nm);
    if (!nm || !ck) return Promise.resolve({ ok: false, reason: 'noname' });
    var o = box(), c = kept(ck) || o.byName[ck] || null;
    if (c && !c.ok && c.reason !== 'none') c = null;          /* 그날 연결 실패는 다시 묻는다 */
    if (c && (!c.ok || c.full || mode !== 'full')) return Promise.resolve(c);
    var p0 = (c && c.ok && c.seq) ? Promise.resolve(c) : firstStep(nm);
    return p0.then(function (base) {
      if (!base.ok) return remember(ck, base);
      if (!base.dur) base.dur = {};
      var need = [], i;
      for (i = 0; i < DUR_SPECS.length; i++) {
        if (mode !== 'full' && i > 0) break;
        if (base.dur[DUR_SPECS[i].key] !== undefined) continue;   /* 이미 받아 둔 갈래는 다시 묻지 않는다 */
        need.push(DUR_SPECS[i]);
      }
      var jobs = need.map(function (s) { return durOne(base.seq, s); });
      var wantDtl = (mode === 'full' && !base.detailed);
      if (wantDtl) jobs.push(call('drugdtl', 'item_seq=' + encodeURIComponent(base.seq)));
      return Promise.all(jobs).then(function (res) {
        var out = {
          ok: true, name: base.name, seq: base.seq, entp: base.entp,
          ingr: (base.ingr || []).slice(0), storage: base.storage || '',
          dur: base.dur, detailed: !!base.detailed, full: (mode === 'full')
        };
        for (var j = 0; j < need.length; j++) out.dur[need[j].key] = res[j];
        if (wantDtl) {
          var xml = res[need.length];
          if (xml != null) {
            var b = itemsOf(xml, 1)[0] || '';
            out.storage = tagOf(b, 'STORAGE_METHOD');
            if (!out.ingr.length) out.ingr = ingredients(tagOf(b, 'MATERIAL_NAME'));
            out.detailed = true;
          } else {
            out.full = false;                 /* 상세를 못 받았으면 다음에 다시 묻는다 */
          }
        }
        return remember(ck, out);
      });
    });
  }

  /* 등록한 약끼리 병용금기 — 각 약의 병용금기 목록에 다른 등록 약 이름이 들어 있는지 맞춰 본다.
     토닥은 '먹지 마세요'라고 판단하지 않는다. 걸린 짝과 기재된 이유만 그대로 돌려준다. */
  function pairs(names) {
    var list = [], seen = {}, i, n, k;
    for (i = 0; i < (names || []).length && list.length < MAX_MEDS; i++) {
      n = String(names[i] == null ? '' : names[i]).trim();
      k = keyName(n);
      if (!n || k.length < 2 || seen[k]) continue;
      seen[k] = 1; list.push(n);
    }
    if (list.length < 2) return Promise.resolve([]);
    var pk = list.map(function (v) { return keyName(v); }).sort().join('|');
    var o = box();
    if (o.pair[pk]) return Promise.resolve(o.pair[pk]);
    return Promise.all(list.map(function (v) { return lookup(v, 'pair'); })).then(function (res) {
      var hits = [], uk = {}, a, b, mates, m, ka, kb, kk;
      for (a = 0; a < list.length; a++) {
        if (!res[a] || !res[a].ok || !res[a].dur) continue;
        mates = res[a].dur.usjnt || [];
        for (b = 0; b < list.length; b++) {
          if (b === a) continue;
          kb = keyName(list[b]);
          if (kb.length < 4) continue;                 /* 너무 짧은 이름은 맞춰 보지 않는다(엉뚱한 겹침 방지) */
          for (m = 0; m < mates.length; m++) {
            ka = keyName(mates[m].mate);
            if (!ka || ka.length < 4) continue;
            if (ka === kb || ka.indexOf(kb) > -1 || kb.indexOf(ka) > -1) {
              kk = [keyName(list[a]), kb].sort().join('|');
              if (!uk[kk]) { uk[kk] = 1; hits.push({ a: list[a], b: list[b], why: mates[m].why }); }
              m = mates.length;
            }
          }
        }
      }
      var o2 = box(); o2.pair[pk] = hits; save(o2);
      return hits;
    });
  }

  /* ── 식약처 허가사항 본문(효능효과·용법용량) ── 2026-09-20 교수님 피드백
     "식약처 허가사항에 용법용량이 있는데 왜 안 넣냐" — 허가정보 API 에는 이 두 본문이 없어서
     중계 함수(/drugdoc)가 식약처 공식 상세 페이지에서 그 두 문단만 글자로 뽑아 준다.
     받은 글은 손대지 않고 그대로 보여 준다(요약하거나 고쳐 쓰지 않는다). */
  var DOC_MS = 13000;        /* 식약처 페이지가 커서 서버가 받아 오는 데 시간이 걸린다 */
  function doc(seq) {
    var s = String(seq == null ? '' : seq).replace(/\D/g, '');
    if (!s) return Promise.resolve(null);
    var kd = kbox().doc[s];
    if (fresh(kd)) return Promise.resolve(kd);
    var o = box();
    if (o.doc[s]) return Promise.resolve(o.doc[s]);
    return call('drugdoc', 'item_seq=' + encodeURIComponent(s), DOC_MS).then(function (txt) {
      if (txt == null) return null;
      var d = null;
      try { d = JSON.parse(txt); } catch (e) { d = null; }
      if (!d || (!d.ee && !d.ud)) return null;
      /* eeCut·udCut — 서버가 '뒤가 잘렸다'고 알려 준 표시를 그대로 들고 간다 (2026-09-27).
         없으면(옛 서버·예전에 받아 둔 것) 담지 않는다 — 75 가 글자 수로 가린다. */
      var v = { ee: String(d.ee || ''), ud: String(d.ud || '') };
      if (typeof d.eeCut === 'boolean') v.eeCut = d.eeCut;
      if (typeof d.udCut === 'boolean') v.udCut = d.udCut;
      var o2 = box();
      o2.doc[s] = v;
      save(o2);
      var k2 = kbox(), x = { ee: v.ee, ud: v.ud, t: Date.now(), ok: true };
      if (typeof v.eeCut === 'boolean') x.eeCut = v.eeCut;
      if (typeof v.udCut === 'boolean') x.udCut = v.udCut;
      k2.doc[s] = x;
      ksave(k2);
      return v;
    });
  }
  /* 효능효과 첫머리 한 줄 — 55 '이 약을 쓰시는 동안' 줄에 쓴다. 고쳐 쓰지 않고 앞부분만 자른다.
     '다음 질환의 보조 치료 :' 같은 머리말은 떼고 그 뒤부터(우루사정 — 2026-10-26 실제 화면) */
  function eeShort(ee, max) {
    var lines = String(ee == null ? '' : ee).split('\n'), i, t;
    for (i = 0; i < lines.length; i++) {
      t = lines[i].replace(/^\s*(?:[0-9]{1,2}\s*[.)]|[○●•ㆍ·\-–*])\s*/, '').replace(/\s+/g, ' ').trim();
      if (t.replace(/[\s:：]/g, '').length < 2) continue;
      var m = /^([^:：]{2,18})\s*[:：]\s*(.+)$/.exec(t);
      if (m && /(치료|질환|증상|경우|효과|다음)/.test(m[1])) t = m[2];
      max = max || 34;
      return t.length > max ? t.slice(0, max).replace(/[\s,·(]+$/, '') + '…' : t;
    }
    return '';
  }

  window.TDPRM = {
    lookup: lookup,
    doc: doc,
    pairs: pairs,
    cached: function (nm) { var ck = keyName(nm); return kept(ck) || box().byName[ck] || null; },
    /* 받아 둔 효능효과·용법용량 — 없으면 null (55 가 묻지 않고 바로 그릴 때 쓴다) */
    docCached: function (seq) {
      var sq = String(seq == null ? '' : seq).replace(/\D/g, '');
      if (!sq) return null;
      var kd = kbox().doc[sq];
      return fresh(kd) ? kd : (box().doc[sq] || null);
    },
    eeShort: eeShort,
    keyName: keyName,
    ingredients: ingredients,
    specs: DUR_SPECS,
    notice: NOTICE,
    officialUrl: function (seq) {
      return 'https://nedrug.mfds.go.kr/pbp/CCBBB01/getItemDetail?itemSeq=' + encodeURIComponent(seq);
    }
  };
})();
