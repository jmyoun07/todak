/* ═══ 토닥 화면 배선 v3 — 치료 일정·한달 기록·진료 준비·대화 기록·업데이트 안내 ═══
   features.js 다음에 로드된다. 같은 원칙: 시안 요소 복제·문구 교체만. */
(function () {
  'use strict';
  var T = window.TD || {};
  var sb = T.sb, $ = T.$, $$ = T.$$, toast = T.toast, busy = T.busy, koError = T.koError, PAGE = T.PAGE;
  if (!sb || !$) return;
  var CFG = window.TODAK_CONFIG || {};

  function ymd(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function kdate(d) { return (d.getMonth() + 1) + '월 ' + d.getDate() + '일'; }
  var WDAY = ['일', '월', '화', '수', '목', '금', '토'];
  var esc = T.esc || function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };

  /* 고르기 칩의 '골랐는지'를 화면 읽기(TalkBack·VoiceOver)에도 알린다 (2026-10-01 새벽 검증).
     73 주기·10 증상 칩은 누를 때·저장값을 불러올 때·직접 입력할 때 여러 곳에서 chip--on 만 바꾼다 —
     그 자리를 하나씩 고치지 않고, 칩 모양(class)이 바뀔 때마다 역할·상태를 따라 맞춘다. 모양·동작은 그대로다.
     '＋ 직접 입력' 칩은 누르면 입력칸이 열리는 단추다. */
  function chipState(box, single) {
    if (!box || box.__cs) return;
    box.__cs = true;
    if (single) box.setAttribute('role', 'radiogroup');
    function sync() {
      $$('.chip', box).forEach(function (c) {
        if (!c.hasAttribute('tabindex')) c.setAttribute('tabindex', '0');
        if (c.textContent.trim().indexOf('＋') === 0) { c.setAttribute('role', 'button'); return; }
        c.setAttribute('role', single ? 'radio' : 'checkbox');
        var on = c.classList.contains('chip--on') ? 'true' : 'false';
        if (c.getAttribute('aria-checked') !== on) c.setAttribute('aria-checked', on);
      });
    }
    sync();
    if (window.MutationObserver) new MutationObserver(sync).observe(box, { subtree: true, childList: true, attributes: true, attributeFilter: ['class'] });
    box.addEventListener('keydown', function (e) {     /* 화면 읽기·키보드로도 고르게 */
      var c = e.target;
      if ((e.key === 'Enter' || e.key === ' ') && c && c.classList && c.classList.contains('chip')) { e.preventDefault(); c.click(); }
    });
  }

  /* app.js 의 세션 도우미를 쓴다. 웹앱에서 예전 app.js 가 캐시에 남아 새 이 파일과 섞이면
     T.withSession 이 없어 화면이 통째로 멈춘다 — 그때만 쓰는 대체 길을 둔다. */
  function sessGet(cb) {
    if (T.withSession) { T.withSession(cb); return; }
    sb.auth.getSession().then(function (r) {
      cb((r && r.data && r.data.session) || null, (r && r.error) || null);
    }, function (e) { cb(null, e || true); });
  }
  function sessOff(btn) {
    if (T.sessOffline) { T.sessOffline(btn); return; }
    if (btn && T.busy) T.busy(btn, false);
    if (toast) toast('연결이 원활하지 않아요. 잠시 후 다시 시도해 주세요.');
  }
  function uid(cb) {
    sessGet(function (ses, err) {
      if (ses) { cb(ses.user.id); return; }
      /* 토큰이 만료된 채 통신이 나쁘면 getSession 은 세션 없이 error 를 돌려준다(실측 25.5초) —
         로그아웃이 아니다. 01-splash 로 내보내면 app.js 첫머리가 todak_ocr_meds 를 지워
         사진으로 읽은 약이 전부 사라지고, 16 증상 기록·10 진료 질문·58 약 이름처럼 적던 것도
         함께 날아간다. 화면에 머물게 하고 알려만 드린다. (2026-09-28 · app.js withSession 참고) */
      if (err) { sessOff(); return; }
      location.replace('01-splash.html');
    });
  }

  /* ── 진료 준비 질문 (이 휴대폰에만 저장: todak_visit_q) ──
     syms·extras·qs = 10 에서 고른 증상과 그 증상으로 만든 질문
     manual        = 69·72 의 '진료 질문에 추가'로 넣은 질문 문장
     off           = 10 에서 뺀 것 (증상 이름 또는 질문 문장)
     at            = 마지막으로 고친 날 (YYYY-MM-DD)
     10·28·77·69·72 가 모두 이 도우미(T.vq)로 읽고 쓴다. */
  var VQ_KEY = 'todak_visit_q';
  function vqRead() {
    var v = null;
    try { v = JSON.parse(localStorage.getItem(VQ_KEY) || 'null'); } catch (e) { v = null; }
    if (!v || typeof v !== 'object') return null;
    /* 예전 69 는 질문 문장을 증상 칩(extras)에 넣었다 — 질문 목록으로 옮긴다 */
    if (v.extras && v.extras.length) {
      var keep = [];
      v.manual = v.manual || [];
      v.extras.forEach(function (x) {
        if (/[?？]/.test(String(x))) { if (v.manual.indexOf(x) < 0) v.manual.push(x); }
        else keep.push(x);
      });
      v.extras = keep;
    }
    if (v.at) v.at = String(v.at).slice(0, 10);
    return v;
  }
  function vqList(v) {                 /* 진료 때 여쭤볼 질문 전체 (증상 질문 + 따로 넣은 질문 중 켜진 것) */
    if (!v) return [];
    var out = (v.qs || []).slice(), off = v.off || {};
    (v.manual || []).forEach(function (q) { if (q && !off[q] && out.indexOf(q) < 0) out.push(q); });
    return out;
  }
  function vqAdd(q) {                  /* 'added' | 'again' | 'dup' | 'fail' */
    q = String(q || '').replace(/\s+/g, ' ').trim();
    if (!q) return 'fail';
    try {
      var v = vqRead() || {};
      v.manual = v.manual || []; v.off = v.off || {};
      var st = 'added';
      if (v.manual.indexOf(q) > -1 || (v.qs || []).indexOf(q) > -1) st = v.off[q] ? 'again' : 'dup';
      else v.manual.push(q);
      delete v.off[q];
      v.at = ymd(new Date());
      localStorage.setItem(VQ_KEY, JSON.stringify(v));
      return st;
    } catch (e) { return 'fail'; }
  }
  function vqToast(st) {
    if (st === 'added') toast('진료 준비 질문에 넣었어요 📝');
    else if (st === 'again') toast('진료 준비 질문에 다시 넣었어요 📝');
    else if (st === 'dup') toast('이미 진료 준비 질문에 있어요');
    else toast('저장하지 못했어요.');
  }
  T.vq = { KEY: VQ_KEY, read: vqRead, list: vqList, add: vqAdd, toast: vqToast };

  /* ── 73 치료 일정 ── */
  function page73() {
    var content = $('.content');
    var nowCard = $$('.card--tint', content)[0];
    var fStart = $$('.field').filter(function (f) { var l = $('label', f); return l && l.textContent.indexOf('시작일') > -1; })[0];
    var fCycle = $$('.field').filter(function (f) { var l = $('label', f); return l && l.textContent.indexOf('주기') > -1; })[0];
    var fTotal = $$('.field').filter(function (f) { var l = $('label', f); return l && l.textContent.indexOf('횟수') > -1; })[0];
    var visitItems = $$('.listitem', content);
    var visitRow = visitItems.filter(function (li) { return li.textContent.indexOf('진료 전 알림') < 0 && li.textContent.indexOf('리포트') < 0; })[0];
    var alarmRow = visitItems.filter(function (li) { return li.textContent.indexOf('진료 전 알림') > -1; })[0];

    /* 가짜 입력 → 진짜 입력으로 교체 */
    var startInput = null;
    if (fStart) {
      var fake = $('.input', fStart);
      startInput = document.createElement('input');
      startInput.type = 'date'; startInput.className = 'input';
      startInput.setAttribute('aria-label', '치료 시작일');
      if (fake) fake.parentNode.replaceChild(startInput, fake);
    }
    var CYCLE_MAP = { '매주': 1, '2주마다': 2, '3주마다': 3, '4주마다': 4 };
    var touched = {};                       /* 사용자가 손댄 그룹은 프리필이 덮지 않는다 */
    var cycleChips = fCycle ? $('.chips', fCycle) : null;
    if (cycleChips) $$('.chip', cycleChips).forEach(function (c) {
      c.classList.remove('chip--on');
      c.style.cursor = 'pointer';
      c.addEventListener('click', function (e) {
        e.preventDefault();
        touched.cycle = 1;
        $$('.chip', cycleChips).forEach(function (o) { o.classList.remove('chip--on'); });
        c.classList.add('chip--on');
        paintNow();
      });
    });
    chipState(cycleChips, true);
    var totalInput = null;
    if (fTotal) {
      var fake2 = $('.input', fTotal) || $('.row', fTotal);
      totalInput = document.createElement('input');
      totalInput.type = 'number'; totalInput.className = 'input';
      totalInput.min = '1'; totalInput.max = '30'; totalInput.placeholder = '예정된 총 횟수 (예: 4)';
      totalInput.setAttribute('aria-label', '예정 횟수');
      if (fake2) fake2.parentNode.replaceChild(totalInput, fake2);
    }
    var visitDate = null, visitTime = null, paintVisitDate = null, paintVisitTime = null;
    if (visitRow) {
      var body = $('.li-body', visitRow);
      var pillEl = $('.pill', visitRow);
      if (body) {
        body.innerHTML = '';
        body.className = 'li-body s73-visit-fields';
        visitDate = document.createElement('input');
        visitDate.type = 'date';
        visitDate.setAttribute('aria-label', '다음 진료 날짜');
        visitTime = document.createElement('input');
        visitTime.type = 'time';
        visitTime.setAttribute('aria-label', '진료 시간');
        var dateWrap = document.createElement('span');
        var dateText = document.createElement('span');
        dateWrap.className = 's73-pick'; dateText.className = 'input s73-pick-display';
        dateWrap.appendChild(dateText); dateWrap.appendChild(visitDate);
        var timeWrap = document.createElement('span');
        var timeText = document.createElement('span');
        timeWrap.className = 's73-pick'; timeText.className = 'input s73-pick-display';
        timeWrap.appendChild(timeText); timeWrap.appendChild(visitTime);
        paintVisitDate = function () {
          var p = String(visitDate.value || '').split('-');
          dateText.textContent = p.length === 3 ? p[0].slice(-2) + '. ' + Number(p[1]) + '. ' + Number(p[2]) + '.' : '날짜 선택';
        };
        paintVisitTime = function () { timeText.textContent = visitTime.value || '시간 선택'; };
        visitDate.addEventListener('change', paintVisitDate);
        visitTime.addEventListener('change', paintVisitTime);
        if (window.TDT) TDT.attach(visitTime);
        body.appendChild(dateWrap); body.appendChild(timeWrap);
        paintVisitDate(); paintVisitTime();
      }
      if (pillEl) {
        var visitSec = visitRow.parentNode;
        var visitTitle = visitSec ? $('.sec-t', visitSec) : null;
        if (visitTitle) {
          var visitHead = document.createElement('div');
          visitHead.className = 's73-visit-head';
          visitSec.insertBefore(visitHead, visitTitle);
          visitHead.appendChild(visitTitle);
          visitHead.appendChild(pillEl);
        }
        var upd = function () {
          if (!visitDate.value) { pillEl.textContent = '입력'; return; }
          var dv = Math.ceil((new Date(visitDate.value + 'T00:00:00') - new Date(ymd(new Date()) + 'T00:00:00')) / 86400000);
          pillEl.textContent = dv < 0 ? '지남' : dv === 0 ? '오늘' : '다음 진료까지 ' + dv + '일';
        };
        visitDate.addEventListener('change', upd);
        setTimeout(upd, 500);
      }
    }
    /* 알림 스위치 ↔ notif_prefs.visit_remind */
    var visitRemindOn = true;
    if (alarmRow) {
      var sw = $('.switch', alarmRow);
      if (sw) {
        var paintSw = function () {
          sw.classList[visitRemindOn ? 'remove' : 'add']('switch--off');
          sw.setAttribute('aria-checked', visitRemindOn ? 'true' : 'false');
        };
        sw.style.cursor = 'pointer';
        sw.addEventListener('click', function (e) { e.preventDefault(); touched.sw = 1; visitRemindOn = !visitRemindOn; paintSw(); });
        paintSw();
      }
    }

    function cycleWeeks() {
      var on = cycleChips ? $$('.chip--on', cycleChips)[0] : null;
      return on ? CYCLE_MAP[on.textContent.trim()] || null : null;
    }
    /* 예정 횟수: 1~30 정수만 받는다. 빈칸 = null, 잘못된 값 = NaN */
    function okTotal(v) { return typeof v === 'number' && v % 1 === 0 && v >= 1 && v <= 30; }
    function totalVal() {
      if (!totalInput) return null;
      if (totalInput.validity && totalInput.validity.badInput) return NaN;
      var s = String(totalInput.value || '').trim();
      if (!s) return null;
      var n = Number(s);
      return /^\d+$/.test(s) && okTotal(n) ? n : NaN;
    }
    function paintNow() {
      if (!nowCard) return;
      var title = $('.card-title', nowCard), sub = $('.card-sub', nowCard);
      var ring = $('.ring', nowCard), rin = $('.ring-in', nowCard);
      var cw = cycleWeeks();
      if (startInput && startInput.value && cw) {
        var cyc = cw * 7;
        var days = Math.floor((new Date(ymd(new Date()) + 'T00:00:00') - new Date(startInput.value + 'T00:00:00')) / 86400000);
        if (days >= 0) {
          var n = Math.floor(days / cyc) + 1, m = (days % cyc) + 1;
          var total = totalVal();
          if (!okTotal(total)) total = null;       /* 잘못 적은 값으로 '마쳤어요'를 띄우지 않는다 */
          if (total && n > total) {
            /* 예정 횟수를 지나면 계속 세지 않는다 */
            if (title) title.textContent = '예정한 ' + total + '회를 모두 마쳤어요';
            if (sub) sub.textContent = '고생 많으셨어요. 이제 다음 진료 일정만 안내해 드릴게요';
            if (ring) ring.style.setProperty('--p', '100%');
            if (rin) rin.innerHTML = total + '회<br>완료';
            return;
          }
          if (title) title.textContent = '항암 ' + n + '주기 · ' + m + '일차' + (total ? ' (총 ' + total + '회 예정)' : '');
          if (sub) sub.textContent = '다음 주사까지 ' + (cyc - (days % cyc)) + '일 남았어요';
          if (ring) ring.style.setProperty('--p', Math.round(100 * m / cyc) + '%');
          if (rin) rin.innerHTML = m + '/' + cyc + '<br>일';
          return;
        }
        if (title) title.textContent = '치료 시작 전이에요';
        if (sub) sub.textContent = '시작일이 되면 주기를 계산해 드려요';
        if (ring) ring.style.setProperty('--p', '0%');
        if (rin) rin.innerHTML = '준비';
        return;
      }
      if (title) title.textContent = '치료 일정을 입력해 주세요';
      if (sub) sub.textContent = '시작일과 주기를 알려 주시면 계산해 드려요';
      if (ring) ring.style.setProperty('--p', '0%');
      if (rin) rin.innerHTML = '－';
    }
    if (startInput) startInput.addEventListener('change', paintNow);
    if (totalInput) totalInput.addEventListener('change', paintNow);
    paintNow();

    /* 저장 버튼 (앱바 ✏️ → 저장) */
    var saveBtn = $('.appbar .action');
    if (saveBtn) {
      saveBtn.textContent = '저장';
      saveBtn.style.cssText = 'color:var(--primary-dark);font-weight:800;cursor:pointer;font-size:15px;';
      saveBtn.setAttribute('role', 'button'); saveBtn.setAttribute('tabindex', '0');
    }

    /* 기존 값 불러오기 (불러오기 전 저장 금지) */
    var ready = false, prof = null;
    function load() {
      uid(function (id) {
        sb.from('profiles').select('treatment,notif_prefs').eq('id', id).maybeSingle().then(function (r) {
          if (r.error) return;
          prof = r.data || {};
          ready = true;
          var t = prof.treatment || {};
          if (t.chemo_start && startInput && !startInput.value) startInput.value = t.chemo_start;
          if (t.cycle_weeks && cycleChips && !touched.cycle && !$$('.chip--on', cycleChips).length) {
            $$('.chip', cycleChips).forEach(function (c) {
              if (CYCLE_MAP[c.textContent.trim()] === t.cycle_weeks) c.classList.add('chip--on');
            });
          }
          /* 예정 횟수는 숫자형 정수이거나 숫자만 있는 글자('4'·'04')면 받는다 — 05 features.js okInt 와 같은 기준 (4차) */
          var tv = typeof t.total_cycles === 'string' && /^\d+$/.test(t.total_cycles) ? Number(t.total_cycles) : t.total_cycles;
          if (okTotal(tv) && totalInput && !totalInput.value) totalInput.value = tv;
          if (t.next_visit && visitDate && !visitDate.value) {
            visitDate.value = t.next_visit;
            visitDate.dispatchEvent(new Event('change'));
          }
          if (t.next_visit_time && visitTime && !visitTime.value) { visitTime.value = t.next_visit_time; if (paintVisitTime) paintVisitTime(); }
          var np = prof.notif_prefs || {};
          if (!touched.sw) visitRemindOn = ('visit_remind' in np) ? !!np.visit_remind : true;
          if (alarmRow) { var sw2 = $('.switch', alarmRow); if (sw2) { sw2.classList[visitRemindOn ? 'remove' : 'add']('switch--off'); sw2.setAttribute('aria-checked', visitRemindOn ? 'true' : 'false'); } }
          paintNow();
        });
      });
    }
    load();

    var dirty = false;
    [startInput, totalInput, visitDate, visitTime].forEach(function (i) { if (i) i.addEventListener('change', function () { dirty = true; }); });
    /* T.dirty 도 켜야 당겨서 새로고침(native.js)이 고른 값을 지우지 않는다 */
    [startInput, totalInput, visitDate, visitTime].forEach(function (i) { if (i) i.addEventListener('input', function () { T.dirty = 1; }); });
    if (cycleChips) cycleChips.addEventListener('click', function () { dirty = true; T.dirty = 1; });
    if (alarmRow) alarmRow.addEventListener('click', function () { dirty = true; T.dirty = 1; });
    function doSave(after) {
      if (saveBtn && saveBtn.__busy) return;                 /* 연타 방지 */
      if (!ready) { toast('이전 일정을 확인하는 중이에요.\n잠시 후 다시 눌러 주세요.'); load(); return; }
      var total = totalVal();
      if (total !== null && !okTotal(total)) {
        toast('예정 횟수는 1부터 30 사이의\n숫자로 적어 주세요.');
        try { totalInput.focus(); } catch (e) {}
        return;
      }
      if (saveBtn) saveBtn.__busy = true;
      var part = {
        chemo_start: (startInput && startInput.value) || null,
        cycle_weeks: cycleWeeks(),
        total_cycles: total,
        next_visit: (visitDate && visitDate.value) || null,
        next_visit_time: (visitTime && visitTime.value) || null
      };
      var np = (prof && prof.notif_prefs) || {};
      np.visit_remind = visitRemindOn;
      /* treatment 는 병원 연락처(84)·치료 종류(04)와 같은 칸을 쓰므로 병합 저장 */
      T.mergeTreatment(part, function (r) {
        if (r && r.error) { if (saveBtn) saveBtn.__busy = false; return toast(koError(r.error)); }
        uid(function (id) {
          sb.from('profiles').update({ notif_prefs: np }).eq('id', id).then(function (r2) {
            if (r2 && r2.error) { if (saveBtn) saveBtn.__busy = false; return toast(koError(r2.error)); }
            if (saveBtn) saveBtn.__busy = false;
            dirty = false;
            for (var k in part) (prof.treatment = prof.treatment || {})[k] = part[k];
            prof.notif_prefs = np;
            toast('치료 일정을 저장했어요 📅');
            paintNow();
            if (window.TDN && window.TDN.notifySync) window.TDN.notifySync(function (st) {
              if (visitRemindOn && window.TDN.deniedToast) window.TDN.deniedToast(st);
            });
            if (after) after();
          }, function () { if (saveBtn) saveBtn.__busy = false; toast('연결이 원활하지 않아요. 다시 시도해 주세요.'); });
        });
      });
    }
    function savedTarget() {
      var m = /[?&]from=([^&#]+)/.exec(location.search || '');
      var to = '05-home.html';
      if (m) {
        try { to = decodeURIComponent(m[1]); } catch (e) { to = '05-home.html'; }
      }
      return /^[0-9a-z-]+\.html(?:[?#].*)?$/i.test(to) ? to : '05-home.html';
    }
    if (saveBtn) saveBtn.addEventListener('click', function (e) {
      e.preventDefault();
      doSave(function () { setTimeout(function () { location.replace(savedTarget()); }, 350); });
    });
    /* 저장을 안 누르고 뒤로 나가면 입력이 사라지므로 자동 저장 후 이동 */
    var backA = $('.appbar .back');
    if (backA) backA.addEventListener('click', function (e) {
      if (!dirty) return;
      e.preventDefault(); e.stopPropagation();
      var to = backA.getAttribute('href') || '13-settings.html';
      doSave(function () { setTimeout(function () { location.replace(to); }, 400); });
    });
  }

  /* ── 73 치료 일정 v2 — 여러 진료를 저장하고 기존 next_visit 소비자는 그대로 둔다 ── */
  function page73Visits() {
    var content = $('.content');
    var nowCard = $('[data-role="visit-summary"]', content);
    var immune = $('[data-role="immune-window"]', content);
    var visitList = $('[data-role="visit-list"]', content);
    var addBtn = $('[data-act="add-visit"]', content);
    var badge = $('[data-role="next-visit-badge"]', content);
    var visitItems = $$('.listitem', content);
    var alarmRow = visitItems.filter(function (li) { return li.textContent.indexOf('진료 전 알림') > -1; })[0];
    var saveBtn = $('.appbar .action');
    var rows = [], prof = null, ready = false, dirty = false, touchedSw = false, visitRemindOn = true;

    function dayOk(v) {
      var m = typeof v === 'string' && /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
      if (!m) return false;
      var d = new Date(+m[1], +m[2] - 1, +m[3]);
      return d.getFullYear() === +m[1] && d.getMonth() === +m[2] - 1 && d.getDate() === +m[3];
    }
    function timeOk(v) { return typeof v === 'string' && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(v); }
    function today() { return ymd(new Date()); }
    function dayDiff(a, b) {
      return Math.round((new Date(a + 'T00:00:00') - new Date(b + 'T00:00:00')) / 86400000);
    }
    function dateText(v) {
      var p = String(v || '').split('-');
      return p.length === 3 ? p[0].slice(-2) + '. ' + Number(p[1]) + '. ' + Number(p[2]) + '.' : '날짜 선택';
    }
    function normalize(raw) {
      var seen = {}, out = [];
      (Array.isArray(raw) ? raw : []).forEach(function (v) {
        if (!v || !dayOk(v.d) || seen[v.d]) return;
        seen[v.d] = 1;
        out.push({ d: v.d, t: timeOk(v.t) ? v.t : null });
      });
      out.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : 0; });
      return out;
    }
    function rowValue(row) {
      return row && dayOk(row.date.value) ? { d: row.date.value, t: timeOk(row.time.value) ? row.time.value : null } : null;
    }
    function collect() {
      return normalize(rows.map(rowValue).filter(function (v) { return !!v; }));
    }
    function markDirty() { dirty = true; T.dirty = 1; }

    function paintSummary() {
      var items = collect(), td = today(), future = items.filter(function (v) { return v.d >= td; });
      var past = items.filter(function (v) { return v.d < td; });
      var next = future[0] || null, title = nowCard ? $('.card-title', nowCard) : null;
      var sub = nowCard ? $('.card-sub', nowCard) : null, ring = nowCard ? $('.ring', nowCard) : null;
      var rin = nowCard ? $('.ring-in', nowCard) : null, total = items.length, completed = past.length;
      if (next) {
        var left = dayDiff(next.d, td);
        if (title) title.textContent = '진료 ' + completed + '/' + total + '회';
        if (sub) sub.textContent = left === 0 ? '오늘 진료가 있어요' : '다음 진료까지 ' + left + '일 남았어요';
        if (badge) badge.textContent = left === 0 ? '오늘' : '다음 진료까지 ' + left + '일';
        if (ring) ring.style.setProperty('--p', Math.round(100 * completed / total) + '%');
        if (rin) rin.innerHTML = completed + '/' + total + '<br>회';
      } else if (total) {
        if (title) title.textContent = '등록한 진료 ' + total + '회';
        if (sub) sub.textContent = '다가올 진료를 추가해 주세요';
        if (badge) badge.textContent = '예정 없음';
        if (ring) ring.style.setProperty('--p', '100%');
        if (rin) rin.innerHTML = total + '회<br>등록';
      } else {
        if (title) title.textContent = '등록된 진료가 없어요';
        if (sub) sub.textContent = '정해진 진료 날짜를 추가해 주세요';
        if (badge) badge.textContent = '일정 없음';
        if (ring) ring.style.setProperty('--p', '0%');
        if (rin) rin.innerHTML = '0회';
      }
      var last = past.length ? past[past.length - 1] : null;
      var since = last ? dayDiff(td, last.d) : -1;
      /* '항암 주사 뒤 7~14일은 면역이 낮아요'는 04 에서 항암화학요법을 고르신 분께만 띄운다 (교수님 2026-10-01: 항암 치료 중인지 모르잖아).
         진료 날짜만으로는 항암 주사를 맞으신 분인지 알 수 없다 — 항암을 고르지 않았거나 치료 종류를 아직 모르면 띄우지 않는다 */
      var trs = prof && prof.treatment && Array.isArray(prof.treatment.treatments) ? prof.treatment.treatments : [];
      var chemo = trs.indexOf('항암화학요법') > -1;
      if (immune) immune.style.display = chemo && since >= 7 && since <= 14 ? '' : 'none';
    }
    function reorderRows() {
      if (!visitList) return;
      var td = today();
      var ordered = rows.slice().sort(function (a, b) {
        var av = rowValue(a), bv = rowValue(b);
        if (!av && !bv) return 0;
        if (!av) return -1;
        if (!bv) return 1;
        var ap = av.d < td, bp = bv.d < td;
        if (ap !== bp) return ap ? 1 : -1;
        if (ap) return av.d > bv.d ? -1 : av.d < bv.d ? 1 : 0;
        return av.d < bv.d ? -1 : av.d > bv.d ? 1 : 0;
      });
      ordered.forEach(function (row) {
        var v = rowValue(row);
        row.el.classList[v && v.d < td ? 'add' : 'remove']('is-past');
        visitList.appendChild(row.el);
      });
    }
    function removeRow(row) {
      var at = rows.indexOf(row);
      if (at > -1) rows.splice(at, 1);
      if (row.el.parentNode) row.el.parentNode.removeChild(row.el);
      if (!rows.length) addRow(null, false);
      markDirty(); reorderRows(); paintSummary();
    }
    function addRow(value, changed) {
      if (!visitList) return null;
      var el = document.createElement('div');
      el.className = 's73-visit-row';
      var dateWrap = document.createElement('span'), dateTextEl = document.createElement('span');
      var date = document.createElement('input');
      dateWrap.className = 's73-pick'; dateTextEl.className = 'input s73-pick-display';
      date.type = 'date'; date.setAttribute('aria-label', '진료 날짜');
      dateWrap.appendChild(dateTextEl); dateWrap.appendChild(date);
      var timeWrap = document.createElement('span'), timeTextEl = document.createElement('span');
      var time = document.createElement('input');
      timeWrap.className = 's73-pick'; timeTextEl.className = 'input s73-pick-display';
      time.type = 'time'; time.setAttribute('aria-label', '진료 시간');
      timeWrap.appendChild(timeTextEl); timeWrap.appendChild(time);
      var del = document.createElement('button');
      del.type = 'button'; del.className = 's73-remove'; del.textContent = '×'; del.setAttribute('aria-label', '이 진료 지우기');
      el.appendChild(dateWrap); el.appendChild(timeWrap); el.appendChild(del);
      visitList.appendChild(el);
      var row = { el: el, date: date, time: time, dateText: dateTextEl, timeText: timeTextEl };
      rows.push(row);
      if (value) { date.value = value.d || ''; time.value = value.t || ''; }
      function paintFields() {
        dateTextEl.textContent = dateText(date.value);
        timeTextEl.textContent = timeOk(time.value) ? time.value : '시간 선택';
      }
      /* 날짜 칸은 글자를 우리가 그리느라 입력칸을 거의 투명하게 덮어 두었다. 안드로이드 웹뷰에서는
         그런 칸을 눌러도 달력이 안 열리는 일이 있어, 눌리면 달력을 직접 연다 (교수님 2026-09-30) */
      dateWrap.addEventListener('click', function () {
        try { if (date.showPicker) date.showPicker(); } catch (ePick) {}
      });
      date.addEventListener('change', function () { paintFields(); markDirty(); reorderRows(); paintSummary(); });
      time.addEventListener('change', function () { paintFields(); markDirty(); paintSummary(); });
      date.addEventListener('input', markDirty); time.addEventListener('input', markDirty);
      del.addEventListener('click', function () { removeRow(row); });
      if (window.TDT) TDT.attach(time);
      paintFields();
      if (changed) markDirty();
      return row;
    }
    function renderRows(items) {
      rows = [];
      if (visitList) visitList.innerHTML = '';
      var td = today();
      var upcoming = items.filter(function (v) { return v.d >= td; });
      var past = items.filter(function (v) { return v.d < td; }).reverse();
      upcoming.concat(past).forEach(function (v) { addRow(v, false); });
      if (!rows.length) addRow(null, false);
      reorderRows(); paintSummary();
    }

    if (addBtn) addBtn.addEventListener('click', function () { var row = addRow(null, true); reorderRows(); paintSummary(); try { row.date.focus(); } catch (e) {} });
    if (saveBtn) {
      saveBtn.textContent = '저장';
      saveBtn.style.cssText = 'color:var(--primary-dark);font-weight:800;cursor:pointer;font-size:15px;';
      saveBtn.setAttribute('role', 'button'); saveBtn.setAttribute('tabindex', '0');
    }
    function paintSwitch() {
      var sw = alarmRow ? $('.switch', alarmRow) : null;
      if (!sw) return;
      sw.classList[visitRemindOn ? 'remove' : 'add']('switch--off');
      sw.setAttribute('aria-checked', visitRemindOn ? 'true' : 'false');
    }
    if (alarmRow) {
      var sw = $('.switch', alarmRow);
      if (sw) {
        sw.style.cursor = 'pointer';
        sw.addEventListener('click', function (e) {
          e.preventDefault(); touchedSw = true; visitRemindOn = !visitRemindOn; markDirty(); paintSwitch();
        });
      }
    }
    paintSwitch();

    function loadFail() {
      ready = false;
      if (nowCard) {
        var title = $('.card-title', nowCard), sub = $('.card-sub', nowCard), rin = $('.ring-in', nowCard);
        if (title) title.textContent = '진료 일정을 불러오지 못했어요';
        if (sub) sub.textContent = '연결을 확인한 뒤 다시 열어 주세요';
        if (rin) rin.innerHTML = '－';
      }
      if (badge) badge.textContent = '확인 필요';
      if (immune) immune.style.display = 'none';
    }
    function load() {
      uid(function (id) {
        sb.from('profiles').select('treatment,notif_prefs').eq('id', id).maybeSingle().then(function (r) {
          if (!r || r.error) { loadFail(); return; }
          prof = r.data || {}; ready = true;
          var t = prof.treatment || {}, items;
          if (Array.isArray(t.visits)) items = normalize(t.visits);
          else items = normalize(dayOk(t.next_visit) ? [{ d: t.next_visit, t: timeOk(t.next_visit_time) ? t.next_visit_time : null }] : []);
          var np = prof.notif_prefs || {};
          if (!touchedSw) visitRemindOn = ('visit_remind' in np) ? !!np.visit_remind : true;
          paintSwitch(); renderRows(items);
        }, loadFail);
      });
    }
    renderRows([]); load();

    function savedTarget() {
      var m = /[?&]from=([^&#]+)/.exec(location.search || ''), to = '05-home.html';
      if (m) { try { to = decodeURIComponent(m[1]); } catch (e) { to = '05-home.html'; } }
      return /^[0-9a-z-]+\.html(?:[?#].*)?$/i.test(to) ? to : '05-home.html';
    }
    function doSave(after) {
      if (saveBtn && saveBtn.__busy) return;
      if (!ready) { toast('이전 일정을 확인하는 중이에요.\n잠시 후 다시 눌러 주세요.'); load(); return; }
      var items = collect(), td = today();
      var future = items.filter(function (v) { return v.d >= td; });
      var next = future[0] || null;
      var part = { visits: items, next_visit: next ? next.d : null, next_visit_time: next ? next.t : null };
      var np = (prof && prof.notif_prefs) || {};
      np.visit_remind = visitRemindOn;
      if (saveBtn) saveBtn.__busy = true;
      T.mergeTreatment(part, function (r) {
        if (r && r.error) { if (saveBtn) saveBtn.__busy = false; toast(koError(r.error)); return; }
        uid(function (id) {
          sb.from('profiles').update({ notif_prefs: np }).eq('id', id).then(function (r2) {
            if (r2 && r2.error) { if (saveBtn) saveBtn.__busy = false; toast(koError(r2.error)); return; }
            if (saveBtn) saveBtn.__busy = false;
            prof.treatment = prof.treatment || {};
            prof.treatment.visits = items; prof.treatment.next_visit = part.next_visit; prof.treatment.next_visit_time = part.next_visit_time;
            prof.notif_prefs = np; dirty = false; renderRows(items);
            toast('치료 일정을 저장했어요 📅');
            if (window.TDN && window.TDN.notifySync) window.TDN.notifySync(function (st) {
              if (visitRemindOn && window.TDN.deniedToast) window.TDN.deniedToast(st);
            });
            if (after) after();
          }, function () { if (saveBtn) saveBtn.__busy = false; toast('연결이 원활하지 않아요. 다시 시도해 주세요.'); });
        });
      });
    }
    if (saveBtn) saveBtn.addEventListener('click', function (e) {
      e.preventDefault(); doSave(function () { setTimeout(function () { location.replace(savedTarget()); }, 350); });
    });
    var backA = $('.appbar .back');
    if (backA) backA.addEventListener('click', function (e) {
      if (!dirty) return;
      e.preventDefault(); e.stopPropagation();
      var to = backA.getAttribute('href') || '13-settings.html';
      doSave(function () { setTimeout(function () { location.replace(to); }, 400); });
    });
  }

  /* ── 98 한달 기록 ── */
  function page98() {
    var card = $$('.card')[0];
    if (!card) return;
    var titleEl = $('.card-title', card);
    var arrows = $$('a[aria-label]', card);
    var prevA = arrows[0], nextA = arrows[1];
    var grids = $$('div[style*="repeat(7"]', card);
    var dayGrid = grids[1];               /* [0]=요일 헤더, [1]=날짜 */
    var tnums = $$('.tile .t-num'), tlabs = $$('.tile .t-lab');
    var symCard = $$('.card--flat').filter(function (c) { return $('.col', c); })[0];
    var symLab = symCard ? symCard.previousElementSibling : null;
    if (symLab && !symLab.classList.contains('section-label')) symLab = null;
    var monthOffset = 0, seq = 0;

    var DOT = { good: 'var(--safe)', mid: 'var(--warn)', bad: 'var(--danger)', none: 'var(--surface-3)' };
    var SEVC = { '없음': 'sev--mild', '약함': 'sev--mild', '보통': 'sev--mod', '심함': 'sev--sev', '매우 심함': 'sev--sev' };

    /* 날짜를 누르면 그날 기록을 아래에 펼쳐 보여줄 카드 */
    var detail = document.createElement('div');
    detail.className = 'card';
    detail.style.display = 'none';
    if (card.parentNode) card.parentNode.insertBefore(detail, card.nextSibling);
    function showDetail(row) {
      if (!row || !row.mood) {
        detail.innerHTML = '<div class="card-sub">이날은 기록이 없어요.</div>';
        detail.style.display = '';
        return;
      }
      var d = new Date(row.date + 'T00:00:00');
      var ms = row.mood >= 4 ? ['좋음', 'sev--mild'] : row.mood === 3 ? ['보통', 'sev--mod'] : ['힘듦', 'sev--sev'];
      var h = '<div class="row" style="justify-content:space-between; align-items:center;">'
        + '<div class="card-title" style="margin:0;">' + kdate(d) + ' (' + WDAY[d.getDay()] + ') 기록</div>'
        + '<span class="sev ' + ms[1] + '">기분 ' + ms[0] + '</span></div>';
      var syms = row.symptoms || [];
      if (syms.length) {
        h += '<div class="section-label" style="margin-top:12px;">겪은 증상</div><div class="col gap-6" style="margin-top:6px;">';
        syms.forEach(function (s) {
          var lv = row.intensity && row.intensity[s];
          h += '<div class="row" style="align-items:center; gap:8px;">'
            + (lv ? '<span class="sev ' + (SEVC[lv] || 'sev--mild') + '" style="flex:0 0 auto;">' + lv + '</span>' : '<span class="tiny muted" style="flex:0 0 auto;">·</span>')
            + '<span class="small grow">' + esc(s) + '</span></div>';
        });
        h += '</div>';
      } else {
        h += '<div class="small muted" style="margin-top:10px;">그날 고른 증상은 없어요.</div>';
      }
      if (row.memo) {
        h += '<div class="section-label" style="margin-top:12px;">메모</div>'
          + '<div class="small" style="margin-top:6px; white-space:pre-wrap;">' + esc(row.memo) + '</div>';
      }
      detail.innerHTML = h;
      detail.style.display = '';
    }

    function paintMonth() {
      if (!dayGrid) return;
      var my = ++seq;
      detail.style.display = 'none';
      /* 이전 달 값이 새 달 제목 밑에 남지 않게 먼저 비운다 */
      dayGrid.innerHTML = '';
      if (tnums[0]) tnums[0].textContent = '…';
      if (tnums[1]) tnums[1].textContent = '…';
      if (!$('.dot-legend', card)) {
        var lg = document.createElement('div'); lg.className = 'dot-legend tiny muted'; lg.style.cssText = 'margin-top:8px;line-height:1.6;';
        /* 색 설명은 화면에 이미 있다 — 여기서는 사용법만 알려 준다 */
        lg.textContent = '날짜를 누르면 그날 기록이 아래에 열려요';
        card.appendChild(lg);
      }
      var base = new Date();
      var first = new Date(base.getFullYear(), base.getMonth() + monthOffset, 1);
      var last = new Date(first.getFullYear(), first.getMonth() + 1, 0);
      if (titleEl) titleEl.textContent = first.getFullYear() + '년 ' + (first.getMonth() + 1) + '월';
      /* 지난달을 볼 때 '이번 달'이라고 적지 않는다 */
      var mname = monthOffset === 0 ? '이번 달' : (first.getMonth() + 1) + '월';
      if (tlabs[1]) tlabs[1].textContent = mname + ' 평균';
      if (symLab) symLab.textContent = mname + ' 자주 겪은 증상';
      /* 시안 예시 막대·이전 달 막대가 불러오는 동안 남지 않게 숨겨 둔다 (불러온 뒤 증상이 있으면 다시 보인다) */
      if (symCard) symCard.style.display = 'none';
      if (symLab) symLab.style.display = 'none';
      if (nextA) {
        nextA.style.opacity = monthOffset === 0 ? '.35' : '1';
        nextA.setAttribute('aria-disabled', monthOffset === 0 ? 'true' : 'false');
      }
      sb.from('checkins').select('date,mood,symptoms,intensity,memo')
        .gte('date', ymd(first)).lte('date', ymd(last))
        .then(function (r) {
          if (my !== seq) return;
          var rowmap = {};
          (r.data || []).forEach(function (row) { rowmap[row.date] = row; });
          if (r.error) { toast('연결이 원활하지 않아요.\n당겨서 새로고침하거나 잠시 후 다시 열어 주세요.'); return; }
          var map = {}, moods = [], symCount = {};
          (r.data || []).forEach(function (row) {
            map[row.date] = row.mood;
            if (row.mood) moods.push(row.mood);
            (row.symptoms || []).forEach(function (s) { symCount[s] = (symCount[s] || 0) + 1; });
          });
          /* 달력 */
          dayGrid.innerHTML = '';
          var lead = (first.getDay() + 6) % 7;   /* 월요일 시작 */
          var i;
          for (i = 0; i < lead; i++) dayGrid.appendChild(document.createElement('div'));
          var todayS = ymd(new Date());
          for (i = 1; i <= last.getDate(); i++) {
            var d = new Date(first.getFullYear(), first.getMonth(), i);
            var ds = ymd(d);
            var cell = document.createElement('div');
            var isToday = ds === todayS;
            var isFuture = ds > todayS;
            cell.setAttribute('style', 'display:flex;flex-direction:column;align-items:center;gap:3px;padding:5px 0;'
              + (isToday ? 'border:1.5px solid var(--primary);border-radius:10px;background:var(--primary-tint);' : ''));
            var mood = map[ds];
            var color = mood ? (mood >= 4 ? DOT.good : mood === 3 ? DOT.mid : DOT.bad) : DOT.none;
            cell.innerHTML = '<div class="tiny' + (isToday ? ' strong' : '') + '" style="color:'
              + (isToday ? 'var(--primary-dark)' : isFuture ? 'var(--on-surface-variant)' : 'var(--on-surface)') + ';">' + i + '</div>'
              + '<span style="width:8px;height:8px;border-radius:50%;background:' + (isFuture ? 'transparent' : color) + ';"></span>';
            if (!isFuture && rowmap[ds]) {
              cell.style.cursor = 'pointer';
              cell.style.borderBottom = '2px solid ' + color;
              cell.setAttribute('data-ds', ds);
              cell.addEventListener('click', function () { showDetail(rowmap[this.getAttribute('data-ds')]); });
            } else if (!isFuture) {
              cell.style.cursor = 'pointer';
              cell.addEventListener('click', function () { showDetail(null); });
            }
            dayGrid.appendChild(cell);
          }
          /* 통계 */
          if (tnums[0]) tnums[0].textContent = moods.length + '일';
          if (tnums[1]) {
            var avg = moods.length ? moods.reduce(function (a, b) { return a + b; }, 0) / moods.length : 0;
            tnums[1].textContent = !moods.length ? '－' : avg >= 3.5 ? '좋음' : avg >= 2.5 ? '보통' : '힘듦';
          }
          /* 자주 겪은 증상 */
          if (symCard) {
            var rows = $$('.col > div', symCard);
            var top = Object.keys(symCount).map(function (k) { return [k, symCount[k]]; })
              .sort(function (a, b) { return b[1] - a[1]; }).slice(0, rows.length);
            rows.forEach(function (row, ri) {
              if (ri < top.length) {
                row.style.display = '';
                var nameEl = $('.strong', row), cntEl = $('.tiny', row);
                var bar = $('div[style*="width"]', $('div[style*="height:8px"]', row));
                if (nameEl) nameEl.textContent = top[ri][0];
                if (cntEl) cntEl.textContent = top[ri][1] + '일';
                if (bar) bar.style.width = Math.round(100 * top[ri][1] / Math.max(1, moods.length)) + '%';
              } else row.style.display = 'none';
            });
            var note = $('p', symCard);
            if (note) note.style.display = top.length ? '' : 'none';
            /* 증상이 없는 달은 제목과 카드를 함께 숨기고, 있는 달로 옮기면 둘 다 다시 보인다 */
            symCard.style.display = top.length ? '' : 'none';
            if (symLab) symLab.style.display = top.length ? '' : 'none';
          }
        });
    }
    if (prevA) prevA.addEventListener('click', function (e) { e.preventDefault(); monthOffset--; paintMonth(); });
    if (nextA) nextA.addEventListener('click', function (e) { e.preventDefault(); if (monthOffset < 0) { monthOffset++; paintMonth(); } });
    paintMonth();
  }

  /* ── 10 진료 준비 (질문 만들기 — 고른 내용은 기기에 저장돼 다시 열어도 남는다) ── */
  function page10() {
    var fSym = $$('.field')[0];
    var chips = fSym ? $('.chips', fSym) : null;
    var qCards = $$('.card').filter(function (c) { return $('.s-box', c); });
    var qWrap = null, qTmpl = null;
    if (qCards.length) {
      qTmpl = qCards[0].cloneNode(true);
      qWrap = document.createElement('div');
      qWrap.className = 'col gap-10';
      qCards[0].parentNode.insertBefore(qWrap, qCards[0]);
      qCards.forEach(function (c) { c.parentNode.removeChild(c); });
    }
    var saved = vqRead();
    var offMap = (saved && saved.off) || {};
    var manual = ((saved && saved.manual) || []).slice();   /* 69·72 에서 넣은 질문 문장 */

    var TPL = {
      '손발 저림': '손발 저림이 계속돼요. 치료약과 관련이 있는지, 조절이 필요한 정도인지 봐 주실 수 있나요?',
      '관절통': '관절통이 아침에 특히 심해 일상이 불편해요. 도움이 될 방법이나 약이 있을까요?',
      '피로': '피로가 오래가는데, 검사가 필요한 정도인지 궁금해요.',
      '메스꺼움': '메스꺼움이 반복되는데, 지금 처방으로 충분한지 봐 주실 수 있나요?',
      '수면 문제': '잠들기 어렵고 자주 깨요. 치료와 관련이 있는지, 도움 받을 방법이 있는지 궁금해요.',
      '열감': '열감·안면홍조가 자주 있는데 조절할 방법이 있을까요?',
      '구내염': '입안이 헐어 식사가 힘든 날이 있어요. 관리 방법이나 약을 알려 주실 수 있나요?',
      '두통': '두통이 잦아졌는데 치료와 관련이 있는지 궁금해요.'
    };
    function makeQ(sym) {
      return TPL[sym] || ('요즘 "' + sym + '" 증상이 잦은데, 진료 때 봐 주실 수 있을까요?');
    }
    function selectedSyms() {
      return $$('.chip--on', chips).map(function (c) { return c.textContent.replace(/\s+/g, ' ').trim(); })
        .filter(function (t) { return t.indexOf('＋') !== 0; });
    }
    function saveQ() {
      try {
        var extras = $$('.chip', chips).map(function (c) { return c.textContent.trim(); })
          .filter(function (t) { return t.indexOf('＋') !== 0 && BASE.indexOf(t) < 0; });
        var qs = selectedSyms().filter(function (sym) { return !offMap[sym]; }).map(makeQ);
        var cur = vqRead() || {};           /* 다른 칸(알 수 없는 값)은 그대로 둔다 */
        cur.syms = selectedSyms(); cur.extras = extras; cur.off = offMap; cur.qs = qs;
        cur.manual = manual; cur.at = ymd(new Date());
        localStorage.setItem(VQ_KEY, JSON.stringify(cur));
      } catch (e) {}
    }
    /* 질문 카드 하나 — key 는 켜고 끌 때 off 에 적는 이름(증상 이름 또는 질문 문장) */
    function qCard(text, key) {
      var c = qTmpl.cloneNode(true);
      var txt = $('.small', c);
      if (txt) txt.textContent = text;
      var box = $('.s-box', c);
      var on = !offMap[key];
      function paint() {
        if (!box) return;
        box.textContent = on ? '✓' : '';
        box.style.background = on ? 'var(--primary)' : 'transparent';
        box.style.borderColor = on ? 'var(--primary)' : 'var(--outline-strong)';
        box.style.color = '#fff';
      }
      paint();
      c.style.cursor = 'pointer';
      c.addEventListener('click', function () {
        on = !on;
        if (on) delete offMap[key]; else offMap[key] = 1;
        paint(); saveQ();
      });
      return c;
    }
    function render() {
      if (!qWrap || !qTmpl || !chips) return;
      qWrap.innerHTML = '';
      var sel = selectedSyms();
      sel.forEach(function (sym) { qWrap.appendChild(qCard(makeQ(sym), sym)); });
      if (!sel.length) {
        var em = document.createElement('div');
        em.className = 'banner banner--info';
        em.innerHTML = '<span class="b-ic">💡</span><div class="small">위에서 증상을 고르면 질문을 만들어 드려요.</div>';
        qWrap.appendChild(em);
      }
      /* '이거 먹어도 되나요?' 등에서 넣은 질문 — 눌러서 빼거나 다시 넣을 수 있다 */
      if (manual.length) {
        var lab = document.createElement('div');
        lab.className = 'tiny strong';
        lab.style.cssText = 'color:var(--primary-dark); margin-top:4px;';
        lab.textContent = '따로 넣어 두신 질문';
        qWrap.appendChild(lab);
        manual.forEach(function (q) { qWrap.appendChild(qCard(q, q)); });
      }
    }
    function addCustomChip(v, on) {
      var plus = $$('.chip', chips).filter(function (c) { return c.textContent.trim().indexOf('＋') === 0; })[0];
      var nc = document.createElement('span');
      nc.className = 'chip' + (on ? ' chip--on' : '');
      nc.textContent = v;
      nc.style.cursor = 'pointer';
      nc.addEventListener('click', function () { nc.classList.toggle('chip--on'); render(); saveQ(); });
      chips.insertBefore(nc, plus || null);
      return nc;
    }
    var BASE = [];
    if (chips) {
      $$('.chip', chips).forEach(function (c) {
        var t = c.textContent.trim();
        c.classList.remove('chip--on');
        c.style.cursor = 'pointer';
        if (t.indexOf('＋') === 0) {
          c.addEventListener('click', function (e) {
            e.preventDefault();
            var inp = chips.__inp;
            if (!inp) {
              inp = document.createElement('input');
              inp.className = 'input'; inp.placeholder = '증상을 적어 주세요 (예: 두근거림)';
              inp.setAttribute('aria-label', '직접 입력할 증상');
              inp.style.marginTop = '10px';
              chips.parentNode.insertBefore(inp, chips.nextSibling);
              chips.__inp = inp;
              /* 엔터를 누르거나 다른 곳을 누르면(칸을 벗어나면) 칩으로 넣는다 — 적은 글이 사라지지 않게 */
              var commit = function () {
                var v = inp.value.replace(/\s+/g, ' ').trim(); if (!v) return;
                inp.value = '';
                var dup = $$('.chip', chips).filter(function (c2) { return c2.textContent.trim() === v; })[0];
                if (dup) dup.classList.add('chip--on');
                else addCustomChip(v, true);
                render(); saveQ();
              };
              inp.addEventListener('keydown', function (ev) {
                if (ev.key !== 'Enter') return;
                ev.preventDefault();
                commit();
              });
              inp.addEventListener('blur', commit);
            }
            inp.focus();
          });
        } else {
          c.addEventListener('click', function (e) { e.preventDefault(); c.classList.toggle('chip--on'); render(); saveQ(); });
        }
      });
      BASE = $$('.chip', chips).map(function (c) { return c.textContent.trim(); });
      chipState(chips, false);

      if (saved && saved.syms) {
        /* 지난번에 만들던 질문 복원 (69·72 에서 질문만 넣어 둔 경우는 아래 '처음' 흐름으로 증상을 골라 둔다) */
        (saved.extras || []).forEach(function (v) { addCustomChip(v, false); });
        (saved.syms || []).forEach(function (v) {
          var hit = $$('.chip', chips).filter(function (c) { return c.textContent.trim() === v; })[0];
          if (hit) hit.classList.add('chip--on');
          else addCustomChip(v, true);
        });
        render();
      } else {
        /* 처음이면 최근 2주 기록에서 자주 겪은 증상을 미리 골라둔다
           (오늘 포함 14일 — 진료 전 리포트(77)와 같은 기간) */
        var since = new Date(); since.setDate(since.getDate() - 13);
        sb.from('checkins').select('symptoms').gte('date', ymd(since)).then(function (r) {
          if (selectedSyms().length) return;      /* 그 사이 사용자가 골랐으면 덮지 않는다 */
          var cnt = {};
          (r.data || []).forEach(function (row) { (row.symptoms || []).forEach(function (sx) { cnt[sx] = (cnt[sx] || 0) + 1; }); });
          var top = Object.keys(cnt).sort(function (a, b) { return cnt[b] - cnt[a]; }).slice(0, 3);
          top.forEach(function (sx) {
            var hit = $$('.chip', chips).filter(function (c) { return c.textContent.trim() === sx; })[0];
            if (hit) hit.classList.add('chip--on');
            else addCustomChip(sx, true);
          });
          render(); saveQ();
        });
      }
    }
    render();
    /* 형제 화면(보관함·리포트)은 방문 스택을 쌓지 않게 replace 이동 */
    $$('a').forEach(function (a) {
      var h = (a.getAttribute('href') || '').split('#')[0];
      if (h === '28-note-archive.html' || h === '77-visit-report.html') {
        a.addEventListener('click', function (e) { e.preventDefault(); location.replace(h); });
      }
    });
  }

  /* ── 21 대화 기록 ── */
  function page21() {
    var content = $('.content');
    var tmpl = $('.listitem', content) ? $('.listitem', content).cloneNode(true) : null;
    /* 예시 목록 비우기 (검색 줄은 유지) */
    $$('.section-label', content).forEach(function (l) { l.parentNode.removeChild(l); });
    $$('.listitem', content).forEach(function (l) { l.parentNode.removeChild(l); });
    var disc = $('.disclaimer', content);
    /* 불러오기 실패(r.error·reject) — '아직 대화가 없어요'로 안내하지 않는다 (4차) */
    function loadFail() {
      var bn = document.createElement('div');
      bn.className = 'banner banner--warn';
      bn.innerHTML = '<span class="b-ic">📶</span><div class="small">대화 기록을 불러오지 못했어요. 연결을 확인하고 다시 열어 주세요.</div>';
      content.insertBefore(bn, disc || null);
    }
    sb.from('chat_messages').select('role,content,created_at').order('created_at', { ascending: false }).limit(300)
      .then(function (r) {
        if (!r || r.error) { loadFail(); return; }
        var rows = r.data || [];
        if (!rows.length) {
          var bn = document.createElement('div');
          bn.className = 'banner banner--info';
          bn.innerHTML = '<span class="b-ic">💬</span><div class="small">아직 대화가 없어요. 상담에서 궁금한 것을 물어보세요.</div>';
          content.insertBefore(bn, disc || null);
          return;
        }
        var groups = {}, order = [];
        rows.forEach(function (m) {
          var d = new Date(m.created_at);
          var k = ymd(d);
          if (!groups[k]) { groups[k] = { count: 0, first: null, date: d }; order.push(k); }
          if (m.role === 'user') {
            groups[k].count++;
            groups[k].first = m.content;   /* 내림차순이라 마지막 대입 = 그날 첫 질문 */
          }
        });
        var todayS = ymd(new Date());
        order.forEach(function (k) {
          var g = groups[k];
          if (!g.count) return;
          var li = tmpl ? tmpl.cloneNode(true) : document.createElement('a');
          /* 그날 대화로 — 상담 화면이 ?date= 를 읽어 그 날짜 부분을 보여 준다.
             from 을 붙여 07 앱바 ‹ 와 휴대폰 뒤로가기가 이 목록으로 돌아오게 한다(app.js FROM_BACK · native.js) */
          li.setAttribute('href', '07-chat.html?date=' + k + '&from=21-chat-history.html');
          var t = $('.li-title', li), s = $('.li-sub', li);
          if (t) t.textContent = (g.first || '대화').slice(0, 18) + ((g.first || '').length > 18 ? '…' : '');
          if (s) s.textContent = '질문 ' + g.count + '개 · ' + (k === todayS ? '오늘' : kdate(g.date) + ' (' + WDAY[g.date.getDay()] + ')');
          var ic = $('.li-ic', li); if (ic) ic.textContent = '💬';
          content.insertBefore(li, disc || null);
        });
      }, loadFail);
  }

  /* ── 05 홈: 새 버전 안내 배너 ── */
  /* '0.9.1' 과 '0.9' 를 칸별 숫자로 비교 — a 가 더 새 버전이면 양수 */
  function verCmp(a, b) {
    var x = String(a || '').split('.'), y = String(b || '').split('.');
    for (var i = 0; i < Math.max(x.length, y.length); i++) {
      var p = parseInt(x[i], 10) || 0, q = parseInt(y[i], 10) || 0;
      if (p !== q) return p - q;
    }
    return 0;
  }
  function updateBanner() {
    /* 웹(아이폰 웹앱)은 늘 최신 화면을 받으므로 설치판에만 안내한다 */
    if (!(window.TDN && window.TDN.isNative)) return;
    sb.from('app_config').select('value').eq('key', 'version').maybeSingle().then(function (r) {
      var v = r.data && r.data.value;
      if (!v || !v.latest || verCmp(v.latest, CFG.appVersion) <= 0) return;
      var c = $('.content');
      if (!c) return;
      var bn = document.createElement('div');
      bn.className = 'banner banner--warn';
      bn.innerHTML = '<span class="b-ic">⬆️</span><div class="small"><b>새 버전(v' + v.latest + ')이 나왔어요.</b> '
        + (v.note ? v.note + ' ' : '') + (v.url ? '' : '새 버전은 토닥 담당자가 전해 드려요.') + '</div>';
      if (v.url) {
        bn.style.cursor = 'pointer';
        bn.addEventListener('click', function () {
          if (window.TDN && window.TDN.openExternal) window.TDN.openExternal(v.url);
          else location.href = v.url;
        });
      }
      c.insertBefore(bn, c.firstChild);
    });
  }

  /* ── 분기 ── */
  if (PAGE === '73-cycle-setup.html') page73Visits();
  else if (PAGE === '98-checkin-month.html') page98();
  else if (PAGE === '10-consult-questions.html') page10();
  else if (PAGE === '21-chat-history.html') page21();
  else if (PAGE === '05-home.html') updateBanner();
})();
