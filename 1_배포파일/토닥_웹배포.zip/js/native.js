/* ═══ 토닥 네이티브 배선 v2 — 딥링크·간편 로그인·비밀번호 재설정·알림·사진 인식·당겨서 새로고침 ═══
   app.js 다음, features.js 앞에 로드된다.
   웹(개발 미리보기·아이폰 웹앱)에서는 각 기능이 정중하게 물러난다.
   v2 적대검증 반영: 알림 권한 거부 안내 · 연타 방지 · 웹 분기 · 오류문구 디코딩 · 재진입 가드 */
/* ── 웹앱 화면 캐시 — 서비스워커 등록 (2026-09-28) ──
   웹앱은 화면을 옮길 때마다 0.5~1초가 걸렸다(APK 는 바로). Netlify 가 모든 파일을 max-age=0 으로 보내서
   화면마다 html·css·js·글꼴 15개 남짓을 서버에 다시 물어보기 때문이다. sw.js 가 앱 파일을 판별로 미리 담아 두고
   화면 이동 때 바로 낸다(자세한 규칙은 sw.js 머리말).
   - 안드로이드 앱(APK)은 파일이 기기 안에 있어 필요 없다 — 등록하지 않는다. 아래 본문과 같은 isNative 판정을 따로 한다
     (본문은 수파베이스를 못 불러오면 일찍 끝나고, 도중에 예외가 나면 그 뒤 코드가 돌지 않는다 — 등록은 그와 상관없이
     돌아야 해서 본문 앞에 따로 둔다).
   - 웹 푸시(webPushSync)와 같은 주소 'sw.js' · 같은 범위라 등록은 하나다. 알림 구독은 그대로 남는다.
   - 화면이 다 뜬 뒤(load)에 등록한다 — 처음 여는 화면의 파일 받기와 겹치지 않게.
   - 새 판 확인: 화면을 열 때와 앱으로 돌아올 때 registration.update() (1분에 한 번까지 · sw.js 는 no-cache 라 304 한 번이면 끝).
     크롬은 이와 따로 화면 이동마다 스스로 sw.js 를 한 번 확인한다(304 · 화면을 막지 않음). 여기서 따로 부르는 것은
     사파리에서도 확실히 묻고, 확인이 실패했는지 알기 위해서다(아래 gone).
     새 판이 있으면 뒤에서 바뀐 파일만 받고, 다 받으면 다음 화면 이동부터 새 판이다. 지금 화면은 새로고침하지 않는다.
   - sw.js 를 더 못 받게 되면(2026-09-28 검수): 배포에서 sw.js 가 빠졌거나(404·410) 사이트 전체가 다른 주소로 넘어가면(301 —
     예: 사용자 도메인을 붙임) update() 가 실패하고, 휴대폰은 옛 캐시에 영영 머문다(비상 스위치도 닿지 않는다).
     update() 가 실패하면 sw.js 를 직접 한 번 물어 그런 상태인지 보고, 두 번 연달아 그렇게 보이면 화면 캐시(todak-*)를 지운다
     → 그다음 화면부터 서버에서 받는다(옮긴 주소면 서버의 넘김을 따라간다). 통신이 끊긴 것이면 아무것도 하지 않는다.
     등록은 지우지 않는다 — 알림(웹 푸시) 구독이 등록에 붙어 있어서, 잘못 보았을 때 약 알림이 끊기지 않게. */
(function () {
  'use strict';
  var cap = window.Capacitor;
  if (cap && cap.isNativePlatform && cap.isNativePlatform()) return;
  if (!('serviceWorker' in navigator)) return;
  var KEY = 'todak_sw_check', GAP = 60 * 1000, GONE = 'todak_sw_gone';
  function setGone(n) {
    try { if (n) localStorage.setItem(GONE, String(n)); else localStorage.removeItem(GONE); } catch (e) {}
  }
  function gone() {
    if (!window.fetch || !window.caches) return;
    /* sw.js 는 서비스워커가 가로채지 않는다 — 곧장 서버에 묻는다. 넘김은 따라가지 않고 넘김인지만 본다 */
    fetch('sw.js', { cache: 'no-store', redirect: 'manual' }).then(function (r) {
      if (!(r.type === 'opaqueredirect' || r.status === 404 || r.status === 410)) { setGone(0); return; }
      var n = 0;
      try { n = +localStorage.getItem(GONE) || 0; } catch (e) {}
      if (n < 1) { setGone(n + 1); return; }                /* 처음 본 것 — 한 번 더 보고 지운다 */
      setGone(0);
      return caches.keys().then(function (ks) {
        return Promise.all(ks.filter(function (k) { return k.indexOf('todak-') === 0; })
          .map(function (k) { return caches.delete(k); }));
      });
    }).then(null, function () {});                          /* 통신 끊김 — 그냥 둔다 */
  }
  function check(reg) {
    if (!reg || !reg.update || reg.installing) return;      /* 막 설치 중이면 묻지 않는다 */
    var now = Date.now(), last = 0;
    try { last = +localStorage.getItem(KEY) || 0; } catch (e) {}
    if (now - last < GAP && now >= last) return;
    try { localStorage.setItem(KEY, String(now)); } catch (e2) {}
    try {
      var p = reg.update();
      if (p && p.then) p.then(function () { setGone(0); }, gone);
    } catch (e3) {}
  }
  function boot() {
    navigator.serviceWorker.register('sw.js').then(function (reg) {
      check(reg);
      document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') check(reg);
      });
    }).catch(function () {});
  }
  if (document.readyState === 'complete') boot();
  else window.addEventListener('load', boot);
})();

(function () {
  'use strict';
  var T = window.TD || {};
  var sb = T.sb, $ = T.$, $$ = T.$$, toast = T.toast, koError = T.koError, PAGE = T.PAGE;
  /* 약 이름 뒤에 붙는 조사 — 받침이 있으면 앞의 것, 없으면 뒤의 것 (‘을/를’ · ‘은/는’).
     숫자·영문으로 끝나는 이름은 소리 내어 읽을 때 받침이 있는 쪽이 많아 예전처럼 ‘을’·‘은’을 쓴다. (2026-09-29) */
  function josaK(v, withJong, noJong) {
    var t = String(v == null ? '' : v).replace(/\s+$/, ''), c = t.charCodeAt(t.length - 1);
    if (!(c >= 0xAC00 && c <= 0xD7A3)) return withJong;
    return ((c - 0xAC00) % 28) ? withJong : noJong;
  }
  if (!sb || !$) return;
  var CFG = window.TODAK_CONFIG || {};

  var cap = window.Capacitor;
  var isNative = !!(cap && cap.isNativePlatform && cap.isNativePlatform());
  var P = (cap && cap.Plugins) || {};

  function goAfterAuth() {
    sb.auth.getSession().then(function (r) {
      if (!r.data.session) return;
      var user = r.data.session.user;
      /* app.js 와 같은 규칙(동의 → 프로필 → 홈)을 탄다 — 간편 로그인도 02 동의를 건너뛰지 않는다 */
      if (T.goAfterLogin) return T.goAfterLogin(user);
      location.replace('05-home.html');
    });
  }

  /* ── 딥링크: todak://auth (간편 로그인 복귀) · todak://reset (비밀번호 재설정) ── */
  function parseHash(url) {
    var h = url.split('#')[1] || '';
    var out = {};
    h.split('&').forEach(function (kv) {
      var p = kv.split('=');
      if (p[0]) {
        try { out[decodeURIComponent(p[0])] = decodeURIComponent((p[1] || '').replace(/\+/g, ' ')); }
        catch (e) { out[p[0]] = p[1] || ''; }
      }
    });
    return out;
  }
  /* 로그인 실패 이유 보여주기 — 우리 함수가 보낸 한국어는 그대로, 그 밖에는 일반 문구 */
  function showAuthError(desc) {
    var msg = String(desc || '').trim();
    /* 링크 만료는 딥링크·웹 어느 쪽으로 돌아오든 같은 안내를 쓴다 */
    if (/expired|otp_expired|invalid/i.test(msg)) {
      return toast('링크 유효시간이 지났어요.\n다시 한 번 요청해 주세요.');
    }
    /* 우리 서버 함수가 보낸 한국어 안내는 그대로, 그 밖(영어 원문·내부 오류)은 감춘다 */
    if (/[가-힣]/.test(msg)) {
      /* oauth-login 이 '이메일 가입을 이용해 주세요' · '이메일 로그인으로 들어와 주세요'로 돌려보낸 경우 — 시작 화면의 이메일 버튼을 잠깐 강조한다 */
      if (/이메일\s*(가입|로그인)/.test(msg)) openEmailCard();
      return toast(msg);
    }
    toast('로그인을 마치지 못했어요.\n다시 시도해 주세요.');
  }

  function handleDeepLink(url) {
    if (!url || url.indexOf('todak://') !== 0) return;
    var frag = parseHash(url);
    if (frag.error_code === 'otp_expired' || /expired/i.test(frag.error_description || '')) {
      toast('링크 유효시간이 지났어요.\n다시 한 번 요청해 주세요.');
      return;
    }
    if (frag.error_description) {
      /* oauth-login 함수는 실패 이유를 한국어 한 줄로 보내온다 — 그대로 보여준다 */
      showAuthError(frag.error_description);
      return;
    }
    if (!frag.access_token || !frag.refresh_token) return;
    try {
      sb.auth.setSession({ access_token: frag.access_token, refresh_token: frag.refresh_token })
        .then(function (r) {
          if (r.error) return toast(koError(r.error));
          if (url.indexOf('todak://reset') === 0) {
            try { sessionStorage.setItem('todak_pw_reset', '1'); } catch (e) {}
            location.href = '81-account-recovery.html';
          } else {
            goAfterAuth();
          }
        }, function (e) { toast(koError(e)); });
    } catch (e2) { toast('로그인 정보를 읽지 못했어요. 다시 시도해 주세요.'); }
  }
  if (isNative && P.App && P.App.addListener) {
    P.App.addListener('appUrlOpen', function (ev) { handleDeepLink(ev && ev.url); });
    if (P.App.getLaunchUrl) P.App.getLaunchUrl().then(function (r) {
      if (!(r && r.url)) return;
      /* 앱을 연 인텐트 URL은 프로세스가 살아 있는 동안 계속 같은 값이 돌아온다 — 한 번만 처리 */
      try { if (sessionStorage.getItem('todak_launch_done') === r.url) return; sessionStorage.setItem('todak_launch_done', r.url); } catch (e) {}
      handleDeepLink(r.url);
    }, function () {});
  }

  /* ── 휴대폰 뒤로가기 버튼 ──
     Capacitor 앱 플러그인은 뒤로가기를 가로챈 뒤, 되돌아갈 기록이 없으면 아무것도 하지 않는다.
     그래서 시작 화면에서 눌러도 앱이 닫히지 않았다(2026-09-18 실기기 재현). 규칙을 여기서 정한다.
       1) 떠 있는 창(시간 고르기·길찾기·전화 확인)이 있으면 그것부터 닫는다
       2) 시작 화면·홈 화면이면 앱을 닫는다
       3) 다른 화면에서 건너온 화면(주소에 ?from=<화면.html>)이면 왼쪽 위 뒤로 버튼을 누른다 — 온 화면으로 돌아간다
       4) 하단 탭 화면(정보·상담·기록·내 정보)이면 홈으로 간다
       5) 그 밖에는 화면 왼쪽 위 뒤로 버튼과 똑같이 움직인다 (화면마다 정해 둔 상위 화면·저장 처리를 그대로 탄다)
       6) 뒤로 버튼도 기록도 없으면 앱을 닫는다 */
  if (isNative && P.App && P.App.addListener) {
    var BACK_ROOTS = { 'index.html': 1, '01-splash.html': 1, '05-home.html': 1 };
    var BACK_TABS = { '06-sideeffects.html': 1, '07-chat.html': 1, '16-checkin.html': 1, '13-settings.html': 1 };
    /* 3) 의 뒤로 버튼 — AI 상담 카드가 연 '06-sideeffects.html?from=07-chat.html' 처럼 온 화면이 주소에 적혀 있으면
       app.js(FROM_BACK)가 앱바 ‹ 를 그 화면으로 바꿔 둔다. 06 은 하단 탭이라 예전에는 휴대폰 뒤로가기만 홈으로 갔다.
       ‹ 를 그대로 누르므로 화면마다 ‹ 에 걸어 둔 저장·확인 창 처리도 똑같이 돈다.
       온 화면 이름이 화면 파일명 꼴이 아니거나, ‹ 에 주소가 없거나, ‹ 가 지금 화면을 가리키면 null(다음 규칙으로) */
    var fromBackLink = function () {
      var m = /[?&]from=([^&#]*)/.exec(location.search || ''), v = '';
      try { v = m ? decodeURIComponent(m[1]) : ''; } catch (e) { v = ''; }
      if (!/^[0-9A-Za-z._-]+\.html$/.test(v) || v === PAGE) return null;
      var a = document.querySelector('.appbar a.back');
      var h = a ? (a.getAttribute('href') || '') : '';
      if (!h || h.charAt(0) === '#' || /^javascript:/i.test(h)) return null;
      if (h.split(/[?#]/)[0].split('/').pop() === PAGE) return null;
      return a;
    };
    P.App.addListener('backButton', function (ev) {
      var tpCancel = document.querySelector('.tp-dim .tp-cancel');
      if (tpCancel) { tpCancel.click(); return; }
      var pkCancel = document.querySelector('.pk-dim .pk-cancel');   /* 고르기 팝업(하루 몇 번·언제·며칠분) */
      if (pkCancel) { pkCancel.click(); return; }
      var pops = $$('[role="dialog"]').filter(function (d) { return !d.hidden && d.offsetParent !== null; });
      if (pops.length) { pops[pops.length - 1].hidden = true; return; }
      /* 여러 장을 넘기는 화면(19 사용법)은 앞 장이 있으면 앞 장으로 — 첫 장이면 아래 규칙대로 */
      if (typeof window.__todakBackStep === 'function' && window.__todakBackStep()) return;
      if (BACK_ROOTS[PAGE]) { P.App.exitApp(); return; }
      var fb = fromBackLink();
      if (fb) { fb.click(); return; }
      if (BACK_TABS[PAGE]) { location.replace('05-home.html'); return; }
      /* 주소(href)가 있는 링크일 때만 누른다 — 19 사용법처럼 자리만 잡아 둔 <span class="back"> 을 누르면
         아무 일도 일어나지 않아 뒤로가기가 먹히지 않았다. 그럴 때는 다음 규칙(기록 → 앱 닫기)으로 넘긴다. */
      var back = document.querySelector('.appbar .back');
      if (back && back.tagName === 'A' && back.getAttribute('href')) { back.click(); return; }
      if (ev && ev.canGoBack) { history.back(); return; }
      P.App.exitApp();
    });
  }

  /* 웹(아이폰)에서 간편 로그인 실패로 돌아온 경우 — 해시의 오류 문구를 보여준다 (web-return-error) */
  if (!isNative && /error_description=/.test(location.hash)) {
    try {
      var em = decodeURIComponent((location.hash.split('error_description=')[1] || '').split('&')[0].replace(/\+/g, ' '));
      if (em) setTimeout(function () { showAuthError(em); }, 600);
      history.replaceState(null, '', location.pathname);
    } catch (e0) {}
  }

  function openExternal(url) {
    if (isNative && P.Browser && P.Browser.open) P.Browser.open({ url: url });
    else location.href = url;
  }

  /* ── 간편 로그인 ──
     구글: 수파베이스 기본 제공 · 카카오/네이버: 서버 함수(oauth-login) 경유(앱 전용) */
  var oauthBusy = false;                       /* 연타로 브라우저 두 번 열리는 것 방지 */
  function oauthDone() { setTimeout(function () { oauthBusy = false; }, 1500); }
  /* '이메일로 시작해 주세요' 안내 뒤, 시작 화면의 이메일 버튼을 잠깐 강조해 어디를 누를지 보이게 한다.
     이메일 칸은 다른 화면(97·96)에 있어 여기서 펼칠 것이 없다. */
  function openEmailCard() {
    var a = document.getElementById('emailLoginLink');
    if (!a) return;
    try { a.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) {}
    a.classList.add('is-hint');
    setTimeout(function () { a.classList.remove('is-hint'); }, 2800);
  }
  var settingsCache = null;
  function authSettings(cb) {
    if (settingsCache) return cb(settingsCache);
    fetch(CFG.url + '/auth/v1/settings', { headers: { apikey: CFG.anonKey } })
      .then(function (r) { return r.json(); })
      .then(function (d) { settingsCache = d; cb(d); }, function () { cb(null); });
  }
  function loginGoogle() {
    if (oauthBusy) return;
    oauthBusy = true;
    authSettings(function (s) {
      if (!s || !s.external || !s.external.google) {
        oauthDone(); openEmailCard();
        return toast('구글 로그인은 준비 중이에요.\n이메일로 시작해 주세요.');
      }
      if (T.noteLoginTry) T.noteLoginTry('google');   /* '최근 로그인' — 누른 방법을 적어 둔다 (app.js noteLoginWay) */
      sb.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: isNative ? 'todak://auth' : (location.origin + '/01-splash.html'),
          skipBrowserRedirect: isNative
        }
      }).then(function (r) {
        oauthDone();
        if (r.error) return toast(koError(r.error));
        if (isNative && r.data && r.data.url) openExternal(r.data.url);
      }, function (e) { oauthDone(); toast(koError(e)); });
    });
  }
  function loginVia(provider) {   /* kakao | naver — 앱은 딥링크로, 웹(아이폰)은 현재 주소로 복귀 */
    if (oauthBusy) return;
    oauthBusy = true;
    var cbUrl = CFG.fnBase + '/oauth-login/' + provider;
    function go() {
      oauthDone();
      var state = String(Date.now()) + Math.floor(Math.random() * 1e9);
      if (!isNative) state += '|ret=' + encodeURIComponent(location.origin);   /* 웹 복귀 주소 (함수가 허용 목록으로 검사) */
      var url = provider === 'naver'
        ? 'https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=' + encodeURIComponent(CFG.naverClientId) + '&redirect_uri=' + encodeURIComponent(cbUrl) + '&state=' + state
        : 'https://kauth.kakao.com/oauth/authorize?response_type=code&client_id=' + encodeURIComponent(CFG.kakaoRestKey) + '&redirect_uri=' + encodeURIComponent(cbUrl) + '&state=' + state;
      if (T.noteLoginTry) T.noteLoginTry(provider);   /* '최근 로그인' — 누른 방법을 적어 둔다 (app.js noteLoginWay) */
      if (isNative) openExternal(url); else location.href = url;
    }
    /* 함수가 살아 있는지 확인은 '참고'일 뿐이다.
       이 응답에는 교차 출처 허용 헤더가 없어서 웹뷰가 읽기를 막는다 — 그때도 로그인은 그대로 진행한다.
       (실제 로그인 왕복은 fetch 가 아니라 주소 이동이라 교차 출처 검사를 받지 않는다) */
    var settled = false;
    function once(fn) { if (settled) return; settled = true; clearTimeout(timer); fn(); }
    var timer = setTimeout(function () { once(go); }, 2500);
    fetch(CFG.fnBase + '/oauth-login/ping', { method: 'GET' }).then(function (r) {
      once(function () {
        if (r.status === 404) { oauthDone(); openEmailCard(); return toast((provider === 'kakao' ? '카카오' : '네이버') + ' 로그인은 준비 중이에요.\n이메일로 시작해 주세요.'); }
        go();
      });
    }, function () { once(go); });
  }
  /* 간편 로그인 버튼은 시작 화면(01) 한 곳에만 있다 (가입·로그인을 한 화면으로 합침, 2026-09-17) */
  if (PAGE === '01-splash.html' || PAGE === 'index.html') {
    $$('a.btn, a[data-oauth]').forEach(function (a) {
      /* 간편 로그인 버튼은 각 회사 공식 이미지라 글자가 없다 — data-oauth 로 알아본다 */
      var key = a.getAttribute('data-oauth') || '';
      var t = a.textContent;
      if (!key) {
        if (t.indexOf('구글') > -1 || t.indexOf('Google') > -1) key = 'google';
        else if (t.indexOf('카카오') > -1) key = 'kakao';
        else if (t.indexOf('네이버') > -1) key = 'naver';
      }
      var go = key === 'google' ? loginGoogle
        : (key === 'kakao' || key === 'naver') ? function () { loginVia(key); } : null;
      if (go) a.addEventListener('click', function (e) { e.preventDefault(); go(); });
    });
  }

  /* ── 81 비밀번호 재설정 ── */
  function page81() {
    var email = $('input[aria-label="이메일 주소"]');
    if (email) email.value = '';
    var resultCard = $$('.card').filter(function (c) { return c.textContent.indexOf('보냈어요') > -1; })[0];
    if (resultCard) resultCard.style.display = 'none';
    var sendBtn = T.btnByText('재설정 링크 보내기');

    var inReset = false;
    try { inReset = sessionStorage.getItem('todak_pw_reset') === '1'; } catch (e) {}
    /* 웹(아이폰)에서는 재설정 링크가 이 화면으로 직접 돌아온다 */
    if (!inReset && location.hash.indexOf('type=recovery') > -1) inReset = true;

    if (inReset) {
      try { sessionStorage.removeItem('todak_pw_reset'); } catch (e) {}
      var fld = email ? email.parentNode : null;
      if (fld) {
        var lb = $('label', fld); if (lb) lb.textContent = '새 비밀번호';
        email.type = 'password'; email.placeholder = '8자 이상'; email.setAttribute('aria-label', '새 비밀번호');
      }
      var info = $('.banner--info .small') || $('.banner--info div');
      if (info) info.innerHTML = '본인 확인이 끝났어요. <b>새 비밀번호</b>를 정해 주세요.';
      if (sendBtn) {
        sendBtn.textContent = '비밀번호 바꾸기';
        sendBtn.addEventListener('click', function (e) {
          e.preventDefault();
          if (sendBtn.__busy) return;
          var pw = (email && email.value) || '';
          if (pw.length < 8) return toast('비밀번호는 8자 이상으로 정해 주세요.');
          T.busy(sendBtn, true, '바꾸는 중…');
          sb.auth.updateUser({ password: pw }).then(function (r) {
            if (r.error) { T.busy(sendBtn, false); return toast(koError(r.error)); }
            toast('비밀번호를 바꿨어요.\n다음부터는 새 비밀번호로 로그인해 주세요.');
            setTimeout(goAfterAuth, 900);
          });
        });
      }
      return;
    }

    if (sendBtn) sendBtn.addEventListener('click', function (e) {
      e.preventDefault();
      if (sendBtn.__busy) return;
      var em = (email && email.value.trim()) || '';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return toast('이메일 주소를 확인해 주세요.');
      T.busy(sendBtn, true, '보내는 중…');
      var back = isNative ? 'todak://reset' : (location.origin + '/81-account-recovery.html');
      sb.auth.resetPasswordForEmail(em, { redirectTo: back }).then(function (r) {
        T.busy(sendBtn, false);
        if (r.error) return toast(koError(r.error));
        if (resultCard) {
          resultCard.style.display = '';
          var t = $('.card-title', resultCard);
          /* 앞 세 글자만 보이고 나머지는 가린다. 앞부분이 짧은 주소('ab@…')는 한 글자만 — 예전에는 slice(0, 3) 이 '@'까지 잘라
             'ab@****@…'로 깨졌다. 적으신 글은 글자로만 넣는다(태그로 읽지 않게 · 2026-10-01 새벽 검증) */
          var at = em.indexOf('@'), loc = em.slice(0, at);
          var shown = loc.slice(0, loc.length > 3 ? 3 : Math.max(1, loc.length - 1)) + '****' + em.slice(at);
          if (t) {
            t.textContent = shown + '으로';
            t.appendChild(document.createElement('br'));
            t.appendChild(document.createTextNode('재설정 링크를 보냈어요'));
          }
        }
        toast('재설정 메일을 보냈어요. 휴대폰 메일함에서 링크를 눌러 주세요.');
      });
    });
  }

  /* ── 알림 (앱 전용 · 기기 안 알림 — 서버 발송 아님) ── */
  var NOTIF_DEFAULT = { mood_check: true, record_remind: true, med_remind: true, visit_remind: true };
  /* 증상 기록·마음 체크 알림 시각 — 23 알림 설정에서 줄을 눌러 바꾼다(profiles.notif_prefs.record_time · mood_time 'HH:MM').
     값이 없거나 이상하면 예전 고정 시각(기록 매일 20:00 · 마음 체크 매주 월요일 10:00)이다. push-send 함수도 같은 기본값·같은 검사다. */
  var NOTIF_TIME = { record_time: '20:00', mood_time: '10:00' };
  function normHM(s) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(typeof s === 'string' ? s : '');
    if (!m || +m[1] > 23 || +m[2] > 59) return null;
    return ('0' + (+m[1])).slice(-2) + ':' + m[2];
  }
  function hm12(hm) {                    /* '20:00' → '오후 8:00' (timepick.js TDT.fmt 와 같은 모양) */
    var h = +hm.slice(0, 2);
    return (h < 12 ? '오전 ' : '오후 ') + ((h % 12) || 12) + ':' + hm.slice(3);
  }
  function notifPrefs(p) {
    var v = (p && p.notif_prefs) || {};
    if (typeof v !== 'object') v = {};  /* 글자·숫자가 들어 있으면 'in' 이 오류를 낸다 */
    var out = {}, k;
    for (k in NOTIF_DEFAULT) out[k] = (k in v) ? !!v[k] : NOTIF_DEFAULT[k];
    for (k in NOTIF_TIME) out[k] = normHM(v[k]) || NOTIF_TIME[k];
    return out;
  }
  var SLOT_TIME = { '아침': '08:00', '점심': '13:00', '저녁': '19:00', '자기전': '22:00' };
  function slotTime(m, slot) {          /* 약별 사용자 지정 시간 우선 */
    var t = (m.schedule && m.schedule.times && m.schedule.times[slot]) || SLOT_TIME[slot];
    if (!t) return null;
    var hm = t.split(':'), h = parseInt(hm[0], 10), mi = parseInt(hm[1], 10);
    /* 0시(밤 12시대)도 시각이다 — 예전 '|| 8' 은 '오전 12:30'(00:30)으로 정한 약을 08:30 에 울렸다 (2026-10-01 새벽 검증).
       서버(push-send hmOf)와 같이 0~23시·0~59분만 시각으로 본다 */
    if (!(h >= 0 && h <= 23)) h = 8;
    if (!(mi >= 0 && mi <= 59)) mi = 0;
    return [h, mi];
  }
  /* ── 며칠분이 지난 약 (화면 표시용) ──
     며칠분(schedule.days)과 시작일(schedule.startedOn 'YYYY-MM-DD' — 54·58 이 저장)이 함께 있는 약은
     시작일을 1일째로 세어 days 일째가 마지막 날이다. 둘 중 하나라도 없으면 끝나는 날을 모르는 약이다(null · false).
     알림은 이 날짜로 끊지 않는다 — 환자가 '이 약 그만 쓰기'를 누를 때까지 계속 울린다(2026-09-18 정책 확정).
     호르몬제처럼 30·90일분을 받아 계속 드시는 약의 알림이 말없이 끊기면 안 되기 때문이다. push-send 함수도 같다.
     55 안내 띠·56 머리처럼 '날짜가 지났어요'를 보여 줄 때만 쓴다. */
  function medLastDay(m) {
    var sc = (m && m.schedule) || {};
    var n = parseInt(sc.days, 10);
    var mt = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(sc.startedOn || ''));
    if (!(n > 0) || !mt) return null;
    return new Date(+mt[1], +mt[2] - 1, +mt[3] + n - 1);
  }
  function medEnded(m, now) {
    var last = medLastDay(m);
    if (!last) return false;
    var d = now || new Date();
    return new Date(d.getFullYear(), d.getMonth(), d.getDate()) > last;
  }
  /* ── 약이 곧 떨어져요 (교수님 2026-09-30) ──
     며칠분(schedule.days)과 시작일(schedule.startedOn — 54·58 이 등록할 때 저장)을 아는 약만 본다.
     둘 중 하나라도 없으면 끝나는 날을 모르니 알리지 않는다.
     떨어지는 날(out) = 시작일 + 며칠분 — 그날부터 약이 없다(마지막으로 드시는 날은 그 전날 · 위 medLastDay 와 같은 셈).
       · 알림: 떨어지기 3일 전(3일분 남음)·1일 전(오늘 드실 만큼만 남음) 오전 9시(진료 알림과 같은 시각). 복약 알림을 켠 분께만.
         같은 날 여러 약이면 한 번만. 등록한 날(과 그 전)에는 알리지 않는다 — 오늘 3일분을 받아 온 분께 '3일분 남았어요'는 뜬금없다.
       · 홈 '지금 할 일' 줄: 1~3일분 남은 사흘 동안(features.js paintRx).
     진료 일정(73 의 visits · next_visit)과 맞춘다 — 떨어지는 날까지 진료가 있으면 '그 진료 때 처방을 받아 오세요',
     진료가 그 뒤면 '다음 진료보다 먼저 떨어져요 · 병원에 미리 연락해 보세요'. 진료 알림(7일 전·하루 전)에도 처방 한마디를 붙인다.
     약 종류로 말을 바꾸지 않는다 — 항구토제처럼 항암 주기에 맞춰 며칠만 드시는 약도 있어서 모든 약에 '계속 드시는 약이면'을 붙인다.
     그래서 약 이름을 봉투에서 정확히 읽었는지와 상관없이 같은 말이 맞다. 약을 끊거나 이어 드시라고 앱이 정하지 않는다.
     잠금화면 알림에는 약 이름을 넣지 않는다(복약 알림과 같은 원칙) — 이름은 앱 화면(홈 줄)에만 쓴다.
     서버(push-send index.ts 의 rx 구간)가 같은 규칙으로 아이폰 웹앱에 보낸다 — 고치면 둘 다 고치고 _qa/test_rx.js 를 돌린다. */
  /* ── rx:start ── */
  var RX = (function () {
    function dnum(s) {
      var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
      return m ? Math.round(Date.UTC(+m[1], +m[2] - 1, +m[3]) / 86400000) : null;
    }
    function dayOf(d) { return Math.round(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000); }
    function md(n) { var d = new Date(n * 86400000); return (d.getUTCMonth() + 1) + '월 ' + d.getUTCDate() + '일'; }
    function outOf(m) {
      var sc = (m && m.schedule) || {}, n = parseInt(sc.days, 10), st = dnum(sc.startedOn);
      if (!(n > 0) || n > 365 || st === null) return null;
      return { start: st, out: st + n };
    }
    function visitDays(treat) {
      var t = treat || {}, seen = {}, out = [];
      var add = function (s) { var n = dnum(s); if (n !== null && !seen[n]) { seen[n] = 1; out.push(n); } };
      if (Object.prototype.toString.call(t.visits) === '[object Array]') t.visits.forEach(function (v) { add(v && v.d); });
      add(t.next_visit);
      return out.sort(function (a, b) { return a - b; });
    }
    /* 그날(day) 1~3일분 남은 약. only([3, 1])가 있으면 남은 날이 그 값인 약만(알림 날) — 없으면 null
       → { day, left(가장 급한 약의 남은 날), out, meds, visit(그날부터 첫 진료 · 날 번호 | null), how('visit'|'late'|'') } */
    function on(meds, treat, day, only) {
      var hit = [];
      (meds || []).forEach(function (m) {
        var o = outOf(m);
        if (!o || day <= o.start) return;
        var left = o.out - day;
        if (left < 1 || left > 3 || (only && only.indexOf(left) < 0)) return;
        hit.push({ m: m, out: o.out, left: left });
      });
      if (!hit.length) return null;
      hit.sort(function (a, b) { return a.left - b.left; });
      var vs = visitDays(treat), v = null, i;
      for (i = 0; i < vs.length; i++) if (vs[i] >= day) { v = vs[i]; break; }
      /* 떨어지는 날 당일 진료도 '그 진료 때 받아 오세요'로 본다(그날 받아 오시면 된다) */
      return { day: day, left: hit[0].left, out: hit[0].out, meds: hit.map(function (h) { return h.m; }), visit: v,
               how: v === null ? '' : v <= hit[0].out ? 'visit' : 'late' };
    }
    /* 알림 글 — 잠금화면에 보이므로 약 이름 없이 */
    function note(p) {
      var head = p.meds.length > 1
        ? (p.left === 1 ? '오늘 드실 만큼만 남은 약이 있어요.' : '등록하신 약 ' + p.meds.length + '개가 곧 떨어져요.')
        : p.left === 1 ? '등록하신 약이 오늘 드실 만큼만 남았어요.' : '등록하신 약이 ' + p.left + '일분 남았어요.';
      var tail = p.how === 'visit' ? '계속 드시는 약이면 ' + (p.visit === p.day ? '오늘' : '이번') + ' 진료 때 처방을 받아 오세요.'
        : p.how === 'late' ? '다음 진료보다 먼저 떨어져요. 계속 드시는 약이면 병원에 미리 연락해 보세요.'
        : '계속 드시는 약이면 떨어지기 전에 처방을 받아 두세요.';
      return { title: '약이 곧 떨어져요', body: head + ' ' + tail };
    }
    /* 홈 '지금 할 일' 줄 — 앱 화면이라 약 이름을 쓴다 */
    function row(p) {
      var names = p.meds.map(function (m) { return String((m && m.name) || '약'); });
      var title = p.meds.length > 1 ? '곧 떨어지는 약이 ' + p.meds.length + '개 있어요'
        : p.left === 1 ? '오늘 드실 약이 마지막이에요' : '약이 ' + p.left + '일분 남았어요';
      var who = names.slice(0, 2).join(' · ') + (names.length > 2 ? ' 외 ' + (names.length - 2) + '개' : '')
        + (p.meds.length > 1 ? '' : ' · ' + (p.left === 1 ? '오늘까지' : md(p.out - 1) + '까지'));
      var how = p.how === 'visit' ? '계속 드시는 약이면 ' + (p.visit === p.day ? '오늘' : md(p.visit)) + ' 진료 때 처방을 받아 오세요'
        : p.how === 'late' ? '다음 진료(' + md(p.visit) + ')보다 먼저 떨어져요. 계속 드시는 약이면 병원에 미리 연락해 보세요'
        : '계속 드시는 약이면 떨어지기 전에 처방을 받아 두세요';
      return { title: title, who: who, how: how };
    }
    /* 진료(v) 알림에 처방 한마디를 붙일지 — 그다음 진료 전(모르면 진료 뒤 30일 안)에 떨어지는 약이 있으면.
       진료보다 30일 넘게 먼저 떨어진 약(오래전에 다 드시고 그만 쓰기를 안 누른 약)은 치지 않는다 */
    function needAt(meds, treat, v) {
      var vs = visitDays(treat), v2 = null, i;
      for (i = 0; i < vs.length; i++) if (vs[i] > v) { v2 = vs[i]; break; }
      var until = v2 !== null ? v2 : v + 30;
      return (meds || []).some(function (m) { var o = outOf(m); return !!o && o.out > v - 30 && o.out <= until; });
    }
    function visitBody(before, meds, treat, vStr) {
      var v = dnum(vStr), rx = v !== null && needAt(meds, treat, v);
      if (before === 7) return rx ? '일주일 뒤 진료예요. 여쭤볼 것을 정리하고, 계속 드시는 약은 처방도 받아 오세요'
        : '일주일 뒤 진료예요. 여쭤볼 것을 미리 정리해 보세요';
      return rx ? '내일 진료예요. 질문을 확인하고, 계속 드시는 약은 처방도 받아 오세요'
        : '내일 진료예요. 진료 준비에서 질문을 확인해 보세요';
    }
    /* 안드로이드 로컬 알림 — 앞으로의 알림 날(약마다 3일 전·1일 전)을 모아 날마다 하나씩, 그날 기기 시각 오전 9시.
       id 는 2000000 + 날 번호(다른 알림 1~4 · 복약 1000~ 과 겹치지 않는다). 오늘 9시가 지났으면 오늘 몫은 건너뛴다 */
    function localList(meds, treat, now) {
      now = now || new Date();
      var today = dayOf(now), days = {}, out = [];
      (meds || []).forEach(function (m) {
        var o = outOf(m);
        if (!o) return;
        [3, 1].forEach(function (k) { var x = o.out - k; if (x > o.start && x >= today) days[x] = 1; });
      });
      Object.keys(days).forEach(function (k) {
        var x = +k, p = on(meds, treat, x, [3, 1]);
        if (!p) return;
        var d0 = new Date(x * 86400000);
        var at = new Date(d0.getUTCFullYear(), d0.getUTCMonth(), d0.getUTCDate(), 9, 0, 0);
        if (at <= now) return;
        var n = note(p);
        out.push({ id: 2000000 + x, title: n.title, body: n.body, at: at });
      });
      return out.sort(function (a, b) { return a.at - b.at; });
    }
    return { dnum: dnum, dayOf: dayOf, outOf: outOf, on: on, note: note, row: row, needAt: needAt, visitBody: visitBody, localList: localList };
  })();
  /* ── rx:end ── */
  /* 02 '맞춤 정보·알림 수신(선택)' 동의 여부 — cb(true | false | null)
     가장 최근 동의 행 하나로 정한다(02 열람 화면과 같은 규칙). 그 행에 withdrawn_at(철회 처리)이 찍혀 있으면 동의 안 함이다.
     null 은 '모름'(연결 끊김·조회 실패)이다 — 부르는 쪽은 이미 걸린 예약을 건드리지 않는다.
     (예전에는 조회가 실패해도 '동의 안 함'으로 읽어, 지하철에서 홈을 열면 복약 알림까지 모두 지워졌다) */
  function consentNotif(cb) {
    sb.auth.getSession().then(function (rs) {
      var ses = rs && rs.data && rs.data.session;
      /* 토큰 갱신이 연결 문제로 실패하면 세션 없이 error 가 온다 — 로그아웃이 아니다 */
      if (!ses) return cb(rs && rs.error ? null : false);
      /* 같은 시각에 찍힌 행이 둘이면 id 가 큰(나중에 넣은) 행 — app.js latestConsentQ·nearby.js 와 같은 정렬 */
      sb.from('consent_records').select('notifications,withdrawn_at').eq('user_id', ses.user.id)
        .order('consented_at', { ascending: false }).order('id', { ascending: false }).limit(1)
        .then(function (r) {
          if (!r || r.error) return cb(null);
          var row = r.data && r.data[0];
          cb(!!(row && row.notifications && !row.withdrawn_at));
        }, function () { cb(null); });
    }, function () { cb(null); });
  }
  function cancelAll(cb) {
    if (!isNative) return webPushOff(cb);
    if (!P.LocalNotifications) return cb();
    P.LocalNotifications.getPending().then(function (p) {
      var o = ((p && p.notifications) || []).map(function (n) { return { id: n.id }; });
      if (o.length) P.LocalNotifications.cancel({ notifications: o }).then(cb, cb); else cb();
    }, cb);
  }
  /* ── 정확한 알람 (안드로이드 '알람 및 리마인더') ──
     복약 알림은 '정확한 알람'으로 걸어야 정한 시각에 울린다. 부정확 알람은 안드로이드가 배터리를 아끼려
     여러 알람을 모아서 터뜨리기 때문에 몇 분에서 십몇 분까지 밀린다(실기기에서 03:35 알림이 밀린 까닭).
     권한은 매니페스트의 USE_EXACT_ALARM(안드로이드 13+) · SCHEDULE_EXACT_ALARM(12 · 12L)으로 받는다.
     그래도 쓸 수 없는 기기가 있다(안드로이드 12 에서 사용자가 껐을 때). 그래서 예약 전에 먼저 물어보고
     쓸 수 없으면 지금처럼 부정확 알람으로 건다 — 알림이 아예 안 오는 일은 없어야 한다.
     먼저 물어보는 또 하나의 까닭: 쓸 수 없는데 정확으로 예약을 걸면 로컬 알림 플러그인이 '알람 및 리마인더'
     시스템 설정 화면을 그 자리에서 띄운다. 홈 화면을 열 때마다 설정 화면이 뜨면 어르신이 놀라신다.
     cb(true | false) — 답이 없으면 false(부정확)로 본다. */
  function exactAllowed(cb) {
    var LN = P.LocalNotifications;
    if (!isNative || !LN || !LN.checkExactNotificationSetting) return cb(false);
    var settled = false;
    var t = setTimeout(function () { pass(false); }, 4000);
    function pass(v) { if (settled) return; settled = true; clearTimeout(t); cb(v); }
    try {
      LN.checkExactNotificationSetting().then(function (r) { pass(!!(r && r.exact_alarm === 'granted')); }, function () { pass(false); });
    } catch (e) { pass(false); }
  }
  /* '알람 및 리마인더' 설정 화면으로 보낸다(안드로이드 12 이상). 23 알림 설정 화면의 안내 버튼만 쓴다 —
     앱이 저절로 띄우지 않는다. 돌아오면 cb(켜졌는지) — 부르는 쪽이 예약을 다시 맞춘다. */
  function exactAsk(cb) {
    var LN = P.LocalNotifications;
    if (!isNative || !LN || !LN.changeExactNotificationSetting) return cb(false);
    try {
      LN.changeExactNotificationSetting().then(function (r) { cb(!!(r && r.exact_alarm === 'granted')); }, function () { cb(false); });
    } catch (e) { cb(false); }
  }
  /* ── 아이폰 웹앱: 웹 푸시 (홈 화면에 추가한 뒤 '알림 허용'을 누른 기기에만 · 서버 함수 push-send 가 시간 맞춰 보냄) ── */
  function isStandalone() { return !!(navigator.standalone || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches)); }
  function isIOS() { return /iPhone|iPad|iPod/i.test(navigator.userAgent); }
  function b64ToU8(b64) {
    var pad = '='.repeat((4 - b64.length % 4) % 4);
    var raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }
  function webPushSync(done) {          /* done('ok'|'denied'|'need-install'|'unsupported') */
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !window.Notification) {
      if (isIOS() && !isStandalone()) return done('need-install');     /* 사파리 탭에서는 알림 API 자체가 없다 */
      return done('unsupported');
    }
    if (isIOS() && !isStandalone()) return done('need-install');
    if (!CFG.vapidPublic) return done('unsupported');
    navigator.serviceWorker.register('sw.js').then(function (reg) {
      return Notification.requestPermission().then(function (perm) {
        if (perm !== 'granted') return done('denied');
        return reg.pushManager.getSubscription().then(function (sub) {
          return sub || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(CFG.vapidPublic) });
        }).then(function (sub) {
          return sb.auth.getSession().then(function (rs) {
            if (!rs.data.session) return done('ok');
            return sb.from('push_subscriptions').upsert({ user_id: rs.data.session.user.id, platform: 'ios_web', token: sub.toJSON() }, { onConflict: 'user_id,platform' })
              .then(function () { done('ok'); }, function () { done('ok'); });
          });
        });
      });
    }).catch(function () { done('unsupported'); });
  }
  function webPushOff(cb) {              /* 로그아웃 때: 구독 해제 + 서버 행 삭제 */
    if (!('serviceWorker' in navigator)) return cb();
    navigator.serviceWorker.getRegistration('sw.js').then(function (reg) {
      if (!reg) return cb();
      reg.pushManager.getSubscription().then(function (sub) {
        var fin = function () { cb(); };
        sb.auth.getSession().then(function (rs) {
          var del = rs.data.session ? sb.from('push_subscriptions').delete().eq('user_id', rs.data.session.user.id).eq('platform', 'ios_web') : Promise.resolve();
          Promise.resolve(del).then(function () { if (sub) sub.unsubscribe().then(fin, fin); else fin(); }, fin);
        });
      }, cb);
    }, cb);
  }

  /* ── 예약 맞추기 ──
     한 번에 하나만 돈다. 도는 중에 온 요청은 버리지 않고 모아 두었다가 끝난 뒤 한 번 더 돌린다
     (23 에서 스위치를 연달아 바꾸면 두 번째 변경이 예약에 빠지던 문제). 모아 둔 요청의 done 은 그 재실행 결과로 부른다.
     opt.passive — 홈·복약 화면이 저절로 맞출 때. 권한을 조르지 않는다(안내는 하루 한 번, 시스템 창은 한 번도 묻지 않았을 때만).
     done('ok'|'denied'|'consent-off'|'unsupported'|'need-install'|'offline')
     'offline' — 동의·알림 설정·약 목록 중 하나라도 못 읽었다. 이미 걸린 예약은 그대로 둔다. */
  var syncBusy = false, syncWait = null;
  function notifySync(done, opt) {
    var ask = !(opt && opt.passive);
    if (syncBusy) {
      syncWait = syncWait || { dones: [], ask: false };
      if (done) syncWait.dones.push(done);
      if (ask) syncWait.ask = true;
      return;
    }
    syncBusy = true;
    var settled = false;
    var guard = setTimeout(function () { end('offline'); }, 20000);   /* 응답이 끝내 안 와도 다음 요청이 막히지 않게 */
    function end(st) {
      if (settled) return;
      settled = true;
      clearTimeout(guard);
      syncBusy = false;
      var w = syncWait;
      syncWait = null;
      if (w) notifySync(function (st2) { w.dones.forEach(function (d) { d(st2); }); }, { passive: !w.ask });
      if (done) done(st);
    }
    consentNotif(function (allowed) {
      if (allowed === null) return end('offline');                 /* 동의 여부를 모르면 예약을 건드리지 않는다 */
      if (!allowed) return cancelAll(function () { end('consent-off'); });
      if (!isNative) return webPushSync(end);
      if (!P.LocalNotifications) return end('unsupported');
      localSync(ask, end);
    });
  }
  /* 권한 안내는 하루 한 번만 — 오늘 이미 했으면 false */
  function nagToday() {
    var d = ymdLocal(new Date());
    try {
      if (localStorage.getItem('todak_notif_nag') === d) return false;
      localStorage.setItem('todak_notif_nag', d);
    } catch (e) {}
    return true;
  }
  function localSync(ask, finish) {
    var LN = P.LocalNotifications;
    LN.checkPermissions().then(function (cp) {
      var st = (cp && cp.display) || '';
      if (st === 'granted') return cp;
      if (ask) {                                                   /* 사용자가 알림을 켜거나 약을 저장한 때 */
        /* 이미 'denied'(거부해 둔 상태 — 시스템 창이 다시 뜨지 않는다)이면 '허용하시면…' 안내는 맞지 않고
           58 의 '「약」을 추가했어요'만 덮는다. 요청은 그대로 보내 결과('denied')를 돌려준다. 설정 안내(deniedToast)는 부른 쪽이 띄운다 —
           23 알림 설정·58 저장·54 저장·복약 시간 저장·약 빼기·app.js 동의 변경 저장이 저마다 띄운다 */
        if (st !== 'denied') toast('알림을 허용하시면 복약·기록 시간을 알려 드려요.');
        return LN.requestPermissions();
      }
      if (!nagToday()) return cp;
      if (st === 'prompt') {                                       /* 한 번도 묻지 않은 경우에만 시스템 창을 띄운다 */
        toast('알림을 허용하시면 복약·기록 시간을 알려 드려요.');
        return LN.requestPermissions();
      }
      deniedToast('denied');
      return cp;
    }).then(function (perm) {
      if (!perm || perm.display !== 'granted') return finish('denied');
      sb.auth.getSession().then(function (rs) {
        var ses = rs && rs.data && rs.data.session;
        if (!ses) return finish(rs && rs.error ? 'offline' : 'ok');
        sb.from('profiles').select('notif_prefs,treatment').eq('id', ses.user.id).maybeSingle().then(function (rp) {
          /* 설정을 못 읽으면 모두 '켜짐'으로 보게 되어 꺼 둔 알림이 되살아난다 — 예약을 건드리지 않고 멈춘다 */
          if (!rp || rp.error) return finish('offline');
          var prefs = notifPrefs(rp.data);
          var treat = (rp.data && rp.data.treatment) || {};
          sb.from('medications').select('id,name,schedule').eq('active', true).then(function (rm) {
            /* 약 목록을 못 읽으면 복약 알림을 모두 지우게 된다 — 멈춘다 */
            if (!rm || rm.error) return finish('offline');
            /* 며칠분이 지난 약도 넣는다 — '그만 쓰기'(active=false)를 누른 약만 빠진다(위 medLastDay 설명) */
            var meds = rm.data || [];
            LN.getPending().then(function (pend) {
              var olds = ((pend && pend.notifications) || []).map(function (n) { return { id: n.id }; });
              var proceed = function () {
                /* exacts — '정확한 알람'으로 걸 알림. 복약만 넣는다.
                   기록(매일 · 기본 저녁 8시) · 마음 체크(매주 월요일 · 기본 오전 10시) · 진료 전(7일 · 하루 전 오전 9시)은 몇 분 밀려도 해가 없고,
                   정확한 알람은 절전 상태를 깨우느라 배터리를 더 쓴다. 꼭 필요한 복약만 정확으로 둔다.
                   기록·마음 체크 시각은 23 알림 설정에서 고른 값(prefs.record_time · mood_time — notifPrefs 가 검사하고 기본값을 채움) */
                var list = [], exacts = [];
                var recT = prefs.record_time, moodT = prefs.mood_time;
                if (prefs.record_remind) list.push({
                  id: 1, title: '오늘 하루 어떠셨어요?',
                  body: '컨디션과 증상을 1분만 기록해 보세요 🌷',
                  isExactNotification: false, schedule: { on: { hour: +recT.slice(0, 2), minute: +recT.slice(3) }, allowWhileIdle: true }
                });
                if (prefs.mood_check) list.push({
                  id: 2, title: '마음 건강 체크',
                  body: '이번 주 마음은 어떠세요? 기록에 남겨 보세요',
                  isExactNotification: false, schedule: { on: { weekday: 2, hour: +moodT.slice(0, 2), minute: +moodT.slice(3) }, allowWhileIdle: true }
                });
                /* 복약 알림 — 문구는 약의 투여경로(schedule.route)에 맞춘다: 드실 / 넣으실 / 바르실 …
                   같은 시각·같은 문구는 한 번만 울린다(약이 여럿이어도 같은 알림이 겹쳐 오지 않게). */
                var medSeen = {};
                if (prefs.med_remind) meds.forEach(function (m) {
                  var rt = ROUTE.ofMed(m);
                  (((m.schedule || {}).slots) || []).forEach(function (slot, si) {
                    var t = slotTime(m, slot);
                    if (!t || slot === '필요시') return;
                    var body = ROUTE.notifyBody(rt, slot);   /* 잠금화면에 약 이름을 보이지 않는다 */
                    var mk = t[0] + ':' + t[1] + '|' + body;
                    if (medSeen[mk]) return;
                    medSeen[mk] = 1;
                    /* isExactNotification 은 아래에서 권한을 보고 정한다(기본값은 부정확) */
                    var one = {
                      id: 1000 + (m.id % 100000) * 10 + si,
                      title: '토닥',
                      body: body,
                      isExactNotification: false, schedule: { on: { hour: t[0], minute: t[1] }, allowWhileIdle: true }
                    };
                    list.push(one);
                    exacts.push(one);
                  });
                });
                /* 약이 곧 떨어져요 — 떨어지기 3일 전·1일 전 오전 9시 (위 RX 설명). 몇 분 밀려도 해가 없어 부정확 알람으로 둔다 */
                if (prefs.med_remind) RX.localList(meds, treat, new Date()).forEach(function (r) {
                  list.push({ id: r.id, title: r.title, body: r.body, isExactNotification: false, schedule: { at: r.at, allowWhileIdle: true } });
                });
                if (prefs.visit_remind && treat.next_visit) {
                  var v = new Date(treat.next_visit + 'T09:00:00');
                  [[7, 3], [1, 4]].forEach(function (pair) {
                    var d = new Date(v); d.setDate(d.getDate() - pair[0]);
                    if (d > new Date()) list.push({
                      id: pair[1], title: '진료가 다가와요',
                      /* 그 진료 뒤 다음 진료 전에 떨어질 약이 있으면 '계속 드시는 약은 처방도 받아 오세요'를 붙인다(RX.visitBody) */
                      body: RX.visitBody(pair[0], meds, treat, treat.next_visit),
                      isExactNotification: false, schedule: { at: d, allowWhileIdle: true }
                    });
                  });
                }
                if (!list.length) return finish('ok');
                /* 복약 알림을 정확한 알람으로 걸 수 있는지 먼저 본다. 안 되면 부정확으로 건다(밀릴 수 있지만 오기는 온다).
                   정확으로 건 예약이 거절되면 한 번 더 부정확으로 걸어 본다 — 알림이 아예 안 오는 일은 없어야 한다. */
                exactAllowed(function (ok) {
                  var i;
                  for (i = 0; i < exacts.length; i++) exacts[i].isExactNotification = !!ok;
                  LN.schedule({ notifications: list }).then(function () { finish('ok'); }, function () {
                    if (!ok || !exacts.length) return finish('ok');
                    for (i = 0; i < exacts.length; i++) exacts[i].isExactNotification = false;
                    LN.schedule({ notifications: list }).then(function () { finish('ok'); }, function () { finish('ok'); });
                  });
                });
              };
              if (olds.length) LN.cancel({ notifications: olds }).then(proceed, proceed);
              else proceed();
            }, function () { finish('ok'); });
          }, function () { finish('offline'); });
        }, function () { finish('offline'); });
      }, function () { finish('offline'); });
    }, function () { finish('denied'); });
  }
  function deniedToast(st) {
    /* 웹(아이폰 홈 화면 앱 · 인터넷 창)에는 '애플리케이션 > 토닥' 길이 없다 — 막힌 까닭에 맞춰 말한다 */
    if (st === 'denied' && !isNative) toast(window.Notification && Notification.permission === 'denied'
      ? '이 휴대폰에서 토닥 알림이 꺼져 있어요.\n휴대폰 설정에서 토닥 알림을 허용해 주세요.'
      : '알림이 아직 허용되지 않았어요.\n' + (PAGE === '23-notif-settings.html' ? '위의 ‘알림 켜기’를 눌러 주세요.' : '알림 설정에서 ‘알림 켜기’를 눌러 주세요.'));   /* 23 에서는 '알림 설정'이 지금 이 화면이다 */
    else if (st === 'denied') toast('휴대폰 알림 권한이 꺼져 있어요.\n설정 › 애플리케이션 › 토닥 › 알림에서\n허용해 주세요.');   /* 23 화면 안내 띠와 같은 글 */
    else if (st === 'consent-off') toast('알림 수신에 동의하지 않으셔서 알림을 보내지 않아요.');
    else if (st === 'need-install') toast('아이폰에서는 사파리 공유 버튼 → ‘홈 화면에 추가’로 설치한 뒤\n알림을 켤 수 있어요.');
    else if (st === 'unsupported' && !isNative) toast('지금 쓰시는 인터넷 창에서는\n알림을 받을 수 없어요.');   /* 23 화면 안내 띠와 같은 글 */
    else if (st === 'offline') toast('연결이 원활하지 않아 알림 예약을 맞추지 못했어요.\n연결된 뒤 홈 화면을 열면 다시 맞춰요.');
  }
  /* ── 약관 동의 직후 휴대폰 접근권한 묻기 ──
     안드로이드 시스템 팝업은 한 번에 하나씩만 뜬다. 앞 팝업이 닫힌 뒤 다음을 띄운다.
     위치·알림은 02 동의 화면에서 켠 경우에만 묻는다. 모두 거절해도 앱은 그대로 쓸 수 있다. */
  function askPermissions(opt, done) {
    opt = opt || {};
    if (!isNative) return done();
    var steps = [];
    if (P.Camera && P.Camera.requestPermissions) {
      steps.push(function () { return P.Camera.requestPermissions({ permissions: ['camera', 'photos'] }); });
    }
    if (opt.location && P.Geolocation && P.Geolocation.requestPermissions) {
      steps.push(function () { return P.Geolocation.requestPermissions(); });
    }
    if (opt.notifications && P.LocalNotifications && P.LocalNotifications.requestPermissions) {
      steps.push(function () { return P.LocalNotifications.requestPermissions(); });
    }
    var i = 0;
    (function next() {
      if (i >= steps.length) return done();
      var step = steps[i++];
      var moved = false;
      function go() { if (moved) return; moved = true; setTimeout(next, 250); }
      /* 권한 팝업이 끝내 응답을 주지 않아도 가입이 막히지 않게 한다 */
      setTimeout(go, 12000);
      try { step().then(go, go); } catch (e) { go(); }
    })();
  }

  /* ── 약봉투 글자 해석기 — 53 촬영이 쓰고, 54 확인·58 직접입력이 제형 판정(formKind)을 함께 쓴다 ──
     화면(page53) 안에 있던 것을 밖으로 꺼냈다. 58 에서 적은 이름으로도 먹는 약/바르는 약을 짐작해야 해서다.
     회귀시험(약인식_개선/회귀시험/run.js)은 'var SKIP_LINE =' 부터 parseMeds 끝까지를 잘라 돌리므로
     파서가 쓰는 것은 모두 이 구간 안에 둔다. */
  var OCRP = (function () {
    /* 사진에서 약 뽑기 — 제품명(목펜정)을 쓰고 성분명(…수화물 68.1mg)은 쓰지 않는다.
       횟수는 "그 약과 같은 줄에 있는 숫자 3개(1회량·횟수·일수)"에서만 읽는다.
       확신이 없으면 비워 두고 54 화면이 환자에게 묻는다 — 잘못된 복약 알림보다 낫다. */
    /* 머리글 변형: 팜IT3000 구형은 가운데 글자가 '횟수'인지 '회수'인지 판독되지 않는다 — 둘 다 받는다 */
    /* 2026-09-27 — 실제 봉투에서 새던 줄을 막는다. 여기 적는 낱말은 '국내 의약품 제품명에는
       쓰이지 않는 말'만 고른다. 예를 들어 '어린이'는 넣지 않는다 — 어린이타이레놀산이 있다. */
    var SKIP_LINE = /병원|의원|약국|성명|전화|주소|처방|조제|보험|계산서|영수|QR|투약량|투여량|횟수|회수|일수|본인부담|약제비|복약안내|복약지도|복용안내|약품|성분|이미지|주의|효능|참고|사항|출력|발행|접수|교부|일련|차트|챠트|면허|요양|내원|진료|유효기간|사용기한|제조|보관|반납|폐기|반품|제약|주식회사|㈜|수진자|생년월일|보호자|바코드|안내문|문의/;
    /* ── 진료과·의료기관 이름 ── 2026-09-28 (팜IT3000 봉투 뒷면 상품사진에서 확인)
       봉투 뒷면에는 '인근 병·의원' 목록이 인쇄돼 있다 — '삼성어린이소아과 (02) 356-8963'.
       '병원'·'의원'이 안 들어간 이름이라 그대로 지나갔고, 파서가 지나친 줄을 다시 보는
       되살리기(HIRA.pickRevive)가 이 줄을 약 이름 후보로 삼아 식약처 조회 글자로 내보냈다.
       환자분이 다니시는 병원 이름은 밖으로 나가면 안 된다.
       두 자짜리(내과·안과…)는 뒤에 한글이 더 붙지 않을 때만 본다 — 약 이름을 함께 막지 않으려고. */
    var MED_DEPT = /(소아청소년과|소아과|이비인후과|정형외과|성형외과|신경외과|흉부외과|재활의학과|가정의학과|영상의학과|마취통증의학과|응급의학과|정신건강의학과|산부인과|비뇨의학과|비뇨기과|피부과|한의원|한방병원|요양원|보건지소|보건소|의료원|클리닉|메디컬|의료재단)|((내과|외과|안과|치과|신경과|정신과)(?![가-힣]))/;
    var MONEY = /(총액|금액|합계|소계|총계|잔액|차액|부담|청구|정산|환산|조정|확정|납부|미납|면제|할인|수납|급여|공단|본인|계산)/;
    var GENERIC = /(수화물|염산염|염산|나트륨|칼슘|시트르산|말레산|황산염|타르타르산|브롬화|인산염|질산염|메실산|푸마르산)/;
    /* 성분명이 '…산'으로 끝나면 그 '산'은 산(酸)이지 가루약(산제) 꼬리가 아니다 — '에날라프릴말레산 10mg' */
    var ACID_TAIL = /(시트르산|말레산|푸마르산|메실산|타르타르산|염산|황산|인산|질산)$/;
    /* 필독 안내문의 약효 분류 괄호 — '[항혈전제]' · '[폐쇄성기도 치료제] 테오브로민 300mg' */
    var CLASS_HEAD = /^\s*[\[【]\s*[^\]】]{1,24}\s*[\]】]\s*/;
    /* 용법·안내 문장에 쓰이는 말 — 약 이름에는 나오지 않는다.
       봉투에 미리 인쇄된 '아침 점심 저녁 취침전' 줄이 순번을 떼고 약 이름으로 잡히지 않게 한다. */
    /* '하루'는 뒤에 오는 말을 함께 본다 — '하루날디정'(탐스로신)은 진짜 약인데 통째로 막혔다.
       용법으로 쓰이는 '하루'는 뒤에 숫자·횟수말이 붙는다('하루 3회'·'하루 세 번'·'하루에'). */
    var USAGE_WORD = /(식후|식전|식간|취침|자기전|아침|점심|저녁|공복|시간마다|일분|하루(?=[0-9]|[한두세네다섯여섯]|회|번|에|만|씩|분|치|종)|매일|복용|드세요|하세요|마세요|최대|이상|이하|까지)/;
    /* 용법 숫자가 아닌 줄 — 조제일자(2026-09-16)·전화번호·금액·약품코드·시각.
       이런 숫자가 그 약 구간에 섞이면 용법을 통째로 날리거나 엉뚱하게 읽는다.
       일·월·연 순 날짜(16.09.26)는 붙여 쓴 것만 본다 — 띄어 쓴 '1 / 1 / 30'은 팜IT3000 구형의 투약량/횟수/일수 칸이다. */
    var NOISE_NUM = /(\d{4}\s*[-./년]\s*\d{1,2}\s*[-./월]\s*\d{1,2})|(\d{1,2}[-./]\d{1,2}[-./]\d{2,4})|(\d{2,4}-\d{3,4}-\d{4})|(\d{1,3}(,\d{3})+)|(\d{5,})|(\d{1,2}\s*:\s*\d{2})/;
    /* 제형 꼬리말 → 투여경로 짐작(2순위 근거. 1순위는 심평원 injcPthNm).
       좁은 제형을 먼저 본다 — '점안액'이 '액'에, '질정'이 '정'에 먼저 걸려 먹는 약으로 뭉개지지 않게.
       eye 눈에 넣는 약 · patch 붙이는 약 · inhale 흡입 · injection 주사(병원에서 맞는 약) · other 그 밖의 외용 · skin 바르는 약 · oral 먹는 약 */
    var FORM_KINDS = [
      /* 2026-09-20 교수님 피드백 — '네오덱스안연고'가 '안약'으로 잡혔다.
         눈에 넣는 약은 점안액·점안현탁액처럼 '점안…'과 '안약'뿐이고,
         안연고는 눈꺼풀에 바르는 연고라 아래 skin(바르는 약)으로 내려보낸다. */
      [/(점안현탁액|점안유탁액|점안용액|점안액|점안제|점안겔|점안|안약)$/, 'eye'],
      [/(첩부제|카타플라스마|플라스타|플라스터|패치|파스)$/, 'patch'],
      [/(흡입액|흡입제|흡입용액|흡입분말|흡입캡슐|흡입기|할러|헬러|레스피맷|엘립타)$/, 'inhale'],
      [/(주사액|주사제|주사|시린지|프리필드펜|[가-힣]{3,}주)$/, 'injection'],
      [/(질좌제|좌제|좌약|질정|질크림|질겔|가글액|가글|구강용액|구강스프레이|점이액|점비액|나잘스프레이|비강스프레이)$/, 'other'],
      [/(안연고|연고|크림|겔|젤|로션|리니멘트|외용액|외용제|도포제|스프레이|에어로졸|폼)$/, 'skin'],
      /* 캡슬·캡술·캅슐 — '캡슐'이 이렇게 읽히는 일이 잦다(2026-09-26 실사진 OCR: 애니코프캡슬·엘도스캡슬).
         이 한 글자 때문에 제형 꼬리를 못 찾아 그 약이 목록에서 통째로 빠졌다. */
      [/(서방정|장용정|서방|정제|정|캡슐|캡슬|캡술|캅슐|캅셀|시럽|과립|산|환|현탁액|건조시럽|산제|내용액|경구액)$/, 'oral'],
      /* 그냥 '…액'은 먹는 물약(라미나지액)도, 가글·소독약(헥사메딘액·포비돈액)도 된다 — 약 이름으로는 잡되 경로는 짐작하지 않는다 */
      [/액$/, 'liquid']
    ];
    /* ── 제형 낱말만 있는 줄 ── 2026-09-27
       봉투·안내문의 생김새 설명이 조각나면 '경질캡슐'·'연질캡슐'·'당의정'·'필름코팅정'만 남는다.
       제형 꼬리가 있으니 약 이름으로 잡혀, 드시지도 않는 약이 목록에 생겼다.
       앞말까지 함께 제형을 가리키는 말일 때만 막는다 — '탁센연질캡슐'·'오메가3연질캡슐' 같은
       진짜 제품명은 앞에 제품 이름이 더 있어 여기 걸리지 않는다. */
    var FORM_ONLY = /^(경질|연질|장용|필름코팅|코팅|당의|나|서방|속방|구강붕해|츄어블|저작|발포|현탁|건조|분산|다층|이층|유핵|소프트|하드)?(정|정제|캡슐|캡슬|캅셀|캅슐|산|산제|과립|과립제|시럽|액|액제|연고|크림|겔|젤|환|환제|주|주사|주사제|패치|첩부제|좌제|현탁액|내복액|점안|점안액|안연고)$/;
    function formKind(x) {
      var s = String(x == null ? '' : x).replace(/\s+/g, '');
      for (var fi = 0; fi < FORM_KINDS.length; fi++) {
        if (!FORM_KINDS[fi][0].test(s)) continue;
        /* '다음주'·'이번주' 같은 날짜 말은 주사제가 아니다 */
        if (FORM_KINDS[fi][1] === 'injection' && /(매|격|다음|이번|지난)주$/.test(s)) return '';
        return FORM_KINDS[fi][1];
      }
      return '';
    }
    /* 이름 뒤에 붙은 용량 표기를 떼어낸다.
       '리피토정(10mg)' '아모잘탄정5/50mg' '히아린점안액0.15%' 처럼 지금까지 통째로
       버려지던 표기를 살리기 위해 괄호·슬래시·퍼센트까지 본다.
       PM+20 은 약품명을 16자에서 자른다 — '…650밀리그' 처럼 잘린 단위도 용량으로 본다. */
    var DOSE_TAIL = /[\s_]*[(\[{]?\s*\d[\d.,]*(?:\s*[\/·:xX×]\s*\d[\d.,]*)*\s*(?:mg|mcg|㎎|㎍|ug|μg|g|kg|ml|mL|㎖|cc|iu|IU|%|퍼센트|밀리그람|밀리그램|밀리그|밀리리터|밀리리|밀리|마이크로그람|마이크로그램|마이크로그|마이크로|그람|그램|단위)?\s*[)\]}]?\s*\.?$/i;
    /* 떼어낸 꼬리에 '용량 단위'가 있었는지 — 예비 통과(제형 꼬리 없는 이름)의 근거.
       맨 숫자만 떼어낸 줄('서울시 강남구 123')은 약 이름으로 보지 않는다. */
    var DOSE_UNIT = /(mg|mcg|㎎|㎍|ug|μg|\dg(?![a-z])|kg|ml|㎖|cc|iu|%|퍼센트|밀리|마이크로|그람|그램|단위|\d\s*\/\s*\d)/i;
    /* 한 행 뭉침에서 이름 뒤 용량(500mg·5/50mg)을 떼는 머리 — 단위가 있어야만 뗀다 */
    var STRENGTH_HEAD = /^\s*[(\[{]?\s*\d[\d.,]*(?:\s*[\/·]\s*\d[\d.,]*)*\s*(?:mg|mcg|㎎|㎍|ug|μg|g|kg|ml|mL|㎖|cc|iu|IU|%|퍼센트|밀리그람|밀리그램|밀리그|밀리리터|밀리리|밀리|마이크로그람|마이크로그램|마이크로그|마이크로|그람|그램|단위)\s*[)\]}]?/i;
    /* 용량을 떼고 남은 것이 정확히 숫자 세 칸(1회량·횟수·일수)일 때만 */
    var ROW_USAGE = /^\s*\d{1,2}(?:\.\d)?(?:\s*[\/·]\s*|\s+)\d{1,2}(?:\s*[\/·]\s*|\s+)\d{1,3}\s*$/;
    /* 표가 한 줄로 뭉쳐 읽히는 일이 잦다 — 특히 아이폰(테서랙트)에서는 한 행이 통째로
       '1 타이레놀정500mg 1 3 5' 로 들어온다. 앞의 순번과 뒤의 숫자 칸을 떼지 않으면
       제형 꼬리(정·액)가 가려져 그 약이 목록에서 통째로 사라진다.
       뒤는 여러 번 떼고, 앞의 순번은 한 번만 — 떼고도 한글이 두 자 이상 남을 때만 손댄다. */
    var SEQ_HEAD = /^\s*\d{1,2}(?:\s*[.)]\s*|\s+)/;
    /* ── 줄 끝·줄 앞에 붙은 잡글자 ── 2026-09-26 실사진 확인
       감열지·괘선이 글자로 읽혀 이름 끝에 막대기 하나가 붙는 일이 잦다('애니코프캡슐300|').
       그 한 글자 때문에 제형 꼬리가 가려져 약이 통째로 빠졌다. 괄호는 건드리지 않는다 —
       '[항혈전제]' 같은 분류 괄호를 가르는 데 쓰기 때문이다. */
    var JUNK_L = /^[\s'"`~^*_=+·:;,.…|｜ㅣ\\/\-–—]+/;
    var JUNK_R = /[\s'"`~^*_=+·:;,.…|｜ㅣ\\\-–—]+$/;
    function trimJunk(x) { return String(x == null ? '' : x).replace(JUNK_L, '').replace(JUNK_R, ''); }
    /* ── 숫자 자리에 끼어든 영문 ── 2026-09-27
       봉투는 감열지에 작게 찍혀서 0 이 O 로, 1 이 l·I 로 읽힐 때가 있다('마그밀정5OOmg').
       그러면 용량 꼬리를 떼지 못해 그 약이 통째로 목록에서 빠지고, 뒤이어 짝을 잘못 맞춘
       옆 약의 용법까지 지워진다. 약 네 개가 잡히니 '못 찾았어요' 알림도 안 떠서 아무 말 없이
       한 약이 빠진다. 그러므로 '단위가 붙은 맨 끝 숫자 꼬리' 에서만, 그것도 진짜 숫자가 한 자
       이상 섞여 있을 때만 되돌린다 — 이름 글자는 절대 건드리지 않는다.
       길이가 그대로이므로 뒤에서 떼어내는 자리 잡기(tail)도 그대로 맞는다. */
    var CONF_TAIL = /([\s_]*[(\[{]?\s*)([0-9OoIl][0-9OoIl.,]*(?:\s*[\/·:xX×]\s*[0-9OoIl][0-9OoIl.,]*)*)(\s*(?:mg|mcg|㎎|㎍|ug|μg|g|kg|ml|mL|㎖|cc|iu|IU|%|퍼센트|밀리그람|밀리그램|밀리그|밀리리터|밀리리|밀리|마이크로그람|마이크로그램|마이크로그|마이크로|그람|그램|단위)\s*[)\]}]?\s*\.?)$/i;
    function unconfuseDose(x) {
      var t = String(x == null ? '' : x);
      var mm = CONF_TAIL.exec(t);
      if (!mm) return t;
      if (!/[0-9]/.test(mm[2])) return t;                  /* 진짜 숫자가 하나도 없으면 용량이 아니다 */
      var d = mm[2].replace(/[Oo]/g, '0').replace(/[Il]/g, '1');
      if (d === mm[2]) return t;                           /* 고칠 것이 없다 */
      return t.slice(0, mm.index) + mm[1] + d + mm[3];
    }
    /* { name: 떼고 남은 이름, seq: 떼어낸 순번, tail: 뒤에서 떼어낸 것 } */
    function stripInfo(x) {
      var s = trimJunk(String(x == null ? '' : x).trim()), seq = '';
      var mh = SEQ_HEAD.exec(s);
      if (mh) {
        var h = s.replace(SEQ_HEAD, '').trim();
        if (h.replace(/[^가-힣]/g, '').length >= 2) { seq = mh[0].replace(/[^0-9]/g, ''); s = h; }
      }
      s = unconfuseDose(s);                             /* '5OOmg' → '500mg' (길이는 그대로) */
      var body = s;
      for (var si = 0; si < 6 && DOSE_TAIL.test(s); si++) {
        var t = s.replace(DOSE_TAIL, '').trim();
        if (!t || t === s) break;
        s = t;
      }
      return { name: s, seq: seq, tail: body.slice(s.length) };
    }
    function stripDose(x) { return stripInfo(x).name; }
    /* ── 생김새 설명 ── 2026-09-20 교수님 피드백 · 2026-09-26 보강
       봉투·안내문은 알약 색과 모양을 함께 찍는다('무색 내지 미황색 현탁액'·'백색 원형의 필름코팅정').
       제형 꼬리가 붙어 있어 약 이름으로 잡혔고, 환자분이 드시지도 않는 약이 목록에 생겼다.
       약 제품명에는 이런 색·모양 말이 쓰이지 않는다. */
    var SHAPE_WORD = /(무색|유백색|미황색|담황색|담적색|연갈색|불투명|반투명|투명한|타원형|장방형|원형의|팔각형|육각형|마름모|각인|절단선|양면|장축|단축|필름코팅|당의정?의)/;
    var COLOR_WORD = /(백색|흰색|황색|적색|청색|녹색|갈색|분홍색|주황색|회색|자색|등황색|노랑|하양|파랑|초록|빨강)/;
    var SHAPE_JOIN = /(내지|또는|원형|타원|모양|색의|색이|앞면|뒷면|한쪽|양쪽|분할선|각인|표면|겉면|양각|음각)/;
    function looksLikeShape(flat) {
      if (SHAPE_WORD.test(flat)) return true;
      return COLOR_WORD.test(flat) && SHAPE_JOIN.test(flat);
    }
    /* ── 환자·조제자 성함 ── 2026-09-26 (마지막 관문에서 넓혔다)
       봉투에 찍힌 '환자 성명 : 김○○' 이나 '담당약사 박○○' 이 OCR 에서 이름만 한 줄로 떨어져 나오면,
       끝 글자가 제형 꼬리와 같은 이름이 약으로 잡혔다.
       약으로 잡히면 목록에도 오르고 식약처 조회 글자로 밖에 나간다 — 성함은 나가면 안 된다.
       처음에는 '딱 세 자 + 정·환' 만 막아서 이런 것들이 그대로 통과했다(글자본으로 실제 확인):
         · 복성 네 자 — 남궁민정 · 황보라정
         · 다른 제형 꼬리 — 이정액(액) · 최영산(산)
         · 직함이 붙어 읽힌 줄 — 담당약사박현정 · 약사김정환 · 제조자정미환
       좁게 보는 원칙은 그대로다 — 제형 꼬리를 떼면 성씨 + 한두 자(복성은 두 자 + 한두 자)만 남는 줄만 막는다.
       그래야 '백초시럽'·'오라겔'·'베아제정'·'마그밀정' 같은 진짜 약이 함께 빠지지 않는다.
       꼬리에 '주'는 넣지 않는다 — '허셉틴주'처럼 성씨로 시작하는 진짜 주사약이 있다.
       세 자 완제품·한방 산제(정로환·오적산)는 따로 받아 둔다. */
    var SURNAME2 = /^(남궁|선우|황보|제갈|사공|서문|독고)/;   /* 복성 — 이름이 네 자가 된다 */
    var SURNAME = /^(김|이|박|최|정|강|조|윤|장|임|한|오|서|신|권|황|안|송|류|유|전|홍|고|문|양|손|배|백|허|남|심|노|하|곽|성|차|주|우|구|나|민|진|지|엄|채|원|천|방|공|현|함|변|염|여|추|도|소|석|선|설|마|길|연|위|표|명|기|반|왕|금|옥|육|맹|제|모|탁|국|어|편|용|봉|피)/;
    var NAME_OK = /^(정로환|청심환|소체환|백초환|쌍화탕|오적산|구풍산|안중산|방풍산|평위산|은교산|삼소산|마자인환|우황환)$/;
    /* 이름 끝 글자와 겹치는 제형 꼬리 */
    var NAME_TAIL_CH = /[정환산액]$/;
    /* 직함·역할이 이름에 붙어 한 줄로 읽힌 것 — 약 제품명에는 이런 말이 쓰이지 않는다 */
    var ROLE_WORD = /(약사|의사|간호사|조제자|제조자|투약자|담당자|담당약|환자|보호자|수진자|성명|성함)/;
    function looksLikePerson(flat) {
      if (NAME_OK.test(flat)) return false;
      if (ROLE_WORD.test(flat) && /^[가-힣]{3,12}$/.test(flat)) return true;
      if (!/^[가-힣]{3,4}$/.test(flat) || !NAME_TAIL_CH.test(flat)) return false;
      if (!SURNAME.test(flat)) return false;
      var k = formKind(flat);
      if (!k) return false;                                  /* 제형 꼬리가 없으면 어차피 약으로 잡히지 않는다 */
      var rest = flat;
      for (var fi = 0; fi < FORM_KINDS.length; fi++) {
        if (FORM_KINDS[fi][0].test(flat)) { rest = flat.replace(FORM_KINDS[fi][0], ''); break; }
      }
      return rest.length <= (SURNAME2.test(flat) ? 3 : 2);
    }
    function looksLikeName(x) {
      if (!x) return false;
      var flat = x.replace(/\s/g, '');
      if (looksLikeShape(flat)) return false;                 /* 알약 생김새 설명은 약 이름이 아니다 */
      if (FORM_ONLY.test(flat)) return false;                 /* '경질캡슐'처럼 제형 낱말만 있는 줄 */
      if (looksLikePerson(flat)) return false;                /* 환자 성함은 약 이름이 아니다 */
      /* 두 칸 카드가 한 줄로 읽혀 약 이름 둘이 붙어 온 줄('엘도스캡슐 리피토정') — 통째로 받으면
         있지도 않은 약이 하나 생긴다. 조각마다 제형 꼬리가 있으면 아래 ③ 통과가 하나씩 집어 낸다.
         (2026-09-26 실사진: 필독 A4 두 칸 카드) */
      if (/\s/.test(x)) {
        var ps = x.replace(/^\s+|\s+$/g, '').split(/\s+/), tailed = 0;
        for (var pi = 0; pi < ps.length; pi++) if (formKind(stripInfo(ps[pi]).name)) tailed++;
        if (tailed >= 2) return false;
      }
      /* '복약 안내'·'투약 량'처럼 띄어 읽힌 머리글도 걸러지게 공백을 뺀 글자로도 본다 */
      if (SKIP_LINE.test(x) || SKIP_LINE.test(flat) || MONEY.test(x)) return false;
      if (MED_DEPT.test(flat)) return false;                  /* 진료과 이름 — 봉투 뒷면 '인근 병·의원' 목록 */
      /* 성분명(…나트륨·…염산염·…수화물)은 이름이 아니다. 다만 제형 꼬리가 붙은 제품명은 약 이름이다 —
         성분명을 그대로 제품명으로 쓰는 복제약(리세드론산나트륨정·로페라미드염산염캡슐·히알루론산나트륨점안액) */
      if (GENERIC.test(x) && (!formKind(x) || ACID_TAIL.test(flat))) return false;
      if (USAGE_WORD.test(flat)) return false;               /* 용법·안내 문구는 이름이 아니다 */
      if (NOISE_NUM.test(x)) return false;                    /* 날짜·전화·금액·약품코드는 이름이 아니다 */
      if (/^\d/.test(flat)) return false;                     /* 약 이름은 숫자로 시작하지 않는다('1일 최대') */
      if (x.length > 22) return false;
      if (flat.length < 3) return false;
      var han = x.replace(/[^가-힣]/g, '');
      if (han.length < 2) return false;                       /* 한글이 거의 없으면 이름으로 보지 않는다 */
      /* 용량을 뗀 뒤에도 숫자가 남을 수 있다('비타민B12정'). 짧은 숫자만, 한글이 충분할 때만 허용 */
      var digits = x.replace(/[^0-9]/g, '');
      if (digits.length > 4) return false;
      if (digits.length && han.length < 3) return false;
      return true;
    }
    /* ── 읽다 만 줄 ── 2026-09-27
       제형 꼬리(정·캡슐·점안액…)는 보이는데 글자가 깨져 이름으로 받지 못한 줄이다.
       '약이 아니어서' 뺀 줄(병원 이름·조제일·생김새 설명)과는 다르다 — 그것들은 여기서 걸러 낸다.
       이런 줄이 있으면 54 가 '이 줄은 못 읽었어요, 빠진 약이 있으면 직접 넣어 주세요' 하고 알린다.
       지어내서 목록에 넣지는 않는다 — 엉뚱한 약을 넣는 것이 못 넣는 것보다 나쁘다. */
    /* 줄 안에서 '약 이름처럼 생긴 토막'을 집어낸다 — 한글 두 자 이상에 제형 꼬리가 바로 붙은 덩어리.
       줄 끝에 잡글자가 붙어('슈가메트서방정5/100… EEE CEE') 이름 칸으로는 못 읽는 줄에서도 집힌다. */
    var MED_TOKEN = /[가-힣]{2,}(?:정제|정|캡슐|캡슬|캅셀|캅슐|시럽|연고|크림|겔|젤|산제|과립|환|현탁액|점안액|안연고|패치|주사|액)(?![가-힣])/;
    function garbledToken(x) {
      var raw = String(x == null ? '' : x).replace(/\s+/g, ' ').trim();
      if (raw.length < 3) return '';
      var flat = raw.replace(/\s/g, '');
      if (looksLikeShape(flat) || looksLikePerson(flat)) return '';
      if (SKIP_LINE.test(raw) || SKIP_LINE.test(flat) || MONEY.test(raw)) return '';
      if (MED_DEPT.test(flat)) return '';
      if (USAGE_WORD.test(flat) || GENERIC.test(raw)) return '';
      if (/(금기|병용|중복|대체|동일성분|일반명)/.test(raw)) return '';   /* 안내 글줄에 적힌 약 이름 */
      var m = MED_TOKEN.exec(flat);
      if (!m) return '';
      var t = m[0];
      if (FORM_ONLY.test(t)) return '';                       /* '경질캡슐'처럼 제형 낱말만 */
      return t.replace(/[^가-힣]/g, '').length >= 3 ? t : '';
    }
    function looksGarbled(x) { return !!garbledToken(x); }
    /* 앱이 표현할 수 있는 복용 횟수는 1~4번뿐이다 (MED_SLOTS) */
    function okTimes(n) { return n >= 1 && n <= 4; }

    /* ── 봉투에 미리 인쇄된 용법 줄 ──
       빈 봉투에도 '1일 ___회 ___일분 □식후30분 □취침전 아침 점심 저녁'이 인쇄돼 있어 OCR 이 그대로 읽는다.
       용법 단어가 보인다고 채택하지 않는다 — 인쇄된 고정 숫자('1일'의 1, '30분'의 30)를 빼고도
       숫자가 남거나 체크 표시가 채워졌을 때만 '채워진 줄'로 본다. */
    var TEMPLATE_WORD = /(회|일분|식후|식전|식사|취침|자기전|아침|점심|저녁|공복|시간마다|표시대로|지시대로|물약)/;
    var CHECK_MARK = /[■●☑✔✓◉▣◼]/;
    function isPreprinted(txt) {
      var s = String(txt == null ? '' : txt).replace(/\s+/g, '');
      if (!TEMPLATE_WORD.test(s) || CHECK_MARK.test(s)) return false;
      s = s.replace(/(식후|식전)(30|3O)분/g, '')
           .replace(/(^|[^0-9])1일(?![0-9]|분)/g, '$1');
      return !/\d/.test(s);
    }

    /* ── 두 줄로 나뉜 표 머리글 ── 2026-09-28 (PM2000 조제약 봉투 · 이팜 영수증 띠에서 확인)
       봉투 표의 머리글은 칸이 좁아 두 줄로 나뉘어 찍힌다 — '1회'/'투약량' · '1일투여'/'횟수' · '총투약'/'일수'.
       아랫줄('투약량'·'횟수'·'일수')은 SKIP_LINE 이 이미 거르는데 윗줄은 걸러지지 않아,
       '1회'가 '하루 한 번'으로 '1일투여'가 '하루치'로 읽혔다.
       이팜 서식(영수증이 왼쪽)에서 '타목시펜정 1/1/28' 이 '하루 1번 1일치'로 바뀌어 들어갔다.
       머리글 조각은 그 자체로는 아무 뜻이 없으므로 용법 줄에서 아예 뺀다. */
    var HEAD_FRAG = /^(1회|1일|일회|일일|매회|회당|총|총량|총계|총투약|총투여|1일투여|1일투약|1회투약|투여|투약|용량|분량)$/;
    function isHeadFrag(txt) { return HEAD_FRAG.test(String(txt == null ? '' : txt).replace(/[\s.:·/]+/g, '')); }
    /* ── 봉투에 인쇄된 '고를 것 늘어놓은 띠' ── 2026-09-28
       팜IT3000 구형·PM2000·크레소티 봉투는 표 아래(크레소티는 위)에 이런 띠를 찍는다 —
         '1일 __회 __일분  ○식후30분 ○식전30분 ○취침전 ○식후즉시'
         '시럽은 1회 __ml씩 __회 복용  ○냉장보관 ○실온보관'
       약사가 손으로 채우면 숫자가 생기지만, 그 띠는 봉투 하나를 통틀어 적은 것이지
       표 안 어느 한 약의 용법이 아니다. 그런데 표 맨 아래 약의 구간에 들어가 그 약에만 붙었다.
       그래서 봉투에 약이 하나뿐일 때만 쓴다 — 여럿이면 비워 두고 54 화면이 환자분께 여쭙는다. */
    var BAND_OPT = /(식후30분|식후3O분|식전30분|식전3O분|식후즉시|식사직전|식직후|취침전|자기전|공복|냉장보관|실온보관|의사지시대로|표시대로)/g;
    var BAND_MARK = /[○◯〇□▢◻]/g;
    function isOptionBand(txt) {
      var s = String(txt == null ? '' : txt).replace(/\s+/g, '');
      var m = s.match(BAND_OPT);
      if (m && m.length >= 2) return true;
      var c = s.match(BAND_MARK);
      return !!(c && c.length >= 2);
    }

    /* ── 표의 열 좌표 읽기 ──
       머리글('순번 / 1회 투약량 / 1일 투여횟수 / 총 투약일수')이 각각 어디 있는지를 기억해 두면
       왼쪽에 순번 열이 하나 더 있어도 숫자를 밀려 읽지 않는다.
       표 본문에 세로 괘선이 없는 서식(팜IT3000 구형·신형)이 대부분이라 머리글 글자 + x 좌표로만 나눈다.
       받는 변형: 투약량|1회투약량|1일투약량 · 횟수|회수|투여횟수 · 일수|투약일수|총투약일수 · 복약안내(글 칸) */
    function findCols(ALL) {
      var c = { seq: null, dose: null, times: null, days: null, guide: null };
      ALL.forEach(function (it) {
        var t = it.text.replace(/\s/g, '');
        if (!t || t.length > 12) return;
        var hit = [];
        if (/^(순번|번호|연번|일련번호|No\.?|NO\.?)$/i.test(t)) hit.push('seq');
        if (/(투약량|투여량|복용량|1회량|일회량)/.test(t) && !/일수|횟수|회수/.test(t)) hit.push('dose');
        if (/(횟수|회수)/.test(t) && !/일수|투약량|투여량/.test(t)) hit.push('times');
        if (/((투약|투여)?일수|일분|투약일)/.test(t) && !/횟수|회수|투약량|투여량/.test(t)) hit.push('days');
        /* 복약안내 칸(글 칸) — 그 아래 숫자는 용법 칸이 아니다. '복약안내(투약량/횟수/일수)' 병합 머리글은 여기 오지 않는다 */
        /* '복용법' 은 PM2000 조제약 봉투의 글 칸 머리글이다(실물 빈 서식에서 확인) */
        if (/^(복약안내|복약지도|복용안내|복약정보|복용법|복용방법|복약법|용법|용법용량)$/.test(t)) hit.push('guide');
        /* 머리글 두 개가 한 덩어리로 읽혔으면 어느 쪽 좌표인지 알 수 없다 — 버린다 */
        if (hit.length !== 1) return;
        if (c[hit[0]] === null) c[hit[0]] = it.x;
      });
      return c;
    }
    /* 머리글 사이의 가장 좁은 간격 = 열 폭의 대략값. 두 개 이상 찾았을 때만 쓸 수 있다 */
    function colGapOf(cols) {
      var xs = [];
      ['seq', 'dose', 'times', 'days'].forEach(function (k) { if (cols && cols[k] !== null) xs.push(cols[k]); });
      if (xs.length < 2) return 0;
      xs.sort(function (a, b) { return a - b; });
      var g = Infinity;
      for (var gi = 1; gi < xs.length; gi++) { var d = xs[gi] - xs[gi - 1]; if (d > 0 && d < g) g = d; }
      return (g === Infinity) ? 0 : g;
    }
    /* 숫자에 붙은 단위 — '3회'·'5일'·'1정'처럼 뜻이 적혀 있으면 열 위치보다 확실하다 */
    var UNIT_DOSE = /^(정|알|캡슐|캅셀|포|매|장|앰플|바이알|밀리|㎖|㎎|ml|mL|g|mg|cc|t|c)$/;
    var UNIT_TIMES = /^(회|번)$/;
    var UNIT_DAYS = /^(일|일분|일치|일간)$/;
    function tokenUnit(tail) {
      var u = String(tail || '').replace(/[\s.,)\]}]/g, '');
      u = u.replace(/씩$/, '');          /* '1정씩 3회' — 단위 뒤의 '씩' 은 뜻에 영향이 없다 */
      if (!u) return '';
      if (UNIT_TIMES.test(u)) return 'times';
      if (UNIT_DAYS.test(u)) return 'days';
      if (UNIT_DOSE.test(u)) return 'dose';
      return '';
    }
    /* 숫자 조각 — 값·붙은 단위·그 줄의 가로 위치·그 줄에 숫자가 하나뿐이었는지 */
    function numTokens(rows) {
      var out = [];
      (rows || []).forEach(function (r) {
        var re = /(\d+(?:[.,]\d+)?)\s*([가-힣a-zA-Z]{0,2})/g, m, inLine = [];
        while ((m = re.exec(r.text))) inLine.push({ v: m[1], u: tokenUnit(m[2]), x: r.x, alone: false });
        inLine.forEach(function (t) { t.alone = inLine.length === 1; out.push(t); });
      });
      return out;
    }
    function buildDose(dose, times, days) {
      var d = (dose === null || dose === undefined || dose === '') ? 1 : parseFloat(String(dose).replace(',', '.'));
      var t = parseInt(String(times).replace(/[^0-9]/g, ''), 10);
      var y = parseInt(String(days).replace(/[^0-9]/g, ''), 10);
      if (!(d > 0 && d <= 10)) return null;                   /* 1회 10정을 넘으면 잘못 읽은 것이다 */
      if (!okTimes(t)) return null;
      if (!(y >= 1 && y <= 120)) return null;
      return { times: t, days: y };
    }
    /* ── 문장으로 적힌 용법 ── 2026-09-26 교수님 피드백(약국마다 표기가 다르다)
       숫자 칸이 아니라 문장으로 적는 약국이 많다 —
         '하루 3회 1정씩 3일분'(필독 2019) · '1일 3회 5일분' · '1회 1정 1일 3회 총 5일분'
         '하루 세번 7일분' · '8시간마다 하루 3회 5일분' · '1일 1회 취침전 30일분'
       지금까지 이런 줄은 숫자 칸 잣대(isNumCell)에서 통째로 걸러져 용법이 빈 채로 54 로 넘어갔다.
       읽는 것은 '하루 몇 번'과 '며칠분' 둘뿐이다 — 1회 투약량은 앱이 쓰지 않으므로 보지 않는다.
       뜻이 뒤집히기 쉬운 자리는 모두 비운다: '1일 3회'의 1은 일수가 아니고, '1회 1정'의 1회는 횟수가 아니며,
       '주 1회'처럼 주 단위로 먹는 약과 '최대 4회까지' 같은 안내 문장은 아예 손대지 않는다.
       → { times: n|0, days: n|0 } · 읽을 수 없으면 null */
    var PH_SKIP = /(최대|이상|이하|까지|초과|미만|넘지|권장|간격|이내|경과|남았|지나면|반복|넘게|정도)/;
    var PH_CYCLE = /(주|격주|격일|매월|개월|한달|사이클|주기)\s*\d*\s*[회번]/;   /* 주·월 단위 횟수는 앱이 담지 못한다 */
    /* ── 날마다 드시는 약이 아닌 경우 ── 2026-09-28
       '1일 1회 격일 복용 30일분' 을 '하루 한 번 30일'로 읽어 저장했다. 이틀에 한 번 드시는 약인데
       앱이 날마다 알렸다. '한 달에 한 번'도 '한달' 과 '한 번' 사이에 '에' 가 끼면 PH_CYCLE 이 놓쳤다.
       앱이 담을 수 있는 것은 '하루 1~4번'뿐이므로, 날마다가 아닌 표기가 보이면 아예 읽지 않는다. */
    var PH_ALT = /(격일|격주|이틀에|사흘에|하루걸러|이틀마다|사흘마다|한달에|1달에|개월에|일주일에|주일에|간헐)/;
    var PH_UNIT = /^\d{1,2}(?:\.\d)?\s*(정|알|캡슐|캡슬|캡술|캅셀|포|매|장|앰플|바이알|스푼|방울|㎖|ml|cc|mg|g)/i;
    var KNUM = { '한': 1, '두': 2, '세': 3, '네': 4 };
    function phraseDose(txt) {
      var s = String(txt == null ? '' : txt);
      if (!/[0-9]/.test(s)) return null;
      if (NOISE_NUM.test(s) || MONEY.test(s) || SKIP_LINE.test(s) || GENERIC.test(s)) return null;
      if (isPreprinted(s)) return null;
      s = s.replace(/\s+/g, '');
      s = s.replace(/([한두세네])([번회])/g, function (a, k, u) { return KNUM[k] + u; });   /* '하루 세번' */
      if (PH_CYCLE.test(s) || PH_ALT.test(s)) return null;
      /* 시각·시간·분 표기는 용법 숫자가 아니다 — '8시간마다' · '식후 30분' · '아침 8시' */
      s = s.replace(/\d+시간(마다|간격|에|이)?/g, ' ')
           .replace(/\d+분(마다|전|후|에|간|씩)?/g, ' ')
           .replace(/\d+시(?![간])\d*/g, ' ');
      /* ── '간격' 같은 안내 말은 시간 표기를 지운 다음에 본다 ── 2026-09-28
         '12시간 간격 1일 2회 7일분' 은 진짜 용법인데 '간격' 한 낱말 때문에 통째로 버려졌다.
         시간 표기에 딸린 '간격'은 바로 위에서 이미 지워졌으므로, 그러고도 남아 있는
         '최대·이상·까지·간격' 은 뜻이 뒤집히기 쉬운 안내 문장이라 그대로 물러난다. */
      if (PH_SKIP.test(s)) return null;
      /* '2주일분' 은 14일분으로 본다(주 단위 횟수는 위에서 이미 물러났다) */
      s = s.replace(/(\d{1,2})주일?(분|치|간|동안)/g, function (a, n) { return (parseInt(n, 10) * 7) + '일분'; });
      var times = null, days = null, bad = false, m;
      var reT = /(\d{1,2})[회번]/g;
      while ((m = reT.exec(s))) {
        var after = s.slice(m.index + m[0].length);
        var before = s.slice(0, m.index);
        /* '1회 1정' — 뒤에 1회 투약량이 붙은 '1회'는 횟수가 아니다(앞에 '하루·1일'이 없을 때만) */
        if (m[1] === '1' && PH_UNIT.test(after) && !/(하루|매일|일일|1일|당일)$/.test(before)) continue;
        var v = parseInt(m[1], 10);
        if (times === null) times = v; else if (times !== v) bad = true;
      }
      var reD = /(\d{1,3})일/g;
      while ((m = reD.exec(s))) {
        var rest = s.slice(m.index + m[0].length);
        if (/^(에|에는)?\d{1,2}[회번]/.test(rest)) continue;     /* '1일 3회' — 앞의 1은 일수가 아니다 */
        var y = parseInt(m[1], 10);
        if (days === null) days = y; else if (days !== y) bad = true;
      }
      if (bad) return null;
      if (!times && !days) return null;
      return { times: times || 0, days: days || 0 };
    }
    /* 머리글 열을 찾았을 때 — 숫자를 가장 가까운 열에 붙여 읽는다 */
    function readByColumn(toks, cols, colGap) {
      if (!cols || cols.times === null || cols.days === null || !colGap) return null;
      var tol = colGap * 0.6, pick = { dose: null, times: null, days: null }, bad = false;
      toks.forEach(function (t) {
        if (bad) return;
        if (!t.alone) { bad = true; return; }                 /* 한 줄에 숫자가 여럿이면 어느 열인지 알 수 없다 */
        var best = null, bd = tol;
        ['seq', 'dose', 'times', 'days', 'guide'].forEach(function (k) {
          if (cols[k] === null || cols[k] === undefined) return;
          var dx = Math.abs(t.x - cols[k]);
          if (dx <= bd) { bd = dx; best = k; }
        });
        if (!best || best === 'seq' || best === 'guide') return;   /* 순번 열·복약안내 글 칸의 숫자는 용법이 아니다 */
        if (pick[best] !== null) { bad = true; return; }      /* 같은 열에 숫자가 둘이면 믿을 수 없다 */
        pick[best] = t.v;
      });
      if (bad || pick.times === null || pick.days === null) return null;
      return buildDose(pick.dose, pick.times, pick.days);
    }
    /* 단위가 적혀 있을 때 — '1정 3회 5일'. 같은 단위가 둘이면 어느 쪽이 맞는지 알 수 없으니 비운다 */
    function readByUnit(toks) {
      var got = { dose: [], times: [], days: [] };
      toks.forEach(function (t) { if (t.u) got[t.u].push(t.v); });
      if (got.times.length !== 1 || got.days.length !== 1) return null;
      if (got.dose.length > 1) return null;
      return buildDose(got.dose.length ? got.dose[0] : null, got.times[0], got.days[0]);
    }
    /* 열을 알고 있으면 어느 열에도 닿지 않는 외딴 숫자(오른쪽 금액 칸 등)는 버린다 */
    function nearAnyCol(x, cols, span) {
      var ok = false;
      ['seq', 'dose', 'times', 'days'].forEach(function (k) {
        if (cols[k] === null) return;
        if (Math.abs(x - cols[k]) <= span) ok = true;
      });
      return ok;
    }
    /* ── 1회 투약량·하루 횟수·일수 ──
       예전에는 그 약 구간의 숫자를 전부 이어붙여 [첫 자리][둘째 자리][나머지] 로 잘랐다.
       그래서 왼쪽에 순번 열이 있으면 '순번1 / 1회1정 / 하루3회 / 5일' 이 1135 로 읽혀
       '하루 1번 35일치'로 조용히 저장됐다. 이제는 열 좌표 → 조각 개수 순으로 읽고,
       어느 쪽으로도 확신이 서지 않으면 null 을 돌려 54 화면이 환자에게 되묻게 한다. */
    function readDose(rows, cols, colGap, ordinal) {
      var toks = numTokens(rows);
      if (colGap) toks = toks.filter(function (t) { return !t.alone || nearAnyCol(t.x, cols, colGap * 2); });
      if (!toks.length) return null;
      var byUnit = readByUnit(toks);                          /* ① 단위가 적혀 있으면 그게 가장 확실하다 */
      if (byUnit) return byUnit;
      var byCol = readByColumn(toks, cols, colGap);           /* ② 머리글 열 좌표 */
      if (byCol) return byCol;
      var v = toks.map(function (t) { return t.v; });         /* ③ 조각 개수 */
      /* 머리글에 순번 열이 있는 것을 확인했다면 맨 앞 조각은 순번이다 */
      if (cols && cols.seq !== null) return (v.length === 4) ? buildDose(v[1], v[2], v[3]) : null;
      if (v.length === 3) return buildDose(v[0], v[1], v[2]);
      /* 조각이 4개 — 맨 앞이 그 약의 순서와 같을 때만 순번으로 보고 떼어낸다 */
      if (v.length === 4 && ordinal && +v[0] === ordinal) return buildDose(v[1], v[2], v[3]);
      return null;                                            /* 1·2개 또는 5개 이상이면 비워 둔다 */
    }

    /* ── 한 줄에 두 약이 붙어 온 행 나누기 ──
       '1 타이레놀정500mg 1 3 5 2 아모잘탄정5/50mg 1 1 30' — 이름 뒤에 숫자 칸이 셋 이상 이어진 다음
       다시 한글로 시작하는 조각이 오면 거기서 자른다. 숫자가 넷 이상이면 마지막 하나는
       '다음 순번(앞 순번 + 1)'일 때만 다음 약에 붙인다. 숫자 줄·머리글 줄은 한글+숫자 셋 조건에 걸리지 않는다. */
    function splitRow(text) {
      var toks = String(text || '').split(' '), segs = [], cur = [], run = 0, han = false;
      var seq0 = /^\d{1,2}$/.test(toks[0] || '') ? +toks[0] : 0, nextSeq = seq0 ? seq0 + 1 : 0;
      for (var ti = 0; ti < toks.length; ti++) {
        var tk = toks[ti];
        if (/^[가-힣]/.test(tk) && han && run >= 3) {
          var carry = [];
          if (run >= 4 && nextSeq && +cur[cur.length - 1] === nextSeq) { carry = [cur.pop()]; nextSeq++; }
          segs.push(cur.join(' '));
          cur = carry; run = 0; han = false;
        }
        cur.push(tk);
        if (/^\d+(?:[.,]\d+)?$/.test(tk)) run++;
        else { run = 0; if (/[가-힣]/.test(tk)) han = true; }
      }
      segs.push(cur.join(' '));
      return segs;
    }

    function parseMeds(items, band) {
      var ALL = [];
      (items || []).map(function (it, i) {
        if (typeof it === 'string') return { text: it.replace(/\s+/g, ' ').trim(), x: 0, y: i, h: 1 };
        return { text: String(it.text || '').replace(/\s+/g, ' ').trim(), x: it.x || 0, y: it.y || 0, h: it.h || 1 };
      }).filter(function (it) { return it.text; }).forEach(function (it) {
        var parts = splitRow(it.text);
        if (parts.length < 2) { ALL.push(it); return; }
        parts.forEach(function (pt, j) { ALL.push({ text: pt, x: it.x, y: it.y + j * 0.001, h: it.h, split: true }); });
      });
      var BAND = band || 0.5;

      var names = [], seen = {}, dupY = [];
      function take(x, it, i, info) {
        var key = x.replace(/\s+/g, '');
        if (seen[key]) {                                      /* 여러 통과에서 같은 이름이 나오면 한 번만 */
          /* 다만 '어디에 또 찍혔는지'는 적어 둔다 — 봉투 앞·뒤에 같은 약이 두 번 인쇄된 경우
             그 자리를 행의 끝으로 보아야 앞 약의 용법 줄이 둘로 보이지 않는다 (아래 참고) */
          dupY.push(it.y);
          return;
        }
        seen[key] = 1;
        /* 한 행 뭉침 '1 타이레놀정500mg 1 3 5' — 이름 뒤에서 떼어낸 숫자 세 칸이 곧 그 약의 용법이다.
           용량(500mg)은 단위가 있을 때만 떼고, 남은 것이 정확히 숫자 셋일 때만 믿는다. */
        var rest = String((info && info.tail) || '').replace(STRENGTH_HEAD, '');
        var rowDose = null;
        if (ROW_USAGE.test(rest) && !NOISE_NUM.test(rest)) {
          var rv = rest.match(/\d+(?:\.\d+)?/g);
          if (rv && rv.length === 3) rowDose = buildDose(rv[0], rv[1], rv[2]);
        }
        names.push({ name: x, at: i, x: it.x, y: it.y, h: it.h || 1, times: 0, days: 0, kind: formKind(x), rowDose: rowDose, split: !!it.split });
      }
      /* 제형 낱말뿐인 이름('외용제'·'주사제'·'점안제') — 제형 꼬리를 떼면 한글이 두 자도 안 남는다 */
      function formWordOnly(x) {
        var s = String(x || '').replace(/\s+/g, '');
        for (var fi = 0; fi < FORM_KINDS.length; fi++) {
          if (FORM_KINDS[fi][0].test(s)) return s.replace(FORM_KINDS[fi][0], '').replace(/[^가-힣]/g, '').length < 2;
        }
        return false;
      }
      /* 줄에서 이름 후보 꺼내기 — 앞의 약효 분류 괄호('[항혈전제] …')는 떼고 본다.
         괄호 뒤가 제형 꼬리 없는 이름이면 필독 안내문의 '[분류] 성분명 용량' 줄이라 약으로 세지 않는다(null) */
      function nameInfo(raw) {
        var body = raw, cls = CLASS_HEAD.test(raw);
        if (cls) body = raw.replace(CLASS_HEAD, '');
        if (!body && cls) {
          /* 줄 전체가 괄호 하나('[타이레놀정500mg]') — 괄호를 떼면 아무것도 안 남아 약이 통째로 빠졌다.
             분류 괄호('[항혈전제]'·'[외용제]')와 가르려고, 괄호 안이 제형 꼬리와 용량까지 갖춘 이름일 때만 받는다.
             제형 낱말뿐인 분류('[외용제 30g]'·'[주사제 1ml]')와 쌍점 안내('[병용금기: 아스피린장용정100mg]')는 받지 않는다 —
             받으면 가짜 약이 생기고 아래 용법 숫자가 그쪽에 붙었다(2026-09-18 검증2b C2·C3) */
          var inner = stripInfo(raw.replace(/^\s*[\[【]\s*/, '').replace(/\s*[\]】]\s*$/, ''));
          if (/[:：]/.test(inner.name) || formWordOnly(inner.name)) return null;
          return (formKind(inner.name) && DOSE_UNIT.test(inner.tail)) ? inner : null;
        }
        if (!body) return null;
        var info = stripInfo(body);
        if (cls && !formKind(info.name)) return null;
        return info;
      }
      function scan(accept) {
        ALL.forEach(function (it, i) {
          var raw = it.text;
          if (raw.length < 2 || raw.length > 40 || !/[가-힣]/.test(raw)) return;
          var info = nameInfo(raw);
          if (info && looksLikeName(info.name) && accept(info, it, i)) take(info.name, it, i, info);
        });
      }

      /* ── 용법 숫자로 볼 줄 고르기 ──
         조제일자(2026-09-16)·전화번호·금액·약품코드·시각은 NOISE_NUM 이 걸러낸다.
         남은 줄도 '숫자 + 단위 한 토막'까지만 받는다 — '1일 3회' 같은 문장은
         뜻이 뒤집혀 읽히기 쉬워 이번 단계에서는 아예 건드리지 않는다. */
      /* '씩' 은 유팜(약국 점유 1/3)·필독 A4 가 쓰는 '1정씩 3회 3일분' 표기의 일부다.
         이 한 글자가 빠져 있어 그 계열 서식의 용법을 통째로 못 읽었다. */
      var CELL_OK = /^[0-9\s.,\/\-()정알캡슐캅셀포매장앰플바이알회번일분치간씩㎖㎎mlgcctMLGCT]+$/;
      var PHRASE_DAY_FIRST = /\d\s*일\s*[^0-9]{0,4}\d\s*[회번]/;   /* '1일 3회' — 일수가 아니다 */
      function isNumCell(txt) {
        if (!/\d/.test(txt)) return false;
        if (isHeadFrag(txt)) return false;                    /* 두 줄로 나뉜 머리글의 윗줄('1회'·'1일투여') */
        if (isPreprinted(txt)) return false;                  /* 빈칸이 안 채워진 인쇄 문구('1일 회 일분') */
        if (NOISE_NUM.test(txt)) return false;
        if (MONEY.test(txt) || SKIP_LINE.test(txt) || GENERIC.test(txt)) return false;
        if (PHRASE_DAY_FIRST.test(txt)) return false;
        if (/(하루|매일|일일|식전|식후|취침|필요|아침|점심|저녁|원|회분|개월|년|월)/.test(txt)) return false;
        return CELL_OK.test(txt);
      }
      var numLines = ALL.filter(function (it) { return isNumCell(it.text); });

      /* ── 성분명 줄 ──
         필독 안내문은 제품명 줄 아래에 '성분명 용량'(아스피린 100mg)을 한 줄 더 찍는다. 이 줄이 ② 통과로 잡히면
         같은 약이 54 에 두 번 나온다. 아래를 모두 채우면 성분 줄로 보고 약으로 세지 않는다.
           · 이름과 용량이 띄어져 있다 — 제품명은 '아리미덱스1mg'처럼 붙여 찍힌다
           · 그 줄 높이에 용법 숫자 칸이 없다 — 표의 한 행이면 같은 높이에 숫자 칸이 있다
           · 같은 칸(가로 위치)에서 바로 위 줄(분류 괄호·숫자 칸은 건너뜀)이 제형 꼬리가 있는 약 이름이다
           · 그 사이에 분류 괄호 줄('[항혈전제]')이 끼어 있다(필독 서식 표지 — 아래 isIngredientLine 의 거리·순서 조건과 함께),
             또는 괄호 줄이 없으면 이 줄에서 가장 가까운 용법 숫자가 그 위 약 이름 줄에 더 가깝다 — 숫자가 위 약의 것이다(numsAbove)
         하나라도 어긋나면 약으로 남긴다 — 중복 항목은 환자가 체크를 풀면 되지만, 빠진 약은 알 길이 없다. */
      /* 용법 숫자가 위 약 이름 줄(p)의 것인가 — 이 줄(it)에서 가장 가까운 숫자 줄(같은 거리면 모두)이
         p 행보다 아래에 있으면서 p 에 더 가까울 때만 그렇다(필독 A5 는 숫자가 제품 줄과 성분 줄 사이 가운데쯤 찍힌다).
         가장 가까운 숫자가 p 와 같은 높이(BAND 안)이거나 p 줄 끝에 붙어 있으면('경동아스피린장용정 1 3 5')
         p 행이 제 숫자를 다 가진 표의 한 행이라, 아래 줄은 숫자 칸만 흐린 다른 약의 행일 수 있다 — 성분 줄로 보지 않는다.
         숫자가 하나도 없으면 누구 것인지 모르니 성분 줄로 보지 않는다.
         (이 확인이 없을 때: 위 약의 숫자가 흐려 안 읽힌 봉투에서 아래 진짜 약 '아리미덱스 1mg' 이 성분 줄로 빠지고
          그 약의 숫자 '1 1 28' 이 위 약에 붙었다 — 2026-09-18 검증 W1~W3. 표 아래 행 숫자 칸만 흐리면 그 약이 빠졌다 — 검증 A4·A6) */
      function numsAbove(p, pi, it) {
        var spots = numLines.map(function (r) { return r.y; });
        var own = String(pi.tail || '').replace(STRENGTH_HEAD, '');
        if (ROW_USAGE.test(own) && !NOISE_NUM.test(own)) spots.push(p.y);
        if (!spots.length) return false;
        var dmin = Infinity;
        spots.forEach(function (y) { dmin = Math.min(dmin, Math.abs(y - it.y)); });
        return spots.every(function (y) { return Math.abs(y - it.y) > dmin || (y - p.y > BAND && y - p.y < dmin); });
      }
      var BRACKET_ONLY = /^[\[【][^\]】]*[\]】]$/, DIGITS_ONLY = /^[\d.,\/·]+$/;
      /* 괄호 하나뿐인 줄이 약효 분류('[항혈전제]')인가 — 괄호 안이 약 이름이면('[타이레놀정500mg]', nameInfo 가 받음) 제품 줄이다 */
      function isClassLine(r) {
        return BRACKET_ONLY.test(r.text.replace(/\s+/g, '')) && !nameInfo(r.text);
      }
      /* 이 줄 바로 아래(같은 칸, 숫자 줄은 건너뜀)가 분류 괄호 줄인가 — 그렇다면 이 줄은 제 분류를 단 제품 줄이다.
         필독은 '제품 / [분류] / 성분' 순이라 성분 줄 바로 아래에는 분류 괄호가 오지 않는다. */
      function classBelow(it, hRef) {
        var q = null;
        ALL.forEach(function (r) {
          if (r === it || r.y <= it.y || r.y - it.y > hRef * 2.5 || Math.abs(r.x - it.x) > hRef * 8) return;
          if (DIGITS_ONLY.test(r.text.replace(/\s+/g, ''))) return;
          if (!q || r.y < q.y) q = r;
        });
        return !!q && isClassLine(q);
      }
      /* 약 이름 줄인가 — scan ①·② 가 받는 모양(제형 꼬리나 용량 표기가 붙은 이름). 숫자 칸·분류 괄호·안내 글줄은 아니다 */
      function nameLike(q) {
        var t = q.text;
        if (t.length < 2 || t.length > 40 || !/[가-힣]/.test(t) || isNumCell(t)) return false;
        var qi = nameInfo(t);
        return !!(qi && looksLikeName(qi.name) && (formKind(qi.name) || DOSE_UNIT.test(qi.tail)));
      }
      function isIngredientLine(it, i, info) {
        if (it.split || !/^\s/.test(info.tail || '')) return false;
        if (ROW_USAGE.test(String(info.tail).replace(STRENGTH_HEAD, ''))) return false;
        var hRef = Math.max(it.h || 1, 1);
        if (numLines.some(function (r) { return r !== it && Math.abs(r.y - it.y) <= BAND; })) return false;
        /* brk — 위 약 이름 줄과 이 줄 사이에 분류 괄호 줄이 있다(필독 서식 표지).
           numFirst — 괄호 줄보다 이 줄 쪽에 같은 칸 숫자 줄이 먼저 있다(글줄로 읽힌 '제품 / [분류] / 1 3 5 / 이 줄') — 그 숫자는 위 약의 것이고 이 줄은 새 행이다
           numBetween — 괄호 줄보다 위(위 약 줄과 괄호 사이)에 같은 칸 숫자 줄이 있다('제품 / 1 3 5 / [점안제] / 이 줄') — 위 약은 제 숫자를 이미 가졌다 */
        var brk = false, numFirst = false, numBetween = false;
        for (var j = i - 1; j >= 0; j--) {
          var p = ALL[j];
          if (p.y > it.y) continue;
          if (it.y - p.y > hRef * 5) return false;             /* 멀리 떨어진 줄은 다른 약의 것이다 */
          if (Math.abs(p.x - it.x) > hRef * 8) continue;       /* 다른 칸(복약안내 글 칸·숫자 열) */
          var t = p.text.replace(/\s+/g, '');
          if (!t) continue;
          if (isClassLine(p)) { brk = true; continue; }
          if (DIGITS_ONLY.test(t)) { if (!brk) numFirst = true; else numBetween = true; continue; }
          var pi = nameInfo(p.text);
          if (!(pi && formKind(pi.name) && looksLikeName(pi.name))) return false;
          /* 분류 괄호를 사이에 둔 성분 줄은 숫자 위치와 상관없이 거른다 — 숫자 칸이 두·세 줄 칸 가운데에 찍혀
             사진을 조금만 비껴 찍어도 성분 줄 쪽으로 기울었다(2026-09-18 검증: 원근 모의 65가지 중 50가지에서 중복).
             다만 윗행 성분 줄을 못 읽어 다음 행 제품('아리미덱스 1mg')이 괄호 아래에 온 경우를 가르려고
             위 약 줄에서 줄 높이 3.5배 안이고, 괄호 줄보다 먼저 숫자 줄이 없고, 이 줄 바로 아래에 제 분류 괄호가 없을 때만이다.
             또 괄호가 다음 행 앞의 구역 머리('[외용약]'·'[점안제]')일 수 있다 — 위 약이 이미 제 숫자를 가졌고(괄호 위 숫자 줄·줄 끝 숫자,
             또는 같은 높이·위 약과 이 줄 사이 숫자가 이 줄 아래 숫자와 같은 숫자 열) 이 줄 바로 아래(1.5줄 안)에 제 숫자가 있으면
             괄호 규칙을 쓰지 않는다(2026-09-19 재확인: 머리 괄호 아래 진짜 약이 빠지고 위 약 용법도 비었다 · 줄 높이 28 이상 E1b).
             필독 성분 줄은 바로 아래에 제 숫자가 없어(다음 행 숫자는 다음 제품 줄 높이) 그대로 걸러진다. 숫자 열로만 세서 순번 열·두 칸 카드의 옆 칸 숫자는 세지 않는다 */
          var pOwn = String(pi.tail || '').replace(STRENGTH_HEAD, '');
          /* below — 이 줄 바로 아래(1.5줄 안) 숫자 가운데 이 줄의 용법으로 볼 만한 것만(2026-09-19 3차 재확인).
             · 그 숫자에 이 줄보다 세로로 더 가까운 다른 약 이름 줄(같은 칸이거나 숫자 쪽으로 더 가까운 칸)이 있으면 그 약 행의 숫자다.
               빽빽한 필독·봉투에서 다음 행 숫자를 이 줄 것으로 세어 성분 줄이 약으로 되살아났고, 순번 열이 있으면 진짜 약 용법도 비었다.
               효능·모양·안내 글줄('안구건조증'·'흰색 원형')은 약 이름이 아니라서 보지 않는다 — 보면 머리 괄호 아래 약이 다시 빠진다.
             · 용법처럼 보이는 숫자만 — 세 칸 뭉침('1 1 28')·회/번/일분 표기·같은 높이 숫자 칸 둘 이상·위 약 숫자 칸과 같은 열의 한 칸.
               쪽 번호('1/2')·바코드 조각·총량 한 칸('15')은 아니다 — 글줄에서 성분 줄 다음 줄이 쪽 번호면 성분 줄이 약으로 되살아났다 */
          var below = numLines.filter(function (r) {
            if (!(r.y > it.y && r.y - it.y <= hRef * 1.5)) return false;
            if (ALL.some(function (q) {
              return q !== it && q.y > it.y && Math.abs(q.y - r.y) < r.y - it.y &&
                (Math.abs(q.x - it.x) <= hRef * 8 || Math.abs(q.x - r.x) < Math.abs(it.x - r.x)) && nameLike(q);
            })) return false;
            return ROW_USAGE.test(r.text) || /[회번]|일분/.test(r.text) ||
              numLines.some(function (q) { return q !== r && (Math.abs(q.y - r.y) <= BAND || (Math.abs(q.y - p.y) <= BAND && Math.abs(q.x - r.x) <= hRef)); });
          });
          var pHasNums = numBetween || (ROW_USAGE.test(pOwn) && !NOISE_NUM.test(pOwn)) ||
            numLines.some(function (r) { return r !== p && Math.abs(r.y - p.y) <= BAND && below.some(function (b) { return Math.abs(b.x - r.x) <= hRef; }); }) ||
            numLines.some(function (r) { return r.y > p.y && r.y < it.y && below.some(function (b) { return Math.abs(b.x - r.x) <= hRef; }); });
          if (brk && !numFirst && !(pHasNums && below.length) && it.y - p.y <= Math.max(hRef, p.h || 1) * 3.5 && !classBelow(it, hRef)) return true;
          return numsAbove(p, pi, it);
        }
        return false;
      }
      /* ① 제형 꼬리(정·캡슐·연고·점안액…)가 있는 이름 */
      scan(function (info) { return !!formKind(info.name); });
      /* ② 제형 꼬리는 없어도 용량 표기(mg·%·5/50)를 떼어낸 이름 — '아리미덱스1mg'.
         예전에는 ①이 하나도 못 찾았을 때만 돌아서, 한 봉투에 둘이 섞이면 ② 쪽 약이 조용히 사라졌다.
         이제 늘 돌리고 ①과 겹치는 이름은 take 가 한 번만 넣는다. 금액·전화·날짜·일반명은 looksLikeName 이,
         필독의 성분명 줄은 isIngredientLine 이 거른다. */
      scan(function (info, it, i) { return DOSE_UNIT.test(info.tail) && !isIngredientLine(it, i, info); });
      /* ③ 한 줄에 여러 칸이 통째로 뭉쳐 들어온 줄에서 이름만 집어내기 — 2026-09-26 실사진 확인
         필독 A4·A5 를 휴대폰으로 찍으면 오른쪽 영수증 칸이 약 줄에 붙어 한 줄이 서른 자를 넘는다.
         ①·②는 줄 전체를 이름으로 보기 때문에 '스물두 자 넘음'에서 걸려 그 사진의 약을 하나도 못 찾았다
         (실사진 A5: 일곱 약 가운데 0개). 그래서 띄어쓰기로 나눈 조각 하나하나를 다시 본다.
         받는 조건은 ①보다 좁다 — 조각 자체에 제형 꼬리가 있어야 하고(용량만으로는 안 받는다),
         looksLikeName 을 지나야 한다. 이렇게 찾은 이름은 '나뉜 줄'로 표시해 그 줄의 숫자를 용법으로 쓰지 않는다 —
         뭉친 줄의 숫자는 영수증 금액일 수도 있어서다. 용법은 비워 두고 54 가 환자분께 여쭙는다. */
      function scanTokens() {
        ALL.forEach(function (it, i) {
          var raw = it.text;
          if (raw.length < 4 || !/[가-힣]/.test(raw)) return;
          var toks = raw.split(/\s+/);
          if (toks.length < 2) return;                      /* 조각이 하나뿐이면 ①·②가 이미 봤다 */
          for (var k = 0; k < toks.length; k++) {
            var tk = trimJunk(toks[k]);
            if (tk.length < 3 || tk.length > 24) continue;
            if (/[\[\]【】:：]/.test(tk)) continue;            /* 분류 괄호·쌍점 안내는 ②가 맡는다 */
            var info = stripInfo(tk);
            if (!formKind(info.name) || formWordOnly(info.name)) continue;
            if (!looksLikeName(info.name)) continue;
            take(info.name, { x: it.x, y: it.y, h: it.h, split: true }, i, null);
          }
        });
      }
      scanTokens();
      /* (예전 ③ 예비 통과 — 제형·용량 근거 없이 '무엇이든 떼어낸 줄'을 이름으로 받던 것 — 은 없앴다.
         약국 주소('대전광역시 동구 대학로 62')가 약 이름으로 채워져 58 에서 심평원 조회로 나갔다.
         근거 없는 줄뿐이면 '약 이름을 찾지 못했어요'로 안내하고 직접 입력하게 한다.) */
      names.sort(function (a, b) { return (a.y - b.y) || (a.at - b.at); });

      var cols = findCols(ALL);
      var colGap = colGapOf(cols);
      /* ── 머리글이 표가 아니라 옆에 붙은 영수증 띠의 것이었던 경우 ── 2026-09-28
         약제비 계산서·영수증[별지 제11호]은 봉투 옆에 세로로 붙는데(팜IT3000 우측 · 이팜/유팜 좌측),
         그 띠 아래에도 '1회 투약량 / 1일투여 횟수 / 총투약 일수' 머리글이 작게 찍혀 있다.
         이것을 표의 열로 잡으면 정작 표 안의 숫자가 '어느 열에도 닿지 않는 외딴 숫자'로 버려져
         용법이 통째로 날아갔다(이팜 서식에서 '1/1/28'이 전부 버려졌다).
         그래서 그 열 가까이에 숫자 칸이 하나도 없으면 표의 머리글이 아니라고 보고 쓰지 않는다. */
      if (colGap) {
        var colHasNum = false;
        ['dose', 'times', 'days'].forEach(function (k) {
          if (cols[k] === null) return;
          if (numLines.some(function (r) { return Math.abs(r.x - cols[k]) <= colGap; })) colHasNum = true;
        });
        if (!colHasNum) {
          cols = { seq: null, dose: null, times: null, days: null, guide: cols.guide };
          colGap = 0;
        }
      }
      var ordered = names.slice().sort(function (a, b) { return a.y - b.y; });
      /* ── 한 줄에 약 카드가 여럿인 서식(필독 A4 두 칸 카드) ──
         같은 높이(BAND 안)에 이름이 둘 이상이면 그 줄의 용법 줄을 가로 칸으로 나눠, 각 약의 칸(이웃 이름과의
         가운데까지) 안에 있는 줄만 그 약에 붙인다. 예전에는 앞 약의 구간이 비고 뒤 약이 아래 줄을 다 가져가
         왼쪽 약의 용법이 오른쪽 약에 조용히 채워졌다. 이름끼리 너무 붙어 칸을 나눌 수 없으면 비워 둔다. */
      var rows = [];
      ordered.forEach(function (n) {
        var last = rows[rows.length - 1];
        if (last && !n.split && !last[0].split && Math.abs(n.y - last[0].y) <= BAND) last.push(n);
        else rows.push([n]);
      });
      rows.forEach(function (row, ri) {
        var lo = row[0].y - BAND;
        var hi = (ri + 1 < rows.length) ? rows[ri + 1][0].y - BAND : Infinity;
        var inRow = numLines.filter(function (r) { return r.y >= lo && r.y < hi; });
        /* ── 같은 약이 봉투 앞·뒤에 두 번 찍힌 경우 ── 2026-09-27
           같은 이름은 한 번만 넣으므로 아래쪽 두 번째 자리에는 이름이 없다. 그래서 마지막 행의
           구간이 끝없이 늘어나 두 번째 '1 2 30' 까지 이 약의 줄로 보여 '어느 쪽인지 모른다'가 되고
           용법이 통째로 비워졌다. 그 자리도 행의 끝으로 본다.
           끊고 나서 그 행에 숫자 줄이 하나도 남지 않으면 끊지 않는다 —
           이름만 위에 한 번 더 찍히고 용법은 아래에만 적힌 봉투도 있다. */
        var hi2 = hi, di, dy;
        for (di = 0; di < dupY.length; di++) {
          dy = dupY[di] - BAND;
          if (dupY[di] - row[0].y > Math.max(BAND, (row[0].h || 1) * 1.5) && dy < hi2) hi2 = dy;
        }
        if (hi2 < hi) {
          var narrowed = numLines.filter(function (r) { return r.y >= lo && r.y < hi2; });
          if (narrowed.length) { inRow = narrowed; hi = hi2; }
        }
        /* 문장으로 적힌 용법을 찾을 때 볼 줄 — 그 약 행의 글줄 전부(숫자 칸이 아닌 줄까지) */
        var inRowTxt = ALL.filter(function (r) { return r.y >= lo && r.y < hi; });
        var byX = row.slice().sort(function (a, b) { return a.x - b.x; });
        var canSplit = true;
        for (var k = 1; k < byX.length; k++) {
          if (byX[k].x - byX[k - 1].x < Math.max(byX[k].h, byX[k - 1].h) * 3) canSplit = false;
        }
        row.forEach(function (n) {
          if (n.rowDose) { n.times = n.rowDose.times; n.days = n.rowDose.days; return; }
          if (n.split) return;                                /* 나눈 행은 그 행 안의 숫자만 믿는다 */
          var mine = inRow, mineTxt = inRowTxt;
          if (row.length > 1) {
            if (!canSplit) return;
            var bi = byX.indexOf(n);
            var xlo = bi > 0 ? (byX[bi - 1].x + n.x) / 2 : -Infinity;
            var xhi = bi < byX.length - 1 ? (n.x + byX[bi + 1].x) / 2 : Infinity;
            mine = inRow.filter(function (r) { return r.x >= xlo && r.x < xhi; });
            mineTxt = inRowTxt.filter(function (r) { return r.x >= xlo && r.x < xhi; });
          }
          mine = mine.slice().sort(function (a, b) { return a.x - b.x; });
          var d = readDose(mine, cols, colGap, ordered.indexOf(n) + 1);
          /* 숫자 칸으로 못 읽었으면 문장으로 적힌 용법을 본다 — 횟수와 일수가 다른 줄에 떨어져 있어도 된다
             (세로쓰기 봉투: '1일 2회' 아래 '14일분'). 같은 칸 안에서 서로 다른 값이 나오면 비워 둔다. */
          if (!d) {
            var pt = null, pd = null, px = false;
            mineTxt.forEach(function (r) {
              if (isHeadFrag(r.text)) return;                 /* 두 줄로 나뉜 머리글의 윗줄 */
              /* 봉투에 인쇄된 체크띠는 봉투 하나를 통틀어 적은 것이다 — 약이 여럿이면 어느 약의 것인지 알 수 없다 */
              if (names.length > 1 && isOptionBand(r.text)) return;
              var p = phraseDose(r.text);
              if (!p) return;
              if (p.times) { if (pt === null) pt = p.times; else if (pt !== p.times) px = true; }
              if (p.days) { if (pd === null) pd = p.days; else if (pd !== p.days) px = true; }
            });
            if (!px && pt && pd) d = buildDose(null, pt, pd);
          }
          if (d) { n.times = d.times; n.days = d.days; }
        });
      });
      /* kind(먹는·넣는·바르는·붙이는…)는 54·58 이 투여경로(schedule.route)로 옮겨 저장한다 */
      return names.map(function (n) {
        return { name: n.name, times: n.times, days: n.days, kind: n.kind || '' };
      });
    }
    /* 한 줄이 스스로 가진 용법 숫자 세 칸(1회량·횟수·일수)을 읽는다 — '아이플루플러스점안 1 4 5'.
       약 목록 대조(HIRA)가 되살린 줄에도 그 줄에 적혀 있던 횟수·일수를 그대로 붙여 주려고 꺼내 둔다. */
    function rowDoseOf(line) {
      var info = stripInfo(String(line == null ? '' : line).replace(/\s+/g, ' ').trim());
      var rest = String(info.tail || '').replace(STRENGTH_HEAD, '');
      if (!ROW_USAGE.test(rest) || NOISE_NUM.test(rest)) return null;
      var rv = rest.match(/\d+(?:\.\d+)?/g);
      return (rv && rv.length === 3) ? buildDose(rv[0], rv[1], rv[2]) : null;
    }
    return { parseMeds: parseMeds, formKind: formKind, stripDose: stripDose, isPreprinted: isPreprinted, findCols: findCols,
             /* 아래 둘은 약 목록 대조(HIRA)가 '파서가 지나친 줄'을 다시 볼 때 같은 잣대를 쓰려고 꺼내 둔 것이다 */
             looksLikeName: looksLikeName, looksGarbled: looksGarbled, garbledToken: garbledToken, rowDoseOf: rowDoseOf };
  })();

  /* ── 식약처 의약품 허가정보와 대조 ── 2026-09-20 교수님 피드백 · 실제 약 봉투 시험
     사진에서 읽은 이름에는 세 가지 탈이 있었다.
       · 인쇄물의 생김새 설명('무색 내지 미황색 현탁액'·'백색 또는 미황색 안연고')이 약 이름으로 잡혔다
       · 같은 약이 오타로 한 번 더 잡혀 중복됐다('레보플레쉬점안액' · '레보플레수쉬점안액')
       · 제형 꼬리가 잘린 약('아이플루플러스점안')은 아예 빠졌다
     처음에는 심평원 약가 목록(/drug · itmNm)과 맞춰 봤는데, 그 목록은 급여 약가라 교수님 봉투의
     점안액·안연고가 빠져 있어 대조가 통째로 실패했다('지금은 약 목록과 맞춰 보지 못했어요').
     그래서 54 로 넘어가기 전에 식약처 허가정보(hosp-proxy 의 /drugprm · item_name)와 맞춰 본다 —
     허가받은 품목이 모두 들어 있고, 칸 이름은 ITEM_NAME·ITEM_SEQ·ENTP_NAME·MATERIAL_NAME(대문자)이다.
       ① 같은/비슷한 이름을 찾으면 정식 이름으로 고친다    ② 못 찾으면 후보에서 빼고 54 가 접어서 보여 준다(되살리기)
       ③ 같은 약이 두 번 잡히면 합친다                     ④ 파서가 지나친 줄도 다시 본다(줄당 한 번 · 최대 12줄)
     보내는 것은 '약 이름 글자'뿐이다 — 위치도, 사진도, 성함도 보내지 않는다.
     읽어낸 글줄은 여기(메모리) 안에서만 쓰고 파일·로그·저장소에 남기지 않는다.
     연결이 안 되거나 조회가 실패하면 지금까지처럼 읽은 그대로 넘긴다(54 가 '대조 못 함'만 알린다). */
  var HIRA = (function () {
    var MAX_CALLS = 20;            /* 사진 한 장에 조회는 많아야 20번(이름 그대로 + 못 찾은 것만 앞 글자로) */
    var MAX_REVIVE = 12;           /* 파서가 지나친 줄은 많아야 12줄만 다시 본다 */
    var ROWS = 20;                 /* 한 번에 받아 보는 줄 수 — 이 수만큼 꽉 차면 목록이 잘린 것이다 */
    /* 봉투에 찍힌 환자 성함·서식 낱말 — 조회 글자로 내보내지 않는다(성함이 밖으로 나가면 안 된다) */
    var NAME_TAIL = /(님|씨|귀하)$/;
    var ENVELOPE_WORD = /(환자|성명|성함|생년월일|생년|교부|조제일자|조제일|약국|병원|의원|처방|수진자|보호자)/;
    var DEADLINE_MS = 7000;        /* 7초가 지나면 그냥 진행한다(조회를 두 번에 나눠 한다) */
    var CALL_MS = 3000;            /* 조회 한 번을 기다리는 시간 */
    var PAREN = /[(（\[【][^)）\]】]*[)）\]】]/g;
    /* 이름 비교에서 빼는 용량 표기 — 숫자에 단위가 붙었을 때만 뗀다('비타민B12정'의 12 는 남긴다) */
    var DOSE_ANY = /\d[\d.,]*(?:\s*[\/·]\s*\d[\d.,]*)*\s*(?:mg|mcg|㎎|㎍|ug|μg|kg|ml|mL|㎖|cc|iu|IU|%|퍼센트|밀리그람|밀리그램|밀리리터|마이크로그람|마이크로그램|국제단위|단위)/gi;
    /* 띄어쓰기·괄호·용량·기호를 뺀 비교용 글자 */
    function normKey(s) {
      var t = String(s == null ? '' : s).replace(PAREN, ' ').replace(/_/g, ' ');
      t = t.replace(DOSE_ANY, ' ').replace(/[^0-9A-Za-z가-힣]/g, '');
      return t.toLowerCase();
    }
    /* 글자 하나 차이를 세는 간단한 거리 — 받침·모음 하나가 틀린 오타를 가려내는 데만 쓴다 */
    function lev(a, b) {
      var m = a.length, n = b.length, i, j, prev = [], cur = [];
      if (!m) return n;
      if (!n) return m;
      for (j = 0; j <= n; j++) prev[j] = j;
      for (i = 1; i <= m; i++) {
        cur[0] = i;
        for (j = 1; j <= n; j++) {
          cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1));
        }
        for (j = 0; j <= n; j++) prev[j] = cur[j];
      }
      return prev[n];
    }
    /* ── 자모로 풀어 비교하기 ── 2026-09-26
       한글 OCR 오독은 글자 하나가 통째로 바뀌기보다 모음·받침 하나가 어긋나는 쪽이 훨씬 많다
       ('크레스토정'→'크래스토쟁'). 글자로 세면 두 자 차이지만 자모로 풀면 두 획 차이다.
       그래서 글자 거리로는 놓치던 오타를 한 단계 더 받아 본다 — 받되 '이름 확인'을 붙인다. */
    var J_CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ';
    var J_JUNG = 'ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ';
    var J_JONG = ' ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ';
    function jamo(s) {
      var out = '', i, c, k, j;
      s = String(s == null ? '' : s);
      for (i = 0; i < s.length; i++) {
        c = s.charCodeAt(i);
        if (c >= 0xAC00 && c <= 0xD7A3) {
          k = c - 0xAC00;
          out += J_CHO.charAt(Math.floor(k / 588)) + J_JUNG.charAt(Math.floor((k % 588) / 28));
          j = k % 28;
          if (j) out += J_JONG.charAt(j);
        } else out += s.charAt(i);
      }
      return out;
    }
    /* 목록의 정식 이름이 '제조사 이름 + 읽은 이름' 꼴인가 — '레트로졸정' ↔ '테바레트로졸정'.
       이 꼴로 맞은 이름이 둘 이상이면 제조사가 다른 별개 제품이므로 혼자 고르지 않는다. */
    function mfgPfx(ck, ok, d) {
      if (!ck || !ok) return false;
      if (ok.length <= ck.length || ok.length - ck.length > 4) return false;
      if (ok.slice(ok.length - ck.length) !== ck) return false;
      if (ck.replace(/[^가-힣]/g, '').length < 4) return false;
      var pre = ok.slice(0, ok.length - ck.length);
      if (KID_WORD.test(pre)) return false;
      /* ── 앞에 더 붙은 것이 정말 '만든 곳 이름'인지 허가정보의 업체명과 견준다 ── 2026-09-27
         이 검사가 없으면 '메틸' 도 접두어로 받아 버린다 — 식약처에서 '프레드니솔론정' 을 물으면
         '삼성메틸프레드니솔론정'(삼성제약)이 오는데, 메틸프레드니솔론은 프레드니솔론과 다른 약이다.
         '테바레트로졸정'(한독테바)·'광동타목시펜정'(광동제약)은 업체명에 그 글자가 있어 그대로 받는다.
         업체명을 모르는 응답에서는 받지 않는다 — 모르면 맞추지 않는 쪽이 안전하다. */
      var ent = String((d && d.entp) || '').replace(/[^0-9A-Za-z가-힣]/g, '').toLowerCase();
      return !!ent && ent.indexOf(pre) >= 0;
    }
    /* 목록의 정식 이름 뒤 괄호에 적힌 성분 — '레트로진정(레보드로프로피진)' → '레보드로프로피진'.
       성분이 다르면 다른 약이다. 후보를 고르실 때 이름만으로는 가릴 수 없어 함께 적어 드린다. */
    function ingOf(d) {
      var raw = String((d && d.rawName) || (d && d.name) || ''), out = [], m;
      var re = /[(（]([^)）]{2,60})[)）]/g;
      while ((m = re.exec(raw)) && out.length < 3) {
        var t = String(m[1]).replace(/\s+/g, ' ').trim();
        if (!t || !/[가-힣A-Za-z]/.test(t)) continue;
        if (/수출|수입|위탁|제조원|판매|허가|변경|성상/.test(t)) continue;
        if (out.indexOf(t) < 0) out.push(t);
      }
      return out.join(' · ');
    }
    /* 사진에서 읽은 이름(ck)과 목록의 정식 이름(ok)이 같은 약인가 — 작을수록 확실하다. 아니면 -1 */
    function score(ck, ok, d) {
      if (!ck || !ok) return -1;
      if (ck === ok) return 0;
      var lo = Math.min(ck.length, ok.length), hi = Math.max(ck.length, ok.length);
      /* 봉투는 이름 뒤에 잘린 용량·성분 설명을 함께 찍는다 — '우루사정100밀리그+담즙산분비촉진제',
         '다비듀오정10/10밀리그'. 목록의 정식 이름이 그 앞머리와 통째로 맞으면 같은 약으로 본다
         (네 자 이상일 때만 — 두세 자는 다른 약의 앞머리일 수 있다). */
      if (ck.indexOf(ok) === 0 && ok.length >= 4) return 1;
      /* 반대로 봉투에서 이름이 잘린 경우 — '아이플루플러스점안'(정식: …점안현탁액) */
      if (ok.indexOf(ck) === 0 && ck.length >= 6) return 1;
      /* ── 제조사 이름만 앞에 더 붙은 정식 이름 ── 2026-09-27
         국내 제네릭은 대부분 '<제조사><성분><제형>' 이다 — 봉투엔 '레트로졸정' 만 찍힐 때
         목록의 정식 이름은 '테바레트로졸정' 이다. 앞에 붙은 두세 글자 때문에 이를 '아예 다른
         약'(-1)으로 버리면, 성분은 전혀 다른데 글자만 비슷한 약('레트로진정' = 기침약)이
         대신 환자분 눈앞에 후보로 오른다. 그래서 '정식 이름이 읽은 이름으로 끝나고 앞에 붙은
         것이 네 자 이하의 짧은 접두어' 면 같은 약으로 본다 — 이름 몸통은 한 글자도 안 틀렸다.
         어린이·소아 표시는 접두어로 보지 않는다 — 어른 약과 갈라야 하므로 지금처럼 둔다. */
      if (mfgPfx(ck, ok, d)) return 1;
      if (hi - lo > 3) return -1;                            /* 길이가 많이 다르면 다른 약이다 */
      if (ok.indexOf(ck) === 0 || ck.indexOf(ok) === 0) return 1;
      var d = lev(ck, ok);
      if (d <= 1 && lo >= 4) return 2;                       /* 받침·모음 하나 차이 */
      if (d <= 2 && lo >= 7 && ck.slice(0, 3) === ok.slice(0, 3)) return 3;
      /* 글자로는 두 자가 다르지만 자모로는 두 획뿐인 오타 — 첫 글자가 같고 다섯 자 이상일 때만 */
      if (lo >= 5 && ck.charAt(0) === ok.charAt(0) && lev(jamo(ck), jamo(ok)) <= 2) return 4;
      return -1;
    }
    /* 목록의 정식 이름에서도 용량 표기를 뗀다 — 사진에서 읽은 이름은 파서가 이미 용량을 떼 놓았고
       ('엔테론정50mg' → '엔테론정'), 어느 용량인지 모르는 채로 '50밀리그램'을 붙이면 안 드시는
       용량이 기록에 남는다. 제품 이름만 정확히 고치고 용량은 붙이지 않는다. */
    function officialName(d) {
      /* 괄호를 뗀 뒤 짝 없이 남은 괄호도 치운다 — 괄호 안에 괄호가 또 있는 이름
         ('넥스티올정(애엽95%에탄올연조엑스(20→1))')에서 ')' 한 짝이 이름에 남았다. */
      var s = String((d && d.name) || '').replace(PAREN, ' ')
        .replace(/[(（\[【)）\]】]/g, ' ').replace(/\s+/g, ' ').trim();
      var b = OCRP.stripDose(s);
      return (b && b.replace(/[^가-힣]/g, '').length >= 2) ? b : s;
    }
    /* 봉투 이름에 적힌 용량 숫자('엔테론정50mg' → '50') — 같은 이름이 용량별로 여럿일 때
       어느 줄을 고를지 가르는 데만 쓴다(맞다/아니다를 뒤집지는 않는다). */
    var DOSE_NUM = /(\d[\d.]*)\s*(?:mg|mcg|㎎|㎍|ug|μg|ml|mL|㎖|%|밀리그|마이크로그|그램|그람)/i;
    function doseNum(raw) {
      var m = DOSE_NUM.exec(String(raw == null ? '' : raw));
      return m ? m[1].replace(/\.0+$/, '') : '';
    }
    function hasDose(d, num) {
      if (!num) return false;
      return new RegExp('(^|[^0-9.])' + num.replace('.', '\\.') + '\\s*(mg|㎎|밀리그|마이크로그|그램|그람|ml|㎖|%)', 'i')
        .test(String((d && d.rawName) || (d && d.name) || ''));
    }
    /* ── 어린이·소아용은 뒤로 ── 2026-09-21 교수님 피드백
       "일반적으로 타이레놀이 있을 텐데 어린이용이 잡히더라고. 애초에 성인인데."
       58 이름 검색(rankDrugs)에는 넣었던 규칙을 봉투 대조 쪽에도 똑같이 넣는다.
       다만 봉투에 '어린이'가 적혀 있으면 정말 어린이용을 드시는 것이니 그대로 맞춘다. */
    var KID_WORD = /(어린이|소아|유아|키즈|베이비|시럽용|드라이시럽)/;
    /* 수출용·동물용 품목은 국내 약국에서 사람에게 조제되지 않는다 — 이름만 같아 헷갈리게 하므로 후보에서 뺀다 */
    var EXPORT_WORD = /수출용|수출명|동물용|수의용/;
    function bestOf(items, ck, raw, out) {
      var best = null, bs = 99, num = doseNum(raw), bestDose = false, bestKid = 0, rival = 0, bestPfx = false;
      /* 똑같이 그럴듯해 고르지 못한 이름들 — 버리지 않고 들고 가 54 에서 환자분이 고르시게 한다 */
      var tied = [], tinfo = [];
      var wantKid = KID_WORD.test(String(raw == null ? '' : raw)) || KID_WORD.test(String(ck || ''));
      (items || []).forEach(function (d) {
        if (EXPORT_WORD.test(String((d && d.rawName) || (d && d.name) || ''))) return;
        var cn = officialName(d);
        var nk = normKey(cn);
        var s = score(ck, nk, d);
        if (s < 0) return;
        /* 제조사 이름만 앞에 더 붙어 맞은 것인가 — 성분·용량은 같아도 만든 곳이 다른 별개 제품이다 */
        var pfx = (s === 1) && mfgPfx(ck, nk, d);
        var kid = (!wantKid && KID_WORD.test(cn)) ? 1 : 0;
        var dz = hasDose(d, num), take;
        /* ── 오타 교정 단계에서 서로 다른 약이 똑같이 그럴듯하면 맞추지 않는다 ── 2026-09-26
           '엉뚱한 약을 넣는 것이 못 맞추는 것보다 훨씬 나쁘다.' 같은 점수에 다른 제품이 둘 이상이면
           용량·이름 길이로 하나를 고르지 않고 물러난다 — 54 가 읽은 그대로 두고 환자분이 고르신다.
           (용량만 다른 같은 제품은 정식 이름이 같아 여기 걸리지 않는다.) */
        /* ── 2026-09-27 넓혔다 ── 제조사 접두어만 다른 이름도 여럿이면 여기 걸리게.
           '아세트아미노펜정' 한 줄에 제조사가 다른 제네릭이 아홉 개 오는 일이 흔하다 —
           길이로 하나를 골라 넣으면 봉투에 적힌 것과 다른 회사 이름이 조용히 기록에 남는다. */
        if (best && s === bs && (s >= 2 || pfx || bestPfx) && nk !== normKey(best.name)) {
          rival = 1;
          if (tied.indexOf(best.name) < 0) { tied.push(best.name); tinfo.push(best); }
          if (tied.indexOf(cn) < 0) { tied.push(cn); tinfo.push({ name: cn, routeKey: d.routeKey || '', meftDivNo: d.meftDivNo || '', seq: d.seq || '', ing: ingOf(d), entp: String((d && d.entp) || '') }); }
        }
        if (s < bs) { rival = 0; tied = []; tinfo = []; }     /* 더 확실한 줄이 나왔으면 앞의 다툼은 잊는다 */
        if (!best || s < bs) take = true;                    /* 더 확실한 줄이 나왔다 */
        else if (s > bs) take = false;
        else if (kid !== bestKid) take = (kid < bestKid);    /* 확신이 같으면 어린이용이 아닌 줄 */
        else if (dz !== bestDose) take = dz;                 /* 그다음이 봉투의 용량과 맞는 줄 */
        else take = cn.length < best.name.length;            /* 그래도 같으면 짧은 이름 */
        if (!take) return;
        bs = s;
        bestDose = dz;
        bestKid = kid;
        /* s(=0 이면 글자까지 똑같다) 를 함께 들고 간다 — 똑같지 않은 매칭은 54 가 '이름 확인'으로 표시한다.
           seq(품목기준코드)도 들고 간다 — 54 가 식약처 용법용량으로 빈 칸을 채울 때 쓴다 */
        bestPfx = pfx;
        best = { name: cn, routeKey: d.routeKey || '', meftDivNo: d.meftDivNo || '', seq: d.seq || '', s: s,
                 ing: ingOf(d), entp: String((d && d.entp) || '') };
      });
      if (out && rival) { out.amb = 1; out.cands = tinfo.slice(0, 5); }
      return rival ? null : best;
    }
    /* features.js 의 <item> 해석기를 쓴다(품목기준코드·분류번호까지 온다). 없으면 이름만 건진다.
       공공데이터포털은 인증키 오류·하루 한도 초과도 HTTP 200 에 실어 보낸다. 그 답을 '목록에 없음'으로
       읽으면 그날 사진에서 읽은 약이 통째로 빠져 버린다 — 오류 답은 null(조회 실패)로 돌려준다.
       resultCode 00(정상)·03(자료 없음)만 답으로 본다. */
    function parseXml(xml) {
      var s = String(xml || '');
      /* 약 목록 응답이라는 증거가 먼저 있어야 한다 — 몸통이 비었거나 JSON·게이트웨이 HTML 을 200 에 실어 보낸 답은
         <resultCode> 가 아예 없어 아래 검사를 그냥 지나친다. 그러면 '목록에 없음'으로 읽혀 약이 통째로 빠진다.
         '자료 없음' 응답에도 resultCode·totalCount 는 들어 있으므로 '없음'과 '실패'는 그대로 갈린다.
         식약처 허가정보는 칸 이름이 대문자(ITEM_NAME)라 그것도 증거로 본다. */
      if (!/<item[\s>]|<ITEM_NAME|<itmNm|<totalCount|<resultCode/i.test(s)) return null;
      if (/OpenAPI_ServiceResponse|<returnReasonCode>|<errMsg>/i.test(s)) return null;
      var rc = /<resultCode>\s*([^<]*)<\/resultCode>/.exec(s);
      if (rc) {
        var c = String(rc[1]).replace(/\s+/g, '');
        if (!/^0*0$/.test(c) && !/^0*3$/.test(c)) return null;
      }
      if (T.drug && T.drug.parsePrm) return T.drug.parsePrm(s);
      var out = [], re = /<ITEM_NAME\b[^>]*>([\s\S]*?)<\/ITEM_NAME>/g, m;
      while ((m = re.exec(s)) && out.length < 30) {
        var nm = String(m[1]).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/\s+/g, ' ').trim();
        if (/수출용|수출명/.test(nm)) continue;            /* 국내 약국에서 조제되지 않는 품목 */
        if (nm) out.push({ name: nm.replace(/_?\([^)]*\)\s*$/, '').trim(), rawName: nm, routeKey: '', meftDivNo: '', seq: '' });
      }
      return out;
    }
    /* 조회 한 번 — 실패해도 거절하지 않고 null 을 돌려준다(실패와 '없음'을 가른다) */
    function lookup(q, token) {
      return new Promise(function (resolve) {
        var done = false;
        var tm = setTimeout(function () { if (!done) { done = true; resolve(null); } }, CALL_MS);
        function end(v) { if (done) return; done = true; clearTimeout(tm); resolve(v); }
        try {
          fetch(CFG.fnBase + '/hosp-proxy/drugprm?numOfRows=' + ROWS + '&item_name=' + encodeURIComponent(q),
                { headers: { 'Authorization': 'Bearer ' + token, 'apikey': CFG.anonKey } })
            .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
            .then(function (xml) { end(parseXml(xml)); }, function () { end(null); });
        } catch (e) { end(null); }
      });
    }
    /* 파서가 지나친 줄 가운데 약 이름 꼴인 것 — 띄어쓰기 없는 한글 세 자 이상만 본다(안내 문장을 거르려고).
       제형 꼬리('…정·…점안액')가 없는 줄은 더 좁게 본다 — 봉투에 한 줄로 찍힌 환자 성함('김영희'·'박순자님')이
       조회 글자가 되어 밖으로 나가지 않게. 꼬리가 없으면 한글 다섯 자 이상만 본다
       ('아이플루플러스점안'은 아홉 자라 그대로 살아남고, 사람 이름 꼴(두~네 자)과 '복약봉투'는 빠진다). */
    function pickRevive(lines, taken) {
      var out = [], seen = {}, known = {}, i, t, base, ck, han;
      (taken || []).forEach(function (m) { known[normKey(m.name)] = 1; });
      for (i = 0; i < (lines || []).length && out.length < MAX_REVIVE; i++) {
        t = lines[i];
        t = (typeof t === 'string') ? t : String((t && t.text) || '');
        t = t.replace(/\s+/g, ' ').trim();
        if (!t) continue;
        base = OCRP.stripDose(t);
        if (!base || base.length > 20 || /\s/.test(base)) continue;
        if (NAME_TAIL.test(base) || ENVELOPE_WORD.test(base)) continue;   /* 사람을 부르는 말·봉투 서식 낱말 */
        han = base.replace(/[^가-힣]/g, '');
        if (han.length < 3) continue;
        if (!OCRP.formKind(base) && han.length < 5) continue;             /* 제형 꼬리가 없으면 다섯 자 이상만 */
        if (!OCRP.looksLikeName(base)) continue;
        ck = normKey(base);
        if (ck.length < 3 || known[ck] || seen[ck]) continue;
        seen[ck] = 1;
        /* 그 줄에 적힌 '1회량 횟수 일수'도 함께 들고 간다 — 되살린 약의 용법을 다시 묻지 않게 */
        out.push({ ck: ck, dose: OCRP.rowDoseOf(t) });
      }
      return out;
    }
    /* meds(사진에서 읽은 약) · lines(읽은 글줄 전부) → Promise<{ meds, checked, calls, hits, drops, revived }> */
    function reconcile(meds, lines) {
      var list = (meds || []).slice(0);
      var out = { meds: list, checked: false, calls: 0, hits: 0, drops: 0, revived: 0 };
      if (!CFG.fnBase || typeof fetch !== 'function' || !list.length) return Promise.resolve(out);
      var deadline = new Date().getTime() + DEADLINE_MS;
      var cache = {}, pending = {}, calls = 0, okCount = 0, token = null, settled = false;

      function ask(q) {                                      /* 같은 글자는 한 번만 묻는다 */
        if (!q) return Promise.resolve(null);
        if (pending[q]) return pending[q];
        if (calls >= MAX_CALLS || new Date().getTime() > deadline) return Promise.resolve(null);
        calls++;
        pending[q] = lookup(q, token).then(function (r) {
          cache[q] = r;
          if (r) okCount++;
          return r;
        });
        return pending[q];
      }
      /* ── 조회에 보낼 글자 ── item_name 은 그 글자를 품은 품목을 모두 돌려준다(부분 일치).
         ① 먼저 읽은 이름 그대로 묻는다 — 잘 읽힌 약은 한 번에 정확히 맞고 받아 오는 줄도 적다.
            봉투에서 제형 꼬리가 잘린 이름('아이플루플러스점안')도 정식 이름의 앞머리라 그대로 걸린다.
         ② 그래도 못 찾은 이름만(오타 — '레보플레수쉬') 앞 글자로 다시 묻는다. 오타는 보통 가운데에 있어
            앞 네 자('레보플레')면 걸리고, 세 자보다 결과가 좁아 20줄 한도에 잘릴 일도 줄어든다. */
      function fullKey(ck) { return ck.slice(0, 24); }
      function preKey(ck) { return ck.length >= 6 ? ck.slice(0, 4) : ck.slice(0, 3); }
      /* 조회 결과로 이 이름을 어떻게 할지 — hit(정식 이름) · miss(목록에 없음) · skip(대조 못 함) */
      function verdict(ck, raw) {
        var r1 = cache[fullKey(ck)], r2 = cache[preKey(ck)];
        var a1 = (r1 instanceof Array), a2 = (r2 instanceof Array);
        if (!a1 && !a2) return { s: 'skip' };                /* 조회를 못 했다 — 그대로 둔다 */
        var amb = { amb: 0 };
        var d = a1 ? bestOf(r1, ck, raw, amb) : null;
        /* ── 2026-09-27 ── 이름 그대로 물은 답에서 이미 '엇비슷한 약이 여럿'이 나왔으면
           그 후보가 가장 가깝다. 앞 글자로 넓게 물은 답으로 덮어쓰면 엉뚱한 약이 올라온다
           (봉투 '암로디핀정' → 태극·국제 암로디핀정 대신 암로핀정·멜로디핀정이 후보로 올랐다). */
        if (!d && amb.amb) return { s: 'pick', cands: amb.cands || [] };
        if (!d && a2) d = bestOf(r2, ck, raw, amb);
        if (d) return { s: 'hit', d: d };
        /* 엇비슷한 약이 둘 이상이라 고르지 못했다 — '목록에 없음'도 '못 맞춰 봄'도 아니다.
           읽은 그대로 두되(접지 않고) 후보를 함께 넘겨 54 에서 환자분이 고르시게 한다. */
        if (amb.amb) return { s: 'pick', cands: amb.cands || [] };
        /* 받아 온 줄이 한도만큼 꽉 찼으면 목록이 잘린 것이다 — 같은 글자로 시작하는 제품이 스무 개가 넘는
           흔한 약(레보플·아모잘·타이레…)은 정작 그 약이 뒤에 밀려 있을 수 있다. 끝까지 본 게 아니므로
           '목록에 없음'으로 단정하지 않고 사진에서 읽은 그대로 둔다. 규칙 ②(못 찾으면 뺀다)는 끝까지 본 경우에만. */
        if ((a1 && r1.length >= ROWS) || (a2 && r2.length >= ROWS)) return { s: 'skip' };
        /* 앞 글자로도 찾아본 뒤에만 '목록에 없음'으로 본다 — 이름 그대로만 물어본 상태라면 아직 모른다 */
        return a2 ? { s: 'miss' } : { s: 'skip' };
      }
      function apply() {
        if (settled) return out;
        settled = true;
        out.calls = calls;
        out.checked = okCount > 0;
        if (!out.checked) return out;
        var merged = [], idx = {}, revivedKeys = {};
        /* 목록에 맞은 같은 약이 한 글자만 깨져 한 번 더 읽힌 경우만 접는다.
           예: '우루사정'과 함께 잡힌 '웅루사정'. 정상 모양의 미등록 약은 숨기지 않는다. */
        function brokenDuplicate(ck, raw) {
          var hit = false;
          list.forEach(function (other) {
            if (hit || other === raw) return;
            var ok = normKey(other.name);
            if (ok.length < 4 || Math.abs(ok.length - ck.length) > 1) return;
            var ov = verdict(ok, other.name);
            if (ov.s !== 'hit') return;
            var official = normKey(ov.d.name);
            if (official !== ck && lev(ck, official) <= 1) hit = true;
          });
          return hit;
        }
        list.forEach(function (m) {
          var ck = normKey(m.name);
          var v = (ck.length >= 2) ? verdict(ck, m.name) : { s: 'skip' };
          if (v.s === 'hit') {
            /* 글자까지 똑같지 않은 매칭(오타 교정·앞부분 일치)은 이웃 약(다른 제품)을 집었을 수 있다 —
               이름은 고치되 '이름 확인' 상태로 남겨 54 가 '확인 필요'를 띄운다(조용히 바뀌지 않게). */
            if (v.d.s > 0 && normKey(v.d.name) !== ck) m.__namechk = 1; else m.__namechk = 0;
            m.name = v.d.name;
            m.hira = { routeKey: v.d.routeKey || '', meftDivNo: v.d.meftDivNo || '', seq: v.d.seq || '' };
            /* 정식 이름으로 고쳤으면 제형도 그 이름에서 다시 본다 — 봉투에서 꼬리가 잘려
               제형을 못 읽었던 약('아이플루플러스점안')도 여기서 눈에 넣는 약으로 잡힌다 */
            var k2 = OCRP.formKind(OCRP.stripDose(v.d.name));
            if (k2) m.kind = k2;
            m.__drop = 0;
            out.hits++;
          } else if (v.s === 'miss') {
            /* 아는 약 목록에 없다는 이유만으로 숨기지 않는다. 한글 이름+제형을 통과한 후보는
               기본 선택 상태로 두고 '확인 필요'를 붙인다. 확인된 약의 깨진 중복만 접는다. */
            if (brokenDuplicate(ck, m)) {
              m.__drop = 1;
              out.drops++;
            } else {
              m.__drop = 0;
              m.__namechk = 1;
            }
          }
          else if (v.s === 'pick') {
            /* 비슷한 이름이 여럿이라 고르지 못했다 — 이름은 읽은 그대로 두고 후보만 들려 보낸다.
               조용히 하나를 골라 넣지 않는다. 엉뚱한 약을 넣는 것이 못 넣는 것보다 나쁘다. */
            m.__pick = (v.cands || []).slice(0, 5);
            m.__namechk = 0;
          }
          /* 이 약을 정말 맞춰 봤다는 표시 — 제 조회가 실패한 약에는 달지 않는다(54 가 그대로임을 알린다) */
          if (v.s !== 'skip') m.chk = 1;
          if (m.__drop) { merged.push(m); return; }
          var k = normKey(m.name);
          if (!Object.prototype.hasOwnProperty.call(idx, k)) { idx[k] = merged.length; merged.push(m); return; }
          /* ③ 같은 약이 두 번 잡혔다 — 빈 칸만 채워 하나로 합친다 */
          var a = merged[idx[k]];
          /* 합쳐지는 두 줄 가운데 하나가 목록의 이름과 글자까지 똑같았다면 이름은 확인된 것이다 */
          if (a.__namechk && !m.__namechk) a.__namechk = 0;
          if (!a.times && m.times) a.times = m.times;
          if (!a.days && m.days) a.days = m.days;
          if (!a.kind && m.kind) a.kind = m.kind;
          if (!a.hira && m.hira) a.hira = m.hira;
        });
        /* ④ 파서가 지나쳤지만 목록에 있는 줄은 되살린다 */
        (out.__rev || []).forEach(function (c) {
          var v = verdict(c.ck);
          if (v.s !== 'hit') return;
          var k = normKey(v.d.name);
          if (Object.prototype.hasOwnProperty.call(idx, k) || revivedKeys[k]) return;
          revivedKeys[k] = 1;
          idx[k] = merged.length;
          merged.push({ name: v.d.name, times: (c.dose && c.dose.times) || 0, days: (c.dose && c.dose.days) || 0,
                        kind: OCRP.formKind(OCRP.stripDose(v.d.name)),
                        hira: { routeKey: v.d.routeKey || '', meftDivNo: v.d.meftDivNo || '', seq: v.d.seq || '' }, chk: 1, revived: 1,
                        __namechk: (v.d.s > 0 && k !== c.ck) ? 1 : 0 });
          out.revived++;
        });
        delete out.__rev;
        out.meds = merged;
        return out;
      }

      var work = sb.auth.getSession().then(function (rs) {
        token = (rs && rs.data && rs.data.session) ? rs.data.session.access_token : null;
        if (!token) return out;                              /* 로그인 전이면 대조하지 않는다 */
        var rev = pickRevive(lines, list);
        out.__rev = rev;
        var keys = [];
        list.forEach(function (m) { var k = normKey(m.name); if (k.length >= 2 && keys.indexOf(k) < 0) keys.push(k); });
        rev.forEach(function (c) { if (keys.indexOf(c.ck) < 0) keys.push(c.ck); });
        /* 1차 — 읽은 이름 그대로 */
        return Promise.all(keys.map(function (k) { return ask(fullKey(k)); })).then(function () {
          /* 2차 — 그래도 못 찾은 이름만 앞 글자로 */
          var need = [];
          keys.forEach(function (k) {
            if (verdict(k).s === 'hit') return;
            var p = preKey(k);
            if (p && p !== fullKey(k) && need.indexOf(p) < 0) need.push(p);
          });
          if (!need.length) return null;
          return Promise.all(need.map(function (p) { return ask(p); }));
        }).then(apply, apply);
      }, function () { return out; });
      /* 너무 오래 걸리면 기다리지 않고 그냥 진행한다 — 읽은 그대로 54 로 넘어간다 */
      function giveUp() {
        if (!settled) { settled = true; out.calls = calls; delete out.__rev; }
        return out;
      }
      return Promise.race([work, new Promise(function (r) {
        setTimeout(function () { r(giveUp()); }, DEADLINE_MS + 400);
      })]);
    }
    return { reconcile: reconcile, normKey: normKey, score: score, bestOf: bestOf, pickRevive: pickRevive };
  })();

  /* ── 식약처 허가사항 본문(효능효과·용법용량) ── 2026-09-20 교수님 피드백
     봉투에 용법이 적혀 있지 않은 약(안약·안연고 등)은 54 2단계에서 '하루 몇 번?·언제?'가 빈 채로 남았다.
     허가정보 API 에는 이 본문이 없어서, 중계 함수(/drugdoc)가 식약처 공식 상세 페이지에서
     효능효과·용법용량 두 문단만 글자로 뽑아 준다. 앱은 그 글에서 '1일 N회'를 찾아 기본값을 제안하고
     제안한 칸에는 '식약처 용법 참고'를 붙여 환자가 고칠 수 있게 한다.
     못 찾으면 지금처럼 비워 둔다 — 임의로 지어내지 않는다. */
  var MFDS = (function () {
    var CALL_MS = 12000;           /* 식약처 페이지가 커서 서버가 받아 오는 데 시간이 걸린다 */
    var cache = {};
    function doc(seq) {
      var s = String(seq == null ? '' : seq).replace(/\D/g, '');
      if (!s || !CFG.fnBase || typeof fetch !== 'function') return Promise.resolve(null);
      if (cache[s]) return cache[s];
      cache[s] = sb.auth.getSession().then(function (rs) {
        var tok = (rs && rs.data && rs.data.session) ? rs.data.session.access_token : null;
        if (!tok) return null;
        return new Promise(function (resolve) {
          var done = false;
          var tm = setTimeout(function () { if (!done) { done = true; resolve(null); } }, CALL_MS);
          function end(v) { if (done) return; done = true; clearTimeout(tm); resolve(v); }
          try {
            fetch(CFG.fnBase + '/hosp-proxy/drugdoc?item_seq=' + encodeURIComponent(s),
                  { headers: { 'Authorization': 'Bearer ' + tok, 'apikey': CFG.anonKey } })
              .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
              .then(function (t) {
                var d = null;
                try { d = JSON.parse(t); } catch (e1) { d = null; }
                end((d && (d.ee || d.ud)) ? { ee: String(d.ee || ''), ud: String(d.ud || '') } : null);
              }, function () { end(null); });
          } catch (e2) { end(null); }
        });
      }, function () { return null; });
      return cache[s];
    }
    /* 한 허가사항에 제형이 여럿 적힌 약('(점안액) … (안연고) …')은 이 약의 제형 자리부터 읽는다 —
       네오덱스안연고는 점안액이 '1일 4-6회', 안연고가 '1일 3-4회'라 자리를 가리지 않으면 잘못 집는다 */
    var FORM_TAGS = ['안연고', '점안현탁액', '점안액', '연고', '크림', '로션', '시럽', '현탁액', '캡슐', '서방정', '정'];
    function sliceForForm(text, name) {
      var nm = String(name == null ? '' : name).replace(/\s+/g, ''), i, j;
      for (i = 0; i < FORM_TAGS.length; i++) {
        if (nm.indexOf(FORM_TAGS[i]) < 0) continue;
        j = text.indexOf('(' + FORM_TAGS[i] + ')');
        if (j > -1) return text.slice(j);
      }
      return text;
    }
    /* ── 제형별로 갈린 본문을 토막으로 ── 2026-09-21 교수님 피드백
       "왜 점안액과 안연고로 나뉘는 거야?" — 같은 성분 조합의 안과 복합제는 식약처 허가사항이
       두 제형(점안액·안연고)의 용법을 한 문서에 함께 적어 둔다(맥시트롤안연고도 똑같다).
       54 의 '하루 몇 번' 자동 채움과 75 화면이 같은 잣대로 읽도록 여기서 한 번만 가른다.
       줄 하나가 통째로 '(안연고)' 꼴일 때만 머리말로 본다 — 문장 속 괄호는 건드리지 않는다. */
    function formHeadTag(line) {
      var m = /^[(（]\s*([^)）]{1,10})\s*[)）]$/.exec(String(line == null ? '' : line).replace(/\s+/g, ' ').trim());
      if (!m) return '';
      var v = m[1].replace(/\s+/g, ''), i;
      for (i = 0; i < FORM_TAGS.length; i++) if (v === FORM_TAGS[i]) return v;
      return '';
    }
    /* 본문 → [{ tag:'점안액', text:'…' }, …] · 머리말이 두 개 넘게 있을 때만 갈린 것으로 본다 */
    function formSections(text) {
      var lines = String(text == null ? '' : text).split('\n');
      var secs = [], cur = null, out = [], i, tag;
      for (i = 0; i < lines.length; i++) {
        tag = formHeadTag(lines[i]);
        if (tag) { cur = { tag: tag, lines: [] }; secs.push(cur); continue; }
        if (cur) cur.lines.push(lines[i]);
      }
      if (secs.length < 2) return [];
      for (i = 0; i < secs.length; i++) {
        out.push({ tag: secs[i].tag, text: secs[i].lines.join('\n').replace(/^\n+/, '').replace(/\n+$/, '') });
      }
      return out;
    }
    /* 토막 가운데 이 약 이름의 제형과 맞는 것 하나 — 가릴 수 없으면 null */
    function formPick(sections, name) {
      var nm = String(name == null ? '' : name).replace(/\s+/g, ''), i, j;
      for (i = 0; i < FORM_TAGS.length; i++) {
        if (nm.indexOf(FORM_TAGS[i]) < 0) continue;
        for (j = 0; j < (sections || []).length; j++) if (sections[j].tag === FORM_TAGS[i]) return sections[j];
      }
      return null;
    }
    var FREQ_RE = /(?:1\s*일|하루|매일)\s*([1-4])\s*(?:[~\-–－∼～]\s*[1-9]\s*)?회/g;
    var FREQ_NOT = /^[^0-9]{0,8}(초과|이상|넘지|넘게|미만|이하)/;
    /* '필요할 때만' 쓰는 약 — 정해진 때가 없다. 타이레놀정500 은 '1일 3-4회 (4-6시간 마다)
       필요시 복용한다' 라고 적혀 있어, 횟수만 읽으면 아프지 않은 날에도 하루 세 번 알림이 울린다. */
    var FREQ_PRN = /필요(할\s*때|시)|증상이?\s*있을\s*때/;
    /* 용법용량 본문 → 하루 몇 번(1~4). 범위로 적혀 있으면('1일 3-4회') 적은 쪽을 쓴다.
       '1일 2회를 초과하지 않는다'는 상한이지 쓰는 횟수가 아니라 건너뛴다. 못 찾으면 0(비워 둔다) */
    function freqOf(udText, name) {
      /* 제형별로 갈린 본문이면 이 약 제형 토막만 읽는다(75 화면과 같은 길) — 못 가르면 예전처럼 앞자리부터 */
      var mine = formPick(formSections(udText), name);
      var s = mine ? mine.text.replace(/\s+/g, ' ')
                   : sliceForForm(String(udText == null ? '' : udText).replace(/\s+/g, ' '), name);
      if (!s) return 0;
      if (FREQ_PRN.test(s)) return 0;   /* 필요할 때만 쓰는 약은 비워 두고 환자분이 고르시게 한다 */
      FREQ_RE.lastIndex = 0;
      var m, n;
      while ((m = FREQ_RE.exec(s))) {
        n = parseInt(m[1], 10);
        if (!(n >= 1 && n <= 4)) continue;
        if (FREQ_NOT.test(s.slice(m.index + m[0].length))) continue;
        return n;
      }
      return 0;
    }
    return { doc: doc, freqOf: freqOf, formSections: formSections, formPick: formPick };
  })();

  /* ── 투여경로(먹는 약·눈에 넣는 약·바르는 약·붙이는 약·기타) ──
     medications.schedule(jsonb) 안에 { route, route_by } 로 저장한다 — DB 구조는 그대로.
     route_by: 'hira' 심평원 injcPthNm · 'form' 이름의 제형 꼬리 · 'user' 환자가 고름.
     route 가 없는 약(이전에 저장된 약)은 먹는 약으로 본다 — 기존 동작·알림 문구가 그대로 유지된다. */
  var ROUTE = (function () {
    var INFO = {
      oral:   { label: '먹는 약',      chip: '먹는 약',      ic: '💊', will: '드실',     done: '드셨어요',     doneIf: '드셨으면',     how: '드시는지',     go: '드세요' },
      eye:    { label: '눈에 넣는 약', chip: '눈에 넣는 약', ic: '👁️', will: '넣으실',   done: '넣으셨어요',   doneIf: '넣으셨으면',   how: '넣으시는지',   go: '넣으세요' },
      skin:   { label: '바르는 약',    chip: '바르는 약',    ic: '🧴', will: '바르실',   done: '바르셨어요',   doneIf: '바르셨으면',   how: '바르시는지',   go: '바르세요' },
      patch:  { label: '붙이는 약',    chip: '붙이는 약',    ic: '🩹', will: '붙이실',   done: '붙이셨어요',   doneIf: '붙이셨으면',   how: '붙이시는지',   go: '붙이세요' },
      inhale: { label: '흡입하는 약',  chip: '기타',         ic: '💨', will: '흡입하실', done: '흡입하셨어요', doneIf: '흡입하셨으면', how: '흡입하시는지', go: '흡입하세요' },
      other:  { label: '기타 약',      chip: '기타',         ic: '💊', will: '사용하실', done: '사용하셨어요', doneIf: '사용하셨으면', how: '사용하시는지', go: '사용하세요' }
    };
    var NONE = { label: '', chip: '', ic: '💊', will: '쓰실', done: '쓰셨어요', doneIf: '쓰셨으면', how: '쓰시는지', go: '쓰세요' };
    var CHIPS = ['먹는 약', '눈에 넣는 약', '바르는 약', '붙이는 약', '기타'];
    var BY_CHIP = { '먹는 약': 'oral', '눈에 넣는 약': 'eye', '바르는 약': 'skin', '붙이는 약': 'patch', '기타': 'other' };
    function known(r) { return Object.prototype.hasOwnProperty.call(INFO, r); }
    function info(r) { return known(r) ? INFO[r] : NONE; }
    function ofMed(m) {
      var r = m && m.schedule && m.schedule.route;
      if (!r) return 'oral';
      return known(r) ? r : 'other';
    }
    /* OCR 제형(kind) → route. 주사는 '기타'로 두고 화면이 따로 안내한다 */
    function fromKind(k) {
      if (k === 'injection') return 'other';
      return known(k) ? k : 'unknown';
    }
    /* 심평원 약 목록 한 줄 → { route, injection } · 근거가 없으면 null */
    function fromHira(d) {
      if (!d || !d.routeKey) return null;
      if (d.routeKey === 'oral') return { route: 'oral', injection: false };
      if (d.routeKey === 'injection') return { route: 'other', injection: true };
      if (d.routeKey !== 'topical') return null;
      /* 외용은 눈·피부·붙이는 약을 가르지 않는다 — 이름의 제형 꼬리, 그다음 약효분류번호로 나눈다 */
      var k = OCRP.formKind(OCRP.stripDose(d.name || ''));
      if (k && k !== 'oral' && k !== 'injection' && known(fromKind(k))) return { route: fromKind(k), injection: false };
      var md = String(d.meftDivNo || '');
      if (/^131/.test(md)) return { route: 'eye', injection: false };     /* 131 안과용제 */
      if (/^26/.test(md)) return { route: 'skin', injection: false };     /* 26x 외피용약 */
      return { route: 'unknown', injection: false };                      /* 외용인 것만 안다 — 환자에게 묻는다 */
    }
    /* 알림 본문 — 약 이름은 넣지 않는다(잠금화면 노출 방지). push-send 함수와 같은 문구 */
    function notifyBody(r, slot) {
      if (r === 'eye') return slot + '에 넣으실 안약이 있어요';
      if (!known(r) || r === 'oral') return slot + ' 약 드실 시간이에요';
      return slot + '에 ' + INFO[r].will + ' 약이 있어요';
    }
    return { INFO: INFO, CHIPS: CHIPS, BY_CHIP: BY_CHIP, known: known, info: info, ofMed: ofMed,
             fromKind: fromKind, fromHira: fromHira, notifyBody: notifyBody };
  })();

  /* medEnded(med)·medLastDay(med) — 며칠분이 지난 약인지·마지막 날. 55·56 등 화면 표시용이다(알림은 끊지 않는다) */
  window.TDN = { isNative: isNative, notifySync: notifySync, deniedToast: deniedToast, openExternal: openExternal, cancelAll: cancelAll, askPermissions: askPermissions,
                 route: ROUTE, ocr: OCRP, hira: HIRA, mfds: MFDS, medEnded: medEnded, medLastDay: medLastDay, rx: RX,
                 /* 고르기 팝업 — 54 와 58(features.js)이 같은 창을 쓴다.
                    WHEN_ITEMS 는 아래에서 값이 들어가므로(var 끌어올림) 함수로 감싸 넘긴다 */
                 pick: pickOpen, pickStyle: function () { pickStyle(); }, whenList: function () { return WHEN_ITEMS; },
                 whenText: whenText, whenDefault: whenDefault, whenTime: whenTime,
                 /* 등록 전 임시 저장(todak_ocr_meds) — 53·54 와 58(features.js)이 같은 곳을 본다 */
                 ocrPend: { get: pendGet, set: pendSet, clear: pendClear } };

  /* 홈·오늘의 복약(55)에 들어올 때 예약을 저절로 맞춘다 — 권한은 조르지 않는다(passive).
     55 는 54·56·58 에서 약을 저장한 뒤 넘어오는 곳이라, 저장 화면이 예약을 마치기 전에 넘어왔어도 여기서 다시 맞춘다. */
  if ((PAGE === '05-home.html' || PAGE === '55-med-today.html') && isNative) {
    setTimeout(function () { notifySync(null, { passive: true }); }, 1200);
  }
  if (PAGE === '05-home.html' && !isNative) {
    /* 웹앱: 이미 허용됐으면 조용히 구독 갱신, 아니면 배너로 안내 (권한 요청은 버튼 탭 안에서만 가능) */
    consentNotif(function (allowed) {
      if (!allowed) return;
      var granted = window.Notification && Notification.permission === 'granted';
      if (granted && isStandalone()) { webPushSync(function () {}); return; }
      var hidden = false; try { hidden = localStorage.getItem('todak_push_banner_off') === '1'; } catch (e) {}
      if (hidden || (window.Notification && Notification.permission === 'denied')) return;
      var c = $('.content'); if (!c) return;
      var bn = document.createElement('div');
      bn.className = 'banner banner--info';
      if (isIOS() && !isStandalone()) {
        bn.innerHTML = '<span class="b-ic">📲</span><div class="small grow"><b>홈 화면에 추가하면</b> 복약·기록 알림을 받을 수 있어요. 사파리 아래 공유 버튼 → ‘홈 화면에 추가’</div><button type="button" class="btn btn-sm" style="flex:0 0 auto;">닫기</button>';
        $('button', bn).addEventListener('click', function () { bn.parentNode.removeChild(bn); try { localStorage.setItem('todak_push_banner_off', '1'); } catch (e) {} });
      } else {
        bn.innerHTML = '<span class="b-ic">🔔</span><div class="small grow">복약·기록 시간에 <b>알림</b>을 받으시겠어요?</div><button type="button" class="btn btn-primary btn-sm" style="flex:0 0 auto;">알림 켜기</button>';
        $('button', bn).addEventListener('click', function () {
          notifySync(function (st) {
            deniedToast(st);
            if (st === 'ok') { toast('알림을 켰어요 🔔'); bn.parentNode.removeChild(bn); }
          });
        });
      }
      /* 분홍 인사 칸(.greet)은 위로 끝까지 붙는 모양이라, 그 위에 띠를 얹으면 인사 칸 윗부분을 덮었다 — 인사 칸 바로 아래에 둔다 (2026-09-28) */
      /* 홈은 인사 칸이 분홍 머리(.brandhead) 안에 들어 있어(05-home.html, 2026-09-28) '.greet 가 .content 바로 아래'라는 조건에
         걸리지 않아 띠가 맨 위(분홍 칸 위)로 갔다 — 분홍 머리째로 보고 그 바로 아래에 둔다 (2026-10-01) */
      var greet = $('.greet', c);
      var head = greet && greet.parentNode && greet.parentNode.classList && greet.parentNode.classList.contains('brandhead') ? greet.parentNode : greet;
      if (head && head.parentNode === c) c.insertBefore(bn, head.nextSibling);
      else c.insertBefore(bn, c.firstChild);
    });
  }

  /* ── 웹앱: 화면 틀(.screen)이 실제로 보이는 높이보다 길게 잡히는 폰 ──
     .screen 은 100dvh 인데, 안드로이드 폰에 '홈 화면에 추가'한 웹앱에서 이 값이 아래 시스템 버튼 줄(Ⅲ ○ ＜)까지 넣은 높이로 잡혀
     아래 탭 줄(홈·상담…)이 버튼 줄 뒤로 밀려 잘렸다 (교수님 폰 2026-09-28).
     틀이 window.innerHeight(실제로 그려지는 높이)보다 길 때만 그 높이로 줄인다 — 제대로 잡히는 브라우저와 앱(APK)은 그대로다.
     자판이 올라와 높이가 바뀌면 resize 로 다시 맞춘다(크롬은 자판에 innerHeight 가 그대로라 달라지지 않는다). */
  if (!isNative) {
    /* 손가락 두 개로 벌려 확대되지 않게 — 앱(APK)처럼 화면 틀을 고정한다 (교수님 2026-09-29).
       아이폰 사파리는 viewport 의 user-scalable=no 를 무시해서 여기서 막는다.
       두 손가락 동작만 막는다 — 두 번 두드려 확대는 app-device.css 의 touch-action 이 막는다.
       여기서 두드리기를 가로채면 단추를 빠르게 두 번 누를 때 두 번째가 씹힌다. */
    var stop = function (e) { if (e.cancelable) e.preventDefault(); };
    ['gesturestart', 'gesturechange', 'gestureend'].forEach(function (n) {
      document.addEventListener(n, stop, { passive: false });
    });
    document.addEventListener('touchmove', function (e) {
      if (e.touches && e.touches.length > 1) stop(e);   /* 손가락 두 개 이상일 때만 */
    }, { passive: false });

    var fitT = 0;
    var fitScreen = function () {
      fitT = 0;
      var sc = document.querySelector('.screen'), want = window.innerHeight;
      if (!sc || !(want > 200)) return;
      sc.style.height = '';
      if (sc.getBoundingClientRect().height - want > 1) sc.style.height = want + 'px';
    };
    var fitLater = function () { if (!fitT) fitT = setTimeout(fitScreen, 120); };
    fitScreen();
    setTimeout(fitScreen, 600);   /* 웹앱은 켜진 직후 창 크기가 한 번 더 바뀌곤 한다 */
    window.addEventListener('resize', fitLater, false);
    window.addEventListener('orientationchange', fitLater, false);
    window.addEventListener('pageshow', fitLater, false);
  }

  /* ── 23 알림 설정 ── */
  function page23() {
    var items = $$('.listitem');
    var MAP = [
      ['마음 건강 체크', 'mood_check'],
      ['컨디션 기록', 'record_remind'],
      ['복약 알림', 'med_remind'],
      ['진료 전 알림', 'visit_remind']
    ];
    /* 줄(스위치 말고)을 누르면 시간 고르기(timepick.js — 복약 시간과 같은 창)가 열리는 두 알림.
       고른 시각은 notif_prefs[tk] 에 'HH:MM' 으로 저장하고, 줄 아래 글자에 '매일 오후 8:00' 처럼 보인다 */
    var TIMED = {
      mood_check: { tk: 'mood_time', pre: '매주 월요일 ' },
      record_remind: { tk: 'record_time', pre: '매일 ' }
    };
    var newsLabel = $$('.section-label').filter(function (l) { return l.textContent.indexOf('소식') > -1; })[0];
    if (newsLabel) {
      var el = newsLabel.nextElementSibling;
      while (el && !el.classList.contains('section-label') && !el.classList.contains('banner')) {
        var nx = el.nextElementSibling; el.parentNode.removeChild(el); el = nx;
      }
      newsLabel.parentNode.removeChild(newsLabel);
    }
    var c = $('.content');
    /* ── 맨 위 안내 ──
       '알림이 켜져 있어요…' 와 가입 동의 안내(주황) 두 칸은 뺐다(교수님 2026-09-28). 늘 보이는 안내는 화면의
       '알림을 누르면 시간을 바꿀 수 있어요' 한 칸뿐이고, 알림이 실제로 오지 않을 때만 한 칸을 맨 위에 붙인다.
       ① 알림 수신 동의가 꺼져 있으면 그 한 줄만 — 동의가 없으면 권한을 켜도 오지 않으므로 아래 ②③은 걷는다.
          '알림 수신 동의 다시 설정하기' 줄을 그 바로 밑으로 올린다. 동의 여부를 모르면(연결 끊김) 붙이지 않는다.
       ② 웹앱: 아이폰에서 홈 화면에 추가하기 전 / 아직 알림을 허용하지 않았을 때(허용 창은 단추를 눌러야만 띄울 수 있다)
       ③ 앱: 휴대폰 알림 권한이 꺼져 있을 때 */
    var consentOff = false, permBn = null;
    function putTop(node) { if (c) c.insertBefore(node, c.firstChild); }
    function dropPerm() { if (permBn && permBn.parentNode) permBn.parentNode.removeChild(permBn); permBn = null; }
    /* 알림이 오지 않는 까닭 칸은 모두 주황(banner--warn) — 늘 있는 '알림을 누르면…'(파랑) 안내와 한눈에 갈리게 한다.
       단추는 눌러서 풀리는 경우에만 둔다. 한 번 '허용 안 함'을 고른 브라우저는 허용 창을 다시 띄우지 않으므로
       그때는 단추 없이 기기 설정 길만 적는다(예전에는 눌러도 아무 일 없는 '알림 켜기'가 남았다). */
    function showPerm(h) {
      var nb = document.createElement('div');
      nb.className = 'banner banner--warn';
      nb.innerHTML = h;
      if (permBn && permBn.parentNode) permBn.parentNode.replaceChild(nb, permBn);
      else putTop(nb);
      permBn = nb;
    }
    function webPerm() {
      if (consentOff) return dropPerm();
      var np = window.Notification ? Notification.permission : '';
      if (isIOS() && !isStandalone()) return showPerm('<span class="b-ic">📲</span><div class="small">아이폰은 <b>홈 화면에 추가한 뒤</b><br>알림을 켤 수 있어요.<br>사파리 아래 공유 버튼 → ‘홈 화면에 추가’</div>');
      if (!window.Notification || !('serviceWorker' in navigator) || !('PushManager' in window)) return showPerm('<span class="b-ic">📵</span><div class="small">지금 쓰시는 인터넷 창에서는<br>알림을 받을 수 없어요.</div>');
      if (np === 'granted') return dropPerm();
      if (np === 'denied') return showPerm('<span class="b-ic">🔕</span><div class="small"><b>이 휴대폰에서 토닥 알림이 꺼져 있어요.</b><br>휴대폰 설정에서 토닥 알림을 허용해 주세요.</div>');
      /* 단추는 글 밑에 둔다 — 옆에 두면 글자를 키운 폰(200%)에서 글이 한 낱말씩 세로로 쌓였다 */
      showPerm('<span class="b-ic">🔔</span><div class="small grow">알림을 받으려면<br>한 번 허용해 주세요.<div style="margin-top:8px;"><button type="button" class="btn btn-primary btn-sm">알림 켜기</button></div></div>');
      var okb = $('button', permBn);
      if (okb) okb.addEventListener('click', function () {
        notifySync(function (st) {
          if (st === 'ok') { toast('알림을 켰어요 🔔'); dropPerm(); return; }
          deniedToast(st);
          webPerm();                                       /* 허용 창에서 '허용 안 함'을 고르셨으면 단추 없는 안내로 바뀐다 */
        });
      });
    }
    if (!isNative) webPerm();
    else if (P.LocalNotifications && P.LocalNotifications.checkPermissions) {
      P.LocalNotifications.checkPermissions().then(function (perm) {
        if (consentOff || !(perm && perm.display === 'denied')) return;
        showPerm('<span class="b-ic">🔕</span><div class="small"><b>휴대폰 알림 권한이 꺼져 있어요.</b><br>켜기 전에는 알림이 울리지 않아요.<br><b>설정 › 애플리케이션 › 토닥 › 알림</b>에서<br>허용해 주세요.</div>');
      }, function () {});
    }
    consentNotif(function (allowed) {
      if (allowed !== false || !c) return;
      consentOff = true;
      dropPerm();
      var row = $$('.listitem', c).filter(function (li) { return (li.getAttribute('href') || '').indexOf('02-consent.html') === 0; })[0];
      if (row) putTop(row);
      var cb = document.createElement('div');
      cb.className = 'banner banner--warn';
      cb.id = 'bn-consent-off';
      cb.innerHTML = '<span class="b-ic">🔕</span><div class="small">알림 수신에 동의하지 않으셔서<br>지금은 알림이 오지 않아요.</div>';
      putTop(cb);
    });
    /* ── '알림이 늦게 올 때' 안내 ──
       늦게 오는 까닭은 둘이다. ① 휴대폰 절전(앱 절전 관리) — 화면의 안내문이 바꾸는 길을 알려 드린다.
       ② '알람 및 리마인더'가 꺼진 경우 — 이때만 설정으로 보내는 버튼을 붙인다.
       앱이 묻지도 않고 시스템 설정 화면을 띄우면 놀라시므로, 누르실 때만 보낸다.
       절전 안내는 안드로이드 앱에만 맞는 말이라 아이폰 웹앱에서는 뺀다. */
    var lateBn = $('#bn-late');
    if (lateBn && !isNative) {
      if (lateBn.parentNode) lateBn.parentNode.removeChild(lateBn);
      lateBn = null;
    }
    if (lateBn) exactAllowed(function (ok) {
      if (ok) return;                                    /* 이미 켜져 있으면 더 여쭙지 않는다 */
      var eb = document.createElement('div');
      eb.className = 'banner banner--warn';
      eb.innerHTML = '<span class="b-ic">🔔</span><div class="small grow"><b>‘알람 및 리마인더’가 꺼져 있어요.</b><br>켜 두시면 복약 알림이 정한 시각에 울려요.<div style="margin-top:8px;"><button type="button" class="btn btn-primary btn-sm">설정 열기</button></div></div>';
      var ebtn = $('button', eb);
      if (ebtn) ebtn.addEventListener('click', function () {
        exactAsk(function (ok2) {
          /* 설정을 바꾸면 안드로이드가 앱을 다시 띄우면서 걸려 있던 정확한 알람을 지운다 — 예약을 다시 맞춘다 */
          notifySync(null, { passive: true });
          if (!ok2) return;
          toast('복약 알림을 정한 시각에 울리도록 맞췄어요 ⏰');
          if (eb.parentNode) eb.parentNode.removeChild(eb);
        });
      });
      if (lateBn.parentNode) lateBn.parentNode.insertBefore(eb, lateBn.nextSibling);
    });
    /* ── 스위치 ──
       불러오기가 끝나기 전·실패했을 때는 스위치를 흐리게 두고 바꾸지 못하게 한다. 실패하면 다시 불러오기 버튼을 보여 준다.
       (예전에는 불러오기가 실패해도 모두 '켜짐'으로 그리고, 하나를 누르면 네 설정 전체를 '켜짐'으로 덮어썼다)
       저장은 이 화면에서 바꾼 항목만 불러온 값에 합쳐서 한다. 한 번에 하나씩 저장하고, 저장 중에 또 바꾸면 끝난 뒤 이어서 저장한다.
       예약은 저장이 모두 끝난 뒤 맞춘다(연달아 바꾼 두 번째 변경이 예약에 빠지지 않게). */
    var uidv = null, saved = null, want = null, changed = {}, saving = false, again = false, askNext = false, loadBn = null, okMsg = null;
    var sws = [], tms = [];
    function paintAll() {
      sws.forEach(function (o) {
        o.sw.style.opacity = want ? '' : '.45';
        if (!want) { o.sw.setAttribute('aria-disabled', 'true'); return; }   /* 불러오기 전에는 켜짐·꺼짐을 그리지 않는다 */
        o.sw.removeAttribute('aria-disabled');
        o.sw.classList[want[o.key] ? 'remove' : 'add']('switch--off');
        o.sw.setAttribute('aria-checked', want[o.key] ? 'true' : 'false');
      });
      tms.forEach(function (o) { if (want) o.sub.textContent = o.pre + hm12(want[o.tk]); });   /* 불러오기 전에는 화면의 기본 시각 그대로 */
    }
    function saveFail(msg) {
      again = false;
      okMsg = null;
      want = notifPrefs({ notif_prefs: saved });                  /* 저장에 실패하면 마지막으로 저장된 값으로 되돌린다(시각도) */
      changed = {};
      paintAll();
      toast(msg);
    }
    function save() {
      if (saving) { again = true; return; }
      saving = true;
      var next = {}, k;
      for (k in saved) next[k] = saved[k];
      for (k in changed) next[k] = want[k];
      sb.from('profiles').update({ notif_prefs: next }).eq('id', uidv).then(function (r2) {
        saving = false;
        if (!r2 || r2.error) return saveFail(r2 && r2.error ? koError(r2.error) : '연결이 원활하지 않아요. 다시 시도해 주세요.');
        saved = next;
        if (again) { again = false; save(); return; }
        var ask = askNext, msg = okMsg;
        askNext = false;
        okMsg = null;
        /* 켠 항목이 있으면 권한을 묻고 안내한다. 끄기만 했으면 조용히 맞춘다.
           시간을 바꿨으면 예약까지 맞춘 뒤 '매일 오후 9:30에 알려 드릴게요' — 예약이 안 되면(동의·권한·연결) 그 까닭을 대신 알린다 */
        notifySync(function (st) {
          if (!isNative) webPerm();                                 /* 웹: 허용 상태가 바뀌었으면 맨 위 안내 칸도 맞춘다(허용됨 → 칸 빼기 · 거부 → 기기 설정 안내) */
          if (st === 'ok') { if (msg) toast(msg); return; }
          if (ask || msg || st === 'offline') deniedToast(st);
        }, { passive: !ask });
      }, function () { saving = false; saveFail('연결이 원활하지 않아요. 다시 시도해 주세요.'); });
    }
    function notLoaded() {
      toast(loadBn ? '알림 설정을 아직 불러오지 못했어요.\n위의 ‘다시 불러오기’를 눌러 주세요.' : '알림 설정을 불러오는 중이에요.');
    }
    /* 시간 고르기 — 복약 시간(56)과 같은 창(timepick.js TDT.open). 확인을 누르면 저장하고 예약을 다시 맞춘다.
       꺼 둔 알림의 시간을 고르시면 그 알림을 켠다(시간을 고른 것은 받겠다는 뜻 — 켜짐 스위치로 바로 보인다) */
    function pickTime(key, tm) {
      if (!want) return notLoaded();
      var TP = window.TDT;
      if (!TP || !TP.open || document.querySelector('.tp-dim')) return;
      TP.open(want[tm.tk], function (picked) {
        var hm = normHM(picked);
        if (!hm || !want) return;
        var wasOff = !want[key];
        if (hm === want[tm.tk] && !wasOff) return;                 /* 같은 시각 그대로 확인만 누르셨으면 저장하지 않는다 */
        want[tm.tk] = hm;
        changed[tm.tk] = 1;
        if (wasOff) { want[key] = true; changed[key] = 1; askNext = true; }
        okMsg = tm.pre + hm12(hm) + '에 알려 드릴게요 🔔';
        paintAll();
        save();
      });
    }
    MAP.forEach(function (pair) {
      var item = items.filter(function (li) { return li.textContent.indexOf(pair[0]) > -1; })[0];
      var sw = item ? $('.switch', item) : null;
      if (!sw) return;
      sws.push({ sw: sw, key: pair[1] });
      sw.style.cursor = 'pointer';
      sw.addEventListener('click', function (e) {
        e.preventDefault(); e.stopPropagation();
        if (!want) return notLoaded();
        want[pair[1]] = !want[pair[1]];
        changed[pair[1]] = 1;
        if (want[pair[1]]) askNext = true;
        paintAll();
        save();
      });
      /* 마음 건강 체크·컨디션 기록 — 스위치 말고 줄을 누르면 시간 고르기 */
      var tm = TIMED[pair[1]];
      var sub = tm ? $('.li-sub', item) : null, body = tm ? $('.li-body', item) : null;
      if (!sub || !body) return;
      tms.push({ sub: sub, tk: tm.tk, pre: tm.pre });
      item.style.cursor = 'pointer';
      body.setAttribute('role', 'button');
      body.setAttribute('tabindex', '0');
      item.addEventListener('click', function (e) {
        if (e.target && e.target.closest && e.target.closest('.switch')) return;
        pickTime(pair[1], tm);
      });
      body.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickTime(pair[1], tm); }
      });
    });
    function loadFail() {
      if (loadBn) { toast('아직 불러오지 못했어요.\n연결을 확인한 뒤 다시 눌러 주세요.'); return; }
      loadBn = document.createElement('div');
      loadBn.className = 'banner banner--warn';
      loadBn.innerHTML = '<span class="b-ic">⚠️</span><div class="small grow">알림 설정을 불러오지 못했어요.<br>연결을 확인한 뒤 다시 불러와 주세요.<div style="margin-top:8px;"><button type="button" class="btn btn-sm">다시 불러오기</button></div></div>';
      $('button', loadBn).addEventListener('click', function () { load(); });
      if (c) c.insertBefore(loadBn, c.firstChild);
    }
    function load() {
      sb.auth.getSession().then(function (rs) {
        var ses = rs && rs.data && rs.data.session;
        if (!ses) { if (rs && rs.error) loadFail(); return; }
        uidv = ses.user.id;
        sb.from('profiles').select('notif_prefs').eq('id', uidv).maybeSingle().then(function (rp) {
          if (!rp || rp.error) return loadFail();
          saved = (rp.data && rp.data.notif_prefs && typeof rp.data.notif_prefs === 'object') ? rp.data.notif_prefs : {};
          want = notifPrefs({ notif_prefs: saved });
          if (loadBn && loadBn.parentNode) loadBn.parentNode.removeChild(loadBn);
          loadBn = null;
          paintAll();
        }, function () { loadFail(); });
      }, function () { loadFail(); });
    }
    paintAll();
    load();
  }

  /* ── 53 사진으로 약 등록 (앱 전용 · 사진은 글자만 읽고 즉시 폐기) ── */
  function page53() {
    /* 뒤로(‹·휴대폰 뒤로가기) — 가입 중(04 치료 정보에서 옴)이거나 내 정보에서 치료 정보를 고치는 중이면 04,
       평소에는 약 직접 입력(58)으로 간다. 평소 들어오는 길이 55·56 → 58 → 53 이다.
       (예전에는 평소 사용자도 가입용 04 로 떨어져, 04 가 가입 표시를 켜고 58·54 저장 뒤 이동까지 04 로 바뀌었다) */
    try {
      var b53 = $('.appbar .back');
      var inTreat = sessionStorage.getItem('todak_onboard') || sessionStorage.getItem('todak_edit');
      if (b53) b53.setAttribute('href', inTreat ? '04-treatment.html' : '58-med-manual.html');
    } catch (e53) {}
    /* '⌨️ 직접 입력' — 사진으로 읽어 두고 아직 등록하지 않은 약이 있으면(54 에서 ‹ 로 되돌아온 길),
       58 을 '바로 등록'이 아니라 '목록에 넣기'로 열어 54 의 목록에 합류시킨다.
       그러지 않으면 58 에서 한 개만 등록되고 읽어 둔 약들이 등록되지 않은 채 남는다. */
    try {
      if (pendGet().length) {
        $$('a').forEach(function (a) {
          if (a.className.indexOf('back') > -1) return;              /* 앱바 ‹ 는 그대로 둔다 */
          var hr = a.getAttribute('href') || '';
          if (hr.indexOf('58-med-manual.html') === 0 && hr.indexOf('add=1') < 0) {
            a.setAttribute('href', '58-med-manual.html?add=1&from=54-med-confirm.html');
          }
        });
      }
    } catch (e53b) {}
    var btns = $$('a');
    var shoot = btns.filter(function (a) { return (a.getAttribute('href') || '').indexOf('54-med-confirm') > -1; })[0];
    var album = btns.filter(function (a) { return (a.getAttribute('href') || '').indexOf('59-med-scan-fail') > -1; })[0];
    var ocrBusy = false;
    /* ── 읽은 줄을 사람이 읽는 순서로 되돌린다 ──
       사진 속 종이가 90도 누워 있으면 기계는 종이 기준이 아니라 사진 기준으로 읽어
       순서가 뒤집힌다. 각 줄의 네 모서리로 글자가 기운 각도를 재고, 그만큼 되돌려
       세운 좌표로 위→아래·왼→오른쪽 정렬한다. */
    function lineGeom(l) {
      var cs = l.cornerPoints, bb = l.boundingBox;
      if (cs && cs.length >= 2) {
        var x0 = cs[0].x, y0 = cs[0].y, x1 = cs[1].x, y1 = cs[1].y;
        var cx = 0, cy = 0;
        for (var i = 0; i < cs.length; i++) { cx += cs[i].x; cy += cs[i].y; }
        return { cx: cx / cs.length, cy: cy / cs.length, ang: Math.atan2(y1 - y0, x1 - x0),
                 h: Math.hypot(cs[3] ? cs[3].x - x0 : 0, cs[3] ? cs[3].y - y0 : 12) || 12 };
      }
      if (bb) {
        return { cx: (bb.left + bb.right) / 2, cy: (bb.top + bb.bottom) / 2, ang: 0,
                 h: Math.abs(bb.bottom - bb.top) || 12 };
      }
      return null;
    }
    function orderLines(res) {
      var raw = [];
      ((res && res.blocks) || []).forEach(function (b) {
        (b.lines || [b]).forEach(function (l) {
          if (!l || !l.text) return;
          var g = lineGeom(l);
          raw.push({ text: l.text, g: g });
        });
      });
      if (!raw.length) return { items: [], rotated: false };

      var withG = raw.filter(function (r) { return r.g; });
      if (withG.length < 2) {
        return { items: raw.map(function (r) { return { text: r.text, y: 0, x: 0, h: 12 }; }), rotated: false };
      }
      /* 기운 각도의 중앙값 — 한두 줄이 삐뚤어도 전체가 흔들리지 않게 */
      var angs = withG.map(function (r) { return r.g.ang; }).sort(function (a, b) { return a - b; });
      var med = angs[Math.floor(angs.length / 2)];
      var cos = Math.cos(-med), sin = Math.sin(-med);
      var items = withG.map(function (r) {
        return {
          text: r.text,
          x: r.g.cx * cos - r.g.cy * sin,
          y: r.g.cx * sin + r.g.cy * cos,
          h: r.g.h
        };
      });
      /* 같은 줄로 볼 높이 — 글자 높이의 절반 */
      var hs = items.map(function (it) { return it.h; }).sort(function (a, b) { return a - b; });
      var band = Math.max(6, (hs[Math.floor(hs.length / 2)] || 12) * 0.6);
      items.sort(function (a, b) {
        return (Math.abs(a.y - b.y) > band) ? (a.y - b.y) : (a.x - b.x);
      });
      return { items: items, rotated: Math.abs(med) > 0.35, band: band };
    }
    var parseMeds = OCRP.parseMeds;
    function finishWith(meds) {
      if (!meds || !meds.length) return toast('약 이름을 찾지 못했어요.\n글자가 잘 보이게 다시 찍거나 직접 입력해 주세요.');
      if (meds.length === 1) {                         /* 한 종뿐이면 지금까지처럼 바로 입력 화면 */
        /* 이름만 넘기면 사진에서 읽은 횟수·일수·제형을 버리게 된다 — 함께 넘겨 58 이 채운다 */
        try {
          sessionStorage.setItem('todak_ocr_one', JSON.stringify({
            name: meds[0].name, times: meds[0].times || 0, days: meds[0].days || 0, kind: meds[0].kind || ''
          }));
        } catch (e) {}
        location.href = '58-med-manual.html';
        return;
      }
      pendSet(meds);
      location.href = '54-med-confirm.html';
    }
    /* ── 넘어가기 전에 심평원 약 목록과 한 번 맞춰 본다 ──
       생김새 설명 줄을 빼고, 오타를 정식 이름으로 고치고, 중복을 합치고, 지나친 약을 되살린다.
       맞춰 보지 못하면(로그인 전·연결 끊김·조회 실패) 읽은 그대로 넘어간다 — 54 가 그렇다고 알린다.
       한 종만 남아도 목록에서 뺀 줄이 있으면 54 로 보낸다(그 화면에서 되살릴 수 있어야 하므로). */
    /* 안내를 대조가 끝날 때까지 유지한다 — toast 는 3초쯤에 저절로 사라지는데 대조는 6.4초까지 기다린다.
       그 사이 53 이 아무 표시 없이 멈춘 것처럼 보였고, 촬영·앨범을 다시 누르면 두 번째 인식이 시작됐다. */
    var waitTimer = null;
    function waitNote(on) {
      if (waitTimer) { clearInterval(waitTimer); waitTimer = null; }
      if (!on) return;
      toast('약 목록과 맞춰 보는 중…');
      waitTimer = setInterval(function () { toast('약 목록과 맞춰 보는 중…'); }, 2500);
    }
    /* ── 읽다 만 줄 세기 ── 2026-09-27
       제형 꼬리는 보이는데 글자가 깨져 약으로 받지 못한 줄이 몇인지 센다.
       목록에 이미 들어간 약과 겹치는 줄은 빼고, 같은 줄은 한 번만 센다.
       세기만 하고 목록에는 넣지 않는다 — 54 가 '못 읽었어요' 하고 솔직하게 알린다. */
    function countGarbled(lines, meds) {
      var seen = {}, known = {}, n = 0, kept = [];
      (meds || []).forEach(function (m) { known[HIRA.normKey(OCRP.stripDose(m.name))] = 1; });
      (lines || []).forEach(function (l) {
        var t = (typeof l === 'string') ? l : String((l && l.text) || '');
        t = t.replace(/\s+/g, ' ').trim();
        var tok = t ? OCRP.garbledToken(t) : '';
        if (!tok) return;
        var k = HIRA.normKey(OCRP.stripDose(tok));
        if (!k || known[k] || seen[k]) return;                /* 이미 목록에 들어간 약은 세지 않는다 */
        seen[k] = 1;
        n++;
        if (kept.length < 3) kept.push(tok.slice(0, 20));
      });
      return { n: n, lines: kept };
    }
    function finishScan(meds, lines) {
      if (!meds || !meds.length) {
        ocrBusy = false;
        /* 하나도 못 찾았을 때 — 글자가 흐려 못 읽은 줄이 있었다면 그것을 먼저 말씀드린다.
           '약이 없었다'와 '읽지 못했다'는 다른 말이고, 뒤쪽이 사실이다. */
        var g0 = countGarbled(lines, []);
        if (g0.n) return toast('약 이름 같은 줄 ' + g0.n + '개가 흐려서 읽지 못했어요.\n잘못 넣지 않으려고 비워 두었어요 — 밝은 곳에서 다시 찍으시거나 직접 입력해 주세요.');
        return finishWith(meds);
      }
      waitNote(true);
      function after(r) {
        waitNote(false);
        ocrBusy = false;                       /* 화면을 넘기거나 안내를 낼 때 푼다 — 그전에는 다시 찍기가 눌리지 않는다 */
        var got = (r && r.meds) || meds;
        var keep = got.filter(function (m) { return !m.__drop; });
        if (got.length === 1 && keep.length === 1) return finishWith(keep);
        if (!keep.length) {
          pendSet(got);
          location.href = '54-med-confirm.html';
          return;
        }
        finishWith(got);
      }
      try { HIRA.reconcile(meds, lines).then(after, function () { after(null); }); }
      catch (e) { after(null); }
    }
    /* 웹(아이폰): 사진 파일 → 브라우저 안에서 글자 읽기. 사진은 휴대폰 밖으로 나가지 않는다 (인식 모듈만 처음 한 번 내려받음) */
    var tessP = null;
    function loadTess() {
      if (window.Tesseract) return Promise.resolve();
      if (tessP) return tessP;
      tessP = new Promise(function (res, rej) {
        var sc = document.createElement('script');
        sc.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
        sc.onload = res; sc.onerror = function () { tessP = null; rej(new Error('load')); };
        document.head.appendChild(sc);
      });
      return tessP;
    }
    function shrink(file) {
      return new Promise(function (res, rej) {
        var img = new Image();
        img.onload = function () {
          var max = 1600, w = img.naturalWidth, h = img.naturalHeight, k = Math.min(1, max / Math.max(w, h));
          var cv = document.createElement('canvas'); cv.width = Math.round(w * k); cv.height = Math.round(h * k);
          cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
          URL.revokeObjectURL(img.src); res(cv);
        };
        img.onerror = rej;
        img.src = typeof file === 'string' ? file : URL.createObjectURL(file);
      });
    }
    function recognizeWeb(file) {
      if (ocrBusy) return;
      ocrBusy = true;
      toast('글자를 읽을 준비를 해요…\n처음 한 번만 1분쯤 걸려요.');
      var lastPct = -1;
      loadTess().then(function () { return shrink(file); }).then(function (cv) {
        return window.Tesseract.recognize(cv, 'kor+eng', { logger: function (m) {
          if (m.status === 'recognizing text') { var p = Math.round((m.progress || 0) * 100); if (p - lastPct >= 25) { lastPct = p; toast('글자를 읽는 중… ' + p + '%'); } }
        } });
      }).then(function (r) {
        var lines = String((r && r.data && r.data.text) || '').split('\n');
        finishScan(parseMeds(lines, 0.5), lines);     /* ocrBusy 는 finishScan 이 끝나면서 푼다 */
      }).catch(function () { waitNote(false); ocrBusy = false; toast('사진을 읽지 못했어요. 직접 입력해 주세요.'); });
    }
    window.TDN = window.TDN || {}; window.TDN.ocrWeb = recognizeWeb;   /* 검증용 */
    var fileCam = null, fileAlb = null;
    if (!isNative) {
      fileCam = document.createElement('input'); fileCam.type = 'file'; fileCam.accept = 'image/*'; fileCam.setAttribute('capture', 'environment'); fileCam.style.display = 'none';
      fileAlb = document.createElement('input'); fileAlb.type = 'file'; fileAlb.accept = 'image/*'; fileAlb.style.display = 'none';
      document.body.appendChild(fileCam); document.body.appendChild(fileAlb);
      [fileCam, fileAlb].forEach(function (inp) { inp.addEventListener('change', function () { if (inp.files && inp.files[0]) recognizeWeb(inp.files[0]); inp.value = ''; }); });
    }
    function recognize(source) {
      if (!isNative) { (source === 'CAMERA' ? fileCam : fileAlb).click(); return; }
      if (!P.Camera || !P.TextRecognition) {
        return toast('사진 인식을 쓸 수 없어요.\n⌨️ 직접 입력으로 넣어 주세요.');
      }
      if (ocrBusy) return;
      ocrBusy = true;
      var tmpPath = null;
      /* 원칙: 사진 원본은 글자를 읽는 즉시 지운다 (성공·실패·취소 모두) */
      function discard() {
        if (tmpPath && P.Filesystem && P.Filesystem.deleteFile) P.Filesystem.deleteFile({ path: tmpPath }).then(function () {}, function () {});
        tmpPath = null;
      }
      /* 감열지(약국 안내문 대부분)에서 '정/장'·'3/8'이 뭉개지지 않게 화질을 올린다.
         자르기 화면(allowEditing)은 끈다 — 표의 오른쪽 칸(횟수·일수)이 잘려 들어오는 주된 경로였다. */
      P.Camera.getPhoto({ source: source, resultType: 'uri', quality: 95, allowEditing: false, correctOrientation: true })
        .then(function (photo) {
          tmpPath = photo.path || photo.webPath;
          toast('글자를 읽는 중이에요…');
          /* script 를 주지 않으면 라틴 문자 인식기가 돌아가 한글을 한 글자도 못 읽는다 */
          return P.TextRecognition.processImage({ path: photo.path || photo.webPath, script: 'KOREAN' })
            .then(function (res) {
              discard();                              /* ocrBusy 는 finishScan 이 끝나면서 푼다 */
              var ord = orderLines(res);
              var items = ord.items;
              if (!items.length && res && res.text) items = res.text.split('\n');
              /* 읽어낸 글줄은 어디에도 남기지 않는다.
                 02 동의문·25 처리방침·53 안내가 "확인해 주신 약 이름과 사용 일정만 남는다"고 고지하므로,
                 진단용 파일 기록(DOCUMENTS/todak-ocr.json)과 인식 전문 콘솔 출력을 두지 않는다. */
              var meds = parseMeds(items, ord.band);
              finishScan(meds, items);
            });
        })
        .catch(function (err) {
          waitNote(false); ocrBusy = false; discard();
          var m = String((err && err.message) || '');
          if (/cancel/i.test(m)) return;
          toast('사진을 읽지 못했어요. 직접 입력해 주세요.');
        });
    }
    if (shoot) shoot.addEventListener('click', function (e) { e.preventDefault(); recognize('CAMERA'); });
    if (album) album.addEventListener('click', function (e) { e.preventDefault(); recognize('PHOTOS'); });
  }

  /* ── 54 사진에서 찾은 약 확인 (여러 종을 한 번에 추가 · 하루 몇 번·언제·며칠분을 직접 고친다) ── */
  var MED_SLOTS = {
    1: [['🌅', '아침', '08:00']],
    2: [['🌅', '아침', '08:00'], ['🌙', '저녁', '20:00']],
    3: [['🌅', '아침', '08:00'], ['☀️', '점심', '13:00'], ['🌙', '저녁', '19:00']],
    4: [['🌅', '아침', '08:00'], ['☀️', '점심', '13:00'], ['🌆', '저녁', '18:00'], ['🌙', '자기전', '22:00']],
    prn: [['💊', '필요시', '']]
  };
  var FREQ_LABEL = { 1: '하루 1번', 2: '하루 2번', 3: '하루 3번', 4: '하루 4번', prn: '필요할 때만' };
  function ymdLocal(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function slotCount(m) { return (m && m.times && MED_SLOTS[m.times]) ? m.times : 0; }

  /* ── 고르기 팝업 ── 시간 고르기(TDT)와 같은 모양으로 아래에서 올라온다.
     하루 몇 번 · 언제 · 며칠분 · 어떤 약인가요를 모두 이 창으로 고른다(손이 저려도 큰 줄을 한 번 누르면 된다).
     o = { title, sub, items:[{v,label}], value(하나 고르기) · values+need(여럿 고르기), onPick } */
  var pickCSS = false;
  function pickStyle() {
    if (pickCSS) return;
    pickCSS = true;
    var css = [
      '.pk-dim{position:fixed;inset:0;background:rgba(20,8,14,.45);z-index:9000;',
      '  display:flex;align-items:flex-end;justify-content:center;}',
      '.pk-dim[hidden]{display:none;}',
      '.pk-sheet{width:100%;max-width:520px;background:var(--surface,#fff);',
      '  border-radius:22px 22px 0 0;padding:18px 16px calc(16px + env(safe-area-inset-bottom));',
      '  box-shadow:0 -8px 30px rgba(0,0,0,.18);max-height:86vh;display:flex;flex-direction:column;',
      '  word-break:keep-all;overflow-wrap:break-word;}',
      '.pk-title{font-weight:800;font-size:17px;line-height:1.45;text-align:center;margin:2px 0 4px;}',
      '.pk-sub{font-size:13px;line-height:1.5;text-align:center;color:var(--on-surface-variant,#6B5860);margin-bottom:10px;}',
      /* N개가 다 찼을 때 나오는 안내 한 줄 */
      '.pk-note{font-size:13px;line-height:1.5;font-weight:700;text-align:center;',
      '  color:var(--primary-dark,#9E2E54);margin:-4px 0 10px;}',
      '.pk-note[hidden]{display:none;}',
      '.pk-list{overflow-y:auto;display:flex;flex-direction:column;gap:8px;padding:2px;}',
      '.pk-it{display:flex;align-items:center;gap:10px;min-height:56px;padding:10px 14px;',
      '  border:1.5px solid var(--outline,#D9C7CE);border-radius:14px;background:var(--white,#fff);',
      '  font-family:inherit;font-size:16px;font-weight:700;color:var(--on-surface,#241C1F);',
      '  text-align:left;cursor:pointer;}',
      '.pk-it.on{border-color:var(--primary,#C43E6B);background:var(--primary-tint,#FCEEF3);color:var(--primary-dark,#9E2E54);}',
      '.pk-it.is-lock{opacity:.5;}',           /* 다 찼을 때 더 켜지지 않는 줄 */
      '.pk-mk{width:22px;flex:0 0 auto;font-size:17px;color:var(--primary,#C43E6B);}',
      '.pk-lb{flex:1;min-width:0;}',
      '.pk-acts{display:flex;gap:10px;margin-top:16px;flex:0 0 auto;}',
      '.pk-acts button{flex:1;border:0;border-radius:14px;padding:14px 0;font-family:inherit;',
      '  font-size:16px;font-weight:800;cursor:pointer;}',
      '.pk-cancel{background:var(--surface-3,#EFE4E9);color:var(--on-surface-variant,#6B5860);}',
      '.pk-ok{background:var(--primary,#C43E6B);color:#fff;}'
    ].join('');
    var el = document.createElement('style');
    el.textContent = css;
    document.head.appendChild(el);
  }
  function pickOpen(o) {
    if (!o || !o.items || !o.items.length) return;
    if (document.querySelector('.pk-dim') || document.querySelector('.tp-dim')) return;   /* 한 번에 하나만 */
    pickStyle();
    var need = o.need > 0 ? o.need : 0;
    /* atLeast — 개수를 정하지 않고 고르는 창(언제 드시나요). 고른 개수가 곧 하루 횟수다 (2026-10-26 사용 의견:
       '하루 2번'이면 아침·저녁으로 정해져 아침·점심 약을 넣을 수 없었다). 부제는 o.subOf(고른 것)로 그린다 */
    var atLeast = (!need && o.atLeast > 0) ? o.atLeast : 0;
    var multi = need > 0 || atLeast > 0;
    var chosen = (o.values || []).slice(0);
    var one = o.value;
    var opener = null;                                  /* 창을 연 버튼 — 닫을 때 초점을 돌려준다 */
    try { opener = document.activeElement; } catch (eA) {}
    var dim = document.createElement('div');
    dim.className = 'pk-dim';
    dim.setAttribute('role', 'dialog');
    dim.setAttribute('aria-modal', 'true');
    dim.setAttribute('aria-label', o.title || '고르기');
    var sheet = document.createElement('div');
    sheet.className = 'pk-sheet';
    var h = document.createElement('div');
    h.className = 'pk-title';
    h.textContent = o.title || '';
    sheet.appendChild(h);
    /* 여럿 고르기(언제)에서는 부제에 고른 개수를 늘 보여 준다 — '3개 중 2개 고르셨어요' */
    var sbx = null, note = null;
    /* 하나만 고르는 창은 누르는 즉시 닫히므로, 그렇다는 것을 한 줄로 알려 드린다 */
    var subTxt = o.sub || (multi ? '' : '누르시면 바로 정해져요');
    if (subTxt || multi) {
      sbx = document.createElement('div');
      sbx.className = 'pk-sub';
      sbx.textContent = subTxt;
      sheet.appendChild(sbx);
    }
    if (multi) {
      note = document.createElement('p');
      note.className = 'pk-note';
      note.textContent = '다른 것을 고르시려면 하나를 먼저 빼 주세요.';
      note.hidden = true;
      sheet.appendChild(note);
    }
    var list = document.createElement('div');
    list.className = 'pk-list';
    var btns = [];
    o.items.forEach(function (it) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'pk-it';
      b.innerHTML = '<span class="pk-mk"></span><span class="pk-lb"></span>';
      $('.pk-lb', b).textContent = it.label;
      b.__v = it.v;
      b.addEventListener('click', function () {
        if (multi) {
          var at = chosen.indexOf(it.v);
          if (at > -1) chosen.splice(at, 1);
          else if (atLeast) chosen.push(it.v);
          /* 한 개만 고르는 창(하루 1번)은 누른 것으로 곧바로 바뀐다 — 고른 것이 하나뿐이라 무엇이 빠졌는지 바로 보인다 */
          else if (need === 1) chosen = [it.v];
          /* 둘 이상 고르는 창은 다 차면 더 켜지지 않는다 — 예전에는 먼저 고른 것을 말없이 밀어내서,
             아침이 빠진 줄 모르고 엉뚱한 시각이 저장되는 일이 있었다 */
          else if (chosen.length >= need) return toast(need + '개까지 고르실 수 있어요.\n하나를 먼저 빼 주세요.');
          else chosen.push(it.v);
        } else {
          /* 하나만 고르는 창(하루 몇 번·며칠분·어떤 약)은 누르는 즉시 그 값으로 정해지고 창이 닫힌다
             — '확인'을 한 번 더 누르지 않으셔도 된다 (0.9.2 사용 의견) */
          one = it.v;
          close();
          if (o.onPick) o.onPick(one);
          return;
        }
        paint();
      });
      btns.push(b);
      list.appendChild(b);
    });
    sheet.appendChild(list);
    function paint() {
      var full = multi && need > 1 && chosen.length >= need;
      btns.forEach(function (b) {
        var on = multi ? chosen.indexOf(b.__v) > -1 : b.__v === one;
        b.classList.toggle('on', on);
        $('.pk-mk', b).textContent = on ? '✓' : '';
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
        b.classList.toggle('is-lock', full && !on);          /* 다 찬 뒤 안 고른 줄은 흐리게 */
        b.setAttribute('aria-disabled', (full && !on) ? 'true' : 'false');
      });
      if (multi && sbx) {
        if (atLeast) {
          var srt = [];
          o.items.forEach(function (it) { if (chosen.indexOf(it.v) > -1) srt.push(it.v); });
          sbx.textContent = o.subOf ? o.subOf(srt) : (chosen.length + '개 고르셨어요');
        } else sbx.textContent = need + '개 중 ' + chosen.length + '개 고르셨어요';
      }
      if (note) note.hidden = !full;
    }
    paint();
    var acts = document.createElement('div');
    acts.className = 'pk-acts';
    var cancel = document.createElement('button');
    cancel.type = 'button'; cancel.className = 'pk-cancel'; cancel.textContent = '취소';
    var ok = document.createElement('button');
    ok.type = 'button'; ok.className = 'pk-ok'; ok.textContent = '확인';
    /* 여럿 고르는 창('언제')에만 '확인'을 둔다 — 하나만 고르는 창은 누르는 즉시 닫히므로 필요 없다 */
    acts.appendChild(cancel); if (multi) acts.appendChild(ok);
    sheet.appendChild(acts);
    dim.appendChild(sheet);
    function close() {
      if (dim.parentNode) dim.parentNode.removeChild(dim);
      document.documentElement.style.overflow = '';
      try { if (opener && opener.focus && document.body.contains(opener)) opener.focus(); } catch (eC) {}
    }
    cancel.addEventListener('click', close);
    dim.addEventListener('click', function (e) { if (e.target === dim) close(); });
    ok.addEventListener('click', function () {
      if (multi) {
        if (atLeast && chosen.length < atLeast) return toast('하나 이상 골라 주세요.');
        if (!atLeast && chosen.length !== need) return toast(need + '개를 골라 주세요.');
        var sorted = [];
        o.items.forEach(function (it) { if (chosen.indexOf(it.v) > -1) sorted.push(it.v); });
        close();
        o.onPick(sorted);
        return;
      }
      if (one === undefined || one === null || one === '') return toast('하나를 골라 주세요.');
      close();
      o.onPick(one);
    });
    document.documentElement.style.overflow = 'hidden';
    document.body.appendChild(dim);
    /* 화면 낭독기가 창이 열린 것을 읽도록 첫 항목으로 초점을 옮긴다 —
       이미 고른 것이 있으면 그 줄로(흐려진 줄에 먼저 닿지 않게) */
    try {
      var f0 = null;
      for (var fi = 0; fi < btns.length; fi++) { if (btns[fi].classList.contains('on')) { f0 = btns[fi]; break; } }
      (f0 || btns[0] || ok).focus();
    } catch (eF) {}
  }

  /* ── 언제(아침·점심·저녁·자기 전) ── 화면에는 '자기 전'으로 보이고, 저장은 예전처럼 '자기전'이다(55·56·알림이 쓰는 이름) */
  var WHEN_ITEMS = [['아침', '아침', '08:00'], ['점심', '점심', '13:00'], ['저녁', '저녁', '19:00'], ['자기전', '자기 전', '22:00']];
  function whenLabel(slot) {
    for (var i = 0; i < WHEN_ITEMS.length; i++) if (WHEN_ITEMS[i][0] === slot) return WHEN_ITEMS[i][1];
    return slot;
  }
  function whenText(list) {
    return (list || []).map(whenLabel).join('·');
  }
  function whenDefault(freq) {
    var plan = MED_SLOTS[freq];
    if (!plan) return [];
    return plan.map(function (p) { return p[1]; });
  }
  /* 실제 알림 시각 — 정해 둔 기본값(아침 8시·점심 1시·저녁 7시·자기 전 10시)을 그대로 쓴다.
     고른 조합이 그 횟수의 기본 조합이면 예전과 완전히 같은 시각이 된다. */
  function whenTime(freq, slot) {
    var plan = MED_SLOTS[freq] || [], i;
    for (i = 0; i < plan.length; i++) if (plan[i][1] === slot) return plan[i][2];
    for (i = 0; i < WHEN_ITEMS.length; i++) if (WHEN_ITEMS[i][0] === slot) return WHEN_ITEMS[i][2];
    return '';
  }
  var ROUTE_SHORT = { oral: '먹는 약', eye: '안약', skin: '연고', patch: '패치', inhale: '흡입', other: '기타' };
  function routeShort(r) { return ROUTE_SHORT[r] || '어떤 약?'; }
  /* 고르는 칩 값(oral·eye·skin·patch·other) — 흡입제는 '기타' 칸에 들어간다 */
  function routeChipVal(r) { return ROUTE.known(r) ? ROUTE.BY_CHIP[ROUTE.info(r).chip] : null; }
  var DAY_CHOICES = [3, 5, 7, 10, 14, 21, 28, 30, 60, 90];

  /* ── 54 사진에서 찾은 약 ──
     1단계: 어떤 약이 들어가는지 이름만 죽 보여주고 맞는지 묻는다.
     2단계: 약마다 하루 몇 번·언제·며칠분을 한 화면에서 고른다(모두 팝업).
     입력 중인 값은 localStorage(todak_ocr_meds)에 그때그때 저장한다 —
     '빠진 약 넣기'로 58 에 갔다 와도, 휴대폰 뒤로가기로 와도 읽어 둔 약이 사라지지 않게. */
  /* ── 등록 전 임시 저장 ── 예전에는 sessionStorage 였는데, 안드로이드가 WebView(그리기 부분)를
     정리하고 되살리면 통째로 비어 사진부터 다시 찍게 됐다. localStorage 로 옮기고 저장 시각을
     함께 적어 둔다. 지우는 때: ① 등록에 성공했을 때 ② 6시간이 지났을 때 ③ 로그아웃할 때
     ④ 약 등록 화면(53·54·58·59) 밖으로 나갔을 때(③④ 는 app.js).
     예전 판이 sessionStorage 에 남긴 값이 있으면 한 번은 그대로 옮겨 읽는다. */
  var OCR_KEY = 'todak_ocr_meds', OCR_AT = 'todak_ocr_meds_at', OCR_TTL = 6 * 60 * 60 * 1000;
  function pendClear() {
    try { localStorage.removeItem(OCR_KEY); localStorage.removeItem(OCR_AT); } catch (e) {}
    try { sessionStorage.removeItem(OCR_KEY); } catch (e1) {}
  }
  function pendSet(list) {
    try {
      localStorage.setItem(OCR_KEY, JSON.stringify(list || []));
      localStorage.setItem(OCR_AT, String(new Date().getTime()));
    } catch (e) {}
    try { sessionStorage.removeItem(OCR_KEY); } catch (e1) {}
  }
  function pendGet() {
    var raw = null, at = 0;
    try { raw = localStorage.getItem(OCR_KEY); at = parseInt(localStorage.getItem(OCR_AT), 10) || 0; } catch (e) {}
    if (raw === null) {                                   /* 예전 판(sessionStorage)에서 옮겨 오기 */
      try { raw = sessionStorage.getItem(OCR_KEY); } catch (e1) {}
      if (raw === null) return [];
      at = new Date().getTime();
      try { localStorage.setItem(OCR_KEY, raw); localStorage.setItem(OCR_AT, String(at)); } catch (e2) {}
      try { sessionStorage.removeItem(OCR_KEY); } catch (e3) {}
    }
    if (at && (new Date().getTime() - at) > OCR_TTL) { pendClear(); return []; }
    var list = null;
    try { list = JSON.parse(raw || '[]'); } catch (e4) { list = null; }
    return (list instanceof Array) ? list : [];
  }
  function page54() {
    var meds = pendGet();
    var s1 = $('[data-step="1"]'), s2 = $('[data-step="2"]');
    var listBox = $('[data-role="med-list"]'), detBox = $('[data-role="det-list"]');
    var foot1 = $('[data-foot="1"]'), foot2 = $('[data-foot="2"]');
    var btnNext = $('[data-act="step2"]'), btnSave = $('[data-act="save"]');
    if (!s1 || !s2 || !listBox || !detBox || !foot1 || !foot2 || !btnNext || !btnSave) return;
    if (!meds.length) { toast('사진에서 읽은 약이 없어요.'); location.replace('53-med-scan.html'); return; }

    var rowT = $('.medrow', listBox).cloneNode(true);
    var detT = $('.detrow', detBox).cloneNode(true);
    detT.className = 'detrow';
    var injNote = $('[data-role="inj-note"]');
    var s2Note = $('[data-role="s2-note"]');
    var head = $('#found-msg'), s2Title = $('[data-role="s2-title"]');

    function store() { pendSet(meds); }
    function picked() { return meds.filter(function (m) { return !m.__off && !m.__drop; }); }
    /* 목록에 보여 줄 약 — 약 목록에 없어 뺀 줄(__drop)은 아래 접힌 칸에 따로 둔다 */
    function kept() { return meds.filter(function (m) { return !m.__drop; }); }

    meds.forEach(function (m) {
      /* 약 목록과 맞춰 둔 줄은 심평원 투여경로를 먼저 믿는다(1순위) — 이름의 제형 꼬리는 2순위 */
      var hr = m.hira ? ROUTE.fromHira({ name: m.name, routeKey: m.hira.routeKey, meftDivNo: m.hira.meftDivNo }) : null;
      var hrOk = !!(hr && ROUTE.known(hr.route));
      m.__inj = hr ? !!hr.injection : (m.kind === 'injection');   /* 이름에서 짐작한 것이라 열 때마다 다시 본다 */
      if (m.__init) return;
      m.__init = 1;
      m.__route = hrOk ? hr.route : ROUTE.fromKind(m.kind);
      m.__routeBy = hrOk ? 'hira' : (m.__route === 'unknown' ? '' : 'form');
      /* 병원에서 맞는 주사약과, 약 목록에 없어 빼 둔 줄은 기본으로 빼 둔다 */
      m.__off = (m.__inj || m.__drop) ? 1 : 0;
      m.__freq = slotCount(m) || 0;                       /* 0 = 사진에서 못 읽음 */
      m.__days = m.days || 0;
      m.__when = m.__freq ? whenDefault(m.__freq) : [];
    });
    store();

    /* ── 이름 고치기 ── 봉투에는 이름이 16자에서 잘려 찍히기도 한다.
       이름을 누르면 고칠 칸이 열리고, 적은 글자로 식약처 허가정보를 찾아 고를 수 있다. */
    var fixBox = null, fixTimer = null, fixSeq = 0;
    function closeFix() {
      if (fixBox && fixBox.parentNode) fixBox.parentNode.removeChild(fixBox);
      fixBox = null;
    }
    function openFix(m, row, after) {
      var open = fixBox && fixBox.__row === row;
      closeFix();
      if (open) return;
      var canSearch = !!(T.drug && T.drug.search && (window.TODAK_CONFIG || {}).fnBase);
      fixBox = document.createElement('div');
      fixBox.__row = row;
      fixBox.className = 'card card--flat';
      fixBox.setAttribute('style', 'border:1px solid var(--outline); padding:12px; flex:0 0 auto;');
      fixBox.innerHTML = '<input class="input" type="text" aria-label="약 이름 고치기">'
        + '<p class="tiny muted" style="margin-top:6px;"></p>'
        + '<div data-sug></div>'
        + '<div class="row" style="gap:8px; margin-top:10px;">'
        + '<button type="button" class="btn btn-primary btn-sm" data-act="use">이 이름으로 쓰기</button>'
        + '<button type="button" class="btn btn-sm" data-act="close">닫기</button></div>';
      var inp = $('input', fixBox), note = $('p', fixBox), sugBox = $('[data-sug]', fixBox);
      inp.value = m.name;
      var picks = (m.__pick && m.__pick.length) ? m.__pick : null;
      note.textContent = picks ? '이 가운데 봉투와 같은 이름을 골라 주세요. 없으면 이름을 고쳐 찾으셔도 돼요.'
        : canSearch ? '두 글자만 쓰셔도 비슷한 약을 찾아 드려요.' : '약 봉투에 적힌 이름대로 고쳐 주세요.';
      function applyName(nm, hira) {
        nm = String(nm || '').trim();
        if (!nm) return;
        m.name = nm;
        /* 목록에서 고른 이름이면 투여경로 근거도 함께 남긴다 — 화면을 다시 열어도 그대로 쓴다 */
        if (hira) { m.hira = { routeKey: hira.routeKey || '', meftDivNo: hira.meftDivNo || '', seq: hira.seq || '' }; m.chk = 1; }
        else m.hira = null;
        m.__namechk = 0;                          /* 환자분이 직접 보고 고르신 이름이라 '확인 필요'를 뗀다 */
        m.__pick = null;                          /* 고르셨으니 '고르기'도 뗀다 */
        if (m.__routeBy !== 'user') {
          var hr = hira ? ROUTE.fromHira(hira) : null;
          if (hr) {
            m.__route = hr.route;
            m.__routeBy = ROUTE.known(hr.route) ? 'hira' : '';
            m.__inj = !!hr.injection;
          } else {
            var k = OCRP.formKind(OCRP.stripDose(nm));
            m.__inj = k === 'injection';
            m.__route = ROUTE.fromKind(k);
            m.__routeBy = m.__route === 'unknown' ? '' : 'form';
          }
        }
        store();
        renderNameChk();
        renderPick();
        if (after) after();
      }
      function render(list, msg) {
        sugBox.innerHTML = '';
        if (!list.length) {
          if (!msg) return;
          var p = document.createElement('p');
          p.className = 'tiny muted'; p.style.marginTop = '6px'; p.textContent = msg;
          sugBox.appendChild(p);
          return;
        }
        list.forEach(function (d, j) {
          var li = document.createElement('div');
          li.className = 'listitem';
          li.setAttribute('style', 'margin-top:' + (j ? '6' : '8') + 'px; cursor:pointer;');
          li.innerHTML = '<span class="li-ic">💊</span><div class="li-body"><div class="li-title"></div>'
            + '<div class="li-sub"></div></div>';
          $('.li-title', li).textContent = d.name;
          /* ── 2026-09-27 ── 이름만 보여 주면 성분이 전혀 다른 약을 가릴 수 없다.
             성분과 만든 곳을 함께 적어 봉투와 견주실 수 있게 한다. */
          var sub = [];
          if (d.ing) sub.push(d.ing);
          if (d.entp) sub.push(d.entp);
          $('.li-sub', li).textContent = sub.length ? (sub.join(' · ') + ' — 눌러서 이 이름으로 바꾸기') : '눌러서 이 이름으로 바꾸기';
          li.addEventListener('click', function (ev) { ev.stopPropagation(); applyName(d.name, d); closeFix(); });
          sugBox.appendChild(li);
        });
      }
      function search() {
        if (!canSearch) return;
        var q = inp.value.trim();
        if (q.length < 2) { render([]); return; }
        var my = ++fixSeq;
        T.drug.search(q).then(function (res) {
          if (my !== fixSeq || !fixBox) return;
          var seenN = {}, list = [];
          /* 3개만 보이던 것을 5개로 — 같은 이름이 여러 개인 약은 앞 세 줄이 어린이용·복합제로 차 버린다 */
          (res.items || []).forEach(function (d) {
            if (d.name && !seenN[d.name] && list.length < 5) { seenN[d.name] = 1; list.push(d); }
          });
          render(list, res.note || '');
        });
      }
      /* 대조에서 똑같이 그럴듯했던 이름들을 먼저 보여 준다 — 글자를 다시 치지 않으셔도 되게 */
      if (picks) render(picks, '');
      inp.addEventListener('input', function () { clearTimeout(fixTimer); fixTimer = setTimeout(search, 350); });
      $('[data-act="use"]', fixBox).addEventListener('click', function () {
        if (!inp.value.trim()) return toast('약 이름을 적어 주세요.');
        applyName(inp.value, null);
        closeFix();
      });
      $('[data-act="close"]', fixBox).addEventListener('click', closeFix);
      row.parentNode.insertBefore(fixBox, row.nextSibling);
      if (!picks) search();
    }

    /* ── 1단계 ── */
    function paintHead() {
      var n = picked().length;
      var all = kept().length;
      var outs = meds.filter(function (m) { return m.__drop; }).length;
      var manual = meds.filter(function (m) { return m.__manual; }).length;
      /* 모두 빠져 목록이 비면 '사진에서 약 0개를 찾았어요'와 바로 아래 접은 칸('…없어 뺐어요 7개')이 서로 어긋난다.
         그때는 무엇을 하시면 되는지(펼쳐서 되살리기)를 머리말에서 바로 알려 드린다. */
      if (head) head.textContent = (!all && outs)
        ? ('사진에서 읽은 ' + outs + '개가 약 목록에 없어 아래에 접어 두었어요 — 펼쳐서 되살릴 수 있어요')
        : (manual ? ('등록할 약 ' + all + '개예요') : ('사진에서 약 ' + all + '개를 찾았어요'));
      if (injNote) injNote.hidden = !kept().filter(function (m) { return m.__inj; }).length;
      btnSave.textContent = '약 ' + n + '개 등록하기';
      if (s2Title) s2Title.textContent = '약마다 하루 몇 번·언제 쓰시는지 골라 주세요';
    }
    /* ── 약 목록에 없어 뺀 줄 ── 2026-09-20 교수님 피드백
       인쇄물의 생김새 설명('무색 내지 미황색 현탁액')이 약 이름으로 읽히는 일이 잦다.
       조용히 지우지 않고 몇 개를 뺐는지 접어서 보여 주고, 누르면 되살릴 수 있게 한다. */
    var dropBox = null, chkNote = null;
    function renderDrop() {
      var outs = meds.filter(function (m) { return m.__drop; });
      if (!dropBox) {
        dropBox = document.createElement('details');
        dropBox.className = 'card card--flat';
        dropBox.setAttribute('style', 'padding:4px 14px 12px; border:1px solid var(--outline);');
        dropBox.innerHTML = '<summary style="font-size:14px; line-height:1.6; padding:13px 0; min-height:44px; cursor:pointer; word-break:keep-all;"></summary>'
          + '<p class="tiny muted" style="margin:2px 0 8px; line-height:1.6; word-break:keep-all;">'
          + '약 봉투에 적힌 <b>생김새 설명</b>이거나 잘못 읽힌 글자일 수 있어요. 진짜 드시는 약이면 <b>되살리기</b>를 눌러 주세요.</p>'
          + '<div data-role="drop-list"></div>';
        listBox.parentNode.insertBefore(dropBox, listBox.nextSibling);
      }
      dropBox.hidden = !outs.length;
      if (!outs.length) return;
      /* 위 목록이 하나도 남지 않았다면 접어 두지 않는다 — 펼쳐야 되살릴 수 있다는 것을 바로 보실 수 있게 */
      if (!kept().length) dropBox.open = true;
      $('summary', dropBox).textContent = '사진에서 읽었지만 약 목록에 없어 뺐어요 ' + outs.length + '개 · 보기';
      var box = $('[data-role="drop-list"]', dropBox);
      box.innerHTML = '';
      outs.forEach(function (m) {
        var row = document.createElement('div');
        row.className = 'row';
        row.setAttribute('style', 'gap:8px; margin-top:8px;');
        var nm = document.createElement('span');
        nm.className = 'grow';
        nm.setAttribute('style', 'font-size:14px; line-height:1.6; word-break:keep-all;');
        nm.textContent = m.name;
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn btn-sm';
        btn.setAttribute('style', 'flex:0 0 auto; min-height:44px;');
        btn.textContent = '되살리기';
        btn.setAttribute('aria-label', m.name + ' 다시 목록에 넣기');
        btn.addEventListener('click', function () {
          m.__drop = 0; m.__off = 0;
          store(); renderList();
          toast('「' + m.name + '」' + josaK(m.name, '을', '를') + ' 다시 넣었어요.\n이름이 다르면 눌러서 고쳐 주세요.');
        });
        row.appendChild(nm); row.appendChild(btn);
        box.appendChild(row);
      });
    }
    /* 목록의 이름과 글자까지 똑같지는 않아 고쳐 쓴 약이 있으면 한 줄 알린다 — 이웃 약(다른 제품)일 수 있다 */
    var nameNote = null;
    function renderNameChk() {
      var nc = meds.filter(function (m) { return m.__namechk && !m.__drop; }).length;
      if (!nameNote) {
        nameNote = document.createElement('p');
        nameNote.className = 'tiny muted';
        nameNote.setAttribute('style', 'line-height:1.6; word-break:keep-all;');
        nameNote.innerHTML = '비슷한 이름으로 고쳐 본 약이 있어요 — <b>「확인 필요」</b>가 붙은 이름을 눌러 봉투와 같은지 봐 주세요.';
        listBox.parentNode.insertBefore(nameNote, listBox);
      }
      nameNote.hidden = !nc;
    }
    /* ── 비슷한 이름이 여럿이라 고르지 못한 약 ── 2026-09-27
       조용히 하나를 골라 넣지 않는다. 그 후보를 그대로 들고 와 환자분이 고르시게 한다. */
    var pickNote = null;
    function renderPick() {
      var np = meds.filter(function (m) { return m.__pick && m.__pick.length && !m.__drop && !m.__off; }).length;
      if (!pickNote) {
        pickNote = document.createElement('p');
        pickNote.className = 'tiny muted';
        pickNote.setAttribute('style', 'line-height:1.6; word-break:keep-all;');
        pickNote.innerHTML = '<b>「고르기」</b>가 붙은 약은 이름이 비슷한 약이 여럿이에요. '
          + '눌러서 봉투와 같은 이름을 골라 주세요.';
        listBox.parentNode.insertBefore(pickNote, listBox);
      }
      pickNote.hidden = !np;
    }
    /* 대조를 못 했을 때만 한 줄 알린다 — 사진에서 읽은 그대로라는 뜻 */
    function renderChk() {
      var un = meds.filter(function (m) { return !m.__manual && !m.chk; }).length;
      if (!chkNote) {
        chkNote = document.createElement('p');
        chkNote.className = 'tiny muted';
        chkNote.setAttribute('style', 'line-height:1.6; word-break:keep-all;');
        chkNote.innerHTML = '지금은 <b>약 목록과 맞춰 보지 못했어요</b> — 사진에서 읽은 그대로 보여 드려요. 이름이 다르면 눌러서 고쳐 주세요.';
        listBox.parentNode.insertBefore(chkNote, listBox);
      }
      chkNote.hidden = !un;
    }
    function renderList() {
      closeFix();
      listBox.innerHTML = '';
      kept().forEach(function (m) {
        var row = rowT.cloneNode(true);
        var box = $('.mr-box', row), nameB = $('.mr-name', row), delB = $('.mr-del', row);
        /* 목록의 이름과 글자까지 똑같지는 않아 고쳐 쓴 약에는 '확인 필요'를 붙인다 —
           이웃 약(성분이 다른 별개 제품)으로 조용히 바뀌지 않게 눌러서 확인하실 수 있다. */
        var chkB = document.createElement('span');
        chkB.className = 'dr-need';
        chkB.setAttribute('style', 'flex:0 0 auto; font-size:13px; font-weight:700; white-space:nowrap;'
          + ' line-height:1.3; color:var(--primary-dark); background:var(--primary-tint);'
          + ' border:1px solid var(--primary-light); border-radius:var(--r-pill); padding:2px 9px;');
        chkB.textContent = '확인 필요';
        row.insertBefore(chkB, delB);
        function paint() {
          row.classList.toggle('is-off', !!m.__off);
          box.textContent = m.__off ? '' : '✓';
          nameB.textContent = m.name;
          var pk = !!(m.__pick && m.__pick.length);
          chkB.hidden = !(m.__namechk || pk);
          chkB.textContent = pk ? '고르기' : '확인 필요';
          nameB.setAttribute('aria-label', m.name
            + (pk ? ' — 비슷한 이름이 여럿이에요. 눌러서 고르기'
                  : m.__namechk ? ' — 이름 확인이 필요해요. 눌러서 고치기' : ' — 눌러서 이름 고치기'));
          delB.textContent = m.__off ? '되돌리기' : '빼기';
          delB.setAttribute('aria-label', m.name + (m.__off ? ' 되돌리기' : ' 목록에서 빼기'));
        }
        paint();
        delB.addEventListener('click', function () {
          m.__off = m.__off ? 0 : 1;
          store(); paint(); paintHead();
          toast(m.__off ? ('「' + m.name + '」' + josaK(m.name, '을', '를') + ' 뺐어요.\n되돌리기를 누르면 다시 들어가요.')
                        : ('「' + m.name + '」' + josaK(m.name, '을', '를') + ' 다시 넣었어요.'));
        });
        nameB.addEventListener('click', function () { openFix(m, row, paint); });
        listBox.appendChild(row);
      });
      renderNameChk();
      renderPick();
      renderChk();
      renderDrop();
      paintHead();
    }

    /* ── 2단계 ── */
    /* 봉투에 용법이 적혀 있지 않은 약은 식약처 용법용량에서 하루 횟수를 받아 채운다.
       한 화면에 많아야 6개만 물어보고(느려지지 않게), 못 찾으면 비워 둔 채로 둔다. */
    var docLeft = 6;
    function askDoc(m, paint) {
      if (docLeft <= 0 || m.__docAsked || m.__freq) return;
      if (!m.hira || !m.hira.seq) return;
      m.__docAsked = 1;
      docLeft--;
      MFDS.doc(m.hira.seq).then(function (d) {
        if (!d || m.__freq) return;                  /* 그 사이 환자분이 고르셨으면 건드리지 않는다 */
        var n = MFDS.freqOf(d.ud, m.name);
        if (!n) return;
        m.__freq = n;
        m.__when = whenDefault(n);
        m.__freqBy = 'mfds';
        store();
        paint();
      }, function () { /* 못 받아도 화면은 그대로 — 비워 둔다 */ });
    }
    function renderDet() {
      detBox.innerHTML = '';
      picked().forEach(function (m) {
        var row = detT.cloneNode(true);
        var top = $('.dr-top', row);
        var nm = $('.dr-name', row);
        var rt = $('.pickbtn[data-k="route"]', row);
        var bf = $('.pickbtn[data-k="freq"]', row);
        var bw = $('.pickbtn[data-k="when"]', row);
        var bd = $('.pickbtn[data-k="days"]', row);
        var need = document.createElement('span');
        need.className = 'dr-need';
        need.textContent = '확인 필요';
        top.insertBefore(need, rt);
        /* 약 종류를 이미 아는 줄은 버튼 대신 작은 글자로만 보여 준다 —
           버튼(44px)이 첫 줄 높이를 혼자 끌어올려 약이 5개만 돼도 마지막 줄이 아래 버튼 띠에 가렸다.
           '확인 필요'(모르는) 줄에서만 누를 수 있는 버튼으로 띄운다. */
        var rtxt = $('.dr-route', row);
        if (!rtxt) {                                    /* 시안이 옛 모양이면 만들어 붙인다 */
          rtxt = document.createElement('span');
          rtxt.className = 'dr-route';
          top.insertBefore(rtxt, rt);
        }
        nm.textContent = m.name;
        /* 식약처 용법을 참고해 채운 칸임을 작게 알린다 — 환자분이 고치실 수 있게 */
        var docNote = document.createElement('p');
        docNote.className = 'tiny muted';
        docNote.setAttribute('style', 'margin:6px 0 0; line-height:1.6; word-break:keep-all;');
        docNote.textContent = '식약처 용법 참고 — 하루 횟수를 넣어 뒀어요. 다르면 눌러서 고쳐 주세요.';
        docNote.hidden = true;
        row.appendChild(docNote);
        function paint() {
          docNote.hidden = !(m.__freqBy === 'mfds' && m.__freq);
          var noR = !ROUTE.known(m.__route);
          var noF = !m.__freq;
          var noW = m.__freq !== 'prn' && !(m.__when && m.__when.length);
          rt.hidden = !noR;
          rtxt.hidden = noR;
          rt.className = 'pickbtn pb-route' + (noR ? ' is-empty' : '');
          if (noR) {
            rt.textContent = routeShort(m.__route) + ' ▾';
            rt.setAttribute('aria-label', m.name + ' 어떤 약인가요');
          } else {
            rtxt.textContent = routeShort(m.__route);
          }
          bf.textContent = (noF ? '하루 몇 번?' : (m.__freq === 'prn' ? '필요할 때' : '하루 ' + m.__freq + '번')) + ' ▾';
          bf.className = 'pickbtn' + (noF ? ' is-empty' : '');
          bf.setAttribute('aria-label', m.name + ' 하루 몇 번');
          if (m.__freq === 'prn') {
            bw.textContent = '알림 없음';
            bw.className = 'pickbtn is-off';
          } else {
            bw.textContent = (noW ? '언제?' : whenText(m.__when)) + ' ▾';
            bw.className = 'pickbtn' + (noW ? ' is-empty' : '');
          }
          bw.setAttribute('aria-label', m.name + ' 언제');
          bd.textContent = (m.__days ? m.__days + '일분' : '며칠분?') + ' ▾';
          bd.className = 'pickbtn';
          bd.setAttribute('aria-label', m.name + ' 며칠분');
          row.classList.toggle('need', noR || noF || noW);
          need.hidden = !(noR || noF || noW);
        }
        paint();
        askDoc(m, paint);
        rt.addEventListener('click', function () {
          pickOpen({
            title: '「' + m.name + '」' + josaK(m.name, '은', '는') + ' 어떤 약인가요?',
            items: ROUTE.CHIPS.map(function (lb) { return { v: ROUTE.BY_CHIP[lb], label: lb }; }),
            value: routeChipVal(m.__route),
            onPick: function (v) {
              /* '기타'로 보이던 흡입제는 그대로 둔다 */
              if (routeChipVal(m.__route) === v) v = m.__route;
              m.__route = v; m.__routeBy = 'user';
              store(); paint();
            }
          });
        });
        /* ── 하루 몇 번 → 언제 → 며칠분 을 이어서 연다 (2026-10-26 사용 의견) ──
           봉투에서 못 읽은 약은 세 칸을 하나씩 다시 눌러야 했다. '하루 몇 번'을 고르면 '언제' 창이, 그것을 고르면
           '며칠분' 창이 바로 이어서 뜬다(넣으실 가능성이 커지게). 중간에 '취소'를 누르시면 거기서 멈춘다.
           '언제'나 '며칠분'을 따로 누르시면 그 창 하나만 뜬다. */
        function chainNext(fn) { if (fn) setTimeout(fn, 160); }
        function openWhen(next) {
          if (m.__freq === 'prn') return toast('필요할 때만 쓰는 약이라 알림 시간은 없어요.\n정해진 시간이 있으면 ‘필요할 때’를 눌러 바꿔 주세요.');
          var ri = ROUTE.info(m.__route);
          /* 언제 — 개수를 정해 두지 않고 드시는 시간을 모두 고르게 한다. 고른 개수가 하루 횟수가 된다 (2026-10-26 사용 의견:
             '하루 2번'이면 아침·저녁으로 정해져 아침·점심 약을 넣으려면 개수부터 맞춰야 했다. 58 직접 입력과 같은 방식) */
          pickOpen({
            title: '「' + m.name + '」 언제 ' + ri.go.replace('세요', '시나요') + '?',
            items: WHEN_ITEMS.map(function (w) { return { v: w[0], label: w[1] }; }),
            values: m.__when || [],
            atLeast: 1,
            subOf: function (v) { return v.length ? '하루 ' + v.length + '번 · ' + whenText(v) : ri.how.replace('는지', '는 시간') + '을 모두 골라 주세요'; },
            onPick: function (v) {
              m.__when = v;
              m.__freq = v.length;
              m.__freqBy = 'user';                  /* 환자분이 고르셨으니 '식약처 용법 참고'는 뗀다 */
              store(); paint();
              chainNext(next);
            }
          });
        }
        function openDays(next) {
          var items = [{ v: 0, label: '모르겠어요' }], seen = {};
          if (m.__days && DAY_CHOICES.indexOf(m.__days) < 0) { items.push({ v: m.__days, label: m.__days + '일분' }); seen[m.__days] = 1; }
          DAY_CHOICES.forEach(function (d) { if (!seen[d]) items.push({ v: d, label: d + '일분' }); });
          pickOpen({
            title: '「' + m.name + '」 며칠분인가요?',
            sub: '모르시면 그냥 두셔도 돼요',
            items: items,
            value: m.__days || 0,
            onPick: function (v) { m.__days = v; store(); paint(); chainNext(next); }
          });
        }
        bf.addEventListener('click', function () {
          pickOpen({
            title: '「' + m.name + '」' + josaK(m.name, '은', '는') + ' 하루 몇 번인가요?',
            items: [{ v: 1, label: '하루 1번' }, { v: 2, label: '하루 2번' }, { v: 3, label: '하루 3번' },
                    { v: 4, label: '하루 4번' }, { v: 'prn', label: '필요할 때만' }],
            value: m.__freq || null,
            onPick: function (v) {
              m.__freq = v;
              m.__freqBy = 'user';                  /* 환자분이 고르셨으니 '식약처 용법 참고'는 뗀다 */
              m.__when = (v === 'prn') ? [] : whenDefault(v);
              store(); paint();
              /* 필요할 때만 쓰는 약은 '언제'가 없다 — 며칠분으로 바로 */
              if (v === 'prn') chainNext(function () { openDays(); });
              else chainNext(function () { openWhen(function () { openDays(); }); });
            }
          });
        });
        bw.addEventListener('click', function () { openWhen(); });
        bd.addEventListener('click', function () { openDays(); });
        detBox.appendChild(row);
      });
      /* 약이 많으면 맨 아래 안내를 감춘다 — 그 두 줄이 마지막 약을 버튼 띠 아래로 밀어냈다 */
      if (s2Note) s2Note.hidden = picked().length >= 5;
    }

    /* ── 단계 넘기기 ── 앱바 ‹ 와 휴대폰 뒤로가기(앱바 ‹ 를 누른다)는 2단계에서 1단계로 돌아간다 */
    function show(step) {
      closeFix();
      s1.hidden = step !== 1;
      s2.hidden = step !== 2;
      foot1.hidden = step !== 1;
      foot2.hidden = step !== 2;
      var c = $('.content');
      if (c) c.scrollTop = 0;
    }
    var backA = $('.appbar a.back');
    if (backA) backA.addEventListener('click', function (e) {
      if (s2.hidden) return;
      e.preventDefault();
      e.stopPropagation();
      show(1);
    });
    btnNext.addEventListener('click', function (e) {
      e.preventDefault();
      if (!picked().length) return toast('등록할 약을 하나 이상 남겨 주세요.');
      renderDet();
      paintHead();
      show(2);
    });

    btnSave.addEventListener('click', function (e) {
      e.preventDefault();
      if (btnSave.__busy) return;
      var list = picked();
      if (!list.length) { show(1); return toast('등록할 약을 하나 이상 남겨 주세요.'); }
      var bad = list.filter(function (m) {
        return !ROUTE.known(m.__route) || !m.__freq || (m.__freq !== 'prn' && !(m.__when && m.__when.length));
      })[0];
      if (bad) {
        toast('「' + bad.name + '」의 빈 칸을 눌러 골라 주세요.');
        var rows = $$('.detrow.need', detBox);
        if (rows.length) { try { rows[0].scrollIntoView({ block: 'center' }); } catch (e1) {} }
        return;
      }
      T.busy(btnSave, true, '등록 중…');
      (T.withSession || function (cb) {
        sb.auth.getSession().then(function (r) {
          cb((r && r.data && r.data.session) || null, (r && r.error) || null);
        }, function (e) { cb(null, e || true); });
      })(function (ses, err) {
        if (!ses) {
          /* 세션 확인이 연결 문제로 실패했다 — 로그아웃이 아니다. 01-splash 로 내보내면
             app.js 첫머리가 todak_ocr_meds 를 지워 사진으로 읽은 약이 전부 사라진다.
             단추를 풀어 드려 같은 화면에서 다시 누르실 수 있게 한다. (2026-09-28) */
          if (err) {
            if (T.sessOffline) T.sessOffline(btnSave);
            else { T.busy(btnSave, false); toast('연결이 원활하지 않아요. 잠시 후 다시 시도해 주세요.'); }
            return;
          }
          T.busy(btnSave, false); location.replace('01-splash.html'); return;
        }
        var id = ses.user.id;
        var rowsToSave = list.map(function (m) {
          var slots = [], times = {};
          if (m.__freq === 'prn') slots = ['필요시'];
          else {
            slots = m.__when.slice(0);
            slots.forEach(function (s) { var tm = whenTime(m.__freq, s); if (tm) times[s] = tm; });
          }
          var sch = {
            freq: FREQ_LABEL[m.__freq] || '하루 1번',
            slots: slots,
            times: times,
            route: m.__route,                        /* oral|eye|skin|patch|inhale|other */
            route_by: m.__routeBy || 'user'          /* hira|form|user */
          };
          /* 하루 횟수를 식약처 용법용량에서 채워 드렸다면 그 근거도 남긴다(환자분이 고치면 'user') */
          if (m.__freqBy) sch.freq_by = m.__freqBy;  /* mfds|user */
          if (m.__days > 0) {
            sch.days = m.__days;                     /* 며칠분 받아왔는지 */
            sch.startedOn = ymdLocal(new Date());    /* 오늘부터 세어 떨어질 날을 계산한다 */
          }
          return { user_id: id, name: m.name, source: m.__manual ? 'manual' : 'ocr', schedule: sch };
        });
        /* ── 이미 넣어 두신 약과 겹치는지 한 번 본다 ── 2026-09-27
           같은 봉투를 두 번 찍으시면 같은 약이 두 줄이 됐다. 사진 한 장 안에서의 겹침은
           심평원 목록과 맞춰 합치지만(HIRA.reconcile), 예전에 등록해 두신 약과는 견주지 않았다.
           단정하지 않고 한 번만 여쭙는다 — 용량이 다른 같은 계열 약을 함께 쓰시는 분도 계신다.
           목록을 못 불러와도 등록은 막지 않는다. */
        var TW = T.medTwin;
        if (btnSave.__twinOk || !TW) { btnSave.__twinOk = 0; return saveRows(rowsToSave, []); }
        sb.from('medications').select('id,name,schedule').eq('active', true).then(function (rd) {
          var haveRows = (rd && !rd.error) ? (rd.data || []) : null;
          var have = haveRows ? haveRows.map(function (x) { return x.name; }) : null;
          /* 이름이 똑같은 약 — 새로 처방받아 오신 것인지 먼저 여쭙는다(features.js '새로 받아 온 약').
             '새로 받아 왔어요'면 그 약들은 새 줄 없이 며칠분만 오늘부터 다시 세고, 나머지만 새로 넣는다 */
          var refills = [];
          if (haveRows && TW.same) {
            rowsToSave.forEach(function (r0) {
              var old = TW.same(r0.name, haveRows);
              if (old && !refills.some(function (x) { return x.med.id === old.id; })) refills.push({ row: r0, med: old });
            });
          }
          if (refills.length && TW.refillAsk) {
            T.busy(btnSave, false);
            return TW.refillAsk({ names: refills.map(function (x) { return x.med.name; }),
              onRefill: function () {
                T.busy(btnSave, true, '등록 중…');
                var rest = rowsToSave.filter(function (r0) { return !refills.some(function (x) { return x.row === r0; }); });
                saveRows(rest, refills);
              },
              onSeparate: function () { btnSave.__twinOk = 1; btnSave.click(); } });
          }
          var hits = [];
          if (have) {
            rowsToSave.forEach(function (r0) {
              var tw = TW.find(r0.name, have);
              if (tw) hits.push(tw);
            });
          }
          if (!hits.length) return saveRows(rowsToSave, []);
          T.busy(btnSave, false);
          hits[0].more = hits.length - 1;
          TW.ask(hits[0], function () { btnSave.__twinOk = 1; btnSave.click(); });
        }, function () { saveRows(rowsToSave, []); });

        /* rows 는 새로 넣을 줄, refills 는 며칠분만 다시 셀 약({ row, med }) */
        function saveRows(rows, refills) {
          var jobs = refills.map(function (x) {
            return sb.from('medications').update({ schedule: TW.refillSchedule(x.med.schedule, (x.row.schedule || {}).days) }).eq('id', x.med.id);
          });
          if (rows.length) jobs.push(sb.from('medications').insert(rows));
          Promise.all(jobs).then(function (rs) {
            var bad = rs.filter(function (r) { return r && r.error; })[0];
            if (bad) { T.busy(btnSave, false); return toast(koError(bad.error)); }
            toast(refills.length && rows.length ? '약 ' + rows.length + '개를 추가하고, 새로 받아 온 약 ' + refills.length + '개는 며칠분을 다시 셀게요'
              : refills.length ? '새로 받아 온 약 ' + refills.length + '개의 며칠분을 오늘부터 다시 셀게요'
              : '약 ' + rows.length + '개를 추가했어요');
            try { localStorage.setItem('todak_med_added_at', new Date().toISOString()); } catch (eM) {}   /* 홈 '진료 뒤 새 약' 여쭙기가 멈추게 */
            pendClear();
            var onboard = false;
            try { onboard = !!(sessionStorage.getItem('todak_onboard') || sessionStorage.getItem('todak_edit')); } catch (e3) {}
            var dest = onboard ? '04-treatment.html' : '55-med-today.html';
            /* 새 약의 복약 알림을 예약한 뒤에 넘어간다 — 먼저 넘어가면 예약이 도중에 끊겨 새 약 알림이 걸리지 않았다.
               오래 걸리면 2초 뒤에 넘어가고, 55 가 들어올 때 다시 맞춘다 */
            var moved = false;
            var go = function () { if (moved) return; moved = true; location.href = dest; };
            var safety = setTimeout(go, 2000);
            notifySync(function (st) {
              /* 권한이 꺼져 있으면(58 과 같게) '추가했어요'를 잠깐 보인 뒤 설정 방법을 알리고 넘어간다 */
              if (st && st !== 'ok' && !(st === 'unsupported' && isNative) && !moved) {
                clearTimeout(safety);
                setTimeout(function () { deniedToast(st); setTimeout(go, 1500); }, 800);
              } else go();
            });
          }, function (err) { T.busy(btnSave, false); toast(koError(err)); });
        }
      });
    });

    renderList();
    show(1);
  }

  /* ── 당겨서 새로고침 — 홈·데이터 화면 (버그로 화면이 안 바뀌었을 때 손으로 복구) ── */
  var PTR_PAGES = {
    '05-home.html': 1, '16-checkin.html': 1, '55-med-today.html': 1, '56-med-schedule.html': 1,
    '73-cycle-setup.html': 1, '98-checkin-month.html': 1, '21-chat-history.html': 1,
    '10-consult-questions.html': 1, '77-visit-report.html': 1, '20-notifications.html': 1
  };
  function bindPTR() {
    var scroller = $('.content') || $('.screen');
    if (!scroller) return;
    var startY = null, armed = false, ind = null;
    function indicator() {
      if (ind) return ind;
      ind = document.createElement('div');
      ind.style.cssText = 'position:fixed;top:calc(8px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);' +
        'z-index:9999;background:var(--white);border:1px solid var(--outline);border-radius:999px;' +
        'padding:8px 16px;font-size:12.5px;font-weight:700;color:var(--primary-dark);box-shadow:0 4px 14px rgba(0,0,0,.12);display:none;';
      document.body.appendChild(ind);
      return ind;
    }
    /* 창(약 목록 고치기·고르기·시간·여쭙는 창)이 떠 있거나, 화면 안쪽의 따로 굴러가는 칸에서 시작한 손짓은 새로고침으로 치지 않는다.
       2026-10-26 사용 의견 — 56·55 에서 '약 목록 고치기' 창의 약을 아래로 끌거나 목록을 빠르게 밀면
       뒤 화면이 맨 위(scrollTop 0)라 그 손짓을 '당겨서 새로고침'으로 읽어 화면이 다시 열렸다. */
    function inPanel(t) {
      /* 뒤로가기로 숨기기만 한 창(hidden)은 떠 있는 것으로 치지 않는다 */
      var ds = document.querySelectorAll('.pk-dim, .tp-dim, #tdask'), k;
      for (k = 0; k < ds.length; k++) if (!ds[k].hidden && ds[k].getClientRects().length) return true;
      for (var n = t; n && n.nodeType === 1 && n !== document.body; n = n.parentNode) {
        if (n === scroller) break;
        if (n.getAttribute('role') === 'dialog' || n.getAttribute('aria-modal') === 'true') return true;
        var oy = '';
        try { oy = getComputedStyle(n).overflowY; } catch (eS) { oy = ''; }
        if (/(auto|scroll)/.test(oy) && n.scrollHeight > n.clientHeight + 1) return true;
      }
      return false;
    }
    document.addEventListener('touchstart', function (e) {
      startY = (scroller.scrollTop <= 0 && e.touches && e.touches.length === 1 && !inPanel(e.target)) ? e.touches[0].clientY : null;
      armed = false;
    }, { passive: true });
    document.addEventListener('touchmove', function (e) {
      if (startY === null) return;
      var dy = e.touches[0].clientY - startY;
      if (dy > 24) {
        var el = indicator();
        el.style.display = '';
        armed = dy > 80;
        el.textContent = armed ? '놓으면 새로고침돼요' : '↓ 당겨서 새로고침';
      }
    }, { passive: true });
    document.addEventListener('touchend', function () {
      if (ind) ind.style.display = 'none';
      if (armed) {
        armed = false;
        if (T.dirty) { toast('입력 중이라 새로고침하지 않았어요.\n저장한 뒤 다시 당겨 주세요.'); startY = null; return; }
        var el = indicator();
        el.textContent = '새로고침 중…';
        el.style.display = '';
        setTimeout(function () { location.reload(); }, 250);
      }
      startY = null;
    }, { passive: true });
  }
  if (PTR_PAGES[PAGE]) bindPTR();
  /* 사용자가 무언가 입력하면 '입력 중' 표시 (당겨서 새로고침 보호용) */
  document.addEventListener('input', function () { T.dirty = 1; }, true);

  /* ── 분기 ── */
  if (PAGE === '81-account-recovery.html') page81();
  else if (PAGE === '54-med-confirm.html') page54();
  else if (PAGE === '23-notif-settings.html') page23();
  else if (PAGE === '53-med-scan.html') page53();
  /* 58 사진 결과 채우기는 features.js page58 이 한다(이름·횟수·일수·약 종류) */
})();
