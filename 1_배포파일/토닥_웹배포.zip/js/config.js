/* 토닥 서버 연결 정보 — 이 값들은 앱에 심어 배포되는 공개값이다.
   (비밀은 DB 비밀번호와 secret/service_role 키, 네이버·구글 Client Secret —
    그것들은 절대 여기 넣지 않는다. 서버 함수의 Secrets 에만 둔다) */
window.TODAK_CONFIG = {
  url: 'https://mbazhywlbrsylitrqimy.supabase.co',
  anonKey: 'sb_publishable_msnZLFWnKKgxnJCDlK8AkA_rXVUOLAs',
  appVersion: '0.9.4',
  /* 간편 로그인 — 인증 요청 URL 조립에만 쓰는 공개 식별자 */
  naverClientId: 'B06x9cvQyTOV1hWyrvYy',
  kakaoJsKey: '2bd6d3ff7251d899362fdce3307df0a4',            /* 카카오맵 표시용(공개 키) */
  kakaoRestKey: '014e054af1d2e812f804a950a054247e',
  /* 공공데이터 인증키는 여기 두지 않는다 — 앱에 심으면 배포본에서 그대로 읽힌다.
     병원 목록·약 이름 조회는 모두 서버 함수(hosp-proxy)를 거치고, 키는 수파베이스 Secrets 에만 있다. */
  /* 서버 함수 주소 */
  vapidPublic: 'BAZq0-ESN0tbocjszKR9bXG-P1iTQwYeI10un2eRCBiiN89EApKA977yn0Ru3VVbQDam4t3iBZskLo37KOKP-Y4',   /* 아이폰 웹앱 알림(웹 푸시) 공개키 — 공개 가능 */
  fnBase: 'https://mbazhywlbrsylitrqimy.supabase.co/functions/v1'
};
