/* 토닥 서비스워커 — ① 웹앱 화면 캐시(2026-09-28) ② 웹앱 알림(웹 푸시) 수신.

   ① 왜 (2026-09-28 교수님): 웹앱은 화면을 옮길 때마다 0.5~1초가 걸리고 APK 는 바로 뜬다.
      화면마다 html 한 장 + css 3 + js 11~12 + 글꼴 조각을 부르는데, Netlify 는 모든 파일을
      'max-age=0, must-revalidate' 로 보내서 화면을 열 때마다 파일 15개 남짓을 서버에 '바뀌었나요?' 하고
      다시 묻는다(304 라도 한 번씩 오간다). APK 는 파일이 기기 안에 있어 묻지 않는다.
      → 앱 파일 전부를 판(VERSION)별 캐시 'todak-app-<판>' 에 미리 담아 두고, 화면 이동 때 캐시에서 바로 낸다.
      화면 이동이 기다리는 서버 요청은 0 이다. 다만 뒤에서 도는 것은 있다 — 크롬은 화면 이동마다 스스로 sw.js 를
      한 번 확인하고(304 · 화면을 막지 않음), 서비스워커가 쉬다 깨어날 때는 화면 html 을 미리 한 번 받아 두기도 한다
      (크롬의 미리 받기 · 캐시에서 내므로 쓰이지 않는다).

   이 파일(www/sw.js)은 '틀'이다. _build_web.py 가 zip 을 만들 때 아래 네 자리표
   (VERSION · PRECACHE · FONTS · HDR)에 이번 판 번호, 파일 목록·지문(sha256 앞 16자), _headers·_redirects 지문을
   채워 zip 에만 넣는다. → 배포마다 sw.js 글자가 바뀌어 휴대폰이 새 서비스워커를 받는다.
   틀 그대로(목록이 빈 채)면 예전처럼 캐시 없이 돌고, 이미 깔린 캐시는 지운다 — 비상 스위치.
   (www 폴더를 zip 없이 그대로 올리거나, 캐시를 급히 끄고 싶으면 이 틀을 올리면 된다)
   sw.js 는 배포에서 절대 빼지 않는다 — 빠지면(404) 이미 깔린 휴대폰은 새 판도 비상 스위치도 받지 못한다
   (native.js 가 두 번 연달아 그렇게 보이면 화면 캐시를 지워 풀어 주지만 그만큼 늦다).
   안드로이드 앱(APK)은 이 파일을 등록하지 않는다 — native.js 가 웹에서만 등록한다.

   새 판이 휴대폰에 보이는 때:
     새 zip 을 올린 뒤 앱(또는 탭)을 열면 → 그 첫 화면은 아직 옛 판(캐시)이다.
     화면이 뜬 뒤 새 판이 있는지 묻고(크롬은 화면 이동마다, native.js 도 화면을 열 때·앱으로 돌아올 때 1분에 한 번까지),
     있으면 뒤에서 '바뀐 파일만' 받는다. 다 받으면 곧바로 새 판이 옛 판을 넘겨받는다(skipWaiting → clients.claim)
     — 그 뒤 다음 화면 이동부터 새 판이다. 지금 보고 있는 화면은 저절로 새로고침하지 않는다(입력 중인 내용을 잃지 않게).
     받다가 실패하면 새 판으로 넘어가지 않고 옛 판이 온전한 채로 계속 낸다 — 덜 찬 캐시는 켜지지 않는다.
       - 통신이 끊겨서면: 다음 확인 때 빠진 파일만 이어서 받는다(휴대폰이 잠깐 끊겨도 3MB 를 처음부터 받지 않게).
       - 받는 사이에 또 새 배포가 올라왔으면(sw.js 가 다른 판이 됨): 받던 것을 버린다 — 두 배포 파일이 섞이지 않게.
       - 그 밖의 실패(저장 공간 부족 · 파일 하나가 계속 404·지문 다름)가 이어지면: 저장 공간 부족은 곧바로,
         나머지는 3번 넘게 · 5분 넘게 실패하면 이 판은 캐시 없이 켠다 — 예전처럼 서버에서 받아(느리지만) 새 판이 보이고,
         옛 판 캐시를 지워 자리도 비운다. 다음 배포 때 다시 캐시를 시도한다. (2026-09-28 검수: 옛 판에 끝없이 머물던 문제)

   손대지 않는 요청: GET 이 아닌 것 · 다른 주소(수파베이스 · 구글 글꼴 · 카카오 지도 · jsdelivr 등 — 로그인·데이터는
   늘 서버로 간다) · sw.js 자신 · 목록에 없는 주소(옛 29·30 주소의 301 넘김, 없는 화면 → Netlify 가 그대로 답한다).
   화면 주소의 ?from=… · #access_token=… 은 그대로 남는다 — 캐시에서 찾을 때만 뗀다(구글·카카오·네이버 로그인 복귀,
   비밀번호 재설정 81, 알림 눌러 05 열기 모두 주소 그대로 연다). */
'use strict';

var VERSION = 'a131ecb23d';
var PRECACHE = {"01-splash.html":"d76278a4f45ffb01","02-consent.html":"e2f66693072ce90c","03-profile-type.html":"ca044a316026147a","04-treatment.html":"a0f62faa086e8162","05-home.html":"418f88da6d39597d","06-sideeffects.html":"1d6b427cbac7c3b9","07-chat.html":"4f0aa0c9561f1528","08-redflag.html":"49114f5edc6a8d9f","09-food-supplement.html":"c70d5dc08ebb0185","10-consult-questions.html":"aba75a7c7ffe22b7","11-crisis.html":"b715139b77a82001","12-sources.html":"2caa607f5df02ba8","13-settings.html":"f23a03f6d68e0cbd","14-concerns.html":"34130d9b2c6ab179","15-sideeffect-detail.html":"7dba56cb185f075f","16-checkin.html":"fdb7428953bb15a3","17-selfcare-library.html":"3d0e8bbcdd465c07","19-tutorial.html":"2534ff50a5863bb1","20-notifications.html":"6c7a1937d82c1125","21-chat-history.html":"8204671d66cbbd13","22-search.html":"ceaffb0230146295","23-notif-settings.html":"89360d9158ffbd16","24-privacy-data.html":"bc1b2798acdb0b09","25-terms.html":"b6ca3859e7538e44","26-help.html":"02edf13d1b08d304","27-share.html":"7851693fd79dd321","28-note-archive.html":"aec49506b1ff3d86","31-detail-nausea.html":"1f7b2c05f2a95fd2","32-detail-hairloss.html":"99d1245a458ae338","33-detail-fatigue.html":"dc34de6589c7628d","34-detail-arthralgia.html":"3714e333eb983a0d","35-detail-hotflash.html":"e538bb00742fdee6","36-detail-mucositis.html":"001f26fae1a1d092","37-detail-myelo.html":"c92d673efda62818","38-detail-diarrhea.html":"1e801585ea9d983e","39-detail-skinrad.html":"4f15e644b0f5baf2","40-detail-lymphedema.html":"e11917d06a827a21","41-detail-cardio.html":"40f16798dd41f40c","42-detail-skintgt.html":"f77af33673ca17cd","43-detail-dryness.html":"23c9ba7070ac2e55","44-detail-bone.html":"c38119f8ee50dc99","45-detail-constipation.html":"47734a71437b34da","46-detail-sleep.html":"34a962d6dce9b5d0","47-detail-anxiety.html":"30c06a1ee4f15c03","48-emergency.html":"1bf81678b8beb635","49-detail-cognitive.html":"9f5a4ada78a394d6","50-detail-taste.html":"1f9bec9dc6db99c3","51-detail-handfoot.html":"7d1e4d45166069f4","52-detail-weight.html":"b6fa8c2a6808ea81","53-med-scan.html":"1c0508c7cb211f1f","54-med-confirm.html":"b680593ea38da418","55-med-today.html":"f68ad6e8392e8b53","56-med-schedule.html":"2362800be00c129a","57-med-missed.html":"f6c4ae95334e9a77","58-med-manual.html":"bd6c11edf7fd808a","59-med-scan-fail.html":"375a3d747dc6eec6","60-food-nausea.html":"b2b23bf1fed0d66f","61-food-appetite.html":"d79d01b1dd70e1be","62-food-mucositis.html":"965db0e45350e9d8","63-food-diarrhea.html":"6c494092be843e36","64-food-constipation.html":"07aa7a314919b561","65-food-taste.html":"b7d20a32b2bdc5b1","66-food-immune.html":"df42af682c9f9acb","67-food-bone.html":"802b941cd1e4b25b","68-food-weight.html":"213d010439e8f929","69-supplement-check.html":"0bade07efd9e118d","70-med-effects.html":"b08e53e35ef34281","71-my-drug-cautions.html":"19274e3273d5af67","72-no-info.html":"e0cc787d6368f251","73-cycle-setup.html":"379bfcd09f299478","74-med-effect-detail.html":"2373010cc8d4b89b","75-med-effect-none.html":"3c8f7fe0e040095c","77-visit-report.html":"5d162b276bc2631d","81-account-recovery.html":"9d29266c182ea9cb","82-account-exit.html":"c0f45c73ebe7809a","84-care-contacts.html":"2d65a967ef7f130a","85-nearby-clinic.html":"f6dbf5a71376d3e9","87-error-retry.html":"96e87165d6dc2a8b","88-empty-states.html":"bd94ac37d387c0d3","90-report-answer.html":"f389d5bdb9f46966","91-nearby-gate.html":"9235a8d6b7d95847","92-nearby-list.html":"043a6f8914bd8d61","93-nearby-fallback.html":"e5c2bfed171ae72d","94-food-soy.html":"c6125c6b21896c05","95-food-alcohol.html":"0bf80e1b9c5dc09d","96-email-signup.html":"b439abdce445b2f9","97-email-login.html":"d46e6361198777bc","98-checkin-month.html":"a74d9244522524fc","99-patient-verify.html":"81c168f48575b7c2","app-device.css":"247b16b298e361c2","app.css":"16f576c222eb1d71","fonts/noto.css":"27153d75d02cf72a","icon-180.png":"599ac517e45c046f","icon-192.png":"aa753eaed50140d0","icon-512.png":"98a3a4e2b8e0dafb","icon-badge-96.png":"009c398a68a533bc","img/oauth/email.svg":"a51b0899899d7396","img/oauth/google_g.png":"f5c6dd4374f36bb8","img/oauth/kakao_symbol.svg":"258ee7121b19a7fc","img/oauth/naver_icon.png":"83eeef830bee319b","img/tutorial/chat2.jpg":"e29de0710a4c69e0","img/tutorial/checkin.jpg":"ee7d980236822cb9","img/tutorial/home.jpg":"a5d857497f0db298","img/tutorial/info.jpg":"d26da6a17aa29bcb","img/tutorial/medtoday.jpg":"08efb1cf2a3194e3","img/tutorial/report.jpg":"31cac33bffccfd95","img/tutorial/scan.jpg":"c85afb49ad1b9f8b","img/tutorial/visit2.jpg":"3dcc922e42dcd745","index.html":"d76278a4f45ffb01","js/app.js":"f0d0c4b0728b8095","js/chat.js":"315f949521a4db4d","js/config.js":"c38f2b51cf94f7d0","js/druginfo.js":"d7a6df3c7ae1c227","js/features.js":"a8b4dfc2f80429b6","js/info.js":"4a5a1ee10ab2dd47","js/kb-index.js":"be3f3bfb4cfd1ab6","js/more.js":"a014ed0db6f5e5ca","js/more2.js":"4398a92b36bc77a4","js/native.js":"0a0bbe63ab3f6c7c","js/nearby.js":"ec761ead99684952","js/timepick.js":"b893855d339c75a9","js/vendor/supabase.js":"f8ce7fab799af191","js/verify.js":"23c39d2125f5539a","manifest.webmanifest":"97e284e0f0713bd2","og-image.png":"04f1d36a0304a5f2"};
var FONTS = {"fonts/0088747f25.woff2":"1275deebcaa012e5","fonts/00f9a2cda2.woff2":"62bf66342286ac18","fonts/01bdd78126.woff2":"3aa8588dae822bb0","fonts/03361587ba.woff2":"10e0676c89aad2b4","fonts/045daa2832.woff2":"e1b8280c9f5c9577","fonts/064b1c589f.woff2":"b11847c60e20c0d8","fonts/09bfc6ebb7.woff2":"a3fda4dc21493df5","fonts/0d4a4e0f0e.woff2":"b494d884301465d9","fonts/0e7f339a48.woff2":"ef69248c42aa8a28","fonts/11d3a08604.woff2":"0300f785997af852","fonts/1685ebd8ab.woff2":"0a9e68adfa8fdd67","fonts/18ea42342f.woff2":"3e18cbe399921b2d","fonts/193b68dfcc.woff2":"768b2043f9ea35fa","fonts/1aee6a1df5.woff2":"b18646a948b64ce7","fonts/1cfa3f86a9.woff2":"5e02a302c52e0b6c","fonts/1f5d6665da.woff2":"2ee54080f0b0dee4","fonts/21322efbe8.woff2":"7281418e047de1b4","fonts/240a1b333d.woff2":"4776bd32aee03549","fonts/25bdc27032.woff2":"85a68fced20fc9d0","fonts/2a1047546b.woff2":"12f2407b1bf32d20","fonts/2ac19c54c0.woff2":"750b7a008eef7a4c","fonts/2be85db840.woff2":"16279746df830f18","fonts/2ee6402417.woff2":"4924784006540380","fonts/345123a162.woff2":"4d712a27cd8ce21f","fonts/3a8083fb93.woff2":"c33e6e78802eb174","fonts/3aeceb6ca5.woff2":"4866a0a559e0dd6d","fonts/3f6896b5e6.woff2":"9bbf59f00e95996c","fonts/407230e5f3.woff2":"07033ae174480613","fonts/41af31bb5a.woff2":"efb7e8d1175cde7c","fonts/43ab48f6e4.woff2":"ae4707a72e4660e8","fonts/477b8e628a.woff2":"daa54d456acb6350","fonts/48dd44fe5e.woff2":"b4be1622a4c0a041","fonts/4949b1bc50.woff2":"e4bedfe7c5a6162d","fonts/4b6d7ebe5d.woff2":"17129da918ea2daa","fonts/4f70d85530.woff2":"be3125ba6ae56418","fonts/52701ca329.woff2":"2ccc6ff28adfdf7b","fonts/54d45cb32d.woff2":"883b6298e4e94168","fonts/54e7b6cd4c.woff2":"7de168c13cb394ee","fonts/56a8c3a01b.woff2":"af344646e3382ef0","fonts/5a8f9926a3.woff2":"9ec3df1c9a0c1df8","fonts/5b8c7bef66.woff2":"eafc6e0d06f94cb5","fonts/5cda800cce.woff2":"e58cd74f4b9f3a55","fonts/5ef511c454.woff2":"45a40cb3a43a406c","fonts/5fb448b654.woff2":"afba414987102133","fonts/5fbcf45ef7.woff2":"aa6b5671f4158c30","fonts/614d0ac890.woff2":"4171fc4ee04cbbe6","fonts/6191505698.woff2":"c5396b0c4028318c","fonts/650e4a41c0.woff2":"1ad30fe759a0e038","fonts/67c68e9682.woff2":"3861da36d0eb54b3","fonts/6d5f341016.woff2":"70045954fc344c5c","fonts/6f52a23619.woff2":"5a9c2053668f781a","fonts/7045eb22b7.woff2":"a1df305f4d0d2790","fonts/735bf8e925.woff2":"ae4408b276bb649d","fonts/7542289f01.woff2":"0bbd4e665234190c","fonts/780e556c4a.woff2":"bc4291982ecc7d4d","fonts/7e4edb2229.woff2":"7a4db36d0c8583d8","fonts/8207013a4f.woff2":"210b80ddfa82cc3a","fonts/8215c466d8.woff2":"499d65c381e42140","fonts/833a6f53fa.woff2":"c5f1266baa0787e4","fonts/87ce866d34.woff2":"9995f9e2926269d6","fonts/89ffddb1ec.woff2":"b78680de0ca4a5b8","fonts/8b8a003925.woff2":"a9c3d1e69c2b9cc8","fonts/91d3c8825d.woff2":"d0c5cb446e9e86db","fonts/9619d12222.woff2":"4f3c8bdc30a810d9","fonts/96205c4688.woff2":"38aca236039ea7b1","fonts/97dd597ff5.woff2":"2c92585b47c61f27","fonts/9a56e42c60.woff2":"be85899aca286cee","fonts/9e1c8eaaac.woff2":"8ce8dfcc2fad2a92","fonts/9f04d3f0dd.woff2":"27d60101432576d2","fonts/a0c4a75c76.woff2":"53125e3d74e595bf","fonts/a25128dc37.woff2":"9bef1f1a9e7b7d1e","fonts/a61b7d8f37.woff2":"811a7f2a0c4fff53","fonts/a66c1d6096.woff2":"70077a3b110b8717","fonts/a7a9531911.woff2":"3c8efefaf5338778","fonts/a8ef3cb13f.woff2":"bdbf18c2147f3b8d","fonts/a970b4baaa.woff2":"95045eda53125c4c","fonts/a98f78949d.woff2":"fca9004ef1d6a3a7","fonts/a998f799b7.woff2":"34698f6cb44fb932","fonts/a9fa6f8388.woff2":"91065b61043d7ef8","fonts/aa62974952.woff2":"a37f045e0387b128","fonts/ac2e2e1221.woff2":"34cbd2e2a3c7ea6a","fonts/ac425b54e1.woff2":"dd7719232de03f66","fonts/ad095cc6f0.woff2":"c22ebbb440bca97b","fonts/ad6d53cc6f.woff2":"40ee6222ed14577b","fonts/b243cc78c5.woff2":"c3510a055ae1e1c9","fonts/b493030de4.woff2":"f74032d4e8f706ec","fonts/b53632cadb.woff2":"0b424ef6881e42a7","fonts/b9041dd1ac.woff2":"297bd37fda24bc1a","fonts/b9a0a2ad4a.woff2":"a36cd66e100c3ae5","fonts/b9a546a0ff.woff2":"4ba18ec04f44f080","fonts/ba928b8ea6.woff2":"9ba79ece28902db6","fonts/baf7d4654c.woff2":"ae33c538343c38af","fonts/bbfa232122.woff2":"23abc68d31b9008e","fonts/bd3bee33c8.woff2":"fb1c55cd44f95c5f","fonts/bdfd48fa34.woff2":"aca240294e58e929","fonts/bfaa89f33d.woff2":"273bb462b5e609e2","fonts/c0de8aa59c.woff2":"72795dcd57624f52","fonts/c217f75e58.woff2":"671d9829370fc25c","fonts/c2e622adc5.woff2":"f4c76c430a1a1952","fonts/c4e8b7ab20.woff2":"771102ea71b52ec2","fonts/c6f9b48212.woff2":"d506c4def1b5075d","fonts/ce747a59e4.woff2":"8040b7ae56e8c768","fonts/d2c0b6de40.woff2":"7b4ddda196f3ce57","fonts/d7e29c897a.woff2":"d9839c7e42d7e58e","fonts/d81df88e95.woff2":"3192fb37c0097dd6","fonts/d82b2383b0.woff2":"f049e3c819f10009","fonts/d85322e526.woff2":"2a13f2490d87963d","fonts/d974f07163.woff2":"4ac45ae19e5115ff","fonts/db801485f1.woff2":"88629647b500f58e","fonts/de1e0c6150.woff2":"3da5b88ce6bbbb42","fonts/de4303273c.woff2":"bd75d5b9cef6c0e1","fonts/de98dddcf7.woff2":"aea3fb176095a6bd","fonts/dfe10b6fab.woff2":"c5c64d6ea9494ae6","fonts/e404c16930.woff2":"b60470d84be80a5e","fonts/e4a3c77b60.woff2":"4ebc089e15c07f28","fonts/e5519db209.woff2":"82dce56af57bf89a","fonts/e71ded8078.woff2":"71b97f259df4fdc4","fonts/e93a8ea8a7.woff2":"14173085eb7a70ce","fonts/ed9cc764f4.woff2":"50f05146e6524134","fonts/f1068f80be.woff2":"ba3f084ff680654c","fonts/f182653ee5.woff2":"aed822d90d953436","fonts/f3da9db590.woff2":"65c732fe80c4b022","fonts/f7ea901dd3.woff2":"c10bf867309caa3e","fonts/fb326399be.woff2":"a34b0164bc99e3cf"};
var HDR = '7499142f1fdf5172';                 /* _headers · _redirects 지문 — 머리(보안 헤더 등)가 바뀌면 옛 캐시를 옮겨 담지 않는다 */

var APP_PREFIX = 'todak-app-';           /* 판별 앱 캐시 — 새 판이 켜지면 옛 판은 지운다 */
var FONT_CACHE = 'todak-fonts';          /* 글꼴 조각 — 판이 바뀌어도 남긴다(화면이 쓰는 조각만 그때그때 담는다) */
var CACHE = APP_PREFIX + VERSION;
var BASE = new URL('./', self.location.href);        /* 앱 뿌리(= sw.js 가 있는 곳) */
var LIST_URL = new URL('__todak-precache.json', BASE).href;   /* 캐시 안 목록표 — 판 번호 + 파일별 지문 */
var FAIL_URL = new URL('__todak-fail.json', BASE).href;       /* 덜 찬 캐시 안 실패 기록 — 몇 번째 · 처음 실패한 때 */
var GIVE_UP_N = 3, GIVE_UP_MS = 5 * 60 * 1000;    /* 이만큼 실패가 이어지면(통신 끊김은 빼고) 이 판은 캐시 없이 켠다 */
var MARK = "var VERSION = '" + VERSION + "'";      /* 서버의 sw.js 가 아직 이 판인지 알아보는 글자 */
var HAS = Object.prototype.hasOwnProperty;

function keysOf(o) { var a = []; for (var k in o) if (HAS.call(o, k)) a.push(k); return a; }
var ON = !!VERSION && keysOf(PRECACHE).length > 0;    /* 틀 그대로면 false — 캐시하지 않는다 */

function abs(p) { return new URL(p, BASE).href; }
function isHtml(p) { return /\.html$/.test(p); }
/* 앱 뿌리 기준 상대 경로 ('05-home.html', 'js/app.js', '' = 뿌리). 다른 주소면 null */
function relOf(u) {
  if (u.origin !== BASE.origin || u.pathname.indexOf(BASE.pathname) !== 0) return null;
  var r = u.pathname.slice(BASE.pathname.length);
  try { r = decodeURIComponent(r); } catch (e) {}
  return r;
}
/* 화면 주소 → 담아 둔 화면 파일. Netlify 와 같게: '/' → 01-splash.html, '/05-home' → 05-home.html */
function pageOf(rel) {
  if (rel === '') rel = '01-splash.html';
  else if (rel.indexOf('/') < 0 && rel.indexOf('.') < 0) rel += '.html';
  return (isHtml(rel) && HAS.call(PRECACHE, rel)) ? rel : null;
}

function hex(buf) {
  var b = new Uint8Array(buf), s = '';
  for (var i = 0; i < b.length; i++) s += (b[i] < 16 ? '0' : '') + b[i].toString(16);
  return s;
}
/* 받은 파일이 이번 판 파일이 맞는지 — 배포가 바뀌는 순간에 받으면 옛 판·새 판 파일이 섞일 수 있다.
   WebCrypto 가 없는 브라우저면 null (검사 없이 받는다) */
function digest(buf) {
  try {
    var sub = self.crypto && self.crypto.subtle;
    if (!sub) return Promise.resolve(null);
    return Promise.resolve(sub.digest('SHA-256', buf)).then(hex, function () { return null; });
  } catch (e) { return Promise.resolve(null); }
}
/* 캐시에 넣을 응답을 새로 만든다 — 넘겨받은(redirected) 응답을 화면으로 내면 사파리가 거절하고,
   Content-Encoding · Vary 같은 전송용 머리는 캐시에서 낼 때 걸림돌이라 필요한 것만 옮긴다 */
var KEEP = ['content-type', 'x-content-type-options', 'x-frame-options', 'content-security-policy', 'referrer-policy', 'permissions-policy'];
function rebuild(res, buf) {
  var h = new Headers();
  for (var i = 0; i < KEEP.length; i++) { var v = res.headers.get(KEEP[i]); if (v) h.set(KEEP[i], v); }
  return new Response(buf, { status: 200, statusText: 'OK', headers: h });
}
function okRes(res) { return !!res && res.status === 200 && (res.type === 'basic' || res.type === 'default'); }
function jsonRes(o) { return new Response(JSON.stringify(o), { headers: { 'Content-Type': 'application/json' } }); }

/* 파일 하나를 서버에서 받는다.
   cache:'no-cache' — 브라우저 HTTP 캐시에 있으면 서버에 '바뀌었나요?'(ETag)를 꼭 묻고, 같으면 304 로 그 사본을 쓴다.
   늘 서버의 지금 파일과 같다(2026-09-28 검수: 'reload' 는 첫 화면이 방금 받은 파일까지 다시 받아 첫 설치가 두 배였다).
   priority:'low' — 쓰고 계신 화면의 요청보다 뒤로(모르는 브라우저는 무시한다).
   HTML 은 지문을 맞춰 보지 않는다: Netlify 가 HTML 마다 '<!-- This site is hosted on Netlify … -->' 주석을 끼워 넣어
   (2026-09-28 실제 배포본 확인) 파일 그대로의 지문과 늘 다르다. css·js·그림은 파일 그대로 나간다(같은 날 확인) — 맞춰 본다.
   HTML 이 다른 배포 것으로 섞이는 것은 설치 끝에 서버의 sw.js 가 아직 이 판인지 보아 막는다(liveSame).
   200 이 아니거나 다른 주소 응답(type 'basic' 아님)이면 실패로 본다. */
function fetchFresh(p, want) {
  return fetch(new Request(abs(p), { cache: 'no-cache', credentials: 'same-origin', priority: 'low' })).then(function (res) {
    if (!okRes(res)) throw new Error('precache ' + p + ' ' + (res && res.status));
    return res.arrayBuffer().then(function (buf) {
      if (isHtml(p)) return rebuild(res, buf);
      return digest(buf).then(function (d) {
        if (d && d.slice(0, want.length) !== want) throw new Error('precache ' + p + ' hash');
        return rebuild(res, buf);
      });
    });
  });
}
/* 서버의 sw.js 가 아직 이 판인가 — true 같다 · false 다른 판(받는 사이 새 배포가 올라옴, 또는 비상 스위치) · null 모름(통신) */
function liveSame() {
  return fetch(new Request(self.location.href, { cache: 'no-cache', credentials: 'same-origin' })).then(function (r) {
    if (!r || r.status !== 200) return null;
    return r.text().then(function (t) { return t.indexOf(MARK) >= 0; });
  }).then(null, function () { return null; });
}
function readList(cache) {
  return cache.match(LIST_URL).then(function (r) { return r ? r.json() : null; })
    .then(function (j) { return (j && j.files) ? j : null; }, function () { return null; });
}
function sameFiles(a, b) {
  var ka = keysOf(a);
  if (ka.length !== keysOf(b).length) return false;
  for (var i = 0; i < ka.length; i++) if (a[ka[i]] !== b[ka[i]]) return false;
  return true;
}
/* 한 번에 n 개씩 — 쓰고 계신 화면의 요청(수파베이스)을 막지 않게. 하나라도 실패하면 더 시작하지 않는다 */
function pool(items, n, fn) {
  var i = 0, failed = false, run = [];
  function next() {
    if (failed || i >= items.length) return Promise.resolve();
    var it = items[i++];
    return fn(it).then(next, function (err) { failed = true; throw err; });
  }
  for (var k = 0; k < n; k++) run.push(next());
  return Promise.all(run);
}
function named(msg, name) { var e = new Error(msg); e.name = name; return e; }

/* 설치: 이번 판 캐시를 채운다.
   지문이 같은 파일은 옛 판 캐시에서 옮겨 담고(머리 지문 HDR 도 같을 때만), 바뀐 파일만 서버에서 받는다.
   다 받은 뒤 서버의 sw.js 가 아직 이 판인지 한 번 더 보고, 목록표를 맨 마지막에 넣는다
   (목록표가 없는 캐시 = 덜 찬 캐시 — 절대 켜지지 않는다). 실패하면 설치를 실패시킨다 → 옛 판이 그대로 돈다.
   실패한 판의 덜 찬 캐시는 남겨 둔다: 다음 확인 때 같은 판이면 빠진 파일만 이어서 받는다.
   단 HTML 은 이어받지 않는다 — 지문을 못 맞춰 보므로, 받는 사이 다른 배포 것이 들어왔을 수 있다
   (다시 받아도 대개 304 · HTML 전부 합쳐 압축 190KB 남짓).
   이미 지나간 다른 판의 덜 찬 캐시는 여기서 지운다. */
function precache() {
  return caches.keys().then(function (ks) {
    var olds = ks.filter(function (n) { return n.indexOf(APP_PREFIX) === 0 && n !== CACHE; });
    return Promise.all(olds.map(function (n) {
      return caches.open(n).then(function (c) {
        return readList(c).then(function (j) {
          if (j) return { cache: c, files: j.files, hdr: j.hdr };
          return caches.delete(n).then(function () { return null; });     /* 지나간 판의 덜 찬 캐시 */
        });
      });
    }));
  }).then(function (prev) {
    prev = prev.filter(function (x) { return !!x && x.hdr === HDR; });   /* 머리가 바뀐 판의 캐시는 옮겨 담지 않는다 */
    return caches.open(CACHE).then(function (cache) {
      return readList(cache).then(function (j) {
        if (j && j.version === VERSION && sameFiles(j.files, PRECACHE)) return;   /* 같은 판이 이미 다 차 있다 */
        if (j) return caches.delete(CACHE).then(precache);                 /* 목록표가 어긋남(있을 수 없는 일) — 처음부터 */
        var stat = { reused: 0, fetched: 0, resumed: 0 };
        function fromPrev(p, i) {
          if (i >= prev.length) return Promise.resolve(null);
          if (prev[i].files[p] !== PRECACHE[p]) return fromPrev(p, i + 1);
          return prev[i].cache.match(abs(p)).then(function (r) { return r || fromPrev(p, i + 1); });
        }
        return pool(keysOf(PRECACHE), 4, function (p) {
          return cache.match(abs(p)).then(function (have) {
            if (have && !isHtml(p)) { stat.resumed++; return null; }       /* 지난번에 이 판으로 받아 둔 것(지문 확인됨) */
            return fromPrev(p, 0).then(function (r) {
              if (r) { stat.reused++; return cache.put(abs(p), r); }
              stat.fetched++;
              return fetchFresh(p, PRECACHE[p]).then(function (r2) { return cache.put(abs(p), r2); });
            });
          });
        }).then(liveSame).then(function (same) {
          /* 받는 사이 새 배포(또는 비상 스위치)가 올라왔다 → 받은 HTML 이 새 배포 것일 수 있다. 버리고 새 판을 기다린다.
             통신이 끊겨 모르면(null) 그대로 둔다 — 두 배포가 몇 초 사이에 겹치고 그 순간 끊기기까지 해야 하는 일 */
          if (same === false) throw named('precache superseded', 'Superseded');
          return cache.delete(FAIL_URL);
        }).then(function () {
          return cache.put(LIST_URL, jsonRes({ version: VERSION, hdr: HDR, files: PRECACHE,
            reused: stat.reused, fetched: stat.fetched, resumed: stat.resumed }));
        });
      });
    });
  });
}

/* 실패 기록 하나 더 — { n: 몇 번째, ms: 처음 실패한 뒤 지난 시간 }. 기록을 못 쓰면(저장 공간) reject */
function countFail() {
  return caches.open(CACHE).then(function (c) {
    return c.match(FAIL_URL).then(function (r) { return r ? r.json() : null; }).then(null, function () { return null; })
      .then(function (f) {
        var now = Date.now();
        f = (f && f.n > 0 && f.t0 <= now) ? { n: f.n + 1, t0: f.t0 } : { n: 1, t0: now };
        return c.put(FAIL_URL, jsonRes(f)).then(function () { return { n: f.n, ms: now - f.t0 }; });
      });
  });
}
/* 이 판은 캐시 없이 켠다: 덜 찬 캐시를 지우고 설치는 성공으로 끝낸다 → 새 서비스워커가 넘겨받고(켜질 때 옛 판 캐시도
   지워 자리가 빈다) 화면·파일은 서버에서 받는다(fromApp 이 캐시를 못 찾으면 서버로). 느리지만 새 판이 보인다. */
function giveUp() {
  return caches.delete(CACHE).then(function () {}, function () {});
}
function install() {
  return precache().then(null, function (err) {
    var name = err && err.name;
    function drop() { return caches.delete(CACHE).then(function () { throw err; }, function () { throw err; }); }
    if (name === 'TypeError') throw err;                   /* 통신 끊김 — 덜 찬 캐시를 두고 다음에 이어서 */
    if (name === 'Superseded') return drop();
    if (name === 'QuotaExceededError') return giveUp();    /* 저장 공간 부족 — 기다려도 나아지지 않는다 */
    return liveSame().then(function (same) {
      if (same === false) return drop();                   /* 지문 다름 등이 새 배포 때문이었다 — 받던 것을 버린다 */
      return countFail().then(function (f) {
        if (f.n >= GIVE_UP_N && f.ms >= GIVE_UP_MS) return giveUp();
        throw err;
      }, giveUp);
    });
  });
}

/* 켜질 때: 옛 판 캐시를 지운다. 글꼴 캐시는 남기되 이번 판 목록에 없거나 지문이 바뀐 조각만 뺀다.
   비상 스위치(목록이 빈 틀)면 앱 캐시·글꼴 캐시를 모두 지운다 → 예전처럼 매번 서버에서 받는다. */
function cleanup() {
  return caches.keys().then(function (ks) {
    return Promise.all(ks.map(function (n) {
      if (n.indexOf(APP_PREFIX) === 0 && (!ON || n !== CACHE)) return caches.delete(n);
      if (n === FONT_CACHE) return ON ? pruneFonts() : caches.delete(n);
      return null;
    }));
  }).catch(function () {});
}
function fontKey(rel) { return abs(rel) + '?h=' + FONTS[rel]; }
function pruneFonts() {
  return caches.open(FONT_CACHE).then(function (c) {
    return c.keys().then(function (reqs) {
      return Promise.all(reqs.map(function (rq) {
        var u = new URL(rq.url), rel = relOf(u);
        if (rel !== null && HAS.call(FONTS, rel) && rq.url === fontKey(rel)) return null;
        return c.delete(rq);
      }));
    });
  });
}

self.addEventListener('install', function (e) {
  if (!ON) { self.skipWaiting(); return; }
  e.waitUntil(install().then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(cleanup().then(function () { return self.clients.claim(); }));
});

/* 이번 판 캐시에서 찾기. 이 서비스워커는 자기 판 캐시만 본다(다른 판 파일과 섞이지 않게).
   caches.open 은 없는 캐시를 새로 만들어 버리므로 has 로 먼저 확인하고, 목록표가 있는(다 찬) 캐시만 쓴다.
   화면 이동 때마다 캐시가 아직 있는지 다시 본다 — 캐시가 지워졌으면(native.js 가 풀어 줌 · 캐시 없이 켠 판)
   그 화면부터 서버로 간다(열어 둔 캐시 손잡이는 지운 뒤에도 옛 내용을 낼 수 있어서) */
var appCacheP = null;
function openApp() {
  return caches.has(CACHE).then(function (ok) {
    if (!ok) return null;
    return caches.open(CACHE).then(function (c) {
      return c.match(LIST_URL).then(function (l) { return l ? c : null; });
    });
  }).then(null, function () { return null; });
}
function fromApp(p, isNav) {
  if (!appCacheP) appCacheP = openApp();
  var hit = appCacheP.then(function (c) { return c ? c.match(abs(p)) : null; });
  /* 화면 이동 때: 캐시가 아직 있는지(has)를 찾기와 나란히 본다 — 차례로 하면 화면마다 몇 ms 더 걸린다(2026-09-28 측정) */
  if (isNav) hit = Promise.all([hit, caches.has(CACHE).then(null, function () { return true; })]).then(function (a) {
    if (a[1]) return a[0];
    appCacheP = null;
    return null;
  });
  return hit.then(function (r) { return r || null; }, function () { return null; });
}
/* 글꼴 조각: 캐시에 있으면 바로, 없으면 서버에서 받아 담는다(이번 판 지문과 맞을 때만) */
function fromFonts(e, rel) {
  var key = fontKey(rel), want = FONTS[rel];
  return caches.open(FONT_CACHE).then(function (c) {
    return c.match(key).then(function (hit) {
      if (hit) return hit;
      return fetch(e.request).then(function (res) {
        if (okRes(res)) {
          var copy = res.clone();
          var put = copy.arrayBuffer().then(function (buf) {
            return digest(buf).then(function (d) {
              if (d && d.slice(0, want.length) !== want) return null;
              return c.put(key, rebuild(copy, buf));
            });
          }).catch(function () {});
          try { e.waitUntil(put); } catch (err) {}
        }
        return res;
      });
    });
  }, function () { return fetch(e.request); });
}

function onFetch(e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  if (req.cache === 'only-if-cached' && req.mode !== 'same-origin') return;
  var u;
  try { u = new URL(req.url); } catch (err) { return; }
  var rel = relOf(u);
  if (rel === null || rel === 'sw.js') return;          /* 다른 주소 · 서비스워커 자신은 손대지 않는다 */
  if (req.mode === 'navigate') {
    var page = pageOf(rel);
    if (!page) return;                                   /* 목록에 없는 주소 — 넘김·404 는 Netlify 가 답한다 */
    /* 캐시에 없으면(지워졌으면) 서버로 — 실패하면 브라우저의 원래 오류 화면이 뜬다 */
    e.respondWith(fromApp(page, true).then(function (r) { return r || fetch(req); }));
    return;
  }
  if (HAS.call(PRECACHE, rel)) {
    e.respondWith(fromApp(rel, false).then(function (r) { return r || fetch(req); }));
    return;
  }
  if (HAS.call(FONTS, rel)) e.respondWith(fromFonts(e, rel));
}
/* 비상 스위치 상태에서는 fetch 처리기를 아예 달지 않는다 — 예전 sw.js 와 똑같이 브라우저가 곧장 서버로 간다 */
if (ON) self.addEventListener('fetch', onFetch);

/* ② 웹 푸시 — 아래 두 처리기는 예전 sw.js 그대로다 (2026-09-28 캐시를 더하면서 한 글자도 바꾸지 않음 · 2026-10-01 tag 한 줄만 바꿈) */
self.addEventListener('push', function (e) {
  var d = {};
  try { d = e.data ? e.data.json() : {}; } catch (err) { d = { title: '토닥', body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || '토닥', {
    body: d.body || '',
    icon: 'icon-192.png',
    /* 배지 — 안드로이드 크롬 웹앱에서 상태표시줄에 뜨는 작은 그림. 크롬은 색을 버리고 알파만 읽으므로
       연분홍 바탕이 든 icon-192 를 쓰면 네모 덩어리(또는 ⓘ)로 뭉개진다. 흰 실루엣을 쓴다.
       (아이폰 사파리 웹푸시는 배지를 쓰지 않고 홈 화면 앱 아이콘을 그대로 쓴다 — 영향 없음) */
    badge: 'icon-badge-96.png',
    /* 같은 알림(같은 화면 + 같은 글)만 하나로 합친다. 예전에는 여는 화면 주소만 tag 로 써서, 같은 시각에 온
       '저녁 약 드실 시간이에요'와 '저녁에 넣으실 안약이 있어요'(둘 다 55)가 서로 덮어 하나만 남았다 (2026-10-01 새벽 검증) */
    tag: (d.url || 'todak') + '|' + String(d.body || '').slice(0, 60),
    data: { url: d.url || '/05-home.html' }
  }));
});

self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  var url = (e.notification.data && e.notification.data.url) || '/05-home.html';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
    for (var i = 0; i < list.length; i++) {
      if ('focus' in list[i]) { list[i].navigate(url); return list[i].focus(); }
    }
    return self.clients.openWindow(url);
  }));
});
